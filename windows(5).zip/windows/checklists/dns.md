# DNS Hardening Checklist (Windows Server 2012 to current)

**Run after the `first15` scripts. Scored DNS is lookup-based: never change or delete records, never block port 53 by subnet, never disable recursion on AD DNS.**

# Summary

- [ ] `dns.ps1 -AuditOnly -Detailed` run first; HIGH findings read.
- [ ] Baseline saved (`-SaveBaselineTo`) once scored lookups work, and a copy kept off the box.
- [ ] `dns.ps1 -AuditOnly`, then `dns.ps1` (low-risk fixes apply automatically, then it asks about the risky ones); scored names still resolve from another host.
- [ ] DNS debug logging on; Splunk monitors `dns*.log`.
- [ ] DnsAdmins members and `ServerLevelPluginDll` checked.
- [ ] Zone transfers reviewed against the packet (MACCDC requires them for secondary DNS).
- [ ] Client DNS servers match the packet (team DNS first; NCCDC also 10.120.0.53).
- [ ] Records compared with the baseline (`-CompareTo`) every 30 to 60 minutes.

## 1. Rules from past packets

- Scoring queries known records and checks the answer. Record tampering costs points.
- Public services must be reachable from nominally all source IPs; only single IPs may be blocked.
- MACCDC 2010, 2013 to 2016: primary DNS must allow zone transfers and inbound DNS from outside; servers forward to root hints.
- NCCDC 2025/2026: disabling DNS lookup capabilities is prohibited; hosts use team DNS first, 10.120.0.53 second.
- Older packets include Server 2003/2008 R2 DNS hosts; `dns.ps1` does not support them (use `dnscmd`).

## 2. Run order

```powershell
.\dns.ps1 -AuditOnly -Detailed
.\dns.ps1 -AuditOnly -SaveBaselineTo C:\CCDC\dns-baseline.json
.\dns.ps1 -AuditOnly
.\dns.ps1
.\dns.ps1 -CompareTo C:\CCDC\dns-baseline.json
```

The restart question (or `-RestartDns`) briefly stops DNS. Do it once, early, then re-test scored lookups.

## 3. Applied automatically

- [ ] Secure dynamic updates (AD-integrated zones). Check non-domain hosts that self-register.
- [ ] SecureResponse, cache locking 100, global query block list (wpad, isatap).
- [ ] DNS debug logging, plugin DLL removal, SIGRed `TcpReceivePacketSize` (2012 to 2019).
- [ ] LLMNR, mDNS and smart name resolution off; Dnscache running.

## 4. Asked at the end (answer no unless sure; or pass the switch)

- [ ] `-RestrictZoneTransfers -AllowZoneTransferTo <secondary IPs>` only after confirming secondaries.
- [ ] `-RemoveFromDnsAdmins <accounts>` for unauthorized members.
- [ ] `-ResponseRateLimiting LogOnly` on 2016+.
- [ ] `-EnforceDnsServers -ApprovedDnsServers <team DNS>,<10.120.0.53>` on clients.
- [ ] `-RestoreHostsFile`, `-DisableWpad` if the packet has no proxy auto-discovery.

## 5. Manual items

- [ ] Delete wildcard, rogue SRV and marshalled-name records after team confirmation.
- [ ] Zone ACL: Authenticated Users create-child is the AD default; remove only if no host must self-register.
- [ ] Multi-homed DNS: `dnscmd /ResetListenAddresses <internal ip>` if an interface faces an untrusted network.
- [ ] Secondary/stub zones: harden on the primary server.
- [ ] Not done on purpose: DNSSEC/TSIG, stopping Dnscache, patching.

## 6. Reviewing a run

Full steps and rollback are in `scripts/first15/readme.md` ("Manual review of dns.ps1 results and changes").

- [ ] Read HIGH/ERROR rows first, then CHANGES MADE, then MANUAL REVIEW.
- [ ] Note the `Recovery files:` folder (`C:\ProgramData\CCDC\DNS\...`) and copy it off the box.
- [ ] Scored names and the DC locator SRV still resolve from another host (`Resolve-DnsName`).
- [ ] Each change verified with `Get-DnsServer*` / `Get-DnsClientServerAddress`.
- [ ] Suspect records checked against the packet and confirmed with the team before any delete.
- [ ] `dns.ps1 -AuditOnly` rerun clean; new baseline saved and copied off the box.

## 7. Detection

- DNS Server event 770 and 140 (plugin DLL), 7045/4697 (service change), 5136 (directory changes).
- Debug log: bursts of AXFR/IXFR, TXT queries, very long labels.
- Rerun `-CompareTo`; any static record added or SRV change is HIGH.

## Sources

CCDC team Google Doc (CVE list), howtowinccdc packet archive (MACCDC, MWCCDC, WRCCDC, NCCDC), Microsoft KB 4569509 (SIGRed), Set-DnsServerPrimaryZone documentation, Semperis "DnsAdmins revisited".
