# MSSQL Hardening Checklist (MWCCDC Invitational #1, Oct 24 2026)

**Run after `first15` scripts. Do not modify port 1433 or scoring connectivity.**

# Summary

- [ ] Default/service credentials replaced where applicable.
- [ ] Website/database credentials updated after rotation.
- [ ] `sa` disabled unless explicitly required.
- [ ] `sysadmin` contains only authorized accounts.
- [ ] Dangerous server features disabled unless required.
- [ ] `TRUSTWORTHY` disabled where unnecessary.
- [ ] Unauthorized linked servers removed.
- [ ] Unauthorized SQL logins disabled/removed.
- [ ] Unauthorized `db_owner`/privileged memberships removed.
- [ ] SQL Browser disabled if unnecessary.
- [ ] Unauthorized SQL Agent jobs removed/disabled.
- [ ] SQL Server patched.
- [ ] Known-good database backup created and verified.
- [ ] Backup stored somewhere protected from Red Team.


## 1. Change default/service credentials

### SQL Server service accounts

Identify the accounts:

```powershell
Get-CimInstance Win32_Service |
  Where-Object {$_.Name -like 'MSSQL*' -or $_.Name -like 'SQL*'} |
  Select-Object Name, StartName, State
```

- [ ] Do not leave SQL services running as unnecessary built-in/default accounts.
- [ ] Use a dedicated service account or appropriate managed service account where supported.
- [ ] Give the account only the rights required by SQL Server.
- [ ] If changing an existing service account, update it through **SQL Server Configuration Manager**, not `services.msc`.

### SQL/application credentials

- [ ] Change any default SQL login passwords.

```
List SQL logins:

SELECT name, is_disabled FROM sys.sql_logins;

Change passwords for known/default accounts:

ALTER LOGIN [USERNAME]
WITH PASSWORD = 'NEW_STRONG_RANDOM_PASSWORD';
```

- [ ] **TELL WEB NEW CREDS!** Update the website's connection string/configuration with the new database credentials.
- [ ] Do **not** rotate a credential until every application using it has been identified.

For a website, search its configuration for the SQL connection string and update it after rotating the credential.

---

## 2. Disable `sa`

Check:

```sql
SELECT name, is_disabled
FROM sys.sql_logins
WHERE name = 'sa';
```

If enabled and not explicitly required:

```sql
ALTER LOGIN [sa] DISABLE;
```

---

## 3. Remove unauthorized `sysadmin`

List current members:

```sql
SELECT sp.name
FROM sys.server_role_members srm
JOIN sys.server_principals sp
  ON srm.member_principal_id = sp.principal_id
JOIN sys.server_principals rolep
  ON srm.role_principal_id = rolep.principal_id
WHERE rolep.name = 'sysadmin';
```

Remove unauthorized accounts:

```sql
ALTER SERVER ROLE [sysadmin] DROP MEMBER [USERNAME];
```

---

## 4. Disable dangerous server features

Check:

```sql
SELECT name, value_in_use
FROM sys.configurations
WHERE name IN (
    'xp_cmdshell',
    'Ole Automation Procedures',
    'Ad Hoc Distributed Queries',
    'clr enabled'
);
```

Disable features that are not required:

```sql
EXEC sp_configure 'show advanced options', 1;
RECONFIGURE;

EXEC sp_configure 'xp_cmdshell', 0;
EXEC sp_configure 'Ole Automation Procedures', 0;
EXEC sp_configure 'Ad Hoc Distributed Queries', 0;
EXEC sp_configure 'clr enabled', 0;

RECONFIGURE;
```

---

## 5. Disable unnecessary `TRUSTWORTHY` databases

Find them:

```sql
SELECT name
FROM sys.databases
WHERE is_trustworthy_on = 1;
```

For databases that do not explicitly require it:

```sql
ALTER DATABASE [DATABASE_NAME] SET TRUSTWORTHY OFF;
```

---

## 6. Remove unauthorized linked servers

List them:

```sql
EXEC sp_linkedservers;
```

Remove unauthorized/unused servers:

```sql
EXEC master.dbo.sp_dropserver
    @server = N'SERVER_NAME',
    @droplogins = 'droplogins';
```

---

## 7. Remove unauthorized SQL logins

List SQL logins:

```sql
SELECT name, is_disabled
FROM sys.sql_logins
ORDER BY name;
```

Disable an unauthorized login:

```sql
ALTER LOGIN [USERNAME] DISABLE;
```

Delete it if confirmed unnecessary:

```sql
DROP LOGIN [USERNAME];
```

**Do not remove the competition/scoring or website account.**

---

## 8. Remove excessive database privileges

For each important database:

```sql
USE [DATABASE_NAME];

SELECT
    member.name AS UserName,
    role.name AS RoleName
FROM sys.database_role_members drm
JOIN sys.database_principals role
  ON drm.role_principal_id = role.principal_id
JOIN sys.database_principals member
  ON drm.member_principal_id = member.principal_id
ORDER BY role.name, member.name;
```

Remove unauthorized privileged memberships:

```sql
ALTER ROLE [db_owner] DROP MEMBER [USERNAME];
```

---

## 9. Disable SQL Server Browser if unnecessary

Check:

```powershell
Get-Service SQLBrowser
```

If named-instance discovery is not required:

```powershell
Stop-Service SQLBrowser
Set-Service SQLBrowser -StartupType Disabled
```

---

## 10. Review SQL Agent jobs for command execution

List jobs:

```sql
SELECT
    j.name,
    j.enabled,
    SUSER_SNAME(j.owner_sid) AS owner
FROM msdb.dbo.sysjobs j;
```

Inspect job steps:

```sql
SELECT
    j.name,
    js.step_id,
    js.subsystem,
    js.command
FROM msdb.dbo.sysjobs j
JOIN msdb.dbo.sysjobsteps js
  ON j.job_id = js.job_id
ORDER BY j.name, js.step_id;
```

- [ ] Disable/remove unauthorized jobs.
- [ ] Pay particular attention to `CmdExec`, PowerShell, and suspicious executable/script commands.

---

## 11. Back up the database

**Do this after the database is in its known-good state. Store the backup somewhere Red Team cannot modify/delete it.**

Full backup:

```sql
BACKUP DATABASE [DATABASE_NAME]
TO DISK = 'D:\CCDC\Database_BACKUP.bak'
WITH INIT, COMPRESSION, CHECKSUM, STATS = 10;
```

Verify the backup:

```sql
RESTORE VERIFYONLY
FROM DISK = 'D:\CCDC\Database_BACKUP.bak'
WITH CHECKSUM;
```

- [ ] Copy the `.bak` to protected/off-host storage if available.
- [ ] Do not store the only backup on the same machine/database volume.
- [ ] Protect the backup from unauthorized modification.

---

## 12. Restore procedure

**Use this only when you intentionally need to roll the database back.**

First identify the backup:

```sql
RESTORE HEADERONLY
FROM DISK = 'D:\CCDC\Database_BACKUP.bak';
```

For a database that can be taken offline:

```sql
ALTER DATABASE [DATABASE_NAME]
SET SINGLE_USER WITH ROLLBACK IMMEDIATE;

RESTORE DATABASE [DATABASE_NAME]
FROM DISK = 'D:\CCDC\Database_BACKUP.bak'
WITH REPLACE, RECOVERY, CHECKSUM;

ALTER DATABASE [DATABASE_NAME]
SET MULTI_USER;
```

Then verify:

```sql
DBCC CHECKDB ([DATABASE_NAME]) WITH NO_INFOMSGS;
```

**Important:** `WITH REPLACE` overwrites the existing database. Confirm the backup and target database before executing it.

---

## 13. Patch SQL Server

Determine version:

```sql
SELECT
    SERVERPROPERTY('ProductVersion'),
    SERVERPROPERTY('ProductLevel'),
    SERVERPROPERTY('Edition');
```

- [ ] Apply the appropriate Microsoft SQL Server security updates/CU for the installed version.
- [ ] Avoid untested major-version upgrades during competition.
