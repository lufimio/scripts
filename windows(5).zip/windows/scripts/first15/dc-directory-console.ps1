# Interactive directory inspection/remediation for dc-impacket-hardening.ps1.
# Dot-sourcing defines functions only. No directory writes occur at import.
Set-StrictMode -Version Latest

function Initialize-DirectoryConsole {
    param([string]$Server, $Domain, $RootDse, [string[]]$ProtectedSids, [string]$RecoveryDirectory)
    $script:DirectoryConsole = @{
        Server=$Server; DomainDN=$Domain.DistinguishedName; DomainSID=$Domain.DomainSID.Value
        ConfigurationDN=$RootDse.ConfigurationNamingContext; SchemaDN=$RootDse.SchemaNamingContext
        ProtectedSids=@($ProtectedSids) + @('S-1-5-10','S-1-3-0',[Security.Principal.WindowsIdentity]::GetCurrent().User.Value)
        RecoveryDirectory=$RecoveryDirectory; Names=@{}; Guids=@{}; History=New-Object 'System.Collections.Generic.List[object]'
    }
    foreach ($attribute in Get-ADObject -SearchBase $RootDse.SchemaNamingContext -LDAPFilter '(schemaIDGUID=*)' -Properties lDAPDisplayName,schemaIDGUID -Server $Server) {
        $guid = New-Object Guid (,[byte[]]$attribute.schemaIDGUID)
        $script:DirectoryConsole.Guids[$guid.ToString()] = $attribute.lDAPDisplayName
    }
    foreach ($right in Get-ADObject -SearchBase ('CN=Extended-Rights,'+$RootDse.ConfigurationNamingContext) -LDAPFilter '(rightsGuid=*)' -Properties displayName,rightsGuid -Server $Server) {
        $script:DirectoryConsole.Guids[[string]$right.rightsGuid] = $right.displayName
    }
}
function ConvertTo-DirectoryLdapValue {
    param([string]$Value)
    $Value.Replace('\','\5c').Replace('*','\2a').Replace('(','\28').Replace(')','\29').Replace([string][char]0,'\00')
}
function Resolve-DirectoryObject {
    param([string]$Identity)
    if ([string]::IsNullOrWhiteSpace($Identity)) { throw 'Enter an account name, SID, GUID or distinguished name.' }
    $server = $script:DirectoryConsole.Server
    if ($Identity -match '^(?i)(CN|OU|DC)=' -or $Identity -match '^[0-9a-fA-F-]{36}$') {
        return Get-ADObject -Identity $Identity -Properties sAMAccountName,objectSid,userAccountControl -Server $server
    }
    $escaped = ConvertTo-DirectoryLdapValue $Identity
    $filter = if ($Identity -match '^S-1-') { "(objectSid=$escaped)" } else { "(|(sAMAccountName=$escaped)(name=$escaped))" }
    $objects = @(Get-ADObject -LDAPFilter $filter -Properties sAMAccountName,objectSid,userAccountControl -Server $server)
    if ($objects.Count -ne 1) { throw "Found $($objects.Count) matches. Use an exact distinguished name for ambiguous objects." }
    $objects[0]
}
function Resolve-DirectorySidName {
    param([string]$SID)
    if (-not $script:DirectoryConsole.Names.ContainsKey($SID)) {
        try {
            $securityId = New-Object Security.Principal.SecurityIdentifier($SID)
            $script:DirectoryConsole.Names[$SID] = $securityId.Translate([Security.Principal.NTAccount]).Value
        } catch { $script:DirectoryConsole.Names[$SID] = $SID }
    }
    $script:DirectoryConsole.Names[$SID]
}
function Resolve-DirectoryGuidName {
    param([string]$Guid)
    if ($Guid -eq [guid]::Empty.ToString()) { return 'All properties/rights' }
    if ($script:DirectoryConsole.Guids.ContainsKey($Guid)) { return $script:DirectoryConsole.Guids[$Guid] }
    $Guid
}
function Get-ConsoleDirectoryEntry {
    param([string]$DN)
    $entry = New-Object DirectoryServices.DirectoryEntry("LDAP://$($script:DirectoryConsole.Server)/$DN")
    $entry.psbase.AuthenticationType = [DirectoryServices.AuthenticationTypes]::Secure -bor [DirectoryServices.AuthenticationTypes]::Signing -bor [DirectoryServices.AuthenticationTypes]::Sealing
    $entry.psbase.Options.SecurityMasks = [DirectoryServices.SecurityMasks]::Dacl -bor [DirectoryServices.SecurityMasks]::Owner
    $entry
}
function Assert-DirectoryTarget {
    param([string]$DN)
    $base = $script:DirectoryConsole.DomainDN
    $domainSuffix = @(($DN -split '(?<!\\),') | Where-Object { $_ -match '^DC=' }) -join ','
    if (-not $domainSuffix.Equals($base,[StringComparison]::OrdinalIgnoreCase)) {
        throw 'Changes are limited to the connected domain. Inspect other domains in a separate session.'
    }
    if ($DN.EndsWith(','+$script:DirectoryConsole.ConfigurationDN,[StringComparison]::OrdinalIgnoreCase) -or $DN.EndsWith(','+$script:DirectoryConsole.SchemaDN,[StringComparison]::OrdinalIgnoreCase)) {
        throw 'Configuration and schema objects are inspection-only in this console.'
    }
}
function Assert-DirectoryPrincipalRemoval {
    param([string]$SID)
    if ($SID -in $script:DirectoryConsole.ProtectedSids) { throw 'Core administrator/DC/SELF/current-operator principals are protected from removal.' }
    if ($SID -match '^S-1-5-21-') {
        $escaped = ConvertTo-DirectoryLdapValue $SID
        $computers = @(Get-ADComputer -LDAPFilter "(objectSid=$escaped)" -Properties userAccountControl -Server $script:DirectoryConsole.Server)
        if (@($computers | Where-Object { [int]$_.userAccountControl -band 8192 }).Count) { throw 'Domain controller principals are protected from removal.' }
    }
}
function Get-DirectoryAttributeState {
    param([string]$DN, [string[]]$Attributes)
    $allowed = @('userAccountControl','servicePrincipalName','msDS-AllowedToDelegateTo','msDS-AllowedToActOnBehalfOfOtherIdentity','ms-DS-MachineAccountQuota','trustAttributes')
    $fields = @(foreach ($name in $Attributes | Sort-Object -Unique) {
        if ($name -notin $allowed) { throw "Unsupported editable attribute: $name" }
        $object = Get-ADObject -Identity $DN -Properties $name -Server $script:DirectoryConsole.Server
        $property = $object.PSObject.Properties[$name]
        $value = if ($null -ne $property) { $property.Value } else { $null }
        if ($name -eq 'msDS-AllowedToActOnBehalfOfOtherIdentity') {
            if ($value -is [DirectoryServices.ActiveDirectorySecurity]) { $value = $value.GetSecurityDescriptorBinaryForm() }
            $encoded = if ($null -ne $value -and @($value).Count) { [Convert]::ToBase64String([byte[]]$value) } else { '' }
            [pscustomobject][ordered]@{ Name=$name; Type='Binary'; Value=$encoded }
        } elseif ($name -in 'userAccountControl','ms-DS-MachineAccountQuota','trustAttributes') {
            [pscustomobject][ordered]@{ Name=$name; Type='Integer'; Value=[string][int]$value }
        } else {
            [pscustomobject][ordered]@{ Name=$name; Type='Strings'; Value=@($value | ForEach-Object { [string]$_ } | Sort-Object -Unique) }
        }
    })
    [pscustomobject][ordered]@{ Fields=$fields }
}
function Set-DirectoryAttributeState {
    param([string]$DN, $State)
    $replace = @{}; $clear = @()
    foreach ($field in $State.Fields) {
        switch ($field.Type) {
            'Integer' { $replace[$field.Name] = [int]$field.Value }
            'Binary' { if ($field.Value) { $replace[$field.Name] = [Convert]::FromBase64String($field.Value) } else { $clear += $field.Name } }
            'Strings' { if (@($field.Value).Count) { $replace[$field.Name] = [string[]]@($field.Value) } else { $clear += $field.Name } }
            default { throw 'Unsupported recovery field encoding.' }
        }
    }
    $arguments = @{ Identity=$DN; Server=$script:DirectoryConsole.Server }
    if ($replace.Count) { $arguments.Replace = $replace }
    if ($clear.Count) { $arguments.Clear = [string[]]$clear }
    if ($replace.Count -or $clear.Count) { Set-ADObject @arguments }
}
function ConvertTo-DirectoryStateText {
    param($State)
    ConvertTo-Json -InputObject $State -Depth 12 -Compress
}
function New-DirectoryPlan {
    param([string]$DN, [ValidateSet('Attributes','ACL','Membership')][string]$Kind, [string]$Description, $Before, $After, [string]$MemberDN='')
    Assert-DirectoryTarget $DN
    $object = Get-ADObject -Identity $DN -Server $script:DirectoryConsole.Server
    $memberGuid = if ($MemberDN) { (Get-ADObject -Identity $MemberDN -Server $script:DirectoryConsole.Server).ObjectGUID.ToString() } else { '' }
    [pscustomobject][ordered]@{
        Version=1; Server=$script:DirectoryConsole.Server; DomainDN=$script:DirectoryConsole.DomainDN
        TargetDN=$DN; ObjectGUID=$object.ObjectGUID.ToString(); Kind=$Kind; Description=$Description
        MemberDN=$MemberDN; MemberGUID=$memberGuid; Before=$Before; After=$After
    }
}
function Get-DirectoryPlanState {
    param($Plan)
    Assert-DirectoryTarget $Plan.TargetDN
    $object = Get-ADObject -Identity $Plan.TargetDN -Server $script:DirectoryConsole.Server
    if ($object.ObjectGUID.ToString() -ne $Plan.ObjectGUID) { throw 'Target identity changed. Refresh the selection.' }
    switch ($Plan.Kind) {
        'Attributes' { Get-DirectoryAttributeState $Plan.TargetDN @($Plan.Before.Fields | ForEach-Object { $_.Name }) }
        'ACL' {
            $entry = Get-ConsoleDirectoryEntry $Plan.TargetDN
            try { [pscustomobject][ordered]@{ SDDL=$entry.psbase.ObjectSecurity.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::Access) } }
            finally { $entry.psbase.Dispose() }
        }
        'Membership' {
            $member = Get-ADObject -Identity $Plan.MemberDN -Server $script:DirectoryConsole.Server
            if ($member.ObjectGUID.ToString() -ne $Plan.MemberGUID) { throw 'Member identity changed. Refresh the selection.' }
            $group = Get-ADGroup -Identity $Plan.TargetDN -Properties member -Server $script:DirectoryConsole.Server
            [pscustomobject][ordered]@{ Present=($Plan.MemberDN -in @($group.member)) }
        }
        default { throw 'Unsupported recovery operation.' }
    }
}
function Set-DirectoryPlanState {
    param($Plan, $State)
    switch ($Plan.Kind) {
        'Attributes' { Set-DirectoryAttributeState $Plan.TargetDN $State }
        'ACL' {
            $entry = Get-ConsoleDirectoryEntry $Plan.TargetDN
            try {
                $acl = $entry.psbase.ObjectSecurity
                $acl.SetSecurityDescriptorSddlForm($State.SDDL,[Security.AccessControl.AccessControlSections]::Access)
                $entry.psbase.Options.SecurityMasks = [DirectoryServices.SecurityMasks]::Dacl
                $entry.psbase.ObjectSecurity = $acl
                $entry.psbase.CommitChanges()
            } finally { $entry.psbase.Dispose() }
        }
        'Membership' {
            if ($State.Present) { Add-ADGroupMember -Identity $Plan.TargetDN -Members $Plan.MemberDN -Server $script:DirectoryConsole.Server }
            else { Remove-ADGroupMember -Identity $Plan.TargetDN -Members $Plan.MemberDN -Server $script:DirectoryConsole.Server -Confirm:$false }
        }
        default { throw 'Unsupported recovery operation.' }
    }
}
function Save-DirectoryRecovery {
    param($Plan, [string]$Status)
    $record = [pscustomobject]@{ Version=1; Status=$Status; UTC=[DateTime]::UtcNow.ToString('o'); Plan=$Plan }
    $json = ConvertTo-Json -InputObject $record -Depth 14 -Compress
    if ([string]::IsNullOrEmpty($script:DirectoryConsole.RecoveryDirectory)) { return ($json | ConvertFrom-Json) }
    $cipher = ConvertTo-SecureString -String $json -AsPlainText -Force | ConvertFrom-SecureString
    $file = Join-Path $script:DirectoryConsole.RecoveryDirectory ('directory-'+[guid]::NewGuid().ToString('N')+'.dpapi')
    [IO.File]::WriteAllText($file,$cipher)
    $file
}
function Invoke-DirectoryPlan {
    param($Plan, [switch]$Selected)
    if ($Plan.Server -ne $script:DirectoryConsole.Server -or $Plan.DomainDN -ne $script:DirectoryConsole.DomainDN) { throw 'Plan belongs to a different DC/domain.' }
    $current = Get-DirectoryPlanState $Plan
    if ((ConvertTo-DirectoryStateText $current) -ne (ConvertTo-DirectoryStateText $Plan.Before)) { throw 'Directory state changed since inspection. Refresh before changing it.' }
    if (-not $Selected) {
        Write-Host "$($Plan.Description) | $($Plan.TargetDN)" -ForegroundColor Yellow
        if ((Read-Host 'Type APPLY to proceed; Enter cancels') -cne 'APPLY') { Write-Host 'Cancelled.'; return }
    }
    # Recheck immediately before the write. This is a concurrency guard, not an AD transaction.
    if ((ConvertTo-DirectoryStateText (Get-DirectoryPlanState $Plan)) -ne (ConvertTo-DirectoryStateText $Plan.Before)) { throw 'Directory changed during confirmation. No write attempted.' }
    $pending = Save-DirectoryRecovery $Plan 'Pending'
    try {
        Set-DirectoryPlanState $Plan $Plan.After
        if ((ConvertTo-DirectoryStateText (Get-DirectoryPlanState $Plan)) -ne (ConvertTo-DirectoryStateText $Plan.After)) { throw 'Readback differs from the proposed state.' }
        $completed = Save-DirectoryRecovery $Plan 'Verified'
        $script:DirectoryConsole.History.Add($completed)
        if (Get-Command Add-Finding -ErrorAction SilentlyContinue) { Add-Finding 'Interactive change' $Plan.TargetDN 'CHANGED' $Plan.Description 'Verified. Undo is available in this session.' }
        Write-Host "DONE: $($Plan.Description)" -ForegroundColor Green
    } catch {
        $script:DirectoryConsole.History.Add($pending)
        Write-Warning 'Change failed or could be partial. Recovery state retained; refresh before retrying.'
        throw
    }
}
function Restore-DirectoryRecovery {
    param($Path, [switch]$Selected)
    if ($Path -is [string]) {
        if (-not [IO.Path]::IsPathRooted($Path) -or $Path.StartsWith('\\')) { throw 'Choose an absolute local recovery file.' }
        $cipher = [IO.File]::ReadAllText($Path) | ConvertTo-SecureString
        $credential = New-Object Management.Automation.PSCredential('recovery',$cipher)
        $record = $credential.GetNetworkCredential().Password | ConvertFrom-Json
    } else { $record = $Path }
    if ($record.Version -ne 1 -or $record.Status -ne 'Verified' -or $record.Plan.Version -ne 1) { throw 'Only verified version-1 recovery records can be restored automatically.' }
    $plan = ConvertTo-Json -InputObject $record.Plan -Depth 14 -Compress | ConvertFrom-Json
    # Revalidate editable fields and object identity even for locally encrypted records.
    $null = Get-DirectoryPlanState $plan
    $before = $plan.Before; $plan.Before = $plan.After; $plan.After = $before
    $plan.Description = 'RESTORE: '+$plan.Description
    Invoke-DirectoryPlan $plan -Selected:$Selected
}
function New-DirectoryAttributePlan {
    param([string]$DN, [string]$Attribute, $NewValue, [string]$Description, $ExpectedBefore=$null)
    $before = Get-DirectoryAttributeState $DN @($Attribute)
    if ($null -ne $ExpectedBefore -and (ConvertTo-DirectoryStateText $before) -ne (ConvertTo-DirectoryStateText $ExpectedBefore)) { throw 'Selection is stale. Refresh it.' }
    $after = ConvertTo-DirectoryStateText $before | ConvertFrom-Json
    $field = @($after.Fields)[0]
    switch ($field.Type) {
        'Strings' { $field.Value = @($NewValue | ForEach-Object { [string]$_ } | Sort-Object -Unique) }
        'Integer' { $field.Value = [string][int]$NewValue }
        'Binary' { $field.Value = [string]$NewValue }
    }
    New-DirectoryPlan $DN 'Attributes' $Description $before $after
}
function Show-DirectoryRows {
    param([object[]]$Rows, [string[]]$Columns, [string]$Name='selection')
    if (-not $Rows.Count) { Write-Host 'No matching objects.'; return }
    $display = for ($index=0; $index -lt $Rows.Count; $index++) {
        $row = [ordered]@{ Number=$index+1 }
        foreach ($column in $Columns) { $row[$column] = $Rows[$index].$column }
        [pscustomobject]$row
    }
    $script:DirectoryConsole.DisplayRows = @($display)
    for($i=0;$i -lt $Rows.Count;$i++){
        $item=$Rows[$i];$number=$i+1
        if('Kind' -in $item.PSObject.Properties.Name -and $item.Kind -eq 'ACL' -and 'Data' -in $item.PSObject.Properties.Name){
            Write-Host "`n[$number] $($item.Target)"
            Write-Host "    |__ $($item.Data.Trustee): $($item.Data.Rights)"
            if($item.Data.Property -ne 'All properties/rights'){Write-Host "    |__ $($item.Data.Property)"}
        }elseif('Trustee' -in $Columns -and 'Rights' -in $Columns){
            Write-Host "`n[$number] $($item.Target)"
            $tag=if($item.Type -ne 'Allow'){" [$($item.Type)]"}elseif($item.Inherited){' [inherited]'}else{''}
            Write-Host "    |__ $($item.Trustee): $($item.Rights)$tag"
            if('Property' -in $Columns -and $item.Property -ne 'All properties/rights'){Write-Host "    |__ $($item.Property)"}
        }elseif('Action' -in $Columns){
            Write-Host "`n[$number] $($item.Target)"
            $hint=if($item.Action -like '*selective authentication*'){' (requires Allowed-to-Authenticate grants)'}elseif($item.Action -like '*forest SID filtering*'){' (SID-history access may stop)'}else{''}
            Write-Host "    |__ $($item.Action)$hint"
        }else{
            $parts=@(foreach($column in $Columns | Where-Object {$_ -notin 'Impact','DistinguishedName','DN'}){[string]$item.$column})
            Write-Host ("[$number] "+($parts -join ' | '))
        }
    }
}
function Read-DirectorySelection {
    param([object[]]$Rows, [string]$Prompt='Select a number; Enter returns')
    if (-not $Rows.Count) { return $null }
    $view=@($script:DirectoryConsole.DisplayRows); $offset=0
    while ($true) {
        $answer = Read-Host ($Prompt+' [N/P/F text]')
        if ([string]::IsNullOrWhiteSpace($answer)) { return $null }
        $number = 0
        if ([int]::TryParse($answer,[ref]$number)) {
            if ($number -lt 1 -or $number -gt $Rows.Count) { Write-Host 'Choose a listed number.'; continue }
            return $Rows[$number-1]
        }
        switch -Regex ($answer) {
            '^(?i)N$' { if ($offset+25 -lt $view.Count) { $offset+=25 }; break }
            '^(?i)P$' { $offset=[math]::Max(0,$offset-25); break }
            '^(?i)F(?:\s+(.*))?$' {
                $term=if ($Matches.ContainsKey(1)) { [string]$Matches[1] } else { '' }; $offset=0
                $view=@($script:DirectoryConsole.DisplayRows | Where-Object { ($_ | Out-String).IndexOf($term,[StringComparison]::OrdinalIgnoreCase) -ge 0 })
                break
            }
            default { Write-Host 'Choose a number, N/P, F text, or Enter.'; continue }
        }
        $view | Select-Object -Skip $offset -First 25 | Format-Table -Wrap -AutoSize | Out-Host
        Write-Host "$($view.Count) matching rows. Numbers remain the original selection numbers."
    }
}
function Get-DirectoryAclRows {
    param([string[]]$DNs, [switch]$CandidatesOnly, [string]$TrusteeSID='', [object[]]$Objects=@())
    if(-not $Objects.Count){$Objects=@(foreach($dn in $DNs){Get-ADObject -Identity $dn -Properties adminCount,nTSecurityDescriptor -Server $script:DirectoryConsole.Server})}
    foreach ($object in $Objects) {
        $dn=$object.DistinguishedName
        $entry=$null
        try {
            $acl=$object.nTSecurityDescriptor
            if($acl -isnot [DirectoryServices.ActiveDirectorySecurity]){$entry=Get-ConsoleDirectoryEntry $dn;$acl=$entry.psbase.ObjectSecurity}
            $sddl = $acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::Access)
            $owner = $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value
            foreach ($ace in $acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])) {
                $sid = $ace.IdentityReference.Value; $rights = $ace.ActiveDirectoryRights
                if ($TrusteeSID -and $sid -ne $TrusteeSID) { continue }
                $control = ($rights -band ([DirectoryServices.ActiveDirectoryRights]::WriteDacl -bor [DirectoryServices.ActiveDirectoryRights]::WriteOwner -bor [DirectoryServices.ActiveDirectoryRights]::WriteProperty -bor [DirectoryServices.ActiveDirectoryRights]::Self -bor [DirectoryServices.ActiveDirectoryRights]::CreateChild -bor [DirectoryServices.ActiveDirectoryRights]::ExtendedRight)) -ne 0
                if ($CandidatesOnly -and ($ace.AccessControlType -ne 'Allow' -or -not $control -or $sid -in $script:DirectoryConsole.ProtectedSids -or $ace.IsInherited)) { continue }
                $sensitive = $dn -match '(?i)^CN=(Administrators|Domain Admins|Enterprise Admins|Schema Admins|AdminSDHolder|DnsAdmins|Account Operators|Backup Operators|Server Operators|Print Operators),'
                $sensitive = $sensitive -or ([int]$object.adminCount -eq 1) -or $object.ObjectClass -eq 'domainDNS'
                $property=Resolve-DirectoryGuidName $ace.ObjectType.ToString()
                $impact=Get-DirectoryPermissionImpact $ace $object $property $sensitive
                if ($CandidatesOnly -and -not $impact) { continue }
                $broad = (($rights -band [DirectoryServices.ActiveDirectoryRights]::GenericAll) -eq [DirectoryServices.ActiveDirectoryRights]::GenericAll) -or [bool]($rights -band ([DirectoryServices.ActiveDirectoryRights]::WriteDacl -bor [DirectoryServices.ActiveDirectoryRights]::WriteOwner))
                [pscustomobject]@{
                    Target=$object.Name; DN=$dn; ObjectGUID=$object.ObjectGUID.ToString(); Trustee=(Resolve-DirectorySidName $sid); SID=$sid
                    Rights=$rights.ToString(); Property=$property; Type=$ace.AccessControlType.ToString(); Impact=$impact
                    Inherited=$ace.IsInherited; Scope=$ace.InheritanceType.ToString(); InheritedClass=(Resolve-DirectoryGuidName $ace.InheritedObjectType.ToString())
                    Owner=(Resolve-DirectorySidName $owner); Priority=$(if ($sensitive -and $broad) { 'HIGH candidate' } else { 'REVIEW' })
                    ACE=$ace; SDDL=$sddl
                }
            }
        } finally { if($null -ne $entry){$entry.psbase.Dispose()} }
    }
}
function Get-DirectoryPermissionImpact {
    param($Ace,$Object,[string]$Property,[bool]$Sensitive)
    $sid=$Ace.IdentityReference.Value; $rights=$Ace.ActiveDirectoryRights; $guid=$Ace.ObjectType.ToString()
    # Suppress documented routine delegations, not arbitrary user/group RIDs.
    if ($sid -eq 'S-1-5-32-548' -and -not $Sensitive) { return '' }
    if ($sid -eq 'S-1-5-32-548' -and $Object.Name -eq 'DnsAdmins' -and [int]$Object.adminCount -ne 1) { return '' }
    if ($Property -eq 'msDS-KeyCredentialLink' -and $sid -in @("$($script:DirectoryConsole.DomainSID)-526","$($script:DirectoryConsole.DomainSID)-527")) { return '' }
    if($Object.DistinguishedName -ieq ('CN=Keys,'+$script:DirectoryConsole.DomainDN) -and $sid -in @("$($script:DirectoryConsole.DomainSID)-526","$($script:DirectoryConsole.DomainSID)-527")){return ''}
    if($sid -eq "$($script:DirectoryConsole.DomainSID)-520" -and $Object.ObjectClass -eq 'container' -and $Object.Name -in 'Policies','PolicyTemplate','PolicyType','SOM','WMIGPO','WMIPolicy' -and $Object.DistinguishedName -like ('*,CN=System,'+$script:DirectoryConsole.DomainDN) -and -not ($rights -band ([DirectoryServices.ActiveDirectoryRights]::WriteDacl -bor [DirectoryServices.ActiveDirectoryRights]::WriteOwner))){return ''}
    if($Object.Name -eq 'MicrosoftDNS' -and $Object.DistinguishedName -ieq ('CN=MicrosoftDNS,CN=System,'+$script:DirectoryConsole.DomainDN) -and (Resolve-DirectorySidName $sid) -like '*\DnsAdmins'){return ''}
    if($Object.Name -eq 'RAS and IAS Servers Access Check' -and $Object.DistinguishedName -ieq ('CN=RAS and IAS Servers Access Check,CN=System,'+$script:DirectoryConsole.DomainDN) -and (Resolve-DirectorySidName $sid) -like '*\RAS and IAS Servers'){return ''}
    if (($rights -band [DirectoryServices.ActiveDirectoryRights]::GenericAll) -eq [DirectoryServices.ActiveDirectoryRights]::GenericAll) { return 'Full control: can change membership/attributes and permissions.' }
    if ($rights -band [DirectoryServices.ActiveDirectoryRights]::WriteDacl) { return 'Can change the DACL and grant further access.' }
    if ($rights -band [DirectoryServices.ActiveDirectoryRights]::WriteOwner) { return 'Can take ownership and obtain DACL control.' }
    if ($rights -band [DirectoryServices.ActiveDirectoryRights]::WriteProperty) {
        if ($guid -eq [guid]::Empty.ToString()) { return 'Can write all writable attributes on this object.' }
        switch ($Property) {
            'member' { if ($Object.ObjectClass -eq 'group') { return 'Can change group membership.' } }
            'msDS-KeyCredentialLink' { return 'Can add authentication keys (shadow credentials).' }
            'servicePrincipalName' { return 'Can change SPNs; permits targeted Kerberoasting of user accounts.' }
            'msDS-AllowedToActOnBehalfOfOtherIdentity' { return 'Can change who may impersonate users to this resource (RBCD).' }
            'msDS-AllowedToDelegateTo' { return 'Can change constrained-delegation destinations.' }
        }
        if ($Property -in 'userAccountControl','msDS-GroupMSAMembership','msDS-ManagedAccountPrecededByLink','msDS-DelegatedMSAState','gPLink','gPCFileSysPath','sAMAccountName','User-Account-Restrictions','Account Restrictions','Group-Membership','Group Membership') { return "Can change security-sensitive property: $Property." }
    }
    if ($rights -band [DirectoryServices.ActiveDirectoryRights]::ExtendedRight) {
        if ($guid -eq [guid]::Empty.ToString()) { return 'All extended rights, including applicable password/reset or replication rights.' }
        if ($guid -eq '00299570-246d-11d0-a768-00aa006e0529') { return 'Can reset the account password.' }
        if ($Object.ObjectClass -eq 'domainDNS' -and $guid -in '1131f6aa-9c07-11d1-f79f-00c04fc2dcd2','1131f6ad-9c07-11d1-f79f-00c04fc2dcd2','89e95b76-444d-4c62-991a-0facbeda640c') { return 'Directory replication grant; review combined rights for DCSync.' }
    }
    if (($rights -band [DirectoryServices.ActiveDirectoryRights]::Self) -and $Object.ObjectClass -eq 'group' -and $guid -in @([guid]::Empty.ToString(),'bf9679c0-0de6-11d0-a285-00aa003049e2')) { return 'Can add itself to this group through validated membership writes.' }
    if (($rights -band [DirectoryServices.ActiveDirectoryRights]::CreateChild) -and $Object.ObjectClass -in 'organizationalUnit','container','domainDNS' -and $Property -in 'All properties/rights','user','computer','group','msDS-DelegatedManagedServiceAccount','msDS-GroupManagedServiceAccount') { return "Can create $Property objects here; quota zero does not remove this grant." }
    ''
}
function Get-DirectoryPermissionCandidates {
    $objects=@(Get-ADObject -LDAPFilter '(|(objectClass=domainDNS)(objectClass=organizationalUnit)(objectClass=container)(objectClass=user)(objectClass=group))' -Properties adminCount,nTSecurityDescriptor -Server $script:DirectoryConsole.Server)
    Get-DirectoryAclRows -Objects $objects -CandidatesOnly | Sort-Object Priority,Target,Trustee,Property
}
function New-DirectoryAceRemovalPlan {
    param($Row)
    if ($Row.Inherited) { throw 'Inherited ACE: inspect the granting ancestor and remove it there. This console will not disable inheritance.' }
    if ($Row.Type -ne 'Allow') { throw 'Only explicit Allow ACEs can be removed through this action.' }
    Assert-DirectoryPrincipalRemoval $Row.SID
    $entry = Get-ConsoleDirectoryEntry $Row.DN
    try {
        $acl = $entry.psbase.ObjectSecurity
        if ($acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::Access) -ne $Row.SDDL) { throw 'ACL changed since listing. Refresh it.' }
        $acl.RemoveAccessRuleSpecific($Row.ACE)
        $after = $acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::Access)
        if ($after -eq $Row.SDDL) { throw 'Selected exact ACE was not found. No write planned.' }
        $plan=New-DirectoryPlan $Row.DN 'ACL' "Remove explicit Allow $($Row.Rights) for $($Row.Trustee) [$($Row.Property)]" ([pscustomobject][ordered]@{SDDL=$Row.SDDL}) ([pscustomobject][ordered]@{SDDL=$after})
        if ($plan.ObjectGUID -ne $Row.ObjectGUID) { throw 'Object identity changed. Refresh the ACL selection.' }
        $plan
    } finally { $entry.psbase.Dispose() }
}
function Show-DirectoryAclMenu {
    $rows=@(Get-DirectoryPermissionCandidates)
    Write-Host "[+] $($rows.Count) permission grants"
    Show-DirectoryRows $rows @('Target','Trustee','Rights','Property','Impact')
    $answer=Read-DirectoryActionAnswer $rows 'Remove number(s) | I inspect object'
    if ($answer -ieq 'I') {
        $object=Resolve-DirectoryObject (Read-Host 'Object name or DN')
        $rows=@(Get-DirectoryAclRows @($object.DistinguishedName))
        Show-DirectoryRows $rows @('Target','Trustee','Rights','Property','Type','Inherited','Scope')
        $answer=Read-DirectoryActionAnswer $rows 'Remove explicit Allow number(s)'
    }
    foreach($index in ConvertTo-DirectorySelectionNumbers $answer $rows.Count) {
        $row=$rows[$index]
        try {
            # Refresh after our own previous removals, but retain identity and exact ACE.
            $fresh=@(Get-DirectoryAclRows @($row.DN) | Where-Object { (Get-DirectoryAceKey $_) -eq (Get-DirectoryAceKey $row) })
            if($fresh.Count -ne 1 -or $fresh[0].ObjectGUID -ne $row.ObjectGUID){throw 'Selected grant changed or is ambiguous. Rescan.'}
            Invoke-DirectoryPlan (New-DirectoryAceRemovalPlan $fresh[0]) -Selected
        } catch {Write-Host "FAILED: $($_.Exception.Message)" -ForegroundColor Red}
    }
}

function Get-DirectoryDelegationRows {
    $objects = @(Get-ADObject -LDAPFilter '(|(msDS-AllowedToDelegateTo=*)(msDS-AllowedToActOnBehalfOfOtherIdentity=*)(userAccountControl:1.2.840.113556.1.4.803:=524288)(userAccountControl:1.2.840.113556.1.4.803:=16777216))' -Properties sAMAccountName,userAccountControl,'msDS-AllowedToDelegateTo','msDS-AllowedToActOnBehalfOfOtherIdentity' -Server $script:DirectoryConsole.Server)
    foreach ($object in $objects) {
        $dn=$object.DistinguishedName; $uac=[int]$object.userAccountControl
        foreach ($flag in @(@{Mask=524288;Name='Unconstrained'},@{Mask=16777216;Name='Protocol transition'})) {
            if ($uac -band $flag.Mask) {
                [pscustomobject]@{Target=$object.Name;DN=$dn;Kind='Flag';Attribute='userAccountControl';Value=$flag.Mask;Detail=$flag.Name;ExpectedDC=[bool]($uac -band 8192);Before=(Get-DirectoryAttributeState $dn @('userAccountControl'))}
            }
        }
        foreach ($target in @($object.'msDS-AllowedToDelegateTo')) {
            [pscustomobject]@{Target=$object.Name;DN=$dn;Kind='Constrained';Attribute='msDS-AllowedToDelegateTo';Value=[string]$target;Detail="Constrained target: $target";ExpectedDC=$false;Before=(Get-DirectoryAttributeState $dn @('msDS-AllowedToDelegateTo'))}
        }
        $before=Get-DirectoryAttributeState $dn @('msDS-AllowedToActOnBehalfOfOtherIdentity')
        $encoded=@($before.Fields)[0].Value
        if ($encoded) {
            $descriptor=New-Object Security.AccessControl.RawSecurityDescriptor([Convert]::FromBase64String($encoded),0)
            if ($null -eq $descriptor.DiscretionaryAcl) { throw "RBCD has a null DACL on $dn; inspect this descriptor manually." }
            for ($i=0;$i -lt $descriptor.DiscretionaryAcl.Count;$i++) {
                $ace=$descriptor.DiscretionaryAcl[$i]
                [pscustomobject]@{Target=$object.Name;DN=$dn;Kind='RBCD';Attribute='msDS-AllowedToActOnBehalfOfOtherIdentity';Value=$i;Detail="RBCD: $(Resolve-DirectorySidName $ace.SecurityIdentifier.Value); $($ace.AceType); mask=$($ace.AccessMask)";SID=$ace.SecurityIdentifier.Value;AceType=$ace.AceType.ToString();ExpectedDC=$false;Before=$before}
            }
        }
    }
}
function New-DirectoryDelegationRemovalPlan {
    param($Row)
    if ($Row.ExpectedDC) { throw 'Expected DC delegation flags are protected. Select a non-DC account.' }
    $field=@($Row.Before.Fields)[0]
    switch ($Row.Kind) {
        'Flag' { $next=[int]$field.Value -band (-bnot [int]$Row.Value) }
        'Constrained' { $next=@($field.Value | Where-Object {$_ -ne $Row.Value}) }
        'RBCD' {
            if ($Row.AceType -notlike 'AccessAllowed*') { throw 'RBCD removal supports Allow ACEs only.' }
            Assert-DirectoryPrincipalRemoval $Row.SID
            $descriptor=New-Object Security.AccessControl.RawSecurityDescriptor([Convert]::FromBase64String($field.Value),0)
            $descriptor.DiscretionaryAcl.RemoveAce([int]$Row.Value)
            if ($descriptor.DiscretionaryAcl.Count -eq 0) { $next='' }
            else {
                $bytes=New-Object byte[] $descriptor.BinaryLength
                $descriptor.GetBinaryForm($bytes,0)
                $next=[Convert]::ToBase64String($bytes)
            }
        }
        default { throw 'Unsupported delegation selection.' }
    }
    New-DirectoryAttributePlan $Row.DN $Row.Attribute $next "Remove $($Row.Detail) from $($Row.Target)" $Row.Before
}
function Show-DirectoryDelegationMenu {
    $rows=@(Get-DirectoryDelegationRows | Where-Object {-not $_.ExpectedDC})
    Write-Host "[+] $($rows.Count) delegation entries (expected DC flags excluded)"
    Show-DirectoryRows $rows @('Target','Detail')
    $answer=Read-DirectoryActionAnswer $rows 'Remove delegation number(s)'
    foreach($index in ConvertTo-DirectorySelectionNumbers $answer $rows.Count){
        $row=$rows[$index]
        try {
            $fresh=@(Get-DirectoryDelegationRows | Where-Object { $_.DN -eq $row.DN -and $_.Kind -eq $row.Kind -and $_.Detail -eq $row.Detail })
            if($fresh.Count -ne 1){throw 'Selected delegation changed. Rescan.'}
            Invoke-DirectoryPlan (New-DirectoryDelegationRemovalPlan $fresh[0]) -Selected
        }catch{Write-Host "FAILED: $($_.Exception.Message)" -ForegroundColor Red}
    }
}

function Show-DirectorySpnMenu {
    $rows=@(Get-DirectorySpnRows)
    Write-Host "[+] $($rows.Count) user SPNs; removing a service SPN can break authentication"
    Show-DirectoryRows $rows @('Target','SPN')
    $answer=Read-DirectoryActionAnswer $rows 'Remove SPN number(s)'
    foreach($index in ConvertTo-DirectorySelectionNumbers $answer $rows.Count){
        $row=$rows[$index]
        $before=Get-DirectoryAttributeState $row.DN @('servicePrincipalName')
        $values=@(@($before.Fields)[0].Value)
        if($row.SPN -notin $values){Write-Host 'Already absent.';continue}
        Invoke-DirectoryPlan (New-DirectoryAttributePlan $row.DN 'servicePrincipalName' @($values | Where-Object {$_ -ne $row.SPN}) "Remove SPN $($row.SPN) from $($row.Target)" $before) -Selected
    }
}

function Show-DirectoryPreauthMenu {
    $rows=@(Get-DirectoryPreauthRows)
    Show-DirectoryRows $rows @('Target','Detail')
    $answer=Read-DirectoryActionAnswer $rows 'Require preauthentication on number(s)'
    foreach($index in ConvertTo-DirectorySelectionNumbers $answer $rows.Count){
        $row=$rows[$index]
        $before=Get-DirectoryAttributeState $row.DN @('userAccountControl')
        Invoke-DirectoryPlan (New-DirectoryAttributePlan $row.DN 'userAccountControl' ([int]@($before.Fields)[0].Value -band (-bnot 4194304)) "Require Kerberos preauthentication on $($row.Target)" $before) -Selected
    }
}

function New-DirectoryMembershipRemovalPlan {
    param([string]$GroupDN, [string]$MemberDN)
    $member=Resolve-DirectoryObject $MemberDN
    Assert-DirectoryPrincipalRemoval ([string]$member.objectSid)
    $group=Get-ADGroup -Identity $GroupDN -Properties member -Server $script:DirectoryConsole.Server
    if ($member.DistinguishedName -notin @($group.member)) { throw 'Selected account is not a direct member. Inspect the nested group that grants membership.' }
    New-DirectoryPlan $GroupDN 'Membership' "Remove direct member $($member.Name) from $($group.Name)" ([pscustomobject][ordered]@{Present=$true}) ([pscustomobject][ordered]@{Present=$false}) $member.DistinguishedName
}
function Show-DirectoryGroupMenu {
    $object=Resolve-DirectoryObject (Read-Host 'Group name or DN')
    $group=Get-ADGroup -Identity $object.DistinguishedName -Properties member -Server $script:DirectoryConsole.Server
    $rows=@(Get-ADGroupMember -Identity $group -Server $script:DirectoryConsole.Server | Select-Object Name,SamAccountName,ObjectClass,DistinguishedName)
    Show-DirectoryRows $rows @('Name','SamAccountName','ObjectClass')
    $answer=Read-DirectoryActionAnswer $rows 'Remove member number(s)'
    foreach($index in ConvertTo-DirectorySelectionNumbers $answer $rows.Count){
        try{Invoke-DirectoryPlan (New-DirectoryMembershipRemovalPlan $group.DistinguishedName $rows[$index].DistinguishedName) -Selected}
        catch{Write-Host "FAILED: $($_.Exception.Message)" -ForegroundColor Red}
    }
}

function Show-DirectoryInventoryMenu {
    Write-Host "`n1) Users  2) Computers  3) Groups  4) Protected accounts (adminCount)`n5) User SPNs  6) A user's authorization groups  7) Custom LDAP query`nEnter) Back"
    $server=$script:DirectoryConsole.Server
    switch (Read-Host 'Inventory') {
        '1' { $rows=@(Get-ADUser -Filter * -Properties adminCount -Server $server | Select-Object Name,SamAccountName,Enabled,adminCount,DistinguishedName) }
        '2' { $rows=@(Get-ADComputer -Filter * -Properties OperatingSystem,'ms-DS-CreatorSID' -Server $server | Select-Object Name,Enabled,OperatingSystem,'ms-DS-CreatorSID',DistinguishedName) }
        '3' { $rows=@(Get-ADGroup -Filter * -Server $server | Select-Object Name,SamAccountName,GroupScope,GroupCategory,DistinguishedName) }
        '4' { $rows=@(Get-ADObject -LDAPFilter '(&(objectClass=user)(adminCount=1))' -Properties sAMAccountName,userAccountControl -Server $server | Select-Object Name,sAMAccountName,userAccountControl,DistinguishedName) }
        '5' { $rows=@(Get-ADUser -LDAPFilter '(servicePrincipalName=*)' -Properties servicePrincipalName,pwdLastSet -Server $server | Select-Object Name,Enabled,@{n='SPNs';e={$_.ServicePrincipalName -join '; '}},pwdLastSet,DistinguishedName) }
        '6' {
            $object=Resolve-DirectoryObject (Read-Host 'User name or DN')
            $rows=@(Get-ADAccountAuthorizationGroup -Identity $object.DistinguishedName -Server $server | Select-Object Name,SamAccountName,SID,DistinguishedName)
        }
        '7' {
            $filter=Read-Host 'LDAP filter (read-only)'
            # A fixed non-secret projection keeps custom queries from dumping password attributes.
            $rows=@(Get-ADObject -LDAPFilter $filter -Properties sAMAccountName -Server $server | Select-Object Name,ObjectClass,sAMAccountName,DistinguishedName)
        }
        default { return }
    }
    if ($rows.Count) {
        Show-DirectoryRows $rows @($rows[0].PSObject.Properties.Name) 'inventory'
        if ($rows.Count -gt 25) {
            $selected=Read-DirectorySelection $rows 'Browse pages/filter, select a row for details, or Enter returns'
            if ($null -ne $selected) { $selected | Format-List | Out-Host }
        }
    } else { Write-Host 'No matching objects.' }
}
function Show-DirectoryInfrastructure {
    foreach($dc in Get-ADDomainController -Filter * -Server $script:DirectoryConsole.Server){Write-Host "[+] DC: $($dc.HostName) ($($dc.IPv4Address))"}
    foreach($trust in Get-DirectoryTrustAssessments){
        Write-Host "[+] $($trust.Name)"
        Write-Host "    |__ $($trust.Status)"
    }
    $rows=@(Get-DirectoryInfrastructureActions)
    Show-DirectoryRows $rows @('Target','Action','Impact')
    $answer=Read-DirectoryActionAnswer $rows 'Apply hardening number(s)'
    foreach($index in ConvertTo-DirectorySelectionNumbers $answer $rows.Count){Invoke-DirectoryPlan (New-DirectoryInfrastructurePlan $rows[$index].Plan) -Selected}
}

function Show-DirectoryCertificates {
    $server=$script:DirectoryConsole.Server; $base=$script:DirectoryConsole.ConfigurationDN
    $cas=@(Get-ADObject -SearchBase $base -LDAPFilter '(objectClass=pKIEnrollmentService)' -Properties dNSHostName,certificateTemplates -Server $server)
    Write-Host 'Enrollment services and published templates' -ForegroundColor Cyan
    $cas | Select-Object Name,dNSHostName,@{n='PublishedTemplates';e={$_.certificateTemplates -join ', '}} | Format-List | Out-Host
    $rows=@(foreach ($template in Get-ADObject -SearchBase $base -LDAPFilter '(objectClass=pKICertificateTemplate)' -Properties 'msPKI-Certificate-Name-Flag','msPKI-Enrollment-Flag','msPKI-RA-Signature',pKIExtendedKeyUsage -Server $server) {
        $nameFlags=[int]$template.'msPKI-Certificate-Name-Flag'; $enroll=[int]$template.'msPKI-Enrollment-Flag'
        [pscustomobject]@{
            Name=$template.Name; PublishedBy=(@($cas | Where-Object {$template.Name -in @($_.certificateTemplates)} | ForEach-Object {$_.Name}) -join ', ')
            SubjectSupplied=[bool]($nameFlags -band 1); Approval=[bool]($enroll -band 2); Signatures=[int]$template.'msPKI-RA-Signature'
            NameFlags=$nameFlags; EnrollmentFlags=$enroll; EKUs=(@($template.pKIExtendedKeyUsage | ForEach-Object {try {(New-Object Security.Cryptography.Oid($_)).FriendlyName+' ['+$_+']'} catch {[string]$_}}) -join '; ')
        }
    })
    Show-DirectoryRows $rows @('Name','PublishedBy','SubjectSupplied','Approval','Signatures','NameFlags','EnrollmentFlags','EKUs') 'certificate-templates'
    if ($rows.Count -gt 25) {
        $selected=Read-DirectorySelection $rows 'Browse templates/filter, select details, or Enter returns'
        if ($null -ne $selected) { $selected | Format-List | Out-Host }
    }
    Write-Host 'Certificate configuration is inspection-only here. Enrollment ACLs, CA enforcement and remote endpoints need separate assessment.'
}
function Start-DirectoryConsole {
    Write-Host '[+] Directory console | changes selected by number | undo: 9'
    while ($true) {
        Write-Host "`nDIRECTORY CONSOLE | $($script:DirectoryConsole.Server)" -ForegroundColor Cyan
        Write-Host '[A] Audit  [1] Browse  [2] Delegation  [3] Permissions  [4] SPNs'
        Write-Host '[5] AS-REP [6] Groups  [7] Trusts      [8] Certificates [9] Undo [0] Exit'
        $choice=Read-Host 'Choose'
        try {
            switch($choice){
                'A' {Show-DirectoryFullAudit}
                '1' {Show-DirectoryInventoryMenu}
                '2' {Show-DirectoryDelegationMenu}
                '3' {Show-DirectoryAclMenu}
                '4' {Show-DirectorySpnMenu}
                '5' {Show-DirectoryPreauthMenu}
                '6' {Show-DirectoryGroupMenu}
                '7' {Show-DirectoryInfrastructure}
                '8' {Show-DirectoryCertificates}
                '9' {Show-DirectoryUndoMenu}
                '0' {return}
                '' {return}
                default {Write-Host 'Choose a listed option.'}
            }
        }catch{
            Write-Host "FAILED: $($_.Exception.Message)" -ForegroundColor Red
            if(Get-Command Add-Finding -ErrorAction SilentlyContinue){Add-Finding 'Interactive operation' $script:DirectoryConsole.Server 'ERROR' $_.Exception.Message 'Refresh before retrying.'}
        }
    }
}

function ConvertTo-DirectorySelectionNumbers {
    param([string]$Answer,[int]$Count)
    if([string]::IsNullOrWhiteSpace($Answer)){return}
    $selected=New-Object 'System.Collections.Generic.SortedSet[int]'
    foreach($part in $Answer -split '[,\s]+'){
        if($part -notmatch '^(\d+)(?:-(\d+))?$'){throw 'Use numbers such as 1,3 or 2-5.'}
        $first=[int]$Matches[1];$last=if($Matches.ContainsKey(2) -and $Matches[2]){[int]$Matches[2]}else{$first}
        if($first -lt 1 -or $last -gt $Count -or $first -gt $last){throw 'Selection outside the displayed list. Nothing selected.'}
        for($n=$first;$n -le $last;$n++){$null=$selected.Add($n-1)}
    }
    foreach($number in $selected){$number}
}
function Get-DirectoryAceKey {
    param($Row)
    $ace=$Row.ACE
    "$($Row.DN)|$($Row.SID)|$($ace.ActiveDirectoryRights)|$($ace.AccessControlType)|$($ace.ObjectType)|$($ace.InheritedObjectType)|$($ace.InheritanceFlags)|$($ace.PropagationFlags)|$($ace.IsInherited)"
}
function Get-DirectorySpnRows {
    foreach($user in Get-ADUser -LDAPFilter '(&(servicePrincipalName=*)(!(sAMAccountName=krbtgt*)))' -Properties servicePrincipalName -Server $script:DirectoryConsole.Server){
        if($user.SID.Value -like '*-502'){continue}
        foreach($spn in $user.ServicePrincipalName){[pscustomobject]@{Target=$user.Name;DN=$user.DistinguishedName;SPN=[string]$spn}}
    }
}
function Get-DirectoryPreauthRows {
    foreach($account in Get-ADObject -LDAPFilter '(userAccountControl:1.2.840.113556.1.4.803:=4194304)' -Properties sAMAccountName -Server $script:DirectoryConsole.Server){
        [pscustomobject]@{Target=$account.Name;DN=$account.DistinguishedName;Detail='Kerberos preauthentication disabled; can permit AS-REP roasting.'}
    }
}
function Get-DirectoryTrustAssessments {
    foreach($trust in Get-ADObject -LDAPFilter '(objectClass=trustedDomain)' -Properties trustAttributes,trustDirection,trustPartner -Server $script:DirectoryConsole.Server){
        $flags=[int]$trust.trustAttributes;$sameForest=[bool]($flags -band 32);$forestTrust=[bool]($flags -band 8)
        $direction=switch([int]$trust.trustDirection){3{'two-way'};2{'outbound'};1{'inbound'};default{'disabled'}}
        if($sameForest){
            $status='EXPECTED';$summary='Same-forest domain trust.'
            $explanation="$direction authentication path within this forest. ForestTransitive=False means this is not a forest-to-forest trust. Selective authentication/quarantine are not blanket fixes for a child-domain trust. Domains in a forest are not separate security boundaries."
        }elseif($forestTrust){
            $status=if($flags -band 64){'REVIEW: relaxed SID filtering'}else{'Forest SID filtering active'}
            $summary='Trust to another forest.'
            $explanation="$direction authentication path. Resource permissions still apply. "
            if($flags -band 64){$explanation+='TREAT_AS_EXTERNAL (0x40) is set: forest SID filtering is relaxed for SID-history compatibility. Review migration/PIM requirements before restoring stricter filtering. '}
            else{$explanation+='Normal forest SID-filtering rules are selected. '}
            $explanation+=if($flags -band 16){'Selective authentication is enabled: remote identities need Allowed to Authenticate grants.'}else{'Selective authentication is off: the trust does not require per-computer Allowed to Authenticate grants; resource ACLs still apply.'}
        }else{
            $status=if($flags -band 4){'External SID quarantine active'}else{'REVIEW: external SID quarantine off'}
            $summary='External/domain trust.';$explanation="$direction authentication path. Quarantine limits accepted SIDs to the directly trusted domain; it is not a setting to copy onto parent/child trusts."
        }
        [pscustomobject]@{Name=$trust.Name;DN=$trust.DistinguishedName;Flags=$flags;Direction=[int]$trust.trustDirection;SameForest=$sameForest;ForestTrust=$forestTrust;Status=$status;Summary=$summary;Explanation=$explanation}
    }
}
function Get-DirectoryInfrastructureActions {
    $dn=$script:DirectoryConsole.DomainDN
    $before=Get-DirectoryAttributeState $dn @('ms-DS-MachineAccountQuota')
    $quota=[int]@($before.Fields)[0].Value
    if($quota -gt 0){
        [pscustomobject]@{Target='Domain machine creation';Action="Set MachineAccountQuota $quota -> 0";Impact='Stops ordinary users creating machines through the quota. Explicit delegated creation rights remain.';Plan=(New-DirectoryAttributePlan $dn 'ms-DS-MachineAccountQuota' 0 'Set MachineAccountQuota to zero' $before)}
    }
    foreach($trust in Get-DirectoryTrustAssessments){
        if($trust.SameForest){continue}
        $before=Get-DirectoryAttributeState $trust.DN @('trustAttributes')
        if($trust.ForestTrust -and ($trust.Flags -band 64) -and -not ($trust.Flags -band 1024)){
            [pscustomobject]@{Target=$trust.Name;Action='Restore normal forest SID filtering';Impact='Disables relaxed SID-history compatibility; migrated SID-history access may stop working.';Plan=(New-DirectoryAttributePlan $trust.DN 'trustAttributes' ($trust.Flags -band (-bnot 64)) "Restore normal forest SID filtering on $($trust.Name)" $before)}
        }
        if(-not $trust.ForestTrust -and -not ($trust.Flags -band 4)){
            [pscustomobject]@{Target=$trust.Name;Action='Enable external-domain SID quarantine';Impact='Rejects SIDs outside the directly trusted domain; may affect SID-history migration access.';Plan=(New-DirectoryAttributePlan $trust.DN 'trustAttributes' ($trust.Flags -bor 4) "Enable external SID quarantine on $($trust.Name)" $before)}
        }
        if(($trust.Direction -band 2) -and -not ($trust.Flags -band 16)){
            [pscustomobject]@{Target=$trust.Name;Action='Enable selective authentication';Impact='Remote users will need explicit Allowed to Authenticate grants on destination computers; existing cross-trust logons may stop.';Plan=(New-DirectoryAttributePlan $trust.DN 'trustAttributes' ($trust.Flags -bor 16) "Enable selective authentication on $($trust.Name)" $before)}
        }
    }
}
function Get-DirectoryIntegerActionValue {
    param([string]$Attribute,[int]$Before,[int]$After,[int]$Current)
    if($Attribute -ne 'trustAttributes'){return $After}
    if($Current -band 32){throw 'Trust is now within the same forest. Rescan; no child-trust hardening applied.'}
    if(($Before -band 64) -and -not ($After -band 64) -and ($Current -band 1024)){throw 'PIM trust requires separate review before changing SID filtering.'}
    # Change only the selected flags, preserving unrelated/new bits and earlier fixes.
    ($Current -band (-bnot ($Before -band (-bnot $After)))) -bor ($After -band (-bnot $Before))
}
function New-DirectoryInfrastructurePlan {
    param($Original)
    $field=@($Original.Before.Fields)[0]
    $before=Get-DirectoryAttributeState $Original.TargetDN @($field.Name)
    $next=Get-DirectoryIntegerActionValue $field.Name ([int]$field.Value) ([int]@($Original.After.Fields)[0].Value) ([int]@($before.Fields)[0].Value)
    $plan=New-DirectoryAttributePlan $Original.TargetDN $field.Name $next $Original.Description $before
    if($plan.ObjectGUID -ne $Original.ObjectGUID){throw 'Trust/domain object identity changed. Rescan.'}
    $plan
}
function Show-DirectoryUndoMenu {
    $rows=@(for($i=0;$i -lt $script:DirectoryConsole.History.Count;$i++){
        $record=$script:DirectoryConsole.History[$i]
        if($record -is [string]){[pscustomobject]@{Change=$record;State='Saved recovery file';Record=$record}}
        else{[pscustomobject]@{Change=$record.Plan.Description;State=$record.Status;Record=$record}}
    })
    Show-DirectoryRows $rows @('Change','State')
    $answer=Read-Host 'Undo change number; F loads an explicit recovery file; Enter returns'
    if($answer -ieq 'F'){
        $path=Read-Host 'Recovery file path'
        Restore-DirectoryRecovery $path -Selected
        return
    }
    foreach($index in ConvertTo-DirectorySelectionNumbers $answer $rows.Count){Restore-DirectoryRecovery $rows[$index].Record -Selected}
}
function Get-DirectoryAuditActions {
    foreach($row in Get-DirectoryPermissionCandidates){
        [pscustomobject]@{Target=$row.Target;Action="Remove $($row.Trustee): $($row.Rights) [$($row.Property)]";Impact=$row.Impact;Kind='ACL';Data=$row}
    }
    foreach($row in Get-DirectoryDelegationRows | Where-Object {-not $_.ExpectedDC}){
        [pscustomobject]@{Target=$row.Target;Action="Remove $($row.Detail)";Impact='Stops the selected delegation path; check service dependencies.';Kind='Delegation';Data=$row}
    }
    foreach($row in Get-DirectoryPreauthRows){
        [pscustomobject]@{Target=$row.Target;Action='Require Kerberos preauthentication';Impact=$row.Detail;Kind='Preauth';Data=$row}
    }
    foreach($row in Get-DirectorySpnRows){
        [pscustomobject]@{Target=$row.Target;Action="Remove SPN $($row.SPN)";Impact='User SPN can be Kerberoasted; removing legitimate service SPNs breaks authentication.';Kind='SPN';Data=$row}
    }
    foreach($row in Get-DirectoryInfrastructureActions){
        [pscustomobject]@{Target=$row.Target;Action=$row.Action;Impact=$row.Impact;Kind='Infrastructure';Data=$row}
    }
}
function Show-DirectoryFullAudit {
    $path=Join-Path $PSScriptRoot 'dc-impacket-hardening.ps1'
    $findings=@(& $path -PassThru 6>$null 3>$null | Where-Object {$null -ne $_.PSObject.Properties['Risk']})
    Show-AuditReport -Findings $findings -ActionListFollows
    $rows=@(Get-DirectoryAuditActions)
    Show-DirectoryRows $rows @('Target','Action','Impact')
    while($true){
        $answer=Read-Host 'Fix number(s) | D audit details | D <number> finding details | Enter back'
        if($answer -ieq 'D'){
            Show-AuditReport -Findings $findings -Expand
            foreach($trust in Get-DirectoryTrustAssessments){Write-Host "[+] $($trust.Name)`n    |__ $($trust.Explanation)"}
        }elseif($answer -match '^(?i)D\s+(\d+)$'){
            Show-DirectoryRowDetails $rows ([int]$Matches[1])
        }else{break}
    }
    foreach($index in ConvertTo-DirectorySelectionNumbers $answer $rows.Count){
        $action=$rows[$index];$row=$action.Data
        try{
            switch($action.Kind){
                'ACL'{
                    $fresh=@(Get-DirectoryAclRows @($row.DN) | Where-Object {(Get-DirectoryAceKey $_) -eq (Get-DirectoryAceKey $row)})
                    if($fresh.Count -ne 1 -or $fresh[0].ObjectGUID -ne $row.ObjectGUID){throw 'ACL selection changed. Rescan.'}
                    $plan=New-DirectoryAceRemovalPlan $fresh[0]
                }
                'Delegation'{
                    $fresh=@(Get-DirectoryDelegationRows | Where-Object {$_.DN -eq $row.DN -and $_.Kind -eq $row.Kind -and $_.Detail -eq $row.Detail})
                    if($fresh.Count -ne 1){throw 'Delegation selection changed. Rescan.'}
                    $plan=New-DirectoryDelegationRemovalPlan $fresh[0]
                }
                'Preauth'{
                    $before=Get-DirectoryAttributeState $row.DN @('userAccountControl')
                    $plan=New-DirectoryAttributePlan $row.DN 'userAccountControl' ([int]@($before.Fields)[0].Value -band (-bnot 4194304)) "Require preauthentication on $($row.Target)" $before
                }
                'SPN'{
                    $before=Get-DirectoryAttributeState $row.DN @('servicePrincipalName')
                    $values=@(@($before.Fields)[0].Value)
                    if($row.SPN -notin $values){throw 'SPN already absent.'}
                    $plan=New-DirectoryAttributePlan $row.DN 'servicePrincipalName' @($values | Where-Object {$_ -ne $row.SPN}) "Remove SPN $($row.SPN) from $($row.Target)" $before
                }
                'Infrastructure'{
                    $plan=New-DirectoryInfrastructurePlan $row.Plan
                }
            }
            Invoke-DirectoryPlan $plan -Selected
        }catch{Write-Host "FAILED: $($_.Exception.Message)" -ForegroundColor Red}
    }
}

function Show-DirectoryRowDetails {
    param([object[]]$Rows,[int]$Number)
    if($Number -lt 1 -or $Number -gt $Rows.Count){Write-Host '[!] Unknown number';return}
    $row=$Rows[$Number-1]
    Write-Host "[+] Details: $Number"
    foreach($name in 'Target','Action','Trustee','SID','Rights','Property','Type','Inherited','Scope','Owner','Detail','SPN','DN','DistinguishedName','Impact'){
        $p=$row.PSObject.Properties[$name]
        if($null -ne $p -and $null -ne $p.Value -and [string]$p.Value -ne ''){Write-Host "    |__ $name`: $($p.Value)"}
    }
    $data=$row.PSObject.Properties['Data']
    if($null -ne $data -and $null -ne $data.Value){
        foreach($name in 'Trustee','Rights','Property','Scope','DN'){
            $p=$data.Value.PSObject.Properties[$name]
            if($null -ne $p -and $null -ne $p.Value){Write-Host "    |__ $name`: $($p.Value)"}
        }
    }
}
function Read-DirectoryActionAnswer {
    param([object[]]$Rows,[string]$Prompt)
    while($true){
        $answer=Read-Host ($Prompt+' | D <number> details | Enter back')
        if($answer -match '^(?i)D\s+(\d+)$'){Show-DirectoryRowDetails $Rows ([int]$Matches[1])}
        else{return $answer}
    }
}
