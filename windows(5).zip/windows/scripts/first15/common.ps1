# Shared console feedback. Keep this file beside the first15 scripts.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:ToolFailures = New-Object 'System.Collections.Generic.List[object]'
$script:ToolCompleted = 0
$script:ToolQuiet = $false
$script:ToolReportedIssues = @{}

function Write-ToolStatus {
    param([string]$Message, [string]$State = 'INFO')
    if ($script:ToolQuiet) {
        if ($State -notin 'FAIL','WARN','ALERT') { return }
        if ($State -ne 'ALERT') {
            $key = $State + '|' + $Message
            if ($script:ToolReportedIssues.ContainsKey($key)) { return }
            $script:ToolReportedIssues[$key] = $true
        }
    }
    $color = switch ($State) { 'FAIL' { 'Red' }; 'RUN' { 'Cyan' }; 'WARN' { 'Yellow' }; 'OK' { 'Green' }; default { 'Gray' } }
    Write-Host ('[{0:HH:mm:ss}] [{1}] {2}' -f (Get-Date), $State, $Message) -ForegroundColor $color
}

function Add-ToolFailure {
    param([string]$Step, [System.Management.Automation.ErrorRecord]$Failure)
    $script:ToolFailures.Add([pscustomobject]@{ Step = $Step; Error = $Failure.Exception.Message })
    Write-ToolStatus "$Step -- $($Failure.Exception.Message). Continuing." 'FAIL'
}

function Invoke-ToolStep {
    param([string]$ToolStepLabel, [scriptblock]$ToolActionBody)
    Write-ToolStatus $ToolStepLabel 'RUN'
    $ToolFailuresBefore = $script:ToolFailures.Count
    try {
        # Dot-source this helper AND the action when later steps need variables it sets.
        . $ToolActionBody
        if ($script:ToolFailures.Count -gt $ToolFailuresBefore) {
            Write-ToolStatus "$ToolStepLabel -- finished with reported failures" 'WARN'
        } else {
            $script:ToolCompleted++
            Write-ToolStatus "$ToolStepLabel -- finished" 'OK'
        }
    } catch { Add-ToolFailure $ToolStepLabel $_ }
}

function Show-ToolSummary {
    Write-Host ''
    Write-ToolStatus "Finished: $script:ToolCompleted steps completed; $($script:ToolFailures.Count) failed."
    if ($script:ToolFailures.Count) {
        $script:ToolFailures | Format-Table Step, Error -Wrap -AutoSize | Out-Host
        Write-Warning 'Some work failed or only partly applied. Review the failures above.'
    }
}
