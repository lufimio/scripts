#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [ValidateSet('Block', 'Audit')][string]$ASRMode = 'Block',
    [switch]$SkipASR,
    [switch]$KeepPrinting,
    [switch]$KeepRemoteRegistry,
    [string[]]$SmtpRelayIPv4 = @('127.0.0.1'),
    [string[]]$UpdatePackage = @(),
    [switch]$ScanUpdates,
    [switch]$DisableDomainGpos = $true,
    [switch]$KeepDomainGpos,
    [switch]$KeepWinRM,
    [switch]$AllowRdpDriveRedirection,
    [switch]$KeepCachedLogons,
    [switch]$KeepSavedCredentials,
    [switch]$KeepDefenderExclusions,
    [switch]$SkipSmbEncryption,
    [switch]$SkipTlsHardening,
    [switch]$SkipDnsHardening,
    [switch]$SkipDirectoryAuditing,
    [switch]$EnableLsaProtection,
    [switch]$EnableRestrictedAdmin,
    [switch]$RequireSignedElevation,
    [switch]$RequireAdminCredentials,
    [switch]$RequireKerberosAES,
    [switch]$DisableIPv6,
    [switch]$DisableDcom,
    [switch]$DisableAdminShares,
    [switch]$DisableRemoteRpc,
    [switch]$EnableBootMitigations,
    [switch]$ResetLocalPolicy,
    [switch]$ResetDefaultDomainGpos,
    [switch]$ResetNtdsAcl,
    [switch]$ResetScmAcl,
    [switch]$RestoreHiveInheritance,
    [switch]$EnableDefenderSandbox,
    [switch]$RemoveAccessibilityBinaries,
    [switch]$DeleteShadowCopies = $true,
    [switch]$KeepShadowCopies,
    [string]$ExploitProtectionPolicy,
    [string]$BackupDirectory = (Join-Path $PSScriptRoot ('hardening-backups-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))),
    [string]$GpoBackupDirectory = (Join-Path $PSScriptRoot ('gpo-backups-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))),
    [switch]$KeepLocalAdminRemoting
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'common.ps1')
function Set-RegistryValue {
    [CmdletBinding()]
    param(
        [string]$Path,
        [string]$Name,
        [object]$Value,
        [ValidateSet('DWord', 'String', 'MultiString')][string]$Type = 'DWord'
    )

    Invoke-ToolStep "Registry $Path\$Name = $Value" {
        if (-not (Test-Path -LiteralPath $Path)) { $null = New-Item -Path $Path -Force }
        $null = New-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -PropertyType $Type -Force
    }
}

function Remove-RootScheduledTasks {
    [CmdletBinding()]
    param()

    # The Task Scheduler Library root only. No subfolders and no task exports.
    try { $tasks = @(Get-ScheduledTask -TaskPath '\' -ErrorAction Stop | Where-Object { $_.TaskPath -eq '\' }) }
    catch {
        if ($_.FullyQualifiedErrorId -like 'CmdletizationQuery_NotFound*' -and $_.CategoryInfo.Category -eq 'ObjectNotFound') { $tasks = @() }
        else { throw }
    }
    $removed = 0
    foreach ($task in $tasks) {
        $name = $task.TaskPath + $task.TaskName
        try {
            Write-ToolStatus "Delete root task: $name" 'RUN'
            Unregister-ScheduledTask -TaskName $task.TaskName -TaskPath $task.TaskPath -Confirm:$false -ErrorAction Stop
            $removed++
            Write-ToolStatus "Deleted root task: $name" 'OK'
        } catch { Add-ToolFailure "Delete root task $name" $_ }
    }
    Write-Host "Root tasks deleted: $removed of $($tasks.Count). Subfolder tasks were retained. No task backups were created."
}

function Update-LocalGroupPolicy {
    [CmdletBinding()]
    param()

    & "$env:windir\System32\gpupdate.exe" /force /wait:30
    if ($LASTEXITCODE -ne 0) { throw "gpupdate failed with exit code $LASTEXITCODE. Review the policy processing errors." }
}

function Set-SmtpHardening {
    [CmdletBinding()]
    param([string[]]$RelayIPv4 = @('127.0.0.1'))

    if (-not (Get-Service -Name SMTPSVC -ErrorAction SilentlyContinue)) { return }
    foreach ($address in $RelayIPv4) {
        $ip = $null
        if (-not [Net.IPAddress]::TryParse($address, [ref]$ip) -or
            $ip.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork -or
            $address -in '0.0.0.0', '255.255.255.255') {
            throw "SMTP relay entries must be individual IPv4 addresses: $address"
        }
    }
    $root = [ADSI]'IIS://localhost/SMTPSVC'
    $servers = @($root.psbase.Children | Where-Object { $_.SchemaClassName -eq 'IIsSmtpServer' })
    if (-not $servers.Count) { throw 'SMTP is installed but no virtual servers were found in the IIS metabase.' }
    foreach ($server in $servers) {
        $relay = $server.psbase.InvokeGet('IPSecurity')
        $type = $relay.GetType()
        $set = [Reflection.BindingFlags]::SetProperty
        $null = $type.InvokeMember('GrantByDefault', $set, $null, $relay, @($false))
        # COM expects one argument containing a SAFEARRAY, including when empty.
        $argument = New-Object object[] 1
        $argument[0] = [object[]]@($RelayIPv4 | ForEach-Object { "$_,255.255.255.255" })
        $null = $type.InvokeMember('IPGrant', $set, $null, $relay, $argument)
        $argument[0] = [object[]]@()
        foreach ($name in 'IPDeny', 'DomainGrant', 'DomainDeny') {
            $null = $type.InvokeMember($name, $set, $null, $relay, $argument)
        }
        $server.psbase.InvokeSet('RelayIpList', $relay)
        $server.psbase.InvokeSet('RelayForAuth', 0)
        # Incoming server-to-server mail remains anonymous; relay is controlled by IP.
        $server.psbase.InvokeSet('AuthFlags', 1)
        $server.psbase.InvokeSet('LogType', 1)
        $server.psbase.CommitChanges()
        foreach ($container in $server.psbase.Children) {
            if ($container.Name -ne 'Domain') { continue }
            foreach ($domain in $container.psbase.Children) {
                $domain.psbase.InvokeSet('RelayIpList', $relay)
                $domain.psbase.InvokeSet('RelayForAuth', 0)
                $domain.psbase.CommitChanges()
            }
        }
        Write-Host "SMTP $($server.Name): relay allowed only from $($RelayIPv4 -join ', '); SMTP AUTH disabled; logging enabled."
    }
    Set-Service -Name SMTPSVC -StartupType Automatic
    Restart-Service -Name SMTPSVC -Force
}

function Set-TimeHardening {
    [CmdletBinding()]
    param()

    if (-not (Get-Service -Name W32Time -ErrorAction SilentlyContinue)) { return }
    $path = 'HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config'
    foreach ($name in 'MaxPosPhaseCorrection', 'MaxNegPhaseCorrection') {
        $current = Get-ItemPropertyValue -LiteralPath $path -Name $name
        if ([long]$current -lt 0 -or [long]$current -gt 3600) {
            Set-RegistryValue $path $name 3600
        }
    }
    Set-RegistryValue $path 'EventLogFlags' 3
    Set-RegistryValue $path 'TimeJumpAuditOffset' 300
    Set-Service -Name W32Time -StartupType Automatic
    Start-Service -Name W32Time
    & "$env:windir\System32\w32tm.exe" /config /update
    if ($LASTEXITCODE -ne 0) { throw "Windows Time configuration reload failed: $LASTEXITCODE" }
    $source = & "$env:windir\System32\w32tm.exe" /query /source
    if ($LASTEXITCODE -ne 0) { throw "Windows Time source query failed: $LASTEXITCODE" }
    Write-Host "Windows Time: corrections capped at one hour; source: $source"
    if ($source -match 'Local CMOS Clock|Free-running System Clock') {
        Write-Warning 'Windows Time has no synchronized upstream reference. Configure a trusted source on the forest-root PDC when available.'
    }
}

function Invoke-CheckedNative {
    param([string]$File, [string[]]$ArgumentList)
    & $File @ArgumentList
    if ($LASTEXITCODE -ne 0) { throw "$File exited with code $LASTEXITCODE" }
}

function Get-HardeningBackupDirectory {
    if (-not (Test-Path -LiteralPath $BackupDirectory)) { $null = New-Item -ItemType Directory -Path $BackupDirectory -Force }
    & {
        $acl = New-Object Security.AccessControl.DirectorySecurity
        $acl.SetAccessRuleProtection($true,$false)
        foreach ($sid in 'S-1-5-18','S-1-5-32-544') {
            $principal = New-Object Security.Principal.SecurityIdentifier($sid)
            $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($principal,'FullControl','ContainerInherit,ObjectInherit','None','Allow')))
        }
        Set-Acl -LiteralPath $BackupDirectory -AclObject $acl
    }
    $BackupDirectory
}

function Set-TlsHardening {
    [CmdletBinding()]param()
    $root = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL'
    foreach ($protocol in 'SSL 2.0','SSL 3.0','PCT 1.0','Multi-Protocol Unified Hello','TLS 1.0','TLS 1.1') {
        foreach ($side in 'Client','Server') {
            Set-RegistryValue "$root\Protocols\$protocol\$side" 'Enabled' 0
            Set-RegistryValue "$root\Protocols\$protocol\$side" 'DisabledByDefault' 1
        }
    }
    foreach ($side in 'Client','Server') {
        Set-RegistryValue "$root\Protocols\TLS 1.2\$side" 'Enabled' 1
        Set-RegistryValue "$root\Protocols\TLS 1.2\$side" 'DisabledByDefault' 0
    }
    foreach ($cipher in 'NULL','DES 56/56','Triple DES 168','RC2 40/128','RC2 56/128','RC2 128/128','RC4 40/128','RC4 56/128','RC4 64/128','RC4 128/128') {
        Set-RegistryValue "$root\Ciphers\$cipher" 'Enabled' 0
    }
    Set-RegistryValue "$root\Hashes\MD5" 'Enabled' 0
    # Preserve modern OS cipher ordering, SHA policies and TLS 1.3. Do not import
    # a mixed NULL/3DES cipher list or force SHA-1 off for every certificate.
    Set-RegistryValue "$root\KeyExchangeAlgorithms\Diffie-Hellman" 'ServerMinKeyBitLength' 2048
    Write-Host 'SCHANNEL: TLS 1.2 enabled, TLS 1.0/1.1 and legacy ciphers disabled; service/OS restart may be required. TLS 1.3 settings retained.'
}

function Remove-AccessibilityHijacks {
    [CmdletBinding()]param()
    foreach ($file in 'sethc.exe','utilman.exe','osk.exe','narrator.exe','magnify.exe') {
        Invoke-ToolStep "Remove accessibility debugger hijack: $file" {
            $key = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\$file"
            $item = Get-Item -LiteralPath $key -ErrorAction SilentlyContinue
            if ($item -and 'Debugger' -in $item.GetValueNames()) {
                Remove-ItemProperty -LiteralPath $key -Name Debugger -Force
            }
        }
        if ($RemoveAccessibilityBinaries) {
            Invoke-ToolStep "Remove accessibility binary (explicit request): $file" {
                $path = Join-Path $env:windir ('System32\'+$file)
                if (Test-Path -LiteralPath $path) {
                    $folder = Join-Path (Get-HardeningBackupDirectory) 'accessibility'
                    $null = New-Item -ItemType Directory -Path $folder -Force
                    Copy-Item -LiteralPath $path -Destination $folder -Force
                    (Get-Acl -LiteralPath $path).Sddl | Set-Content -LiteralPath (Join-Path $folder ($file+'.sddl'))
                    Invoke-CheckedNative "$env:windir\System32\takeown.exe" @('/F',$path,'/A')
                    Invoke-CheckedNative "$env:windir\System32\icacls.exe" @($path,'/grant','*S-1-5-32-544:F')
                    Remove-Item -LiteralPath $path -Force
                }
            }
        }
    }
}

function Set-ExtendedDefenderHardening {
    [CmdletBinding()]param()
    $set = Get-Command Set-MpPreference -ErrorAction SilentlyContinue
    if (-not $set) { Write-Warning 'Defender extended settings skipped: cmdlets unavailable.'; return }
    $status = Get-MpComputerStatus
    if (-not $status.AntivirusEnabled) { Write-Warning 'Defender extended settings skipped: antivirus inactive.'; return }
    if (-not $KeepDefenderExclusions) {
        $remove = Get-Command Remove-MpPreference -ErrorAction Stop
        foreach ($property in 'ExclusionPath','ExclusionProcess','ExclusionExtension','ExclusionIpAddress','AttackSurfaceReductionOnlyExclusions') {
            if (-not $remove.Parameters.ContainsKey($property)) { continue }
            $preferences = Get-MpPreference
            if (-not $preferences.PSObject.Properties[$property]) { continue }
            foreach ($entry in @($preferences.$property)) {
                if (-not $entry) { continue }
                Invoke-ToolStep "Remove Defender exclusion: $property [$entry]" {
                    $arguments = @{ ErrorAction='Stop' }; $arguments[$property] = $entry
                    Remove-MpPreference @arguments
                }
            }
        }
    }
    Invoke-ToolStep 'Enable Defender network protection' {
        if ($set.Parameters.ContainsKey('EnableNetworkProtection')) {
            $current = Get-MpPreference
            $action = if ($ASRMode -eq 'Block' -or "$($current.EnableNetworkProtection)" -in '1','Enabled') { 'Enabled' } else { 'AuditMode' }
            $arguments = @{ EnableNetworkProtection=$action }
            if ($os.ProductType -ne 1) {
                if ($set.Parameters.ContainsKey('AllowNetworkProtectionOnWinServer')) { $arguments.AllowNetworkProtectionOnWinServer=$true }
                if ($build -le 14393 -and $set.Parameters.ContainsKey('AllowNetworkProtectionDownLevel')) { $arguments.AllowNetworkProtectionDownLevel=$true }
                # Microsoft advises against UDP inspection on DC/DNS/high-volume servers.
                if ($set.Parameters.ContainsKey('AllowDatagramProcessingOnWinServer')) { $arguments.AllowDatagramProcessingOnWinServer=$false }
            }
            Set-MpPreference @arguments
            Get-MpPreference | Select-Object EnableNetworkProtection,AllowNetworkProtectionOnWinServer,AllowDatagramProcessingOnWinServer
        }
    }
    Invoke-ToolStep 'Update Defender signatures' {
        if (Get-Command Update-MpSignature -ErrorAction SilentlyContinue) { Update-MpSignature }
    }
    if ($ExploitProtectionPolicy) {
        Invoke-ToolStep 'Import reviewed exploit protection XML' {
            $file = Get-Item -LiteralPath $ExploitProtectionPolicy
            if ($file.Extension -ne '.xml' -or $file.PSIsContainer) { throw 'ExploitProtectionPolicy must be a reviewed XML file.' }
            $null = [xml](Get-Content -LiteralPath $file.FullName -Raw)
            Set-ProcessMitigation -PolicyFilePath $file.FullName
        }
    }
}

function Set-DirectoryAuditing {
    [CmdletBinding()]param()
    Import-Module ActiveDirectory
    $domain = Get-ADDomain -Server $env:COMPUTERNAME
    $base = $domain.DistinguishedName
    $driveName = 'HardeningAD'+[guid]::NewGuid().ToString('N').Substring(0,8)
    $created = $false
    try {
        foreach ($relative in @('','CN=RID Manager$,CN=System','CN=Policies,CN=System','CN=Infrastructure','OU=Domain Controllers','CN=AdminSDHolder,CN=System')) {
            $dn = if ($relative) { "$relative,$base" } else { $base }
            . Invoke-ToolStep "Directory audit policy: $dn" {
                if (-not $created) {
                    $null = New-PSDrive -Name $driveName -PSProvider ActiveDirectory -Root '' -Server $env:COMPUTERNAME
                    $created = $true
                }
                $path = "$driveName`:\$dn"
                $acl = Get-Acl -Path $path -Audit
                $sid = New-Object Security.Principal.SecurityIdentifier('S-1-1-0')
                $rights = [DirectoryServices.ActiveDirectoryRights]::WriteProperty -bor [DirectoryServices.ActiveDirectoryRights]::WriteDacl -bor [DirectoryServices.ActiveDirectoryRights]::WriteOwner -bor [DirectoryServices.ActiveDirectoryRights]::ExtendedRight
                $flags = [Security.AccessControl.AuditFlags]::Success -bor [Security.AccessControl.AuditFlags]::Failure
                $inherit = [DirectoryServices.ActiveDirectorySecurityInheritance]::All
                $existing = @($acl.GetAuditRules($true,$false,[Security.Principal.SecurityIdentifier]) | Where-Object {
                    $_.IdentityReference.Value -eq $sid.Value -and $_.ActiveDirectoryRights -eq $rights -and $_.AuditFlags -eq $flags -and $_.InheritanceType -eq $inherit -and $_.ObjectType -eq [guid]::Empty -and $_.InheritedObjectType -eq [guid]::Empty
                })
                if (-not $existing.Count) {
                    $rule = New-Object DirectoryServices.ActiveDirectoryAuditRule($sid,$rights,$flags,$inherit)
                    $acl.AddAuditRule($rule)
                    Set-Acl -Path $path -AclObject $acl
                }
            }
        }
    } finally { if ($created) { Remove-PSDrive -Name $driveName -ErrorAction SilentlyContinue } }
}

function Set-ExtendedDirectoryHardening {
    [CmdletBinding()]param()
    Import-Module ActiveDirectory
    $server = $env:COMPUTERNAME
    $domain = Get-ADDomain -Server $server
    $root = Get-ADRootDSE -Server $server
    $directory = 'CN=Directory Service,CN=Windows NT,CN=Services,'+$root.ConfigurationNamingContext
    Invoke-ToolStep 'Disable unauthenticated and anonymous directory binds' {
        $object = Get-ADObject -Identity $directory -Server $server -Properties 'msDS-Other-Settings',dsHeuristics
        [string[]]$other = @($object.'msDS-Other-Settings' | Where-Object { $_ -notlike 'DenyUnauthenticatedBind=*' }) + 'DenyUnauthenticatedBind=1'
        $heuristic = [string]$object.dsHeuristics
        if ($heuristic.Length -lt 7) { $heuristic=$heuristic.PadRight(7,'0') }
        $heuristic=$heuristic.Substring(0,6)+'0'+$heuristic.Substring(7)
        Set-ADObject -Identity $object -Server $server -Replace @{ 'msDS-Other-Settings'=$other; dsHeuristics=$heuristic }
    }
    Invoke-ToolStep 'Set LDAP connection idle limit' {
        $dn = 'CN=Default Query Policy,CN=Query-Policies,'+$directory
        $policy = Get-ADObject -Identity $dn -Server $server -Properties lDAPAdminLimits
        [string[]]$limits=@($policy.lDAPAdminLimits | Where-Object { $_ -notlike 'MaxConnIdleTime=*' }) + 'MaxConnIdleTime=180'
        Set-ADObject -Identity $policy -Server $server -Replace @{ lDAPAdminLimits=$limits }
    }
    Set-RegistryValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'DsrmAdminLogonBehavior' 1
    if (-not $SkipDirectoryAuditing) { Set-DirectoryAuditing }
}

function Reset-NtdsPermissions {
    [CmdletBinding()]param()
    $config = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\NTDS\Parameters'
    $database = [IO.Path]::GetFullPath($config.'DSA Database File')
    if ([IO.Path]::GetExtension($database) -ne '.dit' -or -not (Test-Path -LiteralPath $database -PathType Leaf)) { throw 'Configured NTDS database is not an existing .dit file.' }
    $dataPath=Split-Path -Parent $database
    $logPath=[IO.Path]::GetFullPath($config.'Database log files path').TrimEnd('\')
    foreach ($folder in @($dataPath,$logPath) | Sort-Object -Unique) {
        if ($folder.TrimEnd('\') -in $env:windir.TrimEnd('\'),$env:SystemDrive) { throw 'Refusing to replace permissions on a Windows or drive root.' }
        Invoke-ToolStep "Reset configured NTDS folder permissions: $folder" {
            $backup=Join-Path (Get-HardeningBackupDirectory) ('ntds-acls-'+[guid]::NewGuid().ToString('N')+'.json')
            $items=@(Get-Item -LiteralPath $folder; Get-ChildItem -LiteralPath $folder -Force)
            @($items | ForEach-Object { [pscustomobject]@{ Path=$_.FullName; Sddl=(Get-Acl -LiteralPath $_.FullName).Sddl } }) | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $backup
            $acl=New-Object Security.AccessControl.DirectorySecurity
            $acl.SetAccessRuleProtection($true,$false)
            foreach($sid in 'S-1-5-18','S-1-5-32-544') {
                $principal=New-Object Security.Principal.SecurityIdentifier($sid)
                $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($principal,'FullControl','ContainerInherit,ObjectInherit','None','Allow')))
            }
            if($folder -eq $logPath) {
                $creator=New-Object Security.Principal.SecurityIdentifier('S-1-3-0')
                $local=New-Object Security.Principal.SecurityIdentifier('S-1-5-19')
                $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($creator,'FullControl','ContainerInherit,ObjectInherit','InheritOnly','Allow')))
                $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($local,'AppendData,CreateDirectories','ContainerInherit','None','Allow')))
            }
            Set-Acl -LiteralPath $folder -AclObject $acl
            foreach($item in $items | Where-Object FullName -ne $folder) {
                $child=Get-Acl -LiteralPath $item.FullName
                $child.SetAccessRuleProtection($false,$false)
                foreach($entry in @($child.Access | Where-Object {-not $_.IsInherited})){$child.RemoveAccessRuleSpecific($entry)}
                Set-Acl -LiteralPath $item.FullName -AclObject $child
            }
            Write-Host "NTDS DACL backup: $backup. Validate AD startup after reboot."
        }
    }
}

function Disable-DomainGroupPolicies {
    [CmdletBinding()]param()
    Import-Module ActiveDirectory
    Import-Module GroupPolicy
    $policyDomain = Get-ADDomain -Server $env:COMPUTERNAME
    $policyServer = $env:COMPUTERNAME
    $gpos = @(Get-GPO -All -Domain $policyDomain.DNSRoot -Server $policyServer)
    $backupState = @{ Ready = $false }
    foreach ($gpo in $gpos | Where-Object { $_.GpoStatus -ne 'AllSettingsDisabled' }) {
        Invoke-ToolStep "Back up and disable GPO: $($gpo.DisplayName)" {
            if (-not $backupState.Ready) {
                $null = New-Item -Path $GpoBackupDirectory -ItemType Directory -Force
                $acl = New-Object Security.AccessControl.DirectorySecurity
                $acl.SetAccessRuleProtection($true, $false)
                foreach ($sid in 'S-1-5-18', 'S-1-5-32-544') {
                    $principal = New-Object Security.Principal.SecurityIdentifier($sid)
                    $rule = New-Object Security.AccessControl.FileSystemAccessRule($principal, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')
                    $acl.AddAccessRule($rule)
                }
                Set-Acl -LiteralPath $GpoBackupDirectory -AclObject $acl
                $gpos | Select-Object Id, DisplayName, GpoStatus | Export-Csv -LiteralPath (Join-Path $GpoBackupDirectory 'original-status.csv') -NoTypeInformation
                $backupState.Ready = $true
            }
            $null = Backup-GPO -Guid $gpo.Id -Domain $policyDomain.DNSRoot -Server $policyServer -Path $GpoBackupDirectory
            try { $gpo.GpoStatus = 'AllSettingsDisabled' }
            catch {
                throw "GPO write failed for $($gpo.DisplayName): $($_.Exception.Message). The executing identity needs GpoEdit delegation on this GPO; local Administrators membership alone does not grant it. The caller must have edit rights in both AD and SYSVOL. Use a delegated domain account; elevation alone cannot grant domain rights."
            }
            $updated = Get-GPO -Guid $gpo.Id -Domain $policyDomain.DNSRoot -Server $policyServer
            if ($updated.GpoStatus -ne 'AllSettingsDisabled') { throw "GPO readback did not report disabled: $($gpo.DisplayName)" }
            Write-ToolStatus "Disabled GPO: $($gpo.DisplayName); backup: $GpoBackupDirectory" 'OK'
        }
    }
}

function Invoke-OptionalHardeningChanges {
    [CmdletBinding()]param()
    if ($ResetLocalPolicy) {
        Invoke-ToolStep 'Back up and reset local Group Policy' {
            $folder=Join-Path (Get-HardeningBackupDirectory) 'local-policy'
            $null=New-Item -ItemType Directory -Path $folder -Force
            foreach($name in 'GroupPolicy','GroupPolicyUsers') {
                $path=Join-Path $env:windir ('System32\'+$name)
                if(Test-Path -LiteralPath $path){Copy-Item -LiteralPath $path -Destination $folder -Recurse -Force;Remove-Item -LiteralPath $path -Recurse -Force}
            }
        }
    }
    if ($ResetDefaultDomainGpos) {
        Invoke-ToolStep 'Back up domain policy and rebuild default GPOs' {
            if(-not $isDC){throw 'ResetDefaultDomainGpos requires a DC.'}
            Import-Module GroupPolicy
            $folder=Join-Path (Get-HardeningBackupDirectory) 'domain-policy'
            $null=New-Item -ItemType Directory -Path $folder -Force
            $null=Backup-GPO -All -Path $folder -Server $env:COMPUTERNAME
            Invoke-CheckedNative "$env:windir\System32\dcgpofix.exe" @('/target:Both','/ignoreschema')
        }
    }
    if ($ResetNtdsAcl) {
        Invoke-ToolStep 'Reset NTDS DACLs (explicit request)' { if(-not $isDC){throw 'ResetNtdsAcl requires a DC.'}; Reset-NtdsPermissions }
    }
    if ($ResetScmAcl) {
        Invoke-ToolStep 'Back up and reset Service Control Manager permissions' {
            $sc = "$env:windir\System32\sc.exe"
            $original = & $sc sdshow scmanager
            if ($LASTEXITCODE -ne 0) { throw "SCM permission backup failed: $LASTEXITCODE" }
            $original | Set-Content -LiteralPath (Join-Path (Get-HardeningBackupDirectory) 'scmanager-sddl.txt')
            Invoke-CheckedNative $sc @('sdset','scmanager','D:(A;;CC;;;AU)(A;;CCLCRPRC;;;IU)(A;;CCLCRPRC;;;SU)(A;;CCLCRPWPRC;;;SY)(A;;KA;;;BA)(A;;CC;;;AC)S:(AU;FA;KA;;;WD)(AU;OIIOFA;GA;;;WD)')
        }
    }
    if ($RestoreHiveInheritance) {
        Invoke-ToolStep 'Restore registry hive file ACL inheritance' {
            $files = Join-Path $env:windir 'System32\config\*.*'
            $backup = Join-Path (Get-HardeningBackupDirectory) 'registry-hive-acls.txt'
            Invoke-CheckedNative "$env:windir\System32\icacls.exe" @($files,'/save',$backup)
            Invoke-CheckedNative "$env:windir\System32\icacls.exe" @($files,'/inheritance:e')
        }
    }
    if ($EnableDefenderSandbox) {
        Invoke-ToolStep 'Enable Defender antivirus sandbox environment setting' {
            [Environment]::SetEnvironmentVariable('MP_FORCE_USE_SANDBOX','1','Machine')
            Write-Warning 'Defender sandbox requested. Restart and verify MsMpEngCP.exe; platform support is required.'
        }
    }
    if ($EnableBootMitigations) {
        foreach($argsList in @(@('/set','testsigning','off'),@('/set','nointegritychecks','off'),@('/set','{current}','nx','AlwaysOn'))) {
            Invoke-ToolStep ('Boot setting: '+($argsList -join ' ')) {
                Invoke-CheckedNative "$env:windir\System32\bcdedit.exe" $argsList
            }
        }
        Write-Warning 'Boot mitigation changes require restart; older software/drivers may stop working.'
    }
    if ($DeleteShadowCopies -and -not $KeepShadowCopies) {
        Invoke-ToolStep 'Delete all local shadow copies by default' {
            $copies = @(Get-CimInstance Win32_ShadowCopy -ErrorAction Stop)
            if (-not $copies.Count) { Write-Host 'No local shadow copies found.' }
            else {
                Invoke-CheckedNative "$env:windir\System32\vssadmin.exe" @('delete','shadows','/all','/quiet')
                $remaining = @(Get-CimInstance Win32_ShadowCopy -ErrorAction Stop)
                if ($remaining.Count) { throw "$($remaining.Count) shadow copies remain. Some snapshot providers require their own removal tool." }
                Write-Host "Deleted $($copies.Count) local shadow copies; zero remain."
            }
        }
    } else { Write-Host 'Local shadow copies retained by operator choice.' }
}

Write-ToolStatus 'Identify Windows version and domain role' 'RUN'
$os = Get-CimInstance Win32_OperatingSystem
$computer = Get-CimInstance Win32_ComputerSystem
$isDC = $computer.DomainRole -in 4, 5
$build = [int]$os.BuildNumber
$dns = Get-Service -Name DNS -ErrorAction SilentlyContinue
Write-Host "OS: $($os.Caption), build $build; domain controller: $isDC"
Write-Warning 'These are exposure reductions, not proof that CVEs are patched. No OS reboot is requested; patch and feature changes can remain pending.'

. Invoke-ToolStep 'Back up and disable domain GPOs by default' {
    if ($isDC -and $DisableDomainGpos -and -not $KeepDomainGpos) { Disable-DomainGroupPolicies }
    elseif ($isDC) { Write-Host 'Domain GPOs retained by operator choice.' }
    else { Write-Host 'Domain GPO changes run on a DC only; this machine receives local hardening.' }
}
. Invoke-ToolStep 'Refresh Group Policy (up to 30 seconds)' {
    Update-LocalGroupPolicy
}

Write-Warning 'Deleting tasks directly in Task Scheduler Library root only. A root task may belong to an application; its scheduled actions will no longer run. Already running processes are not stopped.'
. Invoke-ToolStep 'Delete root Task Scheduler Library tasks' {
    Remove-RootScheduledTasks
}

$settings = @(
    @{ Path = 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa'; Name = 'OldPasswordAllowedPeriod'; Value = 0 },
    @{ Path = 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa'; Name = 'NoLMHash'; Value = 1 },
    @{ Path = 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa'; Name = 'RestrictAnonymous'; Value = 1 },
    @{ Path = 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa'; Name = 'RestrictAnonymousSAM'; Value = 1 },
    @{ Path = 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa'; Name = 'EveryoneIncludesAnonymous'; Value = 0 },
    @{ Path = 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa'; Name = 'SCENoApplyLegacyAuditPolicy'; Value = 1 },
    @{ Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; Name = 'EnableLUA'; Value = 1 },
    @{ Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; Name = 'PromptOnSecureDesktop'; Value = 1 },
    @{ Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; Name = 'ConsentPromptBehaviorAdmin'; Value = 2 },
    @{ Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; Name = 'ConsentPromptBehaviorUser'; Value = 0 },
    @{ Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'; Name = 'EnableInstallerDetection'; Value = 1 },
    @{ Path = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient'; Name = 'EnableMulticast'; Value = 0 },
    @{ Path = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient'; Name = 'DisableSmartNameResolution'; Value = 1 },
    @{ Path = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer'; Name = 'AlwaysInstallElevated'; Value = 0 },
    @{ Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer'; Name = 'NoDriveTypeAutoRun'; Value = 255 },
    @{ Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer'; Name = 'NoAutorun'; Value = 1 },
    @{ Path = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager'; Name = 'SafeDllSearchMode'; Value = 1 },
    @{ Path = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging'; Name = 'EnableScriptBlockLogging'; Value = 1 },
    @{ Path = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging'; Name = 'EnableModuleLogging'; Value = 1 },
    @{ Path = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging\ModuleNames'; Name = '*'; Value = '*'; Type = 'String' },
    @{ Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit'; Name = 'ProcessCreationIncludeCmdLine_Enabled'; Value = 1 }
)
foreach ($setting in $settings) { Set-RegistryValue @setting }
Write-Warning 'NTLMv2-only enforcement rejects LM/NTLMv1 clients. Retest application authentication.'
set-registryvalue 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'LmCompatibilityLevel' 5
if (-not $KeepLocalAdminRemoting) {
    set-registryvalue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'LocalAccountTokenFilterPolicy' 0
}
$remoteRegistry = Get-Service -Name RemoteRegistry -ErrorAction SilentlyContinue
. Invoke-ToolStep 'Stop and disable RemoteRegistry' {
    if ($remoteRegistry -and -not $KeepRemoteRegistry) {
        Stop-Service -Name RemoteRegistry -Force
        Set-Service -Name RemoteRegistry -StartupType Disabled
    }
}
Write-ToolStatus 'NetBIOS adapter settings and name-resolution mode are preserved for domain discovery.'
# Subcategory GUIDs avoid depending on the Windows display language.
$auditCategories = @(
    @{ Id = '{0CCE922B-69AE-11D9-BED3-505054503030}'; Name = 'Process creation'; Failure = $false },
    @{ Id = '{0CCE9215-69AE-11D9-BED3-505054503030}'; Name = 'Logon'; Failure = $true },
    @{ Id = '{0CCE921B-69AE-11D9-BED3-505054503030}'; Name = 'Special logon'; Failure = $false },
    @{ Id = '{0CCE922F-69AE-11D9-BED3-505054503030}'; Name = 'Audit policy change'; Failure = $true },
    @{ Id = '{0CCE9235-69AE-11D9-BED3-505054503030}'; Name = 'User account management'; Failure = $true },
    @{ Id = '{0CCE9237-69AE-11D9-BED3-505054503030}'; Name = 'Security group management'; Failure = $true },
    @{ Id = '{0CCE923F-69AE-11D9-BED3-505054503030}'; Name = 'Credential validation'; Failure = $true },
    @{ Id = '{0CCE9242-69AE-11D9-BED3-505054503030}'; Name = 'Kerberos authentication service'; Failure = $true }
)
if ($isDC) { $auditCategories += @{Id='{0CCE923B-69AE-11D9-BED3-505054503030}';Name='Directory service access';Failure=$true}; $auditCategories += @{Id='{0CCE923C-69AE-11D9-BED3-505054503030}';Name='Directory service changes';Failure=$true} }
foreach ($category in $auditCategories) {
    . Invoke-ToolStep 'Enable security audit category' {
        $arguments = @('/set', "/subcategory:$($category.Id)", '/success:enable')
        if ($category.Failure) { $arguments += '/failure:enable' }
        & "$env:windir\System32\auditpol.exe" @arguments
        if ($LASTEXITCODE -ne 0) { throw "Audit policy change failed for $($category.Name): $LASTEXITCODE" }
    }
}

. Invoke-ToolStep 'Require SMB signing and disable SMB1 server' {
    Set-SmbServerConfiguration -EnableSMB1Protocol $false -RequireSecuritySignature $true -Force
    Set-SmbClientConfiguration -RequireSecuritySignature $true -Force
}
set-registryvalue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation' 'AllowInsecureGuestAuth' 0
. Invoke-ToolStep 'Remove SMB1 Windows feature' {
    if (Get-Command Get-WindowsFeature -ErrorAction SilentlyContinue) {
        $feature = Get-WindowsFeature -Name FS-SMB1
        if ($feature.Installed) { Uninstall-WindowsFeature -Name FS-SMB1 }
    }
    else {
        $feature = Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol
        if ($feature.State -eq 'Enabled') { Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -NoRestart }
    }
}

$printKey = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint'
set-registryvalue $printKey 'RestrictDriverInstallationToAdministrators' 1
set-registryvalue $printKey 'NoWarningNoElevationOnInstall' 0
set-registryvalue $printKey 'UpdatePromptSettings' 0
. Invoke-ToolStep 'Stop and disable Print Spooler' {
    $spooler = Get-CimInstance Win32_Service -Filter "Name='Spooler'"
    if ($spooler -and -not $KeepPrinting) {
        Stop-Service -Name Spooler -Force
        Set-Service -Name Spooler -StartupType Disabled
    }
}
set-registryvalue 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest' 'UseLogonCredential' 0
set-registryvalue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' 'UserAuthentication' 1

. Invoke-ToolStep 'Harden AD machine quota, Netlogon and LDAP' {
    if ($isDC) {
        Import-Module ActiveDirectory
        $domain = Get-ADDomain
        $server = $env:COMPUTERNAME
        Set-ADObject -Identity $domain.DistinguishedName -Server $server -Replace @{ 'ms-DS-MachineAccountQuota' = 0 }
        Write-Host 'Machine-account quota restricts ordinary users creating computer accounts; delegated joins remain possible. Install DC updates for both noPac CVEs.'
        $netlogon = 'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters'
        set-registryvalue $netlogon 'FullSecureChannelProtection' 1
        $netlogonKey = Get-Item -LiteralPath $netlogon -ErrorAction SilentlyContinue
        if ($null -ne $netlogonKey -and 'vulnerablechannelallowlist' -in $netlogonKey.GetValueNames()) {
            Remove-ItemProperty -LiteralPath $netlogon -Name 'vulnerablechannelallowlist' -Force -ErrorAction Stop
        }
        $ntds = 'HKLM:\SYSTEM\CurrentControlSet\Services\NTDS\Parameters'
        Write-ToolStatus 'LDAP signing settings are preserved for application compatibility.'
        Write-Warning 'LDAP channel binding can reject incompatible LDAPS clients; requires applicable DC updates.'
        set-registryvalue $ntds 'LdapEnforceChannelBinding' 2

    }
}
. Invoke-ToolStep 'Apply DNS SIGRed workaround where applicable' {
    if ($dns -and $os.ProductType -ne 1 -and $build -lt 20348) {
        set-registryvalue 'HKLM:\SYSTEM\CurrentControlSet\Services\DNS\Parameters' 'TcpReceivePacketSize' 65280
        Restart-Service -Name DNS
        Write-Host 'SIGRed workaround does not replace the security update.'
    }
}
. Invoke-ToolStep 'Apply SMBGhost workaround where applicable' {
    if ($os.ProductType -ne 1 -and $build -in 18362, 18363) {
        set-registryvalue 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' 'DisableCompression' 1
        Write-Host 'Applied SMBGhost server-side workaround for SAC 1903/1909; clients still need updates.'
    }
}

foreach ($packagePath in $UpdatePackage) {
    . Invoke-ToolStep 'Install supplied Windows update package' {
        $package = Get-Item -LiteralPath $packagePath
        if ($package.PSIsContainer -or $package.Extension -ne '.msu') { throw 'UpdatePackage must contain applicable Microsoft .msu files.' }
        $hash = (Get-FileHash -LiteralPath $package.FullName -Algorithm SHA256).Hash
        $process = Start-Process -FilePath "$env:windir\System32\wusa.exe" -ArgumentList @(('"{0}"' -f $package.FullName), '/quiet', '/norestart') -Wait -PassThru
        [pscustomobject]@{ Path = $package.FullName; SHA256 = $hash; ExitCode = $process.ExitCode }
        if ($process.ExitCode -notin 0, 3010, 2359302) { throw "Update installer failed: $($process.ExitCode). Review servicing logs." }
        Write-Host "Update result: $($process.ExitCode); 3010 means reboot required, 2359302 means already installed."
    }
}
. Invoke-ToolStep 'Search Windows Update or WSUS' {
    if ($ScanUpdates) {
        $session = New-Object -ComObject Microsoft.Update.Session
        $searcher = $session.CreateUpdateSearcher()
        $result = $searcher.Search("IsInstalled=0 and IsHidden=0 and Type='Software'")
        $result.Updates | Select-Object Title, KBArticleIDs
    }
}
. Invoke-ToolStep 'Enable Microsoft Defender protection' {
    if (Get-Command Set-MpPreference -ErrorAction SilentlyContinue) {
        $defenderStatus = Get-MpComputerStatus
        if ($defenderStatus.AntivirusEnabled) {
            Set-MpPreference -DisableRealtimeMonitoring $false -DisableBehaviorMonitoring $false -DisableArchiveScanning $false -DisableIOAVProtection $false -DisableScriptScanning $false -PUAProtection Enabled
            Set-MpPreference -MAPSReporting Advanced -SubmitSamplesConsent SendSafeSamples -DisableBlockAtFirstSeen $false

            for ($attempt = 0; $attempt -lt 15 -and -not (Get-MpComputerStatus).RealTimeProtectionEnabled; $attempt++) {
                Start-Sleep -Seconds 2
            }
            if (-not (Get-MpComputerStatus).RealTimeProtectionEnabled) {
                throw 'Defender real-time protection did not enable; review effective policy and tamper protection.'
            }
        }
        elseif (-not $defenderStatus.AntivirusEnabled) {
            Write-Warning 'Defender Antivirus is inactive; Defender hardening was skipped.'
        }
    }
    else { Write-Warning 'Defender cmdlets are unavailable; Defender hardening was skipped.' }
}
$asrConfigured = $false
$asrCommand = Get-Command Add-MpPreference -ErrorAction SilentlyContinue
$asrReady = $false
. Invoke-ToolStep 'Check Defender ASR support' {
    if (-not $SkipASR -and $asrCommand -and $asrCommand.Parameters.ContainsKey('AttackSurfaceReductionRules_Ids')) {
        $status = Get-MpComputerStatus
        $asrReady = $status.AntivirusEnabled -and $status.RealTimeProtectionEnabled
    }
}
. Invoke-ToolStep 'Report ASR availability' {
    if (-not $SkipASR -and -not $asrReady) {
        Write-Warning 'ASR skipped: active Defender with ASR support is required. Server 2016 requires the modern unified solution; check platform support.'
    }
}
. Invoke-ToolStep 'Configure Defender ASR rules' {
    if ($asrReady) {
        $asrConfigured = $true
        $rules = [ordered]@{
            '5beb7efe-fd9a-4556-801d-275e5ffc04cc' = 'Potentially obfuscated scripts'
            'b2b3f03d-6a65-4f7b-a9c7-1c7ef74a9ba4' = 'Untrusted processes from USB'
            'c1db55ab-c21a-4637-bb3f-a12568109d35' = 'Advanced ransomware protection'
            '01443614-cd74-433a-b99e-2ecdc07bfc25' = 'Executable prevalence, age and trust'
            '26190899-1602-49e8-8b27-eb1d0a1ce869' = 'Office communication application child processes'
            'd1e49aac-8f56-4280-b9ba-993a6d77406c' = 'PSExec and WMI process creation'
            '56a863a9-875e-4185-98a7-b882c64b5ce5' = 'Vulnerable signed driver abuse'
            '9e6c4e1f-7d60-472f-ba1a-a39ef669e4b2' = 'LSASS credential theft'
            'e6db77e5-3df2-4cf1-b95a-636979351e5b' = 'WMI event subscription persistence'
            'd4f940ab-401b-4efc-aadc-ad5f3c50688a' = 'Office child processes'
            '3b576869-a4ec-4529-8536-b80a7769e899' = 'Office executable content'
            '75668c1f-73b5-4cf0-bb93-3ecf5cb7cc84' = 'Office process injection'
            '92e97fa1-2edf-4476-bdd6-9dd0b4dddc7b' = 'Office macro Win32 API calls'
            'be9ba2d9-53ea-4cdc-84e5-9b1eeee46550' = 'Executable email content'
            'd3e037e1-3eb8-44c8-a917-57927947596d' = 'JS/VBS downloaded executables'
            '7674ba52-37eb-4a4f-a9a1-f0f9a1619a2c' = 'Adobe Reader child processes'
        }
        $preferences = Get-MpPreference
        if ($os.ProductType -ne 1) {
            $rules.Remove('92e97fa1-2edf-4476-bdd6-9dd0b4dddc7b')
        }
        $asrKey = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Windows Defender Exploit Guard\ASR\Rules'
        $desired = if ($ASRMode -eq 'Block') { 1 } else { 2 }
        foreach ($id in $rules.Keys) {
            Invoke-ToolStep "ASR rule: $($rules[$id])" {
                $action = $desired
                $ids = @($preferences.AttackSurfaceReductionRules_Ids)
                $actions = @($preferences.AttackSurfaceReductionRules_Actions)
                $index = [array]::IndexOf($ids, $id)
                $policyKey = Get-Item -LiteralPath $asrKey -ErrorAction SilentlyContinue
                $policyValue = if ($null -ne $policyKey) { $policyKey.GetValue($id, $null) } else { $null }
                # An audit run must not weaken a preexisting block, including registry-only policy.
                if ($desired -eq 2 -and (($index -ge 0 -and $index -lt $actions.Count -and $actions[$index] -eq 1) -or $policyValue -eq '1')) { $action = 1 }
                set-registryvalue $asrKey $id $action.ToString() -Type String
                Add-MpPreference -AttackSurfaceReductionRules_Ids $id -AttackSurfaceReductionRules_Actions $action
            }
        }
    }

}
. Invoke-ToolStep 'Harden SMTP relay if installed' {
    Set-SmtpHardening -RelayIPv4 $SmtpRelayIPv4
}
. Invoke-ToolStep 'Harden Windows Time' {
    Set-TimeHardening
}

. Invoke-ToolStep 'Read back SMB server configuration' {
    Get-SmbServerConfiguration | Select-Object EnableSMB1Protocol, EnableSMB2Protocol, RequireSecuritySignature
}
. Invoke-ToolStep 'Read back SMB client configuration' {
    Get-SmbClientConfiguration | Select-Object RequireSecuritySignature
}

# Additional hardening controls. Potentially disruptive operations have explicit switches.
$extendedSettings = @(
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp';Name='SecurityLayer';Value=2},
    @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services';Name='fEncryptRPCTraffic';Value=1},
    @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services';Name='fAllowToGetHelp';Value=0},
    @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation';Name='AllowProtectedCreds';Value=1},
    @{Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System';Name='FilterAdministratorToken';Value=1},
    @{Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System';Name='EnableUIADesktopToggle';Value=0},
    @{Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System';Name='EnableSecureUIAPaths';Value=1},
    @{Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System';Name='EnableVirtualization';Value=1},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Lsa';Name='LimitBlankPasswordUse';Value=1},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Lsa';Name='SubmitControl';Value=0},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Lsa';Name='TokenLeakDetectDelaySecs';Value=30},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Lsa';Name='RestrictRemoteSAM';Value='O:BAG:BAD:(A;;RC;;;BA)';Type='String'},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Lsa';Name='UseMachineId';Value=1},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0';Name='AllowNullSessionFallback';Value=0},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0';Name='NTLMMinServerSec';Value=537395200},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0';Name='NTLMMinClientSec';Value=537395200},
    @{Path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon';Name='AutoAdminLogon';Value='0';Type='String'},
    @{Path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon';Name='ScreenSaverGracePeriod';Value='0';Type='String'},
    @{Path='HKCU:\SOFTWARE\Policies\Microsoft\Windows\Installer';Name='AlwaysInstallElevated';Value=0},
    @{Path='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer';Name='NoDriveTypeAutoRun';Value=255},
    @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer';Name='NoAutoplayfornonVolume';Value=1},
    @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer';Name='NoDataExecutionPrevention';Value=0},
    @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer';Name='NoHeapTerminationOnCorruption';Value=0},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager';Name='ProtectionMode';Value=1},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager';Name='CWDIllegalInDllSearch';Value=2},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel';Name='DisableExceptionChainValidation';Value=0},
    @{Path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows';Name='LoadAppInit_DLLs';Value=0},
    @{Path='HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows NT\CurrentVersion\Windows';Name='LoadAppInit_DLLs';Value=0},
    @{Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer';Name='DisableLocalMachineRunOnce';Value=1},
    @{Path='HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Policies\Explorer';Name='DisableLocalMachineRunOnce';Value=1},
    @{Path='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer';Name='DisableLocalMachineRunOnce';Value=1},
    @{Path='HKCU:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Policies\Explorer';Name='DisableLocalMachineRunOnce';Value=1},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters';Name='RequireSignOrSeal';Value=1},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters';Name='SealSecureChannel';Value=1},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters';Name='SignSecureChannel';Value=1},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters';Name='EnablePlainTextPassword';Value=0},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters';Name='RestrictNullSessAccess';Value=1},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters';Name='NullSessionPipes';Value=@('');Type='MultiString'},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters';Name='NullSessionShares';Value=@('');Type='MultiString'},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\SecurePipeServers\winreg\AllowedPaths';Name='Machine';Value=@('');Type='MultiString'},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\SecurePipeServers\winreg\AllowedExactPaths';Name='Machine';Value=@('');Type='MultiString'},
    @{Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\WinHttp';Name='DisableWpad';Value=1},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters';Name='EnableMDNS';Value=0},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters';Name='DisableParallelAandAAAA';Value=1},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters';Name='NoNameReleaseOnDemand';Value=1},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters';Name='DisableIPSourceRouting';Value=2},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters';Name='DisableIPSourceRouting';Value=2},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters';Name='EnableICMPRedirect';Value=0},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters';Name='PerformRouterDiscovery';Value=0},
    @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers';Name='DisableWebPnPDownload';Value=1},
    @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers';Name='DisableHTTPPrinting';Value=1},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Print';Name='RpcAuthnLevelPrivacyEnabled';Value=1},
    @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers';Name='CopyFilesPolicy';Value=1},
    @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers';Name='RegisterSpoolerRemoteRpcEndPoint';Value=2},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Print\Providers\LanMan Print Services\Servers';Name='AddPrinterDrivers';Value=1},
    @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\RasMan\Parameters';Name='DisableSavePassword';Value=1},
    @{Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer';Name='PreXPSP2ShellProtocolBehavior';Value=0},
    @{Path='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced';Name='HideFileExt';Value=0},
    @{Path='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced';Name='ShowSuperHidden';Value=1}
)
if ($KeepWinRM) {
    $winrmPolicy = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service'
    $extendedSettings += @{Path=$winrmPolicy;Name='AllowUnencryptedTraffic';Value=1}
    $extendedSettings += @{Path=$winrmPolicy;Name='AllowBasic';Value=1}
    $extendedSettings += @{Path=$winrmPolicy;Name='AllowAutoConfig';Value=1}
    $extendedSettings += @{Path=$winrmPolicy;Name='IPv4Filter';Value='*';Type='String'}
}
if (-not $AllowRdpDriveRedirection) { $extendedSettings += @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services';Name='fDisableCdm';Value=1} }
if (-not $KeepCachedLogons) { $extendedSettings += @{Path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon';Name='CachedLogonsCount';Value='0';Type='String'} }
if (-not $KeepSavedCredentials) { $extendedSettings += @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Lsa';Name='DisableDomainCreds';Value=1} }
if ($RequireSignedElevation) { $extendedSettings += @{Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System';Name='ValidateAdminCodeSignatures';Value=1} }
if ($RequireAdminCredentials) { $extendedSettings += @{Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System';Name='ConsentPromptBehaviorAdmin';Value=1} }
if ($RequireKerberosAES) { $extendedSettings += @{Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Kerberos\Parameters';Name='SupportedEncryptionTypes';Value=24} }
if ($DisableIPv6) { $extendedSettings += @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters';Name='DisabledComponents';Value=255} }
if ($DisableDcom) { $extendedSettings += @{Path='HKLM:\SOFTWARE\Microsoft\Ole';Name='EnableDCOM';Value='N';Type='String'} }
if ($DisableAdminShares) {
    foreach($name in 'AutoShareServer','AutoShareWks'){$extendedSettings += @{Path='HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters';Name=$name;Value=0}}
}
if ($DisableRemoteRpc) {
    $extendedSettings += @{Path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule';Name='DisableRpcOverTcp';Value=1}
    $extendedSettings += @{Path='HKLM:\SYSTEM\CurrentControlSet\Control';Name='DisableRemoteScmEndpoints';Value=1}
    $extendedSettings += @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Rpc';Name='RestrictRemoteClients';Value=1}
}
if ($EnableRestrictedAdmin) {
    $extendedSettings += @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Lsa';Name='DisableRestrictedAdmin';Value=0}
    $extendedSettings += @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Lsa';Name='DisableRestrictedAdminOutboundCreds';Value=1}
    $extendedSettings += @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation';Name='RestrictedRemoteAdministration';Value=1}
    $extendedSettings += @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation';Name='RestrictedRemoteAdministrationType';Value=3}
}
if ($EnableLsaProtection) {
    # Value 2 is only documented on Windows 11 22H2+. Older/server platforms use
    # the explicit UEFI-lock-capable value 1; do not pretend value 2 protects 2022.
    $ppl = if ($os.ProductType -eq 1 -and $build -ge 22621) {2} else {1}
    Write-Warning "LSA protection requested (RunAsPPL=$ppl); restart required. Value 1 can set a UEFI lock; verify plug-in compatibility and WinInit event 12."
    $extendedSettings += @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\Lsa';Name='RunAsPPL';Value=$ppl}
    $extendedSettings += @{Path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\LSASS.exe';Name='AuditLevel';Value=8}
}
foreach($setting in $extendedSettings){Set-RegistryValue @setting}

. Invoke-ToolStep 'Remove stored autologon password value' {
    $path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
    $key=Get-Item -LiteralPath $path -ErrorAction SilentlyContinue
    if($key -and 'DefaultPassword' -in $key.GetValueNames()){Remove-ItemProperty -LiteralPath $path -Name DefaultPassword -Force}
}
. Invoke-ToolStep 'Remove legacy Windows PowerShell v2; keep OpenSSH installed' {
    if(Get-Command Get-WindowsOptionalFeature -ErrorAction SilentlyContinue) {
        foreach($name in 'MicrosoftWindowsPowerShellV2','MicrosoftWindowsPowerShellV2Root') {
            Invoke-ToolStep "Legacy feature: $name" {
                $feature=Get-WindowsOptionalFeature -Online -FeatureName $name
                if ($null -eq $feature -or -not $feature.PSObject.Properties['State']) { Write-Host "Optional feature $name is not available on this Windows version."; return }
                if($feature.State -eq 'Enabled'){$null=Disable-WindowsOptionalFeature -Online -FeatureName $name -NoRestart}
            }
        }
    }
}
if (-not $KeepWinRM) {
    . Invoke-ToolStep 'Disable WinRM; retain SSH and RDP' {
        $service=Get-Service WinRM -ErrorAction SilentlyContinue
        if($service){Set-Service WinRM -StartupType Disabled;Stop-Service WinRM -Force}
    }
}
. Invoke-ToolStep 'Require SMB encryption' {
    if(-not $SkipSmbEncryption){Set-SmbServerConfiguration -EncryptData $true -Force}
}
if(-not $SkipTlsHardening){. Invoke-ToolStep 'Harden SCHANNEL protocols and ciphers' {Set-TlsHardening}}
. Invoke-ToolStep 'Remove accessibility IFEO hijacks; optional binary removal' {Remove-AccessibilityHijacks}
. Invoke-ToolStep 'Configure additional Defender controls' {Set-ExtendedDefenderHardening}
if($isDC){. Invoke-ToolStep 'Configure additional directory protections and auditing' {Set-ExtendedDirectoryHardening}}
if($dns -and -not $SkipDnsHardening) {
    . Invoke-ToolStep 'Enable DNS query block list and response rate limiting' {
        $current=Get-DnsServerGlobalQueryBlockList
        Set-DnsServerGlobalQueryBlockList -Enable $true -List $current.List
        Set-DnsServerResponseRateLimiting -Mode Enable -Force
        Get-DnsServerResponseRateLimiting | Select-Object Mode,ResponsesPerSec,ErrorsPerSec,WindowInSec
    }
}
. Invoke-ToolStep 'Delete local shadow copies and apply selected recovery/boot options' {Invoke-OptionalHardeningChanges}
if($DisableIPv6 -or $DisableDcom -or $DisableAdminShares -or $DisableRemoteRpc){Write-Warning 'Selected network/management restrictions may need restart and can break applications. SSH/RDP services were not disabled.'}

# Refresh after the local changes; domain/local policy can replace registry values.
$finalRefreshCompleted = $false
. Invoke-ToolStep 'Refresh Group Policy (up to 30 seconds)' {
    Update-LocalGroupPolicy
    $finalRefreshCompleted = $true
}
. Invoke-ToolStep 'Report final policy refresh' {
    if ($finalRefreshCompleted) { Write-Host 'Final policy refresh completed. Retest effective settings and scored services; some changes require sign-out or restart.' }
}

# Apply account policies after gpupdate so this run ends with lockout disabled.
if ($isDC) {
    . Invoke-ToolStep 'Disable default domain account lockout' {
        Import-Module ActiveDirectory
        $domain = Get-ADDomain
        $server = $domain.PDCEmulator
        Set-ADDefaultDomainPasswordPolicy -Identity $domain.DNSRoot -Server $server -LockoutThreshold 0
        if ((Get-ADDefaultDomainPasswordPolicy -Identity $domain.DNSRoot -Server $server).LockoutThreshold -ne 0) {
            throw 'Default domain account lockout is still enabled.'
        }
    }
    . Invoke-ToolStep 'Disable fine-grained domain account lockout' {
        Import-Module ActiveDirectory
        $domain = Get-ADDomain
        $server = $domain.PDCEmulator
        foreach ($policy in Get-ADFineGrainedPasswordPolicy -Filter * -Server $server) {
            Invoke-ToolStep "Disable lockout in password policy $($policy.Name)" {
                Set-ADFineGrainedPasswordPolicy -Identity $policy -Server $server -LockoutThreshold 0
                if ((Get-ADFineGrainedPasswordPolicy -Identity $policy -Server $server).LockoutThreshold -ne 0) {
                    throw 'Fine-grained account lockout is still enabled.'
                }
            }
        }
    }
} else {
    . Invoke-ToolStep 'Disable local account lockout' {
        Invoke-CheckedNative "$env:windir\System32\net.exe" @('accounts', '/lockoutthreshold:0')
        Invoke-CheckedNative "$env:windir\System32\net.exe" @('accounts')
    }
}

if ($KeepWinRM) {
    . Invoke-ToolStep 'Allow WinRM Basic authentication, unencrypted traffic and all IPv4 interfaces' {
        Set-Service WinRM -StartupType Automatic
        Start-Service WinRM
        Import-Module Microsoft.WSMan.Management
        $winrmSettings = @(
            @{Path='WSMan:\localhost\Service\AllowUnencrypted';Value=$true},
            @{Path='WSMan:\localhost\Service\Auth\Basic';Value=$true},
            @{Path='WSMan:\localhost\Service\IPv4Filter';Value='*'}
        )
        foreach ($setting in $winrmSettings) {
            # Policy-managed values may already be correct and reject Set-Item.
            if ([string](Get-Item -LiteralPath $setting.Path).Value -ne [string]$setting.Value) {
                Set-Item -LiteralPath $setting.Path -Value $setting.Value -Force
            }
            if ([string](Get-Item -LiteralPath $setting.Path).Value -ne [string]$setting.Value) {
                throw "WinRM setting did not apply: $($setting.Path). Check overriding management policy."
            }
        }
    }
}

. Invoke-ToolStep 'Read back Defender ASR rules' {
    if ($asrConfigured) {
        $effective = Get-MpPreference
        $effectiveIds = @($effective.AttackSurfaceReductionRules_Ids)
        $effectiveActions = @($effective.AttackSurfaceReductionRules_Actions)
        foreach ($id in $rules.Keys) {
            $index = [array]::IndexOf($effectiveIds, $id)
            $action = if ($index -ge 0 -and $index -lt $effectiveActions.Count) { $effectiveActions[$index] } else { $null }
            [pscustomobject]@{ Rule = $rules[$id]; Id = $id; ReportedAction = $action }
            if ($null -eq $action -or ($desired -eq 1 -and $action -ne 1) -or ($desired -eq 2 -and $action -notin 1, 2)) {
                Write-Warning "ASR $id does not report the requested action. Check platform support, tamper protection and management policy."
            }
        }
    }
}

Show-ToolSummary
