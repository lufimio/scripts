#Requires -Version 3.0
[CmdletBinding()]
param(
    [switch]$Apply,
    [switch]$AuditOnly,
    [switch]$NoPrompt,
    [switch]$Detailed,
    [switch]$PassThru,
    [string]$SaveBaselineTo,
    [string]$CompareTo,
    [switch]$SkipLogging,
    [ValidateRange(10, 2048)][int]$LogSizeMB = 200,
    [string]$LogPath = (Join-Path $env:windir 'System32\dns\dns.log'),
    [switch]$RestartDns,
    [switch]$DisableRecursion,
    [switch]$LockFileZoneUpdates,
    [switch]$RestrictZoneTransfers,
    [string[]]$AllowZoneTransferTo = @(),
    [string[]]$RemoveFromDnsAdmins = @(),
    [ValidateSet('LogOnly', 'Enable', 'Disable')][string]$ResponseRateLimiting,
    [string[]]$ApprovedDnsServers = @(),
    [switch]$EnforceDnsServers,
    [switch]$RestoreHostsFile,
    [switch]$DisableWpad,
    [string]$BackupRoot = (Join-Path $env:ProgramData 'CCDC\DNS')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not (New-Object Security.Principal.WindowsPrincipal($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this script from an elevated PowerShell session.'
}
foreach ($address in $AllowZoneTransferTo) {
    $parsed = $null
    if (-not [Net.IPAddress]::TryParse($address, [ref]$parsed) -or $parsed.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork) {
        throw "AllowZoneTransferTo must be IPv4 addresses: $address"
    }
}
if ($AllowZoneTransferTo.Count -and -not $RestrictZoneTransfers) { throw '-AllowZoneTransferTo requires -RestrictZoneTransfers.' }
if ($EnforceDnsServers -and -not $ApprovedDnsServers.Count) { throw '-EnforceDnsServers requires -ApprovedDnsServers.' }
foreach ($address in $ApprovedDnsServers) {
    $parsed = $null
    if (-not [Net.IPAddress]::TryParse($address, [ref]$parsed) -or $parsed.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork) {
        throw "ApprovedDnsServers must be IPv4 addresses: $address"
    }
}
if ($SaveBaselineTo -and (Test-Path -LiteralPath $SaveBaselineTo)) { throw 'SaveBaselineTo already exists; choose a new file.' }
if ($CompareTo -and -not (Test-Path -LiteralPath $CompareTo -PathType Leaf)) { throw 'CompareTo file was not found.' }

if ($AuditOnly -and $Apply) { throw '-AuditOnly and -Apply cannot be combined.' }
if (-not $AuditOnly) { $Apply = [switch]$true }

$script:Findings = New-Object 'System.Collections.Generic.List[object]'
$script:BackupDirectory = $null
$script:Sequence = 0
$script:Failures = 0
$script:RestartWanted = $false
$script:Snapshot = $null
$script:SnapshotSaved = $false
$script:Changed = 0

function Add-Finding {
    param([string]$Area, [string]$Target, [string]$Risk, [string]$Detail, [string]$NextStep)
    $script:Findings.Add([pscustomobject]@{
        Area = $Area; Target = $Target; Risk = $Risk; Detail = $Detail; NextStep = $NextStep
    })
}
function Get-Prop {
    param([object]$Object, [string]$Name)
    if ($null -eq $Object) { return $null }
    $property = $Object.PSObject.Properties[$Name]
    if ($null -ne $property) { return $property.Value }
    return $null
}
function Get-RegValue {
    param([string]$Path, [string]$Name)
    $key = Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
    if ($null -eq $key) { return $null }
    return $key.GetValue($Name, $null)
}
function Get-DisplayTarget {
    param([string]$Target)
    if ($Target.StartsWith('HKLM:\')) { return ($Target -split '\\')[-1] }
    return $Target
}
function Test-PrivateIPv4 {
    param([string]$Address)
    $ip = $null
    if (-not [Net.IPAddress]::TryParse($Address, [ref]$ip) -or $ip.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork) { return $false }
    $b = $ip.GetAddressBytes()
    return ($b[0] -eq 10 -or $b[0] -eq 127 -or ($b[0] -eq 172 -and $b[1] -ge 16 -and $b[1] -le 31) -or ($b[0] -eq 192 -and $b[1] -eq 168) -or ($b[0] -eq 169 -and $b[1] -eq 254))
}
function Invoke-Check {
    param([string]$Name, [scriptblock]$Action)
    try { & $Action }
    catch {
        $script:Failures++
        Add-Finding $Name $env:COMPUTERNAME 'ERROR' $_.Exception.Message 'Check failed; this area has NOT been verified.'
        Write-Warning "$Name failed: $($_.Exception.Message)"
    }
}
function Save-State {
    param([string]$Name, [object]$Value)
    if (-not $script:BackupDirectory) {
        if (-not [IO.Path]::IsPathRooted($BackupRoot) -or $BackupRoot.StartsWith('\\')) { throw 'BackupRoot must be an absolute local path.' }
        # Reject reparse-point ancestors before writing recovery material.
        $ancestor = [IO.DirectoryInfo]$BackupRoot
        while ($null -ne $ancestor) {
            if ($ancestor.Exists -and ($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Backup path contains a reparse point: $($ancestor.FullName)" }
            $ancestor = $ancestor.Parent
        }
        $path = Join-Path $BackupRoot ((Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N'))
        $null = New-Item -ItemType Directory -Path $path -Force
        $acl = New-Object Security.AccessControl.DirectorySecurity
        $acl.SetAccessRuleProtection($true, $false)
        foreach ($sidText in 'S-1-5-18', 'S-1-5-32-544') {
            $sid = New-Object Security.Principal.SecurityIdentifier($sidText)
            $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($sid, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')))
        }
        Set-Acl -LiteralPath $path -AclObject $acl
        $script:BackupDirectory = $path
        Write-Host "Recovery files: $path"
    }
    $script:Sequence++
    $file = Join-Path $script:BackupDirectory (('{0:D4}-{1}.json' -f $script:Sequence, ($Name -replace '[^a-zA-Z0-9_-]', '_')))
    ConvertTo-Json -InputObject $Value -Depth 8 | Set-Content -LiteralPath $file -Encoding UTF8
}
function Invoke-Fix {
    param([string]$Target, [string]$Description, [scriptblock]$Action)
    if ($Apply) {
        try {
            if ($script:Snapshot -and -not $script:SnapshotSaved) { Save-State 'pre-change-snapshot' $script:Snapshot; $script:SnapshotSaved = $true }
            & $Action
            $script:Changed++
            Add-Finding 'Change' $Target 'CHANGED' $Description 'Rerun with -AuditOnly and confirm scored DNS still resolves.'
        } catch {
            $script:Failures++
            Add-Finding 'Change' $Target 'ERROR' "$Description failed: $($_.Exception.Message)" 'Partial changes may exist; inspect the saved recovery files.'
            Write-Warning "$Description failed for ${Target}: $($_.Exception.Message)"
        }
    }
}
function Test-RegistrySetting {
    param([string]$Path, [string]$Name, [int]$Value, [string]$Area, [string]$NextStep = 'Apply with -Apply and verify effective policy (a GPO can overwrite it).')
    $current = Get-RegValue $Path $Name
    if ($null -ne $current -and $current -eq $Value) { return }
    Add-Finding $Area "$Path\$Name" 'REVIEW' "Current=$current; required=$Value (an absent value uses the OS default)." $NextStep
    Invoke-Fix "$Path\$Name" "Set DWORD to $Value" {
        Save-State 'registry' @{ Path = $Path; Name = $Name; Value = $current; Existed = ($null -ne $current) }
        if (-not (Test-Path -LiteralPath $Path)) { $null = New-Item -Path $Path -Force }
        $null = New-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -PropertyType DWord -Force
        if ([int](Get-RegValue $Path $Name) -ne $Value) { throw 'Registry readback failed.' }
    }
}
function Get-RecordData {
    param([object]$Record)
    $parts = foreach ($property in $Record.RecordData.CimInstanceProperties) {
        if ($property.Name -ne 'PSComputerName') { '{0}={1}' -f $property.Name, $property.Value }
    }
    return ($parts -join '; ')
}
function Get-TransferMode {
    param([object]$Zone)
    $value = [string](Get-Prop $Zone 'SecureSecondaries')
    if ($value -match 'Any' -or $value -eq '0') { return 'Any' }
    if ($value -match 'ZoneNameServer' -or $value -eq '1') { return 'NameServers' }
    if ($value -match 'Secure' -or $value -eq '2') { return 'Listed' }
    if ($value -match 'NoTransfer' -or $value -eq '3') { return 'None' }
    return 'Unknown'
}
function Get-DnsSnapshot {
    $settings = New-Object 'System.Collections.Generic.List[object]'
    $records = New-Object 'System.Collections.Generic.List[object]'
    $zones = @(Get-DnsServerZone | Where-Object { -not [bool](Get-Prop $_ 'IsAutoCreated') })
    foreach ($zone in $zones) {
        $zoneName = [string]$zone.ZoneName
        foreach ($property in 'ZoneType', 'IsDsIntegrated', 'DynamicUpdate', 'SecureSecondaries') {
            $settings.Add([pscustomobject]@{ Key = "zone:${zoneName}:${property}"; Value = [string](Get-Prop $zone $property) })
        }
        $secondaries = @(Get-Prop $zone 'SecondaryServers') | Where-Object { $_ } | ForEach-Object { [string]$_ }
        $settings.Add([pscustomobject]@{ Key = "zone:${zoneName}:SecondaryServers"; Value = ($secondaries -join ',') })
        if ([string](Get-Prop $zone 'ZoneType') -eq 'Forwarder') { continue }
        try {
            foreach ($record in Get-DnsServerResourceRecord -ZoneName $zoneName) {
                if ($record.RecordType -eq 'SOA') { continue }
                $records.Add([pscustomobject]@{
                    Zone = $zoneName; Host = [string]$record.HostName; Type = [string]$record.RecordType
                    Data = (Get-RecordData $record); TTL = [int]$record.TimeToLive.TotalSeconds
                    Static = ($null -eq $record.Timestamp)
                })
            }
        } catch {
            Add-Finding 'Record collection' $zoneName 'REVIEW' "Could not read records: $($_.Exception.Message)" 'The zone may be paused, shut down or not loaded. Records in it were not checked.'
        }
    }
    foreach ($forwarder in @(Get-DnsServerForwarder)) {
        $settings.Add([pscustomobject]@{ Key = 'server:Forwarders'; Value = (@($forwarder.IPAddress | ForEach-Object { [string]$_ }) -join ',') })
        $settings.Add([pscustomobject]@{ Key = 'server:UseRootHint'; Value = [string](Get-Prop $forwarder 'UseRootHint') })
    }
    $recursion = Get-DnsServerRecursion
    $settings.Add([pscustomobject]@{ Key = 'server:RecursionEnabled'; Value = [string](Get-Prop $recursion 'Enable') })
    $settings.Add([pscustomobject]@{ Key = 'server:ServerLevelPluginDll'; Value = [string](Get-RegValue 'HKLM:\SYSTEM\CurrentControlSet\Services\DNS\Parameters' 'ServerLevelPluginDll') })
    return [pscustomobject]@{
        SchemaVersion = 1; Computer = $env:COMPUTERNAME; Collected = (Get-Date).ToString('o')
        Settings = $settings.ToArray(); Records = $records.ToArray()
    }
}
function Compare-DnsSnapshot {
    param([object]$Before, [object]$After)
    $changes = New-Object 'System.Collections.Generic.List[object]'
    $old = @{}
    $new = @{}
    foreach ($s in @($Before.Settings | Where-Object { $_ })) { $old[[string]$s.Key] = [string]$s.Value }
    foreach ($s in @($After.Settings | Where-Object { $_ })) { $new[[string]$s.Key] = [string]$s.Value }
    foreach ($key in $new.Keys) {
        if (-not $old.ContainsKey($key)) { $changes.Add([pscustomobject]@{ Change = 'SETTING ADDED'; Item = $key; Old = ''; New = $new[$key]; Static = $true }) }
        elseif ($old[$key] -cne $new[$key]) { $changes.Add([pscustomobject]@{ Change = 'SETTING CHANGED'; Item = $key; Old = $old[$key]; New = $new[$key]; Static = $true }) }
    }
    foreach ($key in $old.Keys) {
        if (-not $new.ContainsKey($key)) { $changes.Add([pscustomobject]@{ Change = 'SETTING REMOVED'; Item = $key; Old = $old[$key]; New = ''; Static = $true }) }
    }
    $oldRecords = @{}
    $newRecords = @{}
    foreach ($r in @($Before.Records | Where-Object { $_ })) { $oldRecords[('{0}|{1}|{2}|{3}' -f $r.Zone, $r.Host, $r.Type, $r.Data).ToLowerInvariant()] = $r }
    foreach ($r in @($After.Records | Where-Object { $_ })) { $newRecords[('{0}|{1}|{2}|{3}' -f $r.Zone, $r.Host, $r.Type, $r.Data).ToLowerInvariant()] = $r }
    foreach ($key in $newRecords.Keys) {
        if (-not $oldRecords.ContainsKey($key)) {
            $r = $newRecords[$key]
            $changes.Add([pscustomobject]@{ Change = 'RECORD ADDED'; Item = "$($r.Zone) $($r.Host) $($r.Type)"; Old = ''; New = $r.Data; Static = [bool]$r.Static })
        }
    }
    foreach ($key in $oldRecords.Keys) {
        if (-not $newRecords.ContainsKey($key)) {
            $r = $oldRecords[$key]
            $changes.Add([pscustomobject]@{ Change = 'RECORD REMOVED'; Item = "$($r.Zone) $($r.Host) $($r.Type)"; Old = $r.Data; New = ''; Static = [bool]$r.Static })
        }
    }
    return $changes.ToArray()
}
function Get-DnsAclEntry {
    param([string]$DistinguishedName)
    $entry = New-Object DirectoryServices.DirectoryEntry("LDAP://$env:COMPUTERNAME/$DistinguishedName")
    $entry.psbase.AuthenticationType = [DirectoryServices.AuthenticationTypes]::Secure -bor [DirectoryServices.AuthenticationTypes]::Signing -bor [DirectoryServices.AuthenticationTypes]::Sealing
    $entry.psbase.Options.SecurityMasks = [DirectoryServices.SecurityMasks]::Dacl
    try {
        foreach ($ace in $entry.psbase.ObjectSecurity.GetAccessRules($true, $true, [Security.Principal.SecurityIdentifier])) {
            if ($ace.AccessControlType -ne 'Allow') { continue }
            [pscustomobject]@{ Sid = $ace.IdentityReference.Value; Rights = $ace.ActiveDirectoryRights; Inherited = $ace.IsInherited }
        }
    } finally { $entry.psbase.Dispose() }
}
function Test-DnsHealth {
    param([string[]]$Names, [string[]]$Servers)
    foreach ($item in $Names) {
        $parts = $item -split '\|'
        $ok = $false
        $detail = 'No answer from any local address.'
        foreach ($server in $Servers) {
            try {
                $answer = @(Resolve-DnsName -Name $parts[0] -Type $parts[1] -Server $server -DnsOnly -QuickTimeout -ErrorAction Stop)
                if ($answer.Count) { $ok = $true; $detail = "Answered by $server."; break }
            } catch { $detail = "$server : $($_.Exception.Message)" }
        }
        [pscustomobject]@{ Name = $parts[0]; Type = $parts[1]; Ok = $ok; Detail = $detail }
    }
}
function Read-Choice {
    param([string]$Question, [string]$Warning, [switch]$TypeYes)
    if ($Warning) { Write-Host $Warning -ForegroundColor Yellow }
    if ($TypeYes) {
        $answer = Read-Host "$Question (type YES to enable; anything else skips)"
        return ($answer -ceq 'YES')
    }
    $answer = Read-Host "$Question [y/N]"
    return ($answer -match '^\s*y(es)?\s*$')
}
function Read-IPv4List {
    param([string]$Question)
    $list = New-Object 'System.Collections.Generic.List[string]'
    $answer = Read-Host $Question
    foreach ($item in @($answer -split '[,; ]+' | Where-Object { $_ })) {
        $parsed = $null
        if ([Net.IPAddress]::TryParse($item, [ref]$parsed) -and $parsed.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork) { $list.Add($item) }
        else { Write-Warning "Ignored '$item': not an IPv4 address." }
    }
    return ,$list.ToArray()
}
function Show-Report {
    param([object[]]$Findings)
    Write-Host ''
    Write-Host 'DNS AUDIT RESULTS' -ForegroundColor Cyan
    Write-Host "$env:COMPUTERNAME | $($Findings.Count) observations | $script:Failures failed checks/changes"
    $counts = foreach ($risk in 'ERROR', 'HIGH', 'REVIEW', 'CHANGED', 'INFO', 'SKIPPED', 'OK') {
        $count = @($Findings | Where-Object Risk -eq $risk).Count
        if ($count) { "$risk`: $count" }
    }
    Write-Host ($counts -join '   |   ')
    Write-Host 'REVIEW items are candidates for investigation, not confirmed vulnerabilities.'
    if ($Detailed) {
        foreach ($group in $Findings | Group-Object Area | Sort-Object Name) {
            Write-Host "`n$($group.Name) ($($group.Count))" -ForegroundColor Cyan
            Write-Host (($group.Group | Select-Object Risk, Target, Detail, NextStep | Format-List | Out-String -Width 120).TrimEnd())
        }
    } else {
        $urgent = @($Findings | Where-Object { $_.Risk -in 'ERROR', 'HIGH' } | Sort-Object @{ Expression = { if ($_.Risk -eq 'ERROR') { 0 } else { 1 } } }, Area, Target)
        if ($urgent.Count) {
            Write-Host "`nHIGH PRIORITY / FAILED CHECKS" -ForegroundColor Yellow
            $rows = $urgent | Select-Object Risk, Area, @{ Name = 'Target'; Expression = { Get-DisplayTarget $_.Target } }, Detail
            Write-Host (($rows | Format-Table -Wrap -AutoSize | Out-String -Width 120).TrimEnd())
        } else { Write-Host "`nNo HIGH or ERROR findings. Review the remaining observations." }
        $changed = @($Findings | Where-Object Risk -eq 'CHANGED')
        if ($changed.Count) {
            Write-Host "`nCHANGES MADE" -ForegroundColor Green
            Write-Host (($changed | Select-Object Target, Detail | Format-Table -Wrap -AutoSize | Out-String -Width 120).TrimEnd())
        }
        $review = @($Findings | Where-Object Risk -eq 'REVIEW' | Group-Object Area | Sort-Object Name)
        if ($review.Count) {
            Write-Host "`nMANUAL REVIEW" -ForegroundColor Cyan
            $rows = foreach ($group in $review) {
                $examples = @($group.Group | ForEach-Object { Get-DisplayTarget $_.Target } | Select-Object -Unique -First 2)
                [pscustomobject]@{ Area = $group.Name; Items = $group.Count; Examples = $examples -join ', ' }
            }
            Write-Host (($rows | Format-Table -Wrap -AutoSize | Out-String -Width 120).TrimEnd())
        }
        Write-Host "`nUse -Detailed for evidence and next steps; -PassThru for filtering/export."
    }
    Write-Host 'Findings reflect the pre-change state. Rerun with -AuditOnly to confirm; this is not proof of complete protection.'
}

# ---------------------------------------------------------------- context
$os = Get-CimInstance Win32_OperatingSystem
$computer = Get-CimInstance Win32_ComputerSystem
$build = [int]$os.BuildNumber
$productType = [int]$os.ProductType
$isDC = [int]$computer.DomainRole -in 4, 5
$domainJoined = [bool]$computer.PartOfDomain
$dnsService = Get-Service -Name DNS -ErrorAction SilentlyContinue
$serverMode = ($null -ne $dnsService) -and [bool](Get-Module -ListAvailable -Name DnsServer)
$dnsRunning = $serverMode -and ($dnsService.Status -eq 'Running')
$selfAddresses = @('127.0.0.1') + @(Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True' | ForEach-Object { $_.IPAddress } | Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' })
$dnsParameters = 'HKLM:\SYSTEM\CurrentControlSet\Services\DNS\Parameters'
# ---------------------------------------------------------------- questions for the risky options
$interactive = $Apply -and -not $NoPrompt -and [Environment]::UserInteractive -and $Host.Name -ne 'Default Host'
if ($interactive) {
    try {
        Write-Host ''
        Write-Host 'The low-risk fixes will be applied automatically. Answer each risky option (Enter = no).' -ForegroundColor Cyan
        if ($serverMode) {
            if (-not $RestartDns -and $dnsRunning -and (Read-Choice 'Restart the DNS service at the end if a change needs it (SIGRed value, plugin DLL, socket pool)?' 'A restart briefly interrupts DNS answers to scoring and clients.')) { $RestartDns = [switch]$true }
            if (-not $RestrictZoneTransfers -and (Read-Choice 'Restrict zone transfers to the zones'' NS servers (plus extra IPs you list)?' 'MACCDC packets say the primary DNS MUST allow zone transfers. Say yes only if no scored secondary or inject needs to pull zones from any address.')) {
                $RestrictZoneTransfers = [switch]$true
                $extra = @(Read-IPv4List 'Extra secondary/scoring DNS IPs allowed to pull zones (comma separated, Enter for none)')
                if ($extra.Count) { $AllowZoneTransferTo = $extra }
            }
            if (-not $LockFileZoneUpdates -and (Read-Choice 'Turn dynamic updates OFF on file-backed (non-AD) zones?' 'DHCP and hosts that register themselves will stop updating those zones.')) { $LockFileZoneUpdates = [switch]$true }
            if (-not $RemoveFromDnsAdmins.Count) {
                $names = Read-Host 'Accounts to remove from DnsAdmins (comma separated, Enter for none)'
                $RemoveFromDnsAdmins = @($names -split '[,;]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
            }
            if (-not $ResponseRateLimiting -and (Get-Command Set-DnsServerResponseRateLimiting -ErrorAction SilentlyContinue)) {
                $mode = Read-Host 'DNS response rate limiting mode: LogOnly, Enable, Disable (Enter to skip)'
                if ($mode -in 'LogOnly', 'Enable', 'Disable') { $ResponseRateLimiting = $mode }
            }
            if (-not $DisableRecursion) {
                if ($isDC) { Write-Host 'Recursion stays on: this is a domain controller (AD clients need it).' }
                elseif (Read-Choice 'Disable recursion (authoritative-only DNS)?' 'NCCDC forbids disabling DNS lookup capabilities, and forwarders and root hints stop working. Almost never correct for a scored host.' -TypeYes) { $DisableRecursion = [switch]$true }
            }
        }
        if (-not $ApprovedDnsServers.Count -and -not $EnforceDnsServers) {
            $approved = @(Read-IPv4List 'Set client DNS servers on every adapter to these IPs, team DNS first (comma separated, Enter to skip)')
            if ($approved.Count) { $ApprovedDnsServers = $approved; $EnforceDnsServers = [switch]$true }
        }
        if (-not $RestoreHostsFile -and (Read-Choice 'Replace the hosts file with a comment-only file (original is saved)?' 'Breaks any name the packet intentionally maps in hosts.')) { $RestoreHostsFile = [switch]$true }
        if (-not $DisableWpad -and (Read-Choice 'Disable WinHTTP proxy auto-discovery (WPAD)?' 'Breaks hosts that find their proxy automatically.')) { $DisableWpad = [switch]$true }
    } catch { Write-Warning "Questions skipped: $($_.Exception.Message)" }
}
Write-Host "Host: $env:COMPUTERNAME | $($os.Caption) build $build | DC: $isDC | DNS role: $serverMode (running: $dnsRunning) | Apply=$Apply"
if ($Apply) { Write-Warning 'Zone, logging and resolver changes affect a scored service. Confirm DNS still resolves from another host after this finishes.' }

# ---------------------------------------------------------------- DNS Server role
$healthBefore = @()
$dcNames = @()
if ($serverMode -and -not $dnsRunning) {
    Add-Finding 'DNS service' 'DNS' 'HIGH' "DNS Server is installed but the service is $($dnsService.Status)." 'Start it (Start-Service DNS) and read the DNS Server event log. If red team stopped it, check ServerLevelPluginDll and zone files first.'
}

Invoke-Check 'DNS service integrity' {
    if (-not $serverMode) { return }
    $service = Get-CimInstance Win32_Service -Filter "Name='DNS'"
    $expectedPath = Join-Path $env:windir 'System32\dns.exe'
    $actualPath = ([string]$service.PathName).Trim().Trim('"')
    if ($actualPath -ine $expectedPath) {
        Add-Finding 'DNS service integrity' 'DNS' 'HIGH' "Service binary is '$actualPath', expected '$expectedPath'." 'Investigate the replacement binary and the service ImagePath change (events 7045, 4697, Sysmon 13).'
    }
    if ([string]$service.StartName -ne 'LocalSystem') {
        Add-Finding 'DNS service integrity' 'DNS' 'HIGH' "Service runs as '$($service.StartName)'; expected LocalSystem." 'Check who changed the logon account (event 4697, 7045) and reset it.'
    }
    $plugin = Get-RegValue $dnsParameters 'ServerLevelPluginDll'
    if ($plugin) {
        $script:RestartWanted = $true
        Add-Finding 'DNS plugin DLL' 'ServerLevelPluginDll' 'HIGH' "A DNS plugin DLL is configured: $plugin. A DnsAdmins member can set this to run code as SYSTEM on the DNS server." 'Remove it, restart DNS (an already loaded DLL stays in memory until restart), then hunt for the DLL, and check DnsAdmins members and event 770.'
        Invoke-Fix 'ServerLevelPluginDll' 'Remove the DNS plugin DLL registry value (original saved)' {
            Save-State 'plugin-dll' @{ Path = $dnsParameters; Name = 'ServerLevelPluginDll'; Value = $plugin }
            Remove-ItemProperty -LiteralPath $dnsParameters -Name 'ServerLevelPluginDll'
            if ($null -ne (Get-RegValue $dnsParameters 'ServerLevelPluginDll')) { throw 'Registry readback failed.' }
        }
    }
    # SIGRed (CVE-2020-1350): 2012 through 2019 and 1803-2004 are affected; 2022 and later are not.
    if ($productType -ne 1 -and $build -lt 20348) {
        $packet = Get-RegValue $dnsParameters 'TcpReceivePacketSize'
        if ($null -eq $packet -or [int64]$packet -gt 65280) {
            $script:RestartWanted = $true
            Add-Finding 'SIGRed workaround' 'TcpReceivePacketSize' 'REVIEW' "Value is '$packet' (absent means the 65535 default). Patch status is not verified; this registry value is Microsoft's stopgap for CVE-2020-1350." 'Apply sets 65280 (0xFF00); it takes effect after the DNS service restarts. Inbound TCP responses over 65280 bytes are dropped; zone transfers are not affected.'
            Invoke-Fix 'TcpReceivePacketSize' 'Set DWORD 65280 (SIGRed workaround)' {
                Save-State 'sigred' @{ Path = $dnsParameters; Name = 'TcpReceivePacketSize'; Value = $packet; Existed = ($null -ne $packet) }
                $null = New-ItemProperty -LiteralPath $dnsParameters -Name 'TcpReceivePacketSize' -Value 65280 -PropertyType DWord -Force
                if ([int64](Get-RegValue $dnsParameters 'TcpReceivePacketSize') -ne 65280) { throw 'Registry readback failed.' }
            }
        }
    }
    $pool = Get-RegValue $dnsParameters 'SocketPoolSize'
    if ($null -ne $pool -and [int]$pool -lt 2500) {
        $script:RestartWanted = $true
        Add-Finding 'DNS socket pool' 'SocketPoolSize' 'REVIEW' "SocketPoolSize=$pool; the default is 2500 and 0 disables source-port randomization (cache poisoning protection)." 'Apply restores 2500 using dnscmd; it takes effect after the DNS service restarts.'
        Invoke-Fix 'SocketPoolSize' 'Restore socket pool size 2500 with dnscmd' {
            Save-State 'socket-pool' @{ Path = $dnsParameters; Name = 'SocketPoolSize'; Value = $pool }
            & dnscmd.exe /Config /SocketPoolSize 2500 | Out-Null
            if ($LASTEXITCODE -ne 0) { throw "dnscmd failed: $LASTEXITCODE" }
        }
    }
}

if ($dnsRunning) {
    Invoke-Check 'DNS snapshot and records' {
        $healthTargets = New-Object 'System.Collections.Generic.List[string]'
        $script:Snapshot = Get-DnsSnapshot
        if ($isDC) {
            Import-Module ActiveDirectory
            $script:dcNamesLocal = @(Get-ADDomainController -Filter * -Server $env:COMPUTERNAME | ForEach-Object { ([string]$_.HostName).ToLowerInvariant() })
            $domainDns = (Get-ADDomain -Server $env:COMPUTERNAME).DNSRoot
            $healthTargets.Add("_ldap._tcp.dc._msdcs.${domainDns}|SRV")
        }
        foreach ($zone in @(Get-DnsServerZone | Where-Object { -not [bool](Get-Prop $_ 'IsAutoCreated') -and -not [bool](Get-Prop $_ 'IsReverseLookupZone') -and $_.ZoneType -eq 'Primary' -and $_.ZoneName -ne 'TrustAnchors' } | Select-Object -First 6)) {
            $healthTargets.Add("$($zone.ZoneName)|SOA")
        }
        $script:HealthTargets = $healthTargets.ToArray()
        $script:HealthBefore = @(Test-DnsHealth -Names $script:HealthTargets -Servers $selfAddresses)
        foreach ($result in $script:HealthBefore) {
            $risk = if ($result.Ok) { 'OK' } else { 'HIGH' }
            Add-Finding 'DNS health (before)' "$($result.Name) $($result.Type)" $risk $result.Detail 'A failing lookup against this server before any change means DNS is already broken or restricted; fix that first.'
        }
        $recordCount = @($script:Snapshot.Records).Count
        Add-Finding 'Record inventory' $env:COMPUTERNAME 'INFO' "Zones=$(@(Get-DnsServerZone | Where-Object { -not [bool](Get-Prop $_ 'IsAutoCreated') }).Count); records=$recordCount." 'Save a baseline with -SaveBaselineTo once scoring is confirmed healthy, then compare later with -CompareTo.'
        if ($SaveBaselineTo) {
            $parent = Split-Path -Parent $SaveBaselineTo
            if ($parent -and -not (Test-Path -LiteralPath $parent)) { $null = New-Item -ItemType Directory -Path $parent -Force }
            ConvertTo-Json -InputObject $script:Snapshot -Depth 6 | Set-Content -LiteralPath $SaveBaselineTo -Encoding UTF8
            Add-Finding 'Baseline' $SaveBaselineTo 'INFO' "Baseline saved ($recordCount records). Keep a copy somewhere red team cannot reach." 'Compare later with -CompareTo.'
        }
        if ($CompareTo) {
            $baseline = Get-Content -LiteralPath $CompareTo -Raw | ConvertFrom-Json
            if ((Get-Prop $baseline 'SchemaVersion') -ne 1 -or $null -eq (Get-Prop $baseline 'Records')) { throw 'CompareTo is not a baseline created by this script.' }
            $changes = @(Compare-DnsSnapshot -Before $baseline -After $script:Snapshot)
            if (-not $changes.Count) { Add-Finding 'Record changes' $CompareTo 'OK' 'No setting or record differences from the baseline.' '' }
            $shown = 0
            foreach ($change in $changes | Sort-Object @{ Expression = { -not $_.Static } }, Change, Item) {
                if ($shown -ge 150) { break }
                $risk = if ($change.Static) { 'HIGH' } else { 'REVIEW' }
                Add-Finding 'Record changes' $change.Item $risk "$($change.Change): old=[$($change.Old)] new=[$($change.New)]" 'Confirm with the team who made this change. If unexpected, revert it and treat as red team activity (DNS Audit log, event 5136, DNS debug log).'
                $shown++
            }
            if ($changes.Count -gt $shown) { Add-Finding 'Record changes' $CompareTo 'REVIEW' "$($changes.Count - $shown) more differences not listed." 'Rerun with -PassThru and filter, or compare the JSON files directly.' }
        }
        # Heuristics on current records.
        $flags = 0
        foreach ($record in @($script:Snapshot.Records)) {
            if ($flags -ge 60) { break }
            $reverse = $record.Zone -match 'arpa$'
            if (-not $reverse -and ($record.Host -eq '*' -or $record.Host.StartsWith('*.'))) {
                Add-Finding 'Suspicious record' "$($record.Zone) $($record.Host) $($record.Type)" 'REVIEW' "Wildcard record: $($record.Data)." 'A wildcard answers every unknown name and can redirect users; delete it unless the packet requires it.'; $flags++
            }
            if ($record.Host -cmatch 'A{20,}' -or $record.Host -match '(?i)1UWhRCA') {
                Add-Finding 'Suspicious record' "$($record.Zone) $($record.Host) $($record.Type)" 'HIGH' "Host name looks like a marshalled-target record used for CVE-2025-33073 coercion: $($record.Data) (static=$($record.Static))." 'Delete it, require signing, and check events 5140/5145 from the host to itself (heuristic, may false-positive).'; $flags++
            }
            elseif (@($record.Host -split '\.' | Where-Object { $_.Length -ge 50 }).Count) {
                Add-Finding 'Suspicious record' "$($record.Zone) $($record.Host) $($record.Type)" 'REVIEW' 'A label of 50 or more characters is unusual and can indicate tunneling or an exploit marker.' 'Check who created it (DNS Audit log) and whether any service uses it.'; $flags++
            }
            if ($record.Type -eq 'TXT' -and $record.Data.Length -gt 120) {
                Add-Finding 'Suspicious record' "$($record.Zone) $($record.Host) TXT" 'REVIEW' "Long TXT record ($($record.Data.Length) characters) can carry C2 or exfiltration data." 'Confirm it is a legitimate SPF/DKIM/verification record.'; $flags++
            }
            if ($record.Type -eq 'SRV' -and $record.Host -match '^_(ldap|kerberos|kpasswd|gc)\.' -and $script:dcNamesLocal.Count -and $record.Data -match 'DomainName=([^;]+)') {
                $target = $Matches[1].Trim().TrimEnd('.').ToLowerInvariant()
                if ($target -notin $script:dcNamesLocal) {
                    Add-Finding 'Suspicious record' "$($record.Zone) $($record.Host) SRV" 'HIGH' "Domain-controller locator record points at $target, which is not a domain controller." 'A rogue SRV record steers logons and Kerberos to an attacker. Delete it after confirming with the team.'; $flags++
                }
            }
        }
    }

    Invoke-Check 'DNS zones' {
        $zones = @(Get-DnsServerZone | Where-Object { -not [bool](Get-Prop $_ 'IsAutoCreated') -and $_.ZoneName -ne 'TrustAnchors' })
        $other = @($zones | Where-Object { $_.ZoneType -ne 'Primary' })
        if ($other.Count) { Add-Finding 'DNS zones' $env:COMPUTERNAME 'INFO' "$($other.Count) non-primary zone(s): $(($other | ForEach-Object { "$($_.ZoneName) ($($_.ZoneType))" }) -join ', '). Transfer and update settings are controlled on the primary server." 'Run this script on the primary DNS server for those zones.' }
        $aclZones = New-Object 'System.Collections.Generic.List[string]'
        foreach ($zone in @($zones | Where-Object { $_.ZoneType -eq 'Primary' })) {
            $zoneName = [string]$zone.ZoneName
            $dsIntegrated = [bool](Get-Prop $zone 'IsDsIntegrated')
            $mode = Get-TransferMode $zone
            if ($mode -eq 'Any') {
                Add-Finding 'Zone transfer' $zoneName 'REVIEW' 'Zone transfers are allowed to ANY server (AXFR hands the full record list to anyone who asks). Past MACCDC packets require the primary DNS server to allow zone transfers, so this may be intentional.' 'Confirm which secondaries must pull this zone, then use -RestrictZoneTransfers (with -AllowZoneTransferTo for the scoring or secondary DNS IPs). Do not choose NoTransfer if a scored secondary DNS server exists.'
                if ($RestrictZoneTransfers) {
                    $nsIps = New-Object 'System.Collections.Generic.List[string]'
                    foreach ($ip in $AllowZoneTransferTo) { $nsIps.Add($ip) }
                    foreach ($ns in @(Get-DnsServerResourceRecord -ZoneName $zoneName -RRType NS -ErrorAction SilentlyContinue)) {
                        $nsHost = [string](Get-Prop (Get-Prop $ns 'RecordData') 'NameServer')
                        if (-not $nsHost) { continue }
                        try {
                            foreach ($a in @(Resolve-DnsName -Name $nsHost -Type A -Server 127.0.0.1 -DnsOnly -ErrorAction Stop | Where-Object { $_.Type -eq 'A' })) {
                                if ($a.IPAddress -notin $nsIps) { $nsIps.Add([string]$a.IPAddress) }
                            }
                        } catch { }
                    }
                    Invoke-Fix $zoneName "Restrict zone transfers to NS servers and -AllowZoneTransferTo ($($nsIps -join ', '))" {
                        Save-State 'zone-transfer' @{ Zone = $zoneName; SecureSecondaries = [string](Get-Prop $zone 'SecureSecondaries'); SecondaryServers = @(Get-Prop $zone 'SecondaryServers' | ForEach-Object { [string]$_ }) }
                        if ($nsIps.Count) {
                            Set-DnsServerPrimaryZone -Name $zoneName -SecureSecondaries TransferToSecureServers -SecondaryServers $nsIps.ToArray() -Notify NotifyServers -NotifyServers $nsIps.ToArray()
                        } else {
                            Set-DnsServerPrimaryZone -Name $zoneName -SecureSecondaries TransferToZoneNameServer
                        }
                        if ((Get-TransferMode (Get-DnsServerZone -Name $zoneName)) -eq 'Any') { throw 'Zone readback still shows transfers to any server.' }
                    }
                }
            } elseif ($mode -eq 'Unknown') {
                Add-Finding 'Zone transfer' $zoneName 'REVIEW' "Could not interpret SecureSecondaries value '$([string](Get-Prop $zone 'SecureSecondaries'))'." 'Check with Get-DnsServerZone and dnsmgmt.msc.'
            } else { Add-Finding 'Zone transfer' $zoneName 'OK' "Transfers: $mode." '' }
            $update = [string](Get-Prop $zone 'DynamicUpdate')
            if ($update -eq 'NonsecureAndSecure') {
                if ($dsIntegrated) {
                    Add-Finding 'Dynamic update' $zoneName 'HIGH' 'Unauthenticated dynamic updates are allowed: anyone who can reach UDP/TCP 53 can add or overwrite records.' 'Set to Secure (this script). Non-domain hosts that register themselves (Linux, printers) will stop registering; existing and static records are unaffected.'
                    Invoke-Fix $zoneName 'Set dynamic updates to Secure only (AD-integrated zone)' {
                        Save-State 'zone-update' @{ Zone = $zoneName; DynamicUpdate = $update }
                        Set-DnsServerPrimaryZone -Name $zoneName -DynamicUpdate Secure
                        if ([string](Get-Prop (Get-DnsServerZone -Name $zoneName) 'DynamicUpdate') -ne 'Secure') { throw 'Zone readback does not show Secure.' }
                    }
                } else {
                    Add-Finding 'Dynamic update' $zoneName 'HIGH' 'Unauthenticated dynamic updates on a file-backed zone. Secure updates need an AD-integrated zone.' 'Convert the zone to AD-integrated, or use -LockFileZoneUpdates to turn dynamic updates off (breaks DHCP/host self-registration).'
                    if ($LockFileZoneUpdates) {
                        Invoke-Fix $zoneName 'Turn dynamic updates off on a file-backed zone' {
                            Save-State 'zone-update' @{ Zone = $zoneName; DynamicUpdate = $update }
                            Set-DnsServerPrimaryZone -Name $zoneName -DynamicUpdate None
                            if ([string](Get-Prop (Get-DnsServerZone -Name $zoneName) 'DynamicUpdate') -ne 'None') { throw 'Zone readback does not show None.' }
                        }
                    }
                }
            } else { Add-Finding 'Dynamic update' $zoneName 'OK' "Dynamic update: $update." '' }
            if ($isDC -and $dsIntegrated -and (Get-Prop $zone 'DistinguishedName')) {
                try {
                    $broad = @(Get-DnsAclEntry ([string]$zone.DistinguishedName) | Where-Object { $_.Sid -eq 'S-1-5-11' -and ($_.Rights -band [DirectoryServices.ActiveDirectoryRights]::CreateChild) })
                    if ($broad.Count) { $aclZones.Add($zoneName) }
                } catch { Add-Finding 'Zone ACL' $zoneName 'REVIEW' "Could not read the zone ACL: $($_.Exception.Message)" 'Check manually in ADSI Edit.' }
            }
        }
        if ($aclZones.Count) {
            Add-Finding 'Zone ACL' ($aclZones -join ', ') 'REVIEW' 'Authenticated Users can create child objects (DNS records) in these zones. This is the AD default, and it lets any domain user plant records (CVE-2025-33073 prerequisite).' 'Only remove it if no new domain machine must register itself: ADSI Edit on the zone object, remove Authenticated Users Create all child objects. Not automated because it can stop new hosts from registering.'
        }
    }

    Invoke-Check 'DNS server settings' {
        $recursion = Get-DnsServerRecursion
        if (-not [bool](Get-Prop $recursion 'SecureResponse')) {
            Add-Finding 'Cache pollution' 'SecureResponse' 'HIGH' 'The server caches every record a remote server returns, including records outside that server''s zone.' 'Enable SecureResponse (this script).'
            Invoke-Fix 'Recursion SecureResponse' 'Enable SecureResponse so only in-zone records are cached' {
                Save-State 'recursion' @{ SecureResponse = (Get-Prop $recursion 'SecureResponse'); Enable = (Get-Prop $recursion 'Enable') }
                Set-DnsServerRecursion -SecureResponse $true
                if (-not [bool](Get-Prop (Get-DnsServerRecursion) 'SecureResponse')) { throw 'Readback failed.' }
            }
        } else { Add-Finding 'Cache pollution' 'SecureResponse' 'OK' 'SecureResponse is on.' '' }
        $forwarders = @(Get-DnsServerForwarder | ForEach-Object { $_.IPAddress } | Where-Object { $_ } | ForEach-Object { [string]$_ })
        if ([bool](Get-Prop $recursion 'Enable')) {
            Add-Finding 'Recursion' $env:COMPUTERNAME 'INFO' "Recursion is on. Forwarders: $(if ($forwarders.Count) { $forwarders -join ', ' } else { 'none (root hints)' })." 'Normal for an AD DNS server that serves clients. Keep port 53 open to all sources on scored DNS (packets forbid subnet blocks; block single attacker IPs only). Use Response Rate Limiting on 2016+ against amplification. Confirm the forwarders match the packet.'
            if ($DisableRecursion) {
                Write-Warning 'Disabling recursion stops forwarders and root hints. NCCDC prohibits disabling DNS lookup capabilities and AD clients need recursion. Do not use on a DC or the team DNS server.'
                Invoke-Fix 'Recursion' 'Disable recursion (forwarders also stop working)' {
                    Save-State 'recursion' @{ Enable = $true; Forwarders = $forwarders }
                    Set-DnsServerRecursion -Enable $false
                    if ([bool](Get-Prop (Get-DnsServerRecursion) 'Enable')) { throw 'Readback failed.' }
                }
            }
        } else { Add-Finding 'Recursion' $env:COMPUTERNAME 'INFO' 'Recursion is off; this server only answers for zones it hosts. Forwarders are not used while recursion is off.' 'Fine for an authoritative-only server. Clients that rely on this server for external names will fail.' }
        $cache = Get-DnsServerCache
        $locking = Get-Prop $cache 'LockingPercent'
        if ($null -ne $locking -and [int]$locking -lt 100) {
            Add-Finding 'Cache locking' 'LockingPercent' 'REVIEW' "Cache locking is $locking percent (100 is full protection against overwriting cached records before TTL expiry)." 'Set to 100 (this script).'
            Invoke-Fix 'LockingPercent' 'Set cache locking to 100 percent' {
                Save-State 'cache-locking' @{ LockingPercent = $locking }
                Set-DnsServerCache -LockingPercent 100
                if ([int](Get-Prop (Get-DnsServerCache) 'LockingPercent') -ne 100) { throw 'Readback failed.' }
            }
        }
        $blockList = Get-DnsServerGlobalQueryBlockList
        $names = @((Get-Prop $blockList 'List') | Where-Object { $_ } | ForEach-Object { ([string]$_).ToLowerInvariant() })
        $missing = @('wpad', 'isatap' | Where-Object { $_ -notin $names })
        if (-not [bool](Get-Prop $blockList 'Enable') -or $missing.Count) {
            Add-Finding 'Global query block list' 'GlobalQueryBlockList' 'HIGH' "Block list enabled=$([bool](Get-Prop $blockList 'Enable')); missing names: $($missing -join ', '). WPAD and ISATAP names are hijacked to redirect proxy and tunnel traffic." 'Enable it and include wpad and isatap (this script keeps your other entries).'
            Invoke-Fix 'GlobalQueryBlockList' 'Enable the global query block list with wpad and isatap' {
                Save-State 'block-list' @{ Enable = (Get-Prop $blockList 'Enable'); List = $names }
                Set-DnsServerGlobalQueryBlockList -Enable $true -List @($names + $missing | Select-Object -Unique)
            }
        }
        if ($ResponseRateLimiting) {
            if (Get-Command Set-DnsServerResponseRateLimiting -ErrorAction SilentlyContinue) {
                $rrl = Get-DnsServerResponseRateLimiting
                Invoke-Fix 'ResponseRateLimiting' "Set response rate limiting mode to $ResponseRateLimiting" {
                    Save-State 'rrl' @{ Mode = [string](Get-Prop $rrl 'Mode') }
                    Set-DnsServerResponseRateLimiting -Mode $ResponseRateLimiting -Force
                }
            } else { Add-Finding 'Response rate limiting' $env:COMPUTERNAME 'SKIPPED' 'This Windows Server version has no response rate limiting (Server 2016 and later only).' 'Use firewall scoping instead.' }
        }
        try {
            $setting = Get-DnsServerSetting -All
            $listen = @((Get-Prop $setting 'ListeningIPAddress') | Where-Object { $_ } | ForEach-Object { [string]$_ })
            Add-Finding 'Listening addresses' $env:COMPUTERNAME 'INFO' "DNS listens on: $(if ($listen.Count) { $listen -join ', ' } else { 'all addresses' })." 'On a multi-homed host, restrict listening to internal addresses (dnscmd /ResetListenAddresses <ip>, then restart DNS) if an interface faces an untrusted network.'
        } catch { Add-Finding 'Listening addresses' $env:COMPUTERNAME 'SKIPPED' "Could not read listening addresses: $($_.Exception.Message)" '' }
    }

    Invoke-Check 'DNS logging' {
        if ($SkipLogging) { Add-Finding 'DNS logging' $env:COMPUTERNAME 'SKIPPED' 'Skipped by -SkipLogging.' ''; return }
        $diagnostics = Get-DnsServerDiagnostics
        $command = Get-Command Set-DnsServerDiagnostics
        # The update flag is named differently across documentation and versions; use whichever this host has.
        $updateName = if ($command.Parameters.ContainsKey('Update')) { 'Update' } elseif ($command.Parameters.ContainsKey('Updates')) { 'Updates' } else { $null }
        $wanted = [ordered]@{
            EnableLoggingToFile = $true; EnableLogFileRollover = $true; Queries = $true; Answers = $true
            Notifications = $true; SendPackets = $true; ReceivePackets = $true; UdpPackets = $true
            TcpPackets = $true; QuestionTransactions = $true; FullPackets = $false; UseSystemEventLog = $true
        }
        if ($updateName) { $wanted[$updateName] = $true }
        $off = @($wanted.Keys | Where-Object { $_ -notin 'FullPackets' -and $command.Parameters.ContainsKey($_) -and -not [bool](Get-Prop $diagnostics $_) })
        $pathNow = [string](Get-Prop $diagnostics 'LogFilePath')
        if ($off.Count -or ($pathNow -ine $LogPath)) {
            Add-Finding 'DNS logging' $env:COMPUTERNAME 'HIGH' "DNS debug logging is incomplete (off: $($off -join ', '); log file: '$pathNow'). Without it you cannot see queries, updates or zone changes, and Splunk gets nothing." "Enable it (this script) to $LogPath with rollover at $LogSizeMB MB; Splunk monitors dns*.log in that folder."
            Invoke-Fix 'DNS debug logging' "Enable DNS debug logging to $LogPath (rollover $LogSizeMB MB, no full packets)" {
                Save-State 'dns-diagnostics' $diagnostics
                $arguments = @{}
                foreach ($key in $wanted.Keys) { if ($command.Parameters.ContainsKey($key)) { $arguments[$key] = $wanted[$key] } }
                if ($command.Parameters.ContainsKey('LogFilePath')) { $arguments['LogFilePath'] = $LogPath }
                if ($command.Parameters.ContainsKey('MaxMBFileSize')) { $arguments['MaxMBFileSize'] = [uint32]$LogSizeMB }
                if ($command.Parameters.ContainsKey('EventLogLevel')) { $arguments['EventLogLevel'] = [uint32]4 }
                Set-DnsServerDiagnostics @arguments
                if (-not [bool](Get-Prop (Get-DnsServerDiagnostics) 'EnableLoggingToFile')) { throw 'Readback does not show file logging enabled.' }
            }
        } else { Add-Finding 'DNS logging' $env:COMPUTERNAME 'OK' "DNS debug logging is on: $pathNow." '' }
        $channel = 'Microsoft-Windows-DNSServer/Audit'
        $info = & wevtutil.exe gl $channel
        if ($LASTEXITCODE -ne 0) {
            Add-Finding 'DNS audit log' $channel 'SKIPPED' 'This Windows Server version has no DNS Server Audit channel (Server 2012 R2 and later).' 'Use the debug log and event 5136 on a DC.'
        } elseif (-not ($info | Select-String -Pattern '^\s*enabled:\s*true' -Quiet)) {
            Add-Finding 'DNS audit log' $channel 'REVIEW' 'The DNS Server Audit channel is disabled; it records zone, record and setting changes.' 'Enable it (this script).'
            Invoke-Fix $channel 'Enable the DNS Server Audit event channel' {
                Save-State 'dns-audit-channel' @{ Channel = $channel; Enabled = $false }
                & wevtutil.exe sl $channel /e:true
                if ($LASTEXITCODE -ne 0) { throw "wevtutil failed: $LASTEXITCODE" }
            }
        } else { Add-Finding 'DNS audit log' $channel 'OK' 'Audit channel is enabled.' '' }
    }

    Invoke-Check 'DnsAdmins and DNS container permissions' {
        $members = @()
        if ($isDC) {
            Import-Module ActiveDirectory
            $members = @(Get-ADGroupMember -Identity 'DnsAdmins' -Server $env:COMPUTERNAME | ForEach-Object { [string]$_.SamAccountName })
        } else {
            $group = [ADSI]"WinNT://$env:COMPUTERNAME/DnsAdmins,group"
            $members = @($group.psbase.Invoke('Members') | ForEach-Object { $_.GetType().InvokeMember('Name', 'GetProperty', $null, $_, $null) })
        }
        foreach ($member in $members) {
            Add-Finding 'DnsAdmins' $member 'REVIEW' 'Direct member of DnsAdmins. Members can load a DLL into the DNS service (SYSTEM, on a DC this reaches Domain Admin). Treat as Domain Admin.' 'Remove anyone who is not needed with -RemoveFromDnsAdmins <name>. Nested groups are shown as groups.'
        }
        if (-not $members.Count) { Add-Finding 'DnsAdmins' 'DnsAdmins' 'OK' 'DnsAdmins has no direct members.' '' }
        foreach ($identityName in $RemoveFromDnsAdmins) {
            if ($identityName -notin $members) { throw "$identityName is not a direct member of DnsAdmins." }
            Invoke-Fix $identityName 'Remove from DnsAdmins' {
                Save-State 'dnsadmins' @{ Removed = $identityName; Members = $members }
                if ($isDC) { Remove-ADGroupMember -Identity 'DnsAdmins' -Members $identityName -Confirm:$false -Server $env:COMPUTERNAME }
                else { & net.exe localgroup DnsAdmins $identityName /delete | Out-Null; if ($LASTEXITCODE -ne 0) { throw "net localgroup failed: $LASTEXITCODE" } }
            }
        }
        if ($isDC) {
            $domain = Get-ADDomain -Server $env:COMPUTERNAME
            $forestRoot = Get-ADDomain -Identity (Get-ADForest -Server $env:COMPUTERNAME).RootDomain -Server $env:COMPUTERNAME
            $dnsAdminsSid = (Get-ADGroup -Identity 'DnsAdmins' -Server $env:COMPUTERNAME).SID.Value
            $trusted = @('S-1-5-18', 'S-1-5-32-544', 'S-1-5-9', 'S-1-3-0', $dnsAdminsSid, "$($domain.DomainSID.Value)-512", "$($domain.DomainSID.Value)-500", "$($forestRoot.DomainSID.Value)-519")
            $write = [DirectoryServices.ActiveDirectoryRights]::GenericAll -bor [DirectoryServices.ActiveDirectoryRights]::GenericWrite -bor [DirectoryServices.ActiveDirectoryRights]::WriteDacl -bor [DirectoryServices.ActiveDirectoryRights]::WriteOwner -bor [DirectoryServices.ActiveDirectoryRights]::WriteProperty -bor [DirectoryServices.ActiveDirectoryRights]::CreateChild -bor [DirectoryServices.ActiveDirectoryRights]::Delete -bor [DirectoryServices.ActiveDirectoryRights]::DeleteTree
            foreach ($ace in @(Get-DnsAclEntry "CN=MicrosoftDNS,CN=System,$($domain.DistinguishedName)")) {
                if ($ace.Sid -in $trusted -or -not ($ace.Rights -band $write)) { continue }
                Add-Finding 'MicrosoftDNS container ACL' $ace.Sid 'REVIEW' "Non-default write access to the DNS configuration container: rights=$($ace.Rights); inherited=$($ace.Inherited). With RPC access to the DC this is enough to load a plugin DLL without being in DnsAdmins." 'Resolve the SID, confirm it is expected, and remove it in ADSI Edit (CN=System > CN=MicrosoftDNS > Security).'
            }
        }
    }
}

# ---------------------------------------------------------------- Restart and post-change health
if ($script:RestartWanted -and $dnsRunning) {
    if ($Apply -and $RestartDns) {
        Invoke-Check 'DNS restart' {
            Invoke-Fix 'DNS service' 'Restart the DNS service (a few seconds of DNS outage) to apply the plugin, socket pool and SIGRed changes' {
                Restart-Service -Name DNS -Force
                $deadline = (Get-Date).AddSeconds(45)
                while ((Get-Service -Name DNS).Status -ne 'Running' -and (Get-Date) -lt $deadline) { Start-Sleep -Seconds 2 }
                if ((Get-Service -Name DNS).Status -ne 'Running') { throw 'DNS did not return to Running within 45 seconds. Start it manually and read the DNS Server event log.' }
            }
        }
    } elseif ($Apply) {
        Add-Finding 'DNS restart' 'DNS' 'REVIEW' 'The plugin, socket pool or SIGRed change takes effect only after the DNS service restarts.' 'Restart-Service DNS when a few seconds of outage is acceptable, or rerun with -Apply -RestartDns.'
    }
}
if ($Apply -and $script:Changed -and $dnsRunning -and (Get-Variable -Name HealthTargets -Scope Script -ErrorAction SilentlyContinue)) {
    Invoke-Check 'DNS health (after)' {
        $after = @(Test-DnsHealth -Names $script:HealthTargets -Servers $selfAddresses)
        foreach ($result in $after) {
            $wasOk = [bool](@($script:HealthBefore | Where-Object { $_.Name -eq $result.Name -and $_.Type -eq $result.Type -and $_.Ok }).Count)
            $risk = if ($result.Ok) { 'OK' } elseif ($wasOk) { 'HIGH' } else { 'REVIEW' }
            $note = if ($risk -eq 'HIGH') { 'REGRESSION: this lookup worked before the changes. Restore the old values from the saved recovery files and retest.' } else { '' }
            Add-Finding 'DNS health (after)' "$($result.Name) $($result.Type)" $risk $result.Detail $note
        }
    }
}

# ---------------------------------------------------------------- Client resolver (every Windows host)
Invoke-Check 'DNS client' {
    $resolver = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient'
    Test-RegistrySetting $resolver 'EnableMulticast' 0 'LLMNR' 'LLMNR lets any host on the segment answer name lookups (Responder). Set to 0.'
    Test-RegistrySetting $resolver 'DisableSmartNameResolution' 1 'Multi-homed name resolution' 'Stops DNS queries going out every adapter in parallel.'
    if ($build -ge 15063) {
        Test-RegistrySetting 'HKLM:\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters' 'EnableMDNS' 0 'mDNS' 'Multicast DNS is another spoofable local name source (Windows 10 1703 and Server 2019 and later).'
    }
    $wpad = Get-RegValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\WinHttp' 'DisableWpad'
    if ($wpad -ne 1) {
        Add-Finding 'WPAD' 'DisableWpad' 'REVIEW' 'WinHTTP still auto-discovers proxies through the wpad name, which attackers answer via LLMNR/DNS.' 'Use -DisableWpad if no host here needs proxy auto-discovery (the DNS server block list already covers the server side).'
        if ($DisableWpad) {
            Invoke-Fix 'DisableWpad' 'Set WinHTTP DisableWpad to 1' {
                $winHttp = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\WinHttp'
                Save-State 'wpad' @{ Path = $winHttp; Name = 'DisableWpad'; Value = $wpad; Existed = ($null -ne $wpad) }
                if (-not (Test-Path -LiteralPath $winHttp)) { $null = New-Item -Path $winHttp -Force }
                $null = New-ItemProperty -LiteralPath $winHttp -Name 'DisableWpad' -Value 1 -PropertyType DWord -Force
            }
        }
    }
    $client = Get-CimInstance Win32_Service -Filter "Name='Dnscache'"
    if ($client -and ($client.State -ne 'Running' -or $client.StartMode -eq 'Disabled')) {
        Add-Finding 'DNS Client service' 'Dnscache' 'HIGH' "Dnscache is $($client.State) / $($client.StartMode). Many components, including AD logon and DHCP, depend on it." 'Set it to Automatic and start it (this script). Do not stop it as a CVE workaround.'
        Invoke-Fix 'Dnscache' 'Set the DNS Client service to Automatic and start it' {
            Save-State 'dnscache' @{ State = [string]$client.State; StartMode = [string]$client.StartMode }
            Set-Service -Name Dnscache -StartupType Automatic
            Start-Service -Name Dnscache
        }
    }
    $hostsPath = Join-Path $env:windir 'System32\drivers\etc\hosts'
    $lines = @(Get-Content -LiteralPath $hostsPath -ErrorAction Stop)
    $active = @($lines | Where-Object { $_ -match '^\s*[^#\s]' -and $_ -notmatch '^\s*(127\.0\.0\.1|::1)\s+localhost\s*(#.*)?$' })
    foreach ($line in $active | Select-Object -First 20) {
        Add-Finding 'hosts file' $hostsPath 'REVIEW' "Active entry: $($line.Trim())" 'A hosts entry overrides DNS for that name (used to redirect or block updates and AV). Delete anything you do not recognize.'
    }
    if ($active.Count -gt 20) { Add-Finding 'hosts file' $hostsPath 'REVIEW' "$($active.Count - 20) more active entries not listed." 'Open the file.' }
    if ($active.Count -and $RestoreHostsFile) {
        Invoke-Fix $hostsPath 'Replace the hosts file with a comment-only file (original saved)' {
            Save-State 'hosts-file' @{ Path = $hostsPath; Lines = $lines }
            Set-Content -LiteralPath $hostsPath -Encoding ASCII -Value @('# Reset by dns.ps1. The original was saved in the DNS recovery folder.', '# localhost is resolved internally by Windows.')
        }
    }
    $adapters = @(Get-DnsClientServerAddress -ErrorAction Stop | Where-Object { [int]$_.AddressFamily -eq 2 -and @($_.ServerAddresses).Count -and $_.InterfaceAlias -notmatch 'Loopback' })
    foreach ($adapter in $adapters) {
        $servers = @($adapter.ServerAddresses | ForEach-Object { [string]$_ })
        $bad = @()
        if ($ApprovedDnsServers.Count) { $bad = @($servers | Where-Object { $_ -notin $ApprovedDnsServers -and $_ -ne '127.0.0.1' }) }
        elseif ($domainJoined) { $bad = @($servers | Where-Object { -not (Test-PrivateIPv4 $_) }) }
        if ($bad.Count) {
            $why = if ($ApprovedDnsServers.Count) { 'not in -ApprovedDnsServers' } else { 'is a public resolver; domain members must use the domain DNS servers or logon and Kerberos fail' }
            Add-Finding 'Client DNS servers' $adapter.InterfaceAlias 'HIGH' "DNS server(s) $($bad -join ', ') $why. Configured: $($servers -join ', ')." 'Set the approved servers (use -EnforceDnsServers with -ApprovedDnsServers), or fix it in the adapter properties.'
            if ($EnforceDnsServers) {
                Invoke-Fix $adapter.InterfaceAlias "Set DNS servers to $($ApprovedDnsServers -join ', ')" {
                    Save-State 'client-dns' @{ InterfaceAlias = $adapter.InterfaceAlias; InterfaceIndex = $adapter.InterfaceIndex; ServerAddresses = $servers }
                    Set-DnsClientServerAddress -InterfaceIndex $adapter.InterfaceIndex -ServerAddresses $ApprovedDnsServers
                }
            }
        } else { Add-Finding 'Client DNS servers' $adapter.InterfaceAlias 'INFO' "DNS servers: $($servers -join ', ')." 'Confirm they match the competition packet.' }
    }
}

Add-Finding 'Coverage limits' $env:COMPUTERNAME 'INFO' 'This audits and hardens configuration only. DNS Server and DNS Client patches (for example SIGRed and the 2026 DNS Client/Server advisories reported by secondary sources) are not installed or verified. Record heuristics are indicators, not proof; red team with Domain Admin can undo any setting.' 'Check Microsoft Security Update Guide for your build when patching is possible, and keep a baseline to diff against.'
if ($PassThru) { $script:Findings }
else { Show-Report -Findings $script:Findings.ToArray() }
if ($script:Failures) { throw "$script:Failures checks or changes failed. Review ERROR findings; the assessment is incomplete." }
