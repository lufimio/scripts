#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string[]]$AllowedTCPPorts = @(),
    [string[]]$AllowedUDPPorts = @(),
    [ValidateSet('Custom','DomainController')][string]$Preset = 'Custom',
    [string[]]$RemoteAddress = @('Any'),
    [switch]$Once,
    [switch]$DisableWinRM,
    [ValidateRange(2,3600)][int]$IntervalSeconds = 2,
    [switch]$ListOnly,
    [switch]$Detailed,
    [string[]]$BlockPort = @(),
    [string[]]$UnblockPort = @(),
    [ValidateSet('TCP', 'UDP')][string]$Protocol = 'TCP',
    [switch]$EnableFirewall,
    [switch]$AllowManagementPortBlock,
    [string]$BackupDirectory = (Join-Path $PSScriptRoot 'firewall-backups')
)
# Stop before loading helpers or changing policy if this copy cannot run normally.
$ErrorActionPreference = 'Stop'
if ($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage') { throw 'This script requires FullLanguage. Startup stopped; no firewall changes made.' }
. (Join-Path $PSScriptRoot 'common.ps1')
$script:FirewallBackup = $null
$script:RuleGroup = 'Firewall Port Blocks'

function ConvertTo-PortList {
    param([string[]]$Values)
    foreach ($item in $Values) {
        foreach ($token in $item -split '[,\s]+') {
            $token = $token.Trim()
            if (-not $token) { continue }
            if ($token -notmatch '^(\d{1,5})(?:-(\d{1,5}))?$') { throw "Invalid port/range: $token. Use 445 or 49152-65535." }
            $first = [int]$Matches[1]
            $last = if ($Matches[2]) { [int]$Matches[2] } else { $first }
            if ($first -lt 1 -or $last -gt 65535 -or $first -gt $last) { throw "Invalid port/range: $token" }
            if ($first -eq $last) { "$first" } else { "$first-$last" }
        }
    }
}

function Backup-Firewall {
    if ($script:FirewallBackup) { return }
    if (-not (Test-Path -LiteralPath $BackupDirectory)) { $null = New-Item -ItemType Directory -Path $BackupDirectory }
    $file = Join-Path $BackupDirectory ((Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '-' + [guid]::NewGuid().ToString('N') + '.wfw')
    & "$env:windir\System32\netsh.exe" advfirewall export $file | Out-Null
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $file)) { throw 'Firewall backup failed; no changes made for this action.' }
    $script:FirewallBackup = $file
    Write-ToolStatus "Backup: $file"
    Write-Host "Full rollback (restores the whole previous firewall): netsh advfirewall import `"$file`""
}

function Assert-LocalFirewallControl {
    $profiles = @(Get-NetFirewallProfile -PolicyStore ActiveStore)
    if (@($profiles | Where-Object { "$($_.AllowLocalFirewallRules)" -eq 'False' }).Count) {
        throw 'Domain policy ignores local firewall rules on at least one profile. Change that policy before using local blocks.'
    }
}

function Get-EnabledInboundRules {
    param([string]$Action)
    try { Get-NetFirewallRule -PolicyStore ActiveStore -Enabled True -Direction Inbound -Action $Action -ErrorAction Stop }
    catch {
        # NetSecurity reports an empty CIM query as ObjectNotFound, not an empty array.
        if ($_.FullyQualifiedErrorId -notlike 'CmdletizationQuery_NotFound*') { throw }
    }
}

function Show-Firewall {
    Invoke-ToolStep 'Read firewall profiles and default actions' {
        Get-NetFirewallProfile -PolicyStore ActiveStore |
            Select-Object Name, Enabled, DefaultInboundAction, DefaultOutboundAction, AllowLocalFirewallRules |
            Format-Table -AutoSize | Out-Host
    }
    Invoke-ToolStep 'Read enabled inbound allow rules (all profiles)' {
        Write-Host 'Allow rules show permission candidates. Profiles, addresses, apps/services, IPsec and block rules affect actual reachability.'
        $rows = @(foreach ($rule in Get-EnabledInboundRules Allow) {
            try {
                $ports = $rule | Get-NetFirewallPortFilter
                $addresses = $rule | Get-NetFirewallAddressFilter
                $application = $rule | Get-NetFirewallApplicationFilter
                $service = $rule | Get-NetFirewallServiceFilter
                [pscustomobject]@{
                    Port = @($ports.LocalPort) -join ','; Protocol = "$($ports.Protocol)"
                    Source = @($addresses.RemoteAddress) -join ','; Profile = "$($rule.Profile)"
                    Rule = $rule.DisplayName; Program = $application.Program; Service = $service.Service
                    Policy = $rule.PolicyStoreSourceType
                }
            } catch { Add-ToolFailure "Read allow rule $($rule.DisplayName)" $_ }
        })
        if ($rows.Count) {
            # Do not hide Any, ranges, RPC keywords, or app-only rules.
            if ($Detailed) {
                $rows | Sort-Object Protocol, Port, Rule | Format-Table Protocol, Port, Source, Profile, Rule, Program, Service, Policy -Wrap -AutoSize | Out-Host
            } else {
                $rows | Group-Object Protocol, Port | ForEach-Object {
                    $first = $_.Group[0]
                    $sources = @($_.Group.Source | Sort-Object -Unique)
                    $sourceText = ($sources | Select-Object -First 2) -join '; '
                    if ($sources.Count -gt 2) { $sourceText += " (+$($sources.Count - 2) more)" }
                    [pscustomobject]@{
                        Protocol = $first.Protocol; Port = $first.Port; ServiceFilters = @($_.Group.Service | Sort-Object -Unique) -join '; '; Rules = $_.Count
                        Sources = $sourceText
                        Profiles = @($_.Group.Profile | Sort-Object -Unique) -join '; '
                    }
                } | Sort-Object Protocol, Port | Format-Table -Wrap -AutoSize | Out-Host
                Write-Host 'Grouped by port. Sources/profiles summarize different rules; they do not describe a single combined allowance. Use -Detailed for exact per-rule filters, programs and services.'
            }
        } else { Write-Host 'No enabled inbound allow rules collected.' }
        Write-Host "Allow rules collected: $($rows.Count). Any means all ports for that protocol, subject to the other filters."
    }
    Invoke-ToolStep 'Read listening TCP ports and bound UDP ports' {
        $processNames = @{}
        Get-Process | ForEach-Object { $processNames[[int]$_.Id] = $_.ProcessName }
        $serviceOwners = @{}
        Get-CimInstance Win32_Service | Where-Object { $_.ProcessId -gt 0 } | ForEach-Object { if (-not $serviceOwners.ContainsKey([int]$_.ProcessId)) { $serviceOwners[[int]$_.ProcessId] = @() }; $serviceOwners[[int]$_.ProcessId] += $_.Name }
        $listeners = @(
            Get-NetTCPConnection -State Listen | ForEach-Object {
                [pscustomobject]@{ Protocol = 'TCP'; Port = $_.LocalPort; Address = $_.LocalAddress; Process = $processNames[[int]$_.OwningProcess]; Services = @($serviceOwners[[int]$_.OwningProcess]) -join ',' }
            }
            Get-NetUDPEndpoint | ForEach-Object {
                [pscustomobject]@{ Protocol = 'UDP'; Port = $_.LocalPort; Address = $_.LocalAddress; Process = $processNames[[int]$_.OwningProcess]; Services = @($serviceOwners[[int]$_.OwningProcess]) -join ',' }
            }
        )
        $listeners | Sort-Object Protocol, Port, Address | Format-Table Protocol, Port, Address, Process, Services -Wrap -AutoSize | Out-Host
        Write-Host 'A listener is not proof the firewall allows it. UDP entries are bound endpoints.'
    }
    Invoke-ToolStep 'Read enabled inbound block rules' {
        foreach ($rule in Get-EnabledInboundRules Block) {
            try {
                $ports = $rule | Get-NetFirewallPortFilter
                [pscustomobject]@{ Protocol = $ports.Protocol; Port = @($ports.LocalPort) -join ','; Rule = $rule.DisplayName; Profile = $rule.Profile }
            } catch { Add-ToolFailure "Read block rule $($rule.DisplayName)" $_ }
        }
    } | Format-Table -AutoSize | Out-Host
    Write-Host 'If a profile is disabled, its firewall does not filter traffic. Use -EnableFirewall to enable all profiles.'
    Write-Host 'Allowlist mode sets default inbound Block and disables unselected TCP/UDP allowances. Outbound policy is preserved.'
}

function Set-PortBlock {
    param([string[]]$Ports, [string]$Transport, [bool]$Remove = $false)
    # Validate the entire request before changing anything.
    $normalized = @(ConvertTo-PortList $Ports | Sort-Object -Unique)
    foreach ($port in $normalized) {
        Invoke-ToolStep "$(if ($Remove) { 'Undo firewall block' } else { 'Block inbound' }) $Transport $port" {
            if (-not $Remove -and $Transport -eq 'TCP' -and -not $AllowManagementPortBlock) {
                $ends = $port -split '-'
                $low = [int]$ends[0]; $high = if ($ends.Count -eq 2) { [int]$ends[1] } else { $low }
                $managementPorts = @(Get-ManagementPorts | ForEach-Object { [int]$_ })
                if (@($managementPorts | Where-Object { $_ -ge $low -and $_ -le $high }).Count) {
                    throw 'Range includes a management port. Use the VM console and -AllowManagementPortBlock if you intend to disconnect management.'
                }
            }
            $ruleName = "Firewall-Block-$Transport-$port"
            Assert-LocalFirewallControl
            Backup-Firewall
            $existing = Get-NetFirewallRule -PolicyStore PersistentStore -Name $ruleName -ErrorAction SilentlyContinue
            if ($Remove) {
                if ($existing -and $existing.Group -eq $script:RuleGroup) { $existing | Remove-NetFirewallRule }
                elseif ($existing) { throw 'Rule name belongs to another rule group; refusing to remove it.' }
                else { Write-Host 'This tool has no matching block to remove.' }
            } else {
                if ($existing -and $existing.Group -ne $script:RuleGroup) { throw 'Rule name belongs to another rule group; refusing to overwrite it.' }
                if ($existing) {
                    $existing | Set-NetFirewallRule -Enabled True -Action Block -Direction Inbound -Profile Any -Protocol $Transport -LocalPort $port -RemoteAddress Any -LocalAddress Any -Program Any -Service Any
                } else {
                    $null = New-NetFirewallRule -PolicyStore PersistentStore -Name $ruleName -DisplayName "Firewall block $Transport $port" -Group $script:RuleGroup -Direction Inbound -Action Block -Enabled True -Profile Any -Protocol $Transport -LocalPort $port -RemoteAddress Any
                }
                $effective = Get-NetFirewallRule -PolicyStore ActiveStore -Name $ruleName -ErrorAction Stop
                if ("$($effective.Enabled)" -ne 'True' -or "$($effective.Action)" -ne 'Block') { throw 'The block is not effective. Review domain policy.' }
            }
            Write-Host 'Undo removes only the exact Tool block. Other blocks/default policy still apply. Split ranges must be undone using the original range.'
        }
    }
}

function Enable-FirewallProfiles {
    Invoke-ToolStep 'Enable firewall on Domain, Private and Public profiles' {
        Assert-LocalFirewallControl
        Backup-Firewall
        Set-NetFirewallProfile -Profile Domain, Private, Public -Enabled True
        $profiles = @(Get-NetFirewallProfile -PolicyStore ActiveStore)
        if (@($profiles | Where-Object { "$($_.Enabled)" -ne 'True' }).Count) { throw 'A firewall profile remains disabled by effective policy.' }
    }
}

function Test-AllowlistedPorts {
    param([string[]]$RulePorts, [string[]]$Allowed)
    # Every point of every rule range must be covered, including adjacent selected ranges.
    $ranges = @(foreach ($value in $Allowed) {
        $parts = $value -split '-'
        [pscustomobject]@{ Low = [int]$parts[0]; High = [int]$parts[-1] }
    }) | Sort-Object Low, High
    if (-not $RulePorts.Count) { return $false }
    foreach ($value in $RulePorts) {
        foreach ($token in $value -split ',') {
            if ($token -notmatch '^(\d{1,5})(?:-(\d{1,5}))?$') { return $false }
            $parts = $token -split '-'; $next = [int]$parts[0]; $end = [int]$parts[-1]
            if ($next -lt 1 -or $end -gt 65535 -or $next -gt $end) { return $false }
            foreach ($range in $ranges) {
                if ($range.High -lt $next) { continue }
                if ($range.Low -gt $next) { break }
                $next = [Math]::Max($next, $range.High + 1)
                if ($next -gt $end) { break }
            }
            if ($next -le $end) { return $false }
        }
    }
    return $true
}

function Get-ManagementPorts {
    $ports = @(22,3389)
    $custom = Get-ItemPropertyValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -Name PortNumber -ErrorAction SilentlyContinue
    if ($custom) { $ports += [int]$custom }
    @($ports | Sort-Object -Unique | ForEach-Object { "$_" })
}

function Initialize-FirewallWatcher {
    $script:KnownInbound = @{}
    $script:WatchReady = $false
}

function Get-FirewallRuleChanges {
    param([object[]]$Rules)
    if (-not $script:WatchReady) { return }
    foreach ($rule in $Rules) {
        $name = [string]$rule.Name
        if (-not $script:KnownInbound.ContainsKey($name)) {
            [pscustomobject]@{ Name=$name; DisplayName=$rule.DisplayName; Change='New inbound rule' }
        } elseif ($script:KnownInbound[$name] -notlike 'True|*' -and "$($rule.Enabled)" -eq 'True' -and "$($rule.Action)" -eq 'Allow') {
            [pscustomobject]@{ Name=$name; DisplayName=$rule.DisplayName; Change='Inbound allow rule re-enabled' }
        }
    }
}

function Complete-FirewallSnapshot {
    param([object[]]$Events)
    # Query after enforcement to include our new rules and remember disabled ones.
    # Updating only after a successful query prevents false alerts on discovery failures.
    $state = @{}
    foreach ($rule in Get-NetFirewallRule -PolicyStore ActiveStore -Direction Inbound -ErrorAction Stop) {
        $state[[string]$rule.Name] = "$($rule.Enabled)|$($rule.Action)"
    }
    foreach ($event in $Events) {
        $outcome = if ($state.ContainsKey($event.Name) -and $state[$event.Name] -like 'True|*') { 'enabled (' + ($state[$event.Name] -split '\|')[1] + ')' } else { 'disabled' }
        Write-ToolStatus "$($event.Change): $($event.DisplayName) -- $outcome" 'ALERT'
    }
    $script:KnownInbound = $state
    $script:WatchReady = $true
}

function Invoke-AllowlistPass {
    # Clear per-pass failures so watch mode stays bounded, retaining deduplicated diagnostics.
    $script:ToolFailures.Clear()
    $script:ToolCompleted = 0
    # Discovery/backup must succeed before changing policy. Every later rule action is isolated.
    Assert-LocalFirewallControl
    $profiles = @(Get-NetFirewallProfile -PolicyStore ActiveStore)
    if (@($profiles | Where-Object { "$($_.AllowInboundRules)" -eq 'False' }).Count) {
        throw 'Effective policy disables inbound allowances. Resolve that policy before applying an allowlist.'
    }
    $allInbound = @(Get-NetFirewallRule -PolicyStore ActiveStore -Direction Inbound -ErrorAction Stop)
    $rules = @($allInbound | Where-Object {"$($_.Enabled)" -eq 'True' -and "$($_.Action)" -eq 'Allow'})
    $events = @(Get-FirewallRuleChanges $allInbound)
    $management = @(Get-ManagementPorts)
    Backup-Firewall
    $before = $script:ToolFailures.Count
    $canonicalScope = New-Object 'System.Collections.Generic.List[string]'
    foreach ($address in $RemoteAddress) { $canonicalScope.Add($address) }
    foreach ($transport in 'TCP','UDP') {
        $selected = if ($transport -eq 'TCP') { $AllowedTCPPorts } else { $AllowedUDPPorts }
        foreach ($port in $selected) {
            Invoke-ToolStep "Ensure allowed $transport $port from $($RemoteAddress -join ',')" {
                $name = "Firewall-Allow-$transport-$port"
                $existing = Get-NetFirewallRule -PolicyStore PersistentStore -Name $name -ErrorAction SilentlyContinue
                if ($existing -and $existing.Group -ne 'Firewall Allowlist') { throw "Rule name belongs to another group: $name" }
                if ($existing) {
                    $existing | Set-NetFirewallRule -Enabled True -Direction Inbound -Action Allow -Profile Any -Protocol $transport -LocalPort $port -RemotePort Any -RemoteAddress $RemoteAddress -LocalAddress Any -Program Any -Service Any
                } else {
                    $null = New-NetFirewallRule -PolicyStore PersistentStore -Name $name -DisplayName "Firewall allow $transport $port" -Group 'Firewall Allowlist' -Direction Inbound -Action Allow -Profile Any -Enabled True -Protocol $transport -LocalPort $port -RemoteAddress $RemoteAddress
                }
                $effective = Get-NetFirewallRule -PolicyStore ActiveStore -Name $name -ErrorAction Stop
                if ("$($effective.Enabled)" -ne 'True' -or "$($effective.Action)" -ne 'Allow') { throw "Allowance not effective: $name" }
                # Windows may return a CIDR as a dotted subnet mask. Compare using
                # the canonical spelling read back from our own effective rule.
                foreach ($address in @(( $effective | Get-NetFirewallAddressFilter ).RemoteAddress)) { $canonicalScope.Add("$address") }
            }
        }
    }
    if ($script:ToolFailures.Count -gt $before) {
        Write-ToolStatus 'Some selected allowances failed. Skipping rule disabling and profile tightening for this pass; later passes retry.' 'WARN'
        Complete-FirewallSnapshot -Events $events
        return
    }
    foreach ($rule in $rules) {
        Invoke-ToolStep "Review inbound allowance: $($rule.DisplayName)" {
            $filter = $rule | Get-NetFirewallPortFilter
            $transport = switch ("$($filter.Protocol)") { '6' {'TCP'}; '17' {'UDP'}; default { "$($filter.Protocol)".ToUpperInvariant() } }
            if ($transport -in 'ICMPV4','ICMPV6','1','58') { return }
            $ports = @($filter.LocalPort | ForEach-Object { "$_" })
            $selected = if ($transport -eq 'TCP') { $AllowedTCPPorts } elseif ($transport -eq 'UDP') { $AllowedUDPPorts } else { @() }
            if ($transport -eq 'TCP' -and -not $AllowManagementPortBlock -and (Test-AllowlistedPorts $ports $management)) {
                Write-ToolStatus "Keep scoped management rule: $($rule.DisplayName) (original address/app filters retained)"
                return
            }
            # RemoteAddress is a scope for the allowlist: retain other rules only if their
            # source scope fits it too. New managed rules replace disallowed broad scopes.
            $addresses = @(( $rule | Get-NetFirewallAddressFilter ).RemoteAddress | ForEach-Object { "$_" })
            $scopeFits = 'Any' -in $RemoteAddress -or @($addresses | Where-Object { $_ -notin $canonicalScope }).Count -eq 0
            if ($transport -in 'TCP','UDP' -and $scopeFits -and (Test-AllowlistedPorts $ports $selected)) { return }
            if ("$($rule.PolicyStoreSourceType)" -notin 'Local','') { throw "Cannot disable policy-managed allowance $($rule.DisplayName). Edit its source GPO; the allowlist is incomplete." }
            Set-NetFirewallRule -PolicyStore PersistentStore -Name $rule.Name -Enabled False
            $remaining = Get-NetFirewallRule -PolicyStore ActiveStore -Name $rule.Name -ErrorAction Stop
            if ("$($remaining.Enabled)" -eq 'True') { throw 'Rule remains enabled in effective policy.' }
            Write-ToolStatus "Disabled: $($rule.DisplayName) [$transport $($ports -join ',')]"
        }
    }
    Invoke-ToolStep 'Enable all profiles, default inbound Block, and log dropped packets' {
        Set-NetFirewallProfile -Profile Domain,Private,Public -Enabled True -DefaultInboundAction Block -LogBlocked True
        foreach ($profile in Get-NetFirewallProfile -PolicyStore ActiveStore) {
            if ("$($profile.Enabled)" -ne 'True' -or "$($profile.DefaultInboundAction)" -ne 'Block') { throw "Effective profile $($profile.Name) did not accept enforcement." }
            Write-ToolStatus "Drop log ($($profile.Name)): $($profile.LogFileName)"
        }
    }
    Complete-FirewallSnapshot -Events $events
}

# Explicit allowlists print their selection below; avoid a full inventory on every CLI apply.
Initialize-FirewallWatcher
if ($ListOnly) { Show-Firewall; Show-ToolSummary; return }
if ($EnableFirewall -or $BlockPort.Count -or $UnblockPort.Count) { Show-Firewall }
if ($EnableFirewall) { Enable-FirewallProfiles }
if ($BlockPort.Count) { Set-PortBlock $BlockPort $Protocol }
if ($UnblockPort.Count) { Set-PortBlock $UnblockPort $Protocol -Remove $true }
if ($ListOnly -or $EnableFirewall -or $BlockPort.Count -or $UnblockPort.Count) { Show-ToolSummary; return }
if ($Preset -eq 'DomainController') {
    $AllowedTCPPorts += '53','88','135','389','445','464','636','3268','3269','9389','49152-65535'
    $AllowedUDPPorts += '53','88','123','389','464'

}
if (-not $PSBoundParameters.ContainsKey('AllowedTCPPorts') -and -not $PSBoundParameters.ContainsKey('AllowedUDPPorts') -and $Preset -eq 'Custom') {
    $AllowedTCPPorts = @((Read-Host 'TCP ports to ALLOW (comma/space separated; ranges accepted)'))
    $AllowedUDPPorts = @((Read-Host 'UDP ports to ALLOW (blank = none)'))
}
$AllowedTCPPorts = @(ConvertTo-PortList $AllowedTCPPorts | Sort-Object -Unique)
$AllowedUDPPorts = @(ConvertTo-PortList $AllowedUDPPorts | Sort-Object -Unique)
Write-Host "`nALLOW TCP: $($AllowedTCPPorts -join ', ') | UDP: $($AllowedUDPPorts -join ', ') | sources: $($RemoteAddress -join ', ')"
Write-Host 'Other TCP/UDP inbound allowances are disabled. ICMP and existing blocks remain. Outbound policy remains.'
if (-not $AllowManagementPortBlock) { Write-Host 'Existing explicit SSH/RDP TCP management allowances are retained with their original scopes. No new management access is added automatically.' }
Write-Host 'Ctrl+C stops watching; firewall changes remain. Only new/re-enabled inbound rules and errors are reported.'
$script:ToolQuiet = $true
if ($DisableWinRM) {
    Invoke-ToolStep 'Disable WinRM service' {
        Set-Service WinRM -StartupType Disabled -ErrorAction Stop
        Stop-Service WinRM -Force -ErrorAction Stop
    }
}
do {
    try { Invoke-AllowlistPass } catch { Add-ToolFailure 'Allowlist enforcement pass' $_ }
    if ($Once) { break }
    Start-Sleep -Seconds $IntervalSeconds
} while ($true)
Show-ToolSummary
