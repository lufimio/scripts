#Requires -Version 5.1
#Requires -RunAsAdministrator
<#
.SYNOPSIS
Audits and hardens Windows DHCP (DHCP Server role and DHCP client behavior) without patching, rebooting, or changing scopes.
.DESCRIPTION
Run elevated on every Windows host. DHCP Server checks run only where the DHCP Server role and the DhcpServer module exist
(Server 2012 and later, including Server Core). Client checks run everywhere (Server, Windows 8.1/10/11 Home, Pro, Enterprise).

By default the low-risk fixes are applied automatically, then a yes/no question is asked for each risky option, at the
moment a problem is found (Enter means no). -AuditOnly makes the whole run read-only, -WhatIf previews every change, and
-NoPrompt skips the questions (they are also skipped automatically when input is redirected, for example over SSH or the
central runner). Scope ranges, lease times, scopes and the DHCP role are never changed or removed.

Why these checks (past CCDC packets): MACCDC 2020, MWCCDC 2019 and NECCDC 2019 ran AD, DNS and DHCP on one Windows Server;
NCCDC 2021 to 2026 require the DHCP service on the AD server(s); NCCDC 2018 to 2020 fix the pool at 10.X.X.101-150;
NCCDC clients must use the team DNS (10.X.X.5) first and 10.120.0.53 second. DHCP is not a scored service name, so the
risk is clients losing addresses, gateway or DNS, which breaks AD logon and scored lookups.

Audit (always):
  Service integrity   DHCPServer service state, ServiceDll, svchost command line, dhcpssvc.dll signature, database paths.
  Callout DLLs        CalloutDlls registry value (code runs as SYSTEM in the DHCP service).
  Authorization       Authorized servers in AD (Get-DhcpServerInDC) and whether this server is one of them.
  Scopes              State, range vs -ExpectedRange, pool usage, bad leases, exclusions, reservations, policies, filters,
                      failover, DHCPv6 scopes, DNS update settings, name protection.
  Options             Server and scope options. Option 6 (DNS) and 3 (router) vs -ExpectedDnsServers / -ExpectedRouters,
                      non-private DNS servers, and options 252 (WPAD), 66, 67, 150 (boot servers).
  Firewall            Whether an enabled inbound allow rule for UDP 67 exists (firewall.ps1 disables other allowances) and
                      whether a firewall.ps1 watcher is running that would disable the rule this script creates.
  Logs                Today's DhcpSrvLog (pool exhausted, address conflicts, rogue-detection events) and DHCP System events.
  Client leases       Which DHCP server handed each adapter its lease (-ApprovedDhcpServers); rogue server detection.
  Baseline            -SaveBaselineTo / -CompareTo of scopes, options, exclusions, reservations, policies, filters, authorization.

Automatic fixes (each only when the current value is weaker):
  Audit logging       DHCP audit log enabled (Splunk can monitor DhcpSrvLog-*.log).
  Callout DLLs        CalloutDlls value removed (original saved first); takes effect after a DHCP service restart.
  Recovery files      Before the first change: Export-DhcpServer (with leases) and Backup-DhcpServer plus a JSON snapshot.

Asked about (or pass the switch to answer yes without a question):
  -AuthorizeServer            Authorize this DHCP server in AD (needs Enterprise Admins). Needed when it is not authorized.
  -EnforceOptions             Reset option 6 / 3 to -ExpectedDnsServers / -ExpectedRouters where they differ.
  -RemoveSuspiciousOptions    Remove options 252, 66, 67 and 150 (WPAD and boot-server options) if present.
  -EnableConflictDetection    Ping before offering an address (ConflictDetectionAttempts 1). Adds a short delay per lease.
  -EnableNameProtection       Name protection on scopes (Server 2012 R2 and later). Test client logons afterwards.
  -BlockDhcpFromIPs           Block UDP 67 from single attacker IPs (never subnets).
  -AllowUdp67                 Create the inbound allow rule for UDP 67 (the only script that opens it; see note below).
  -BlockDhcpv6                Block DHCPv6 (UDP 546/547) and IPv6 router advertisements on this host (mitm6 defense).
  -RestartDhcp                Restart the DHCP service at the end if a change needs it.

Not covered here on purpose: DHCP Administrators and DHCP Users membership (users.ps1 removes accounts from every group),
LLMNR/mDNS/NetBIOS (hardening.ps1), DNS records and zones (dns.ps1), and port allowlisting (firewall.ps1).

UDP 67 is opened only by this script, and only when the DHCP Server role is installed (-AllowUdp67 or a yes to the question).
Do not pass 67 to firewall.ps1. firewall.ps1 disables every inbound allow rule outside its list, including this script's rule,
so run it first and without the watcher (firewall.ps1 -Once), or stop a running watcher, then run dhcp.ps1. If the watcher
keeps running, it will disable this rule again and DHCP stops. This script reports a running watcher as a HIGH finding.

Deliberately NOT done: changing scope ranges or lease times, deleting or deactivating scopes, de-authorizing a server,
MAC allow/deny filters, failover setup, removing the DHCP role, scoping UDP 67 in the Windows firewall (a DHCPDISCOVER comes
from 0.0.0.0, so a remote-address rule can stop all leases; restrict UDP 67 on the perimeter firewall instead), and sending
a probe to find rogue servers (use nmap --script broadcast-dhcp-discover from a workstation). Patching is not done.

Compatibility: Server 2008 R2 and older have no DhcpServer module; use netsh dhcp server export. On a DC, DHCP registers
DNS records as the DC computer account, which works with secure dynamic updates. If DHCP runs on another server and zones
are Secure-only, set Set-DhcpServerDnsCredential with a dedicated low-privilege account instead of using DnsUpdateProxy.
Run the Windows scripts in this order: users.ps1, hardening.ps1, firewall.ps1, dns.ps1, dhcp.ps1.
On a DC that also runs DHCP, run firewall.ps1 -Preset DomainController -Once first (the watcher would disable the UDP 67 rule), then this script.

Backups: before the first change, files are saved under -BackupRoot in a unique SYSTEM/Administrators-only folder:
dhcp-export.xml (restore: Import-DhcpServer -File <xml> -BackupPath <dir> -Leases), dhcp-db (Restore-DhcpServer -Path <dir>)
and JSON files with each old value.

Findings describe the state before changes. Rerun with -AuditOnly to confirm the result.
.EXAMPLE
.\dhcp.ps1
.EXAMPLE
.\dhcp.ps1 -AuditOnly -Detailed
.EXAMPLE
.\dhcp.ps1 -AuditOnly -SaveBaselineTo C:\CCDC\dhcp-baseline.json
.EXAMPLE
.\dhcp.ps1 -AuditOnly -CompareTo C:\CCDC\dhcp-baseline.json
.EXAMPLE
.\dhcp.ps1 -WhatIf
.EXAMPLE
.\dhcp.ps1 -ExpectedDnsServers 10.20.20.5,10.120.0.53 -ExpectedRouters 10.20.20.1 -ExpectedRange 10.20.20.101-10.20.20.150
.EXAMPLE
.\dhcp.ps1 -NoPrompt -EnforceOptions -ExpectedDnsServers 10.20.20.5,10.120.0.53 -RestartDhcp
.LINK
https://learn.microsoft.com/en-us/powershell/module/dhcpserver/
.LINK
https://learn.microsoft.com/en-us/windows-server/networking/technologies/dhcp/dhcp-top
#>
[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
param(
    [switch]$Apply,
    [switch]$AuditOnly,
    [switch]$NoPrompt,
    [switch]$Detailed,
    [switch]$PassThru,
    [string]$SaveBaselineTo,
    [string]$CompareTo,
    [string[]]$ExpectedDnsServers = @(),
    [string[]]$ExpectedRouters = @(),
    [string[]]$ExpectedRange = @(),
    [string[]]$ApprovedDhcpServers = @(),
    [switch]$SkipLogging,
    [switch]$AuthorizeServer,
    [switch]$EnforceOptions,
    [switch]$RemoveSuspiciousOptions,
    [switch]$EnableConflictDetection,
    [switch]$EnableNameProtection,
    [string[]]$BlockDhcpFromIPs = @(),
    [switch]$BlockDhcpv6,
    [switch]$AllowUdp67,
    [switch]$RestartDhcp,
    [string]$BackupRoot = (Join-Path $env:ProgramData 'CCDC\DHCP')
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'common.ps1')

function Split-List {
    param([string[]]$Values)
    @($Values | ForEach-Object { $_ -split '[,;\s]+' } | Where-Object { $_ } | ForEach-Object { $_.Trim() })
}
function Test-IPv4 {
    param([string]$Value)
    $ip = $null
    return ([Net.IPAddress]::TryParse($Value, [ref]$ip) -and $ip.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork)
}
function Assert-IPv4List {
    param([string]$Name, [string[]]$Values)
    foreach ($value in $Values) { if (-not (Test-IPv4 $value)) { throw "$Name must be IPv4 addresses: $value" } }
}

$ExpectedDnsServers = @(Split-List $ExpectedDnsServers)
$ExpectedRouters = @(Split-List $ExpectedRouters)
$ExpectedRange = @(Split-List $ExpectedRange)
$ApprovedDhcpServers = @(Split-List $ApprovedDhcpServers)
$BlockDhcpFromIPs = @(Split-List $BlockDhcpFromIPs)
Assert-IPv4List 'ExpectedDnsServers' $ExpectedDnsServers
Assert-IPv4List 'ExpectedRouters' $ExpectedRouters
Assert-IPv4List 'ApprovedDhcpServers' $ApprovedDhcpServers
Assert-IPv4List 'BlockDhcpFromIPs' $BlockDhcpFromIPs
foreach ($range in $ExpectedRange) {
    $pair = $range -split '-'
    if ($pair.Count -ne 2 -or -not (Test-IPv4 $pair[0]) -or -not (Test-IPv4 $pair[1])) { throw "ExpectedRange must look like 10.20.20.101-10.20.20.150: $range" }
}
if ($EnforceOptions -and -not ($ExpectedDnsServers.Count -or $ExpectedRouters.Count)) { throw '-EnforceOptions requires -ExpectedDnsServers and/or -ExpectedRouters.' }
if ($AuditOnly -and $Apply) { throw '-AuditOnly and -Apply cannot be combined.' }
if ($SaveBaselineTo -and (Test-Path -LiteralPath $SaveBaselineTo)) { throw 'SaveBaselineTo already exists; choose a new file.' }
if ($CompareTo -and -not (Test-Path -LiteralPath $CompareTo -PathType Leaf)) { throw 'CompareTo file was not found.' }
if (-not $AuditOnly) { $Apply = [switch]$true }

$script:Caller = $PSCmdlet
$script:Findings = New-Object 'System.Collections.Generic.List[object]'
$script:BackupDirectory = $null
$script:Sequence = 0
$script:Failures = 0
$script:RestartWanted = $false
$script:Snapshot = $null
$script:PreChangeDone = $false
$script:Changed = 0
$script:Answers = @{}
$script:ServerMode = $false
$script:ScopesBefore = @()

function Add-Finding {
    param([string]$Area, [string]$Target, [string]$Risk, [string]$Detail, [string]$NextStep)
    $script:Findings.Add([pscustomobject]@{ Area = $Area; Target = $Target; Risk = $Risk; Detail = $Detail; NextStep = $NextStep })
}
function Get-Prop {
    param([object]$Object, [string]$Name)
    if ($null -eq $Object) { return $null }
    $property = $Object.PSObject.Properties[$Name]
    if ($null -ne $property) { return $property.Value }
    return $null
}
function Get-RegValue {
    param([string]$Path, [string]$Name)
    $key = Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
    if ($null -eq $key) { return $null }
    return $key.GetValue($Name, $null)
}
function Get-DisplayTarget {
    param([string]$Target)
    if ($Target.StartsWith('HKLM:\')) { return ($Target -split '\\')[-1] }
    return $Target
}
function Test-PrivateIPv4 {
    param([string]$Address)
    if (-not (Test-IPv4 $Address)) { return $false }
    $b = ([Net.IPAddress]::Parse($Address)).GetAddressBytes()
    return ($b[0] -eq 10 -or $b[0] -eq 127 -or ($b[0] -eq 172 -and $b[1] -ge 16 -and $b[1] -le 31) -or ($b[0] -eq 192 -and $b[1] -eq 168) -or ($b[0] -eq 169 -and $b[1] -eq 254))
}
function Invoke-Check {
    param([string]$Name, [scriptblock]$Action)
    try { & $Action }
    catch {
        $script:Failures++
        Add-Finding $Name $env:COMPUTERNAME 'ERROR' $_.Exception.Message 'Check failed; this area has NOT been verified.'
        Write-ToolStatus "$Name failed: $($_.Exception.Message)" 'WARN'
    }
}
function Get-Choice {
    param([string]$Key, [bool]$Preset, [string]$Question, [string]$Warning)
    if ($Preset) { return $true }
    if (-not $Apply -or $NoPrompt) { return $false }
    if ($script:Answers.ContainsKey($Key)) { return [bool]$script:Answers[$Key] }
    $yes = $false
    try {
        if ([Environment]::UserInteractive -and $Host.Name -ne 'Default Host' -and -not [Console]::IsInputRedirected) {
            if ($Warning) { Write-Host $Warning -ForegroundColor Yellow }
            $answer = Read-Host "$Question [y/N]"
            $yes = ($answer -match '^\s*y(es)?\s*$')
        }
    } catch { $yes = $false }
    $script:Answers[$Key] = $yes
    return $yes
}
function Save-State {
    param([string]$Name, [object]$Value)
    if (-not $script:BackupDirectory) {
        if (-not [IO.Path]::IsPathRooted($BackupRoot) -or $BackupRoot.StartsWith('\\')) { throw 'BackupRoot must be an absolute local path.' }
        # Reject reparse-point ancestors before writing recovery material.
        $ancestor = [IO.DirectoryInfo]$BackupRoot
        while ($null -ne $ancestor) {
            if ($ancestor.Exists -and ($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Backup path contains a reparse point: $($ancestor.FullName)" }
            $ancestor = $ancestor.Parent
        }
        $path = Join-Path $BackupRoot ((Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N'))
        $null = New-Item -ItemType Directory -Path $path -Force -WhatIf:$false
        $acl = New-Object Security.AccessControl.DirectorySecurity
        $acl.SetAccessRuleProtection($true, $false)
        foreach ($sidText in 'S-1-5-18', 'S-1-5-32-544') {
            $sid = New-Object Security.Principal.SecurityIdentifier($sidText)
            $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($sid, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')))
        }
        Set-Acl -LiteralPath $path -AclObject $acl -WhatIf:$false
        $script:BackupDirectory = $path
        Write-ToolStatus "Recovery files: $path"
    }
    $script:Sequence++
    $file = Join-Path $script:BackupDirectory (('{0:D4}-{1}.json' -f $script:Sequence, ($Name -replace '[^a-zA-Z0-9_-]', '_')))
    ConvertTo-Json -InputObject $Value -Depth 8 | Set-Content -LiteralPath $file -Encoding UTF8 -WhatIf:$false
}
function Invoke-PreChange {
    if ($script:PreChangeDone) { return }
    if ($script:Snapshot) { Save-State 'pre-change-snapshot' $script:Snapshot } elseif (-not $script:BackupDirectory) { Save-State 'pre-change-marker' @{ Computer = $env:COMPUTERNAME; Time = (Get-Date).ToString('o') } }
    if ($script:ServerMode -and $dhcpService.Status -eq 'Running') {
        $export = Join-Path $script:BackupDirectory 'dhcp-export.xml'
        Export-DhcpServer -File $export -Leases -Force
        $database = Join-Path $script:BackupDirectory 'dhcp-db'
        $null = New-Item -ItemType Directory -Path $database -Force -WhatIf:$false
        Backup-DhcpServer -Path $database
        if (-not (Test-Path -LiteralPath $export)) { throw 'Export-DhcpServer did not produce a file; no changes were made.' }
    }
    $script:PreChangeDone = $true
}
function Invoke-Fix {
    param([string]$Target, [string]$Description, [scriptblock]$Action)
    if ($Apply -and $script:Caller.ShouldProcess($Target, $Description)) {
        try {
            Invoke-PreChange
            & $Action
            $script:Changed++
            Add-Finding 'Change' $Target 'CHANGED' $Description 'Rerun with -AuditOnly and confirm clients still get leases (ipconfig /renew from a workstation).'
        } catch {
            $script:Failures++
            Add-Finding 'Change' $Target 'ERROR' "$Description failed: $($_.Exception.Message)" 'Partial changes may exist; inspect the saved recovery files.'
            Write-ToolStatus "$Description failed for ${Target}: $($_.Exception.Message)" 'WARN'
        }
    }
}
function Get-OptionList {
    param([object]$ScopeId)
    if ($null -eq $ScopeId) { return @(Get-DhcpServerv4OptionValue -ErrorAction SilentlyContinue) }
    return @(Get-DhcpServerv4OptionValue -ScopeId $ScopeId -ErrorAction SilentlyContinue)
}
function Get-AuthorizedDhcpServers {
    # Get-DhcpServerInDC throws a terminating error on a workgroup server or when AD cannot be reached, so guard it.
    $script:AuthorizationError = $null
    if (-not $domainJoined) { return @() }
    try { return @(Get-DhcpServerInDC -ErrorAction Stop) }
    catch { $script:AuthorizationError = $_.Exception.Message; return @() }
}
function Get-DhcpSnapshot {
    $settings = New-Object 'System.Collections.Generic.List[object]'
    $add = { param($key, $value) $settings.Add([pscustomobject]@{ Key = [string]$key; Value = [string]$value }) }
    $serverSetting = Get-DhcpServerSetting
    & $add 'server:IsAuthorized' (Get-Prop $serverSetting 'IsAuthorized')
    & $add 'server:ConflictDetectionAttempts' (Get-Prop $serverSetting 'ConflictDetectionAttempts')
    foreach ($entry in @(Get-AuthorizedDhcpServers)) { & $add ('authorized:' + [string](Get-Prop $entry 'DnsName')) (Get-Prop $entry 'IPAddress') }
    foreach ($option in (Get-OptionList $null)) { & $add ('option:server:' + (Get-Prop $option 'OptionId')) ((@(Get-Prop $option 'Value') | ForEach-Object { [string]$_ }) -join ',') }
    foreach ($scope in @(Get-DhcpServerv4Scope -ErrorAction SilentlyContinue)) {
        $id = [string]$scope.ScopeId
        & $add "scope:$id" ('{0}|{1}-{2}|{3}|{4}|{5}' -f $scope.Name, $scope.StartRange, $scope.EndRange, $scope.SubnetMask, $scope.State, $scope.LeaseDuration)
        foreach ($option in (Get-OptionList $scope.ScopeId)) {
            $key = 'option:' + $id + ':' + (Get-Prop $option 'OptionId')
            $vendor = [string](Get-Prop $option 'VendorClass'); if ($vendor) { $key += ':v=' + $vendor }
            $userClass = [string](Get-Prop $option 'UserClass'); if ($userClass) { $key += ':u=' + $userClass }
            & $add $key ((@(Get-Prop $option 'Value') | ForEach-Object { [string]$_ }) -join ',')
        }
        foreach ($range in @(Get-DhcpServerv4ExclusionRange -ScopeId $scope.ScopeId -ErrorAction SilentlyContinue)) { & $add ("exclusion:${id}:" + $range.StartRange + '-' + $range.EndRange) 'present' }
        foreach ($reservation in @(Get-DhcpServerv4Reservation -ScopeId $scope.ScopeId -ErrorAction SilentlyContinue)) { & $add ("reservation:${id}:" + $reservation.IPAddress) $reservation.ClientId }
        foreach ($policy in @(Get-DhcpServerv4Policy -ScopeId $scope.ScopeId -ErrorAction SilentlyContinue)) { & $add ("policy:${id}:" + $policy.Name) (Get-Prop $policy 'Enabled') }
    }
    foreach ($scope in @(Get-DhcpServerv6Scope -ErrorAction SilentlyContinue)) { & $add ('scope6:' + [string]$scope.Prefix) (Get-Prop $scope 'State') }
    foreach ($failover in @(Get-DhcpServerv4Failover -ErrorAction SilentlyContinue)) { & $add ('failover:' + [string]$failover.Name) (Get-Prop $failover 'PartnerServer') }
    return [pscustomobject]@{ SchemaVersion = 1; Computer = $env:COMPUTERNAME; Collected = (Get-Date).ToString('o'); Settings = $settings.ToArray() }
}
function Compare-DhcpSnapshot {
    param([object]$Before, [object]$After)
    $changes = New-Object 'System.Collections.Generic.List[object]'
    $old = @{}
    $new = @{}
    foreach ($s in @($Before.Settings | Where-Object { $_ })) { $old[[string]$s.Key] = [string]$s.Value }
    foreach ($s in @($After.Settings | Where-Object { $_ })) { $new[[string]$s.Key] = [string]$s.Value }
    foreach ($key in $new.Keys) {
        if (-not $old.ContainsKey($key)) { $changes.Add([pscustomobject]@{ Change = 'ADDED'; Item = $key; Old = ''; New = $new[$key] }) }
        elseif ($old[$key] -cne $new[$key]) { $changes.Add([pscustomobject]@{ Change = 'CHANGED'; Item = $key; Old = $old[$key]; New = $new[$key] }) }
    }
    foreach ($key in $old.Keys) {
        if (-not $new.ContainsKey($key)) { $changes.Add([pscustomobject]@{ Change = 'REMOVED'; Item = $key; Old = $old[$key]; New = '' }) }
    }
    return $changes.ToArray()
}
function Show-Report {
    param([object[]]$Findings)
    Write-Host ''
    Write-Host 'DHCP AUDIT RESULTS' -ForegroundColor Cyan
    Write-Host "$env:COMPUTERNAME | $($Findings.Count) observations | $script:Failures failed checks/changes"
    $counts = foreach ($risk in 'ERROR', 'HIGH', 'REVIEW', 'CHANGED', 'INFO', 'SKIPPED', 'OK') {
        $count = @($Findings | Where-Object Risk -eq $risk).Count
        if ($count) { "$risk`: $count" }
    }
    Write-Host ($counts -join '   |   ')
    Write-Host 'REVIEW items are candidates for investigation, not confirmed vulnerabilities.'
    if ($Detailed) {
        foreach ($group in $Findings | Group-Object Area | Sort-Object Name) {
            Write-Host "`n$($group.Name) ($($group.Count))" -ForegroundColor Cyan
            Write-Host (($group.Group | Select-Object Risk, Target, Detail, NextStep | Format-List | Out-String -Width 120).TrimEnd())
        }
    } else {
        $urgent = @($Findings | Where-Object { $_.Risk -in 'ERROR', 'HIGH' } | Sort-Object @{ Expression = { if ($_.Risk -eq 'ERROR') { 0 } else { 1 } } }, Area, Target)
        if ($urgent.Count) {
            Write-Host "`nHIGH PRIORITY / FAILED CHECKS" -ForegroundColor Yellow
            $rows = $urgent | Select-Object Risk, Area, @{ Name = 'Target'; Expression = { Get-DisplayTarget $_.Target } }, Detail
            Write-Host (($rows | Format-Table -Wrap -AutoSize | Out-String -Width 120).TrimEnd())
        } else { Write-Host "`nNo HIGH or ERROR findings. Review the remaining observations." }
        $changed = @($Findings | Where-Object Risk -eq 'CHANGED')
        if ($changed.Count) {
            Write-Host "`nCHANGES MADE" -ForegroundColor Green
            Write-Host (($changed | Select-Object Target, Detail | Format-Table -Wrap -AutoSize | Out-String -Width 120).TrimEnd())
        }
        $review = @($Findings | Where-Object Risk -eq 'REVIEW' | Group-Object Area | Sort-Object Name)
        if ($review.Count) {
            Write-Host "`nMANUAL REVIEW" -ForegroundColor Cyan
            $rows = foreach ($group in $review) {
                $examples = @($group.Group | ForEach-Object { Get-DisplayTarget $_.Target } | Select-Object -Unique -First 2)
                [pscustomobject]@{ Area = $group.Name; Items = $group.Count; Examples = $examples -join ', ' }
            }
            Write-Host (($rows | Format-Table -Wrap -AutoSize | Out-String -Width 120).TrimEnd())
        }
        Write-Host "`nUse -Detailed for evidence and next steps; -PassThru for filtering/export."
    }
    Write-Host 'Findings reflect the pre-change state. Rerun with -AuditOnly to confirm; this is not proof of complete protection.'
}

# ---------------------------------------------------------------- context
$os = Get-CimInstance Win32_OperatingSystem
$computer = Get-CimInstance Win32_ComputerSystem
$build = [int]$os.BuildNumber
$script:IsDC = [int]$computer.DomainRole -in 4, 5
$domainJoined = [bool]$computer.PartOfDomain
$dhcpService = Get-Service -Name DHCPServer -ErrorAction SilentlyContinue
$moduleAvailable = [bool](Get-Module -ListAvailable -Name DhcpServer)
$script:ServerMode = ($null -ne $dhcpService) -and $moduleAvailable
$selfAddresses = @(Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True' | ForEach-Object { $_.IPAddress } | Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' })
$dhcpParameters = 'HKLM:\SYSTEM\CurrentControlSet\Services\DHCPServer\Parameters'
Write-Host "Host: $env:COMPUTERNAME | $($os.Caption) build $build | DC: $($script:IsDC) | DHCP role: $($null -ne $dhcpService) (module: $moduleAvailable) | Apply=$Apply WhatIf=$WhatIfPreference"
if ($Apply) { Write-Warning 'DHCP changes affect every client on the network. Confirm a workstation can still renew its lease after this finishes.' }

# ---------------------------------------------------------------- DHCP Server role
$scopesBefore = @()
if ($dhcpService -and -not $moduleAvailable) {
    Add-Finding 'DHCP role' 'DHCPServer' 'INFO' 'The DHCP Server service exists but the DhcpServer PowerShell module does not (Server 2008 R2 or older, or RSAT missing).' 'Back up with: netsh dhcp server export C:\CCDC\dhcp.dat all. Review scopes and options with netsh dhcp server show scope / mibinfo.'
}
if ($dhcpService) {
    Invoke-Check 'DHCP service integrity' {
        $service = Get-CimInstance Win32_Service -Filter "Name='DHCPServer'"
        if ([string]$service.State -ne 'Running' -or [string]$service.StartMode -eq 'Disabled') {
            Add-Finding 'DHCP service' 'DHCPServer' 'HIGH' "DHCP Server is $($service.State) / $($service.StartMode). Clients stop getting leases and NCCDC requires the service to be maintained. This script assumes it starts Running and Automatic and does not change it." 'Start it yourself (Start-Service DHCPServer) and read the DhcpServer events in the System log. If it stops again, check authorization (Get-DhcpServerInDC) and the callout DLL value.'
        } else { Add-Finding 'DHCP service' 'DHCPServer' 'OK' "DHCP Server is Running / $($service.StartMode)." '' }
        $command = ([string]$service.PathName)
        if ($command -notmatch '(?i)svchost\.exe"?\s+-k\s+DHCPServer') {
            Add-Finding 'DHCP service integrity' 'DHCPServer' 'HIGH' "Service command line is '$command'; the default runs under svchost -k DHCPServer." 'Investigate the replaced ImagePath (events 7045, 4697, Sysmon 13) and restore it.'
        }
        $serviceDll = Get-RegValue $dhcpParameters 'ServiceDll'
        $expectedDll = Join-Path $env:windir 'System32\dhcpssvc.dll'
        $actualDll = [Environment]::ExpandEnvironmentVariables([string]$serviceDll)
        if ($serviceDll -and $actualDll -ine $expectedDll) {
            Add-Finding 'DHCP service integrity' 'ServiceDll' 'HIGH' "ServiceDll is '$actualDll', expected '$expectedDll'. A swapped service DLL runs as the DHCP service." 'Restore the value, verify the file signature, and hunt for the replacement DLL.'
        }
        if (Test-Path -LiteralPath $expectedDll) {
            $signature = Get-AuthenticodeSignature -FilePath $expectedDll
            if ($signature.Status -ne 'Valid') {
                Add-Finding 'DHCP service integrity' $expectedDll 'REVIEW' "Signature status is $($signature.Status)." 'Compare the file hash with a known-good host or run sfc /scanfile on it.'
            }
        }
        foreach ($name in 'DatabasePath', 'BackupDatabasePath') {
            $value = [Environment]::ExpandEnvironmentVariables([string](Get-RegValue $dhcpParameters $name))
            if ($value -and $value -inotlike (Join-Path $env:windir 'System32\dhcp*')) {
                Add-Finding 'DHCP service integrity' $name 'REVIEW' "$name is '$value' (default is under System32\dhcp)." 'Confirm the team moved it on purpose; an attacker-controlled path can hide a rogue lease database.'
            }
        }
        $callouts = Get-RegValue $dhcpParameters 'CalloutDlls'
        if ($callouts) {
            $script:RestartWanted = $true
            Add-Finding 'DHCP callout DLL' 'CalloutDlls' 'HIGH' "A DHCP callout DLL is configured: $(@($callouts) -join ', '). A DHCP Administrators member can use this to run code as SYSTEM in the DHCP service (persistence and, on a DC, Domain Admin)." 'Remove it (this script), restart the DHCP service (an already loaded DLL stays in memory until restart), then hunt for the DLL and check DHCP Administrators.'
            Invoke-Fix 'CalloutDlls' 'Remove the DHCP callout DLL registry value (original saved)' {
                Save-State 'callout-dlls' @{ Path = $dhcpParameters; Name = 'CalloutDlls'; Value = @($callouts); CalloutEnabled = (Get-RegValue $dhcpParameters 'CalloutEnabled') }
                Remove-ItemProperty -LiteralPath $dhcpParameters -Name 'CalloutDlls'
                if ($null -ne (Get-RegValue $dhcpParameters 'CalloutDlls')) { throw 'Registry readback failed.' }
            }
        } else { Add-Finding 'DHCP callout DLL' 'CalloutDlls' 'OK' 'No callout DLL is configured.' '' }
    }
}

if ($script:ServerMode -and $dhcpService.Status -eq 'Running') {
    Invoke-Check 'DHCP snapshot and baseline' {
        $script:Snapshot = Get-DhcpSnapshot
        $script:ScopesBefore = @(Get-DhcpServerv4Scope -ErrorAction SilentlyContinue | ForEach-Object { '{0}={1}' -f $_.ScopeId, $_.State })
        $count = @($script:Snapshot.Settings).Count
        Add-Finding 'DHCP inventory' $env:COMPUTERNAME 'INFO' "Scopes=$(@($script:ScopesBefore).Count); recorded settings=$count." 'Save a baseline with -SaveBaselineTo once clients lease correctly, then compare later with -CompareTo.'
        if ($SaveBaselineTo) {
            $parent = Split-Path -Parent $SaveBaselineTo
            if ($parent -and -not (Test-Path -LiteralPath $parent)) { $null = New-Item -ItemType Directory -Path $parent -Force }
            ConvertTo-Json -InputObject $script:Snapshot -Depth 6 | Set-Content -LiteralPath $SaveBaselineTo -Encoding UTF8
            Add-Finding 'Baseline' $SaveBaselineTo 'INFO' "Baseline saved ($count settings). Keep a copy where red team cannot reach." 'Compare later with -CompareTo.'
        }
        if ($CompareTo) {
            $baseline = Get-Content -LiteralPath $CompareTo -Raw | ConvertFrom-Json
            if ((Get-Prop $baseline 'SchemaVersion') -ne 1 -or $null -eq (Get-Prop $baseline 'Settings')) { throw 'CompareTo is not a baseline created by this script.' }
            $changes = @(Compare-DhcpSnapshot -Before $baseline -After $script:Snapshot)
            if (-not $changes.Count) { Add-Finding 'DHCP changes' $CompareTo 'OK' 'No scope, option, exclusion, reservation, policy or authorization differences from the baseline.' '' }
            $shown = 0
            foreach ($change in $changes | Sort-Object Item) {
                if ($shown -ge 150) { break }
                Add-Finding 'DHCP changes' $change.Item 'HIGH' "$($change.Change): old=[$($change.Old)] new=[$($change.New)]" 'Confirm with the team who made this change. If unexpected, revert it and treat it as red team activity (DHCP audit log, System log).'
                $shown++
            }
            if ($changes.Count -gt $shown) { Add-Finding 'DHCP changes' $CompareTo 'REVIEW' "$($changes.Count - $shown) more differences not listed." 'Rerun with -PassThru and filter, or compare the JSON files directly.' }
        }
    }

    Invoke-Check 'DHCP server state' {
        $setting = Get-DhcpServerSetting
        $authorized = @(Get-AuthorizedDhcpServers)
        if ($script:AuthorizationError) { Add-Finding 'DHCP authorization' $env:COMPUTERNAME 'REVIEW' "Could not read the authorized DHCP servers from Active Directory: $($script:AuthorizationError)" 'Check the domain controller is reachable and you are a domain account, then rerun.' }
        $isAuthorized = [bool](Get-Prop $setting 'IsAuthorized')
        $isDomainJoined = [bool](Get-Prop $setting 'IsDomainJoined')
        if ($isDomainJoined -and -not $isAuthorized) {
            Add-Finding 'DHCP authorization' $env:COMPUTERNAME 'HIGH' 'This DHCP server is domain-joined but is NOT authorized in Active Directory, so it stops answering clients (rogue-server protection).' 'Authorize it (asked below; needs Enterprise Admins) or run: Add-DhcpServerInDC -DnsName <fqdn> -IPAddress <ip>.'
            if (Get-Choice 'AuthorizeServer' $AuthorizeServer.IsPresent 'Authorize this DHCP server in Active Directory?' 'Only do this if this server is the real DHCP server for the team. It needs Enterprise Admins rights.') {
                Invoke-Fix $env:COMPUTERNAME 'Authorize this DHCP server in Active Directory' {
                    $fqdn = ([Net.Dns]::GetHostEntry($env:COMPUTERNAME)).HostName
                    $address = @($selfAddresses | Where-Object { Test-IPv4 $_ })[0]
                    Add-DhcpServerInDC -DnsName $fqdn -IPAddress $address
                    if (-not [bool](Get-Prop (Get-DhcpServerSetting) 'IsAuthorized')) { throw 'Authorization readback failed.' }
                }
            }
        } elseif ($isDomainJoined) { Add-Finding 'DHCP authorization' $env:COMPUTERNAME 'OK' 'This server is authorized in Active Directory.' '' }
        else { Add-Finding 'DHCP authorization' $env:COMPUTERNAME 'INFO' 'This server is not domain-joined, so Active Directory authorization does not apply.' 'Join it to the domain and authorize it before it can answer clients there.' }
        foreach ($entry in $authorized) {
            $dnsName = [string](Get-Prop $entry 'DnsName'); $ip = [string](Get-Prop $entry 'IPAddress')
            if ($ApprovedDhcpServers.Count -and $ip -notin $ApprovedDhcpServers) {
                Add-Finding 'DHCP authorization' "$dnsName ($ip)" 'HIGH' 'An authorized DHCP server is not in -ApprovedDhcpServers. An attacker with Enterprise Admin rights can authorize a rogue server.' 'Confirm with the team, then remove it with Remove-DhcpServerInDC after checking its scopes.'
            } else { Add-Finding 'DHCP authorization' "$dnsName ($ip)" 'INFO' 'Authorized DHCP server in AD.' 'Compare with the packet. Only the real DHCP server(s) should be listed.' }
        }
        $attempts = [int](Get-Prop $setting 'ConflictDetectionAttempts')
        if ($attempts -lt 1) {
            Add-Finding 'Conflict detection' 'ConflictDetectionAttempts' 'REVIEW' 'Conflict detection is off, so the server can lease an address that an attacker (or a static host) already uses.' 'Optional: ConflictDetectionAttempts 1 pings before offering an address (asked below).'
            if (Get-Choice 'ConflictDetection' $EnableConflictDetection.IsPresent 'Turn on DHCP conflict detection (1 ping before each offer)?' 'Adds a short delay to every new lease. Fine for small pools; skip it if lease latency matters.') {
                Invoke-Fix 'ConflictDetectionAttempts' 'Set conflict detection attempts to 1' {
                    Save-State 'conflict-detection' @{ ConflictDetectionAttempts = $attempts }
                    Set-DhcpServerSetting -ConflictDetectionAttempts 1
                    if ([int](Get-Prop (Get-DhcpServerSetting) 'ConflictDetectionAttempts') -ne 1) { throw 'Readback failed.' }
                }
            }
        } else { Add-Finding 'Conflict detection' 'ConflictDetectionAttempts' 'OK' "Conflict detection attempts: $attempts." '' }
        $credential = Get-DhcpServerDnsCredential -ErrorAction SilentlyContinue
        $credUser = [string](Get-Prop $credential 'UserName')
        Add-Finding 'DHCP DNS update' 'DnsCredential' 'INFO' "DHCP DNS update credential: $(if ($credUser) { $credUser } else { 'none (uses the server computer account)' })." 'On a DC the computer account is fine with Secure dynamic updates. On another server, set Set-DhcpServerDnsCredential with a dedicated low-privilege account instead of adding it to DnsUpdateProxy.'
        $failover = @(Get-DhcpServerv4Failover -ErrorAction SilentlyContinue)
        foreach ($f in $failover) { Add-Finding 'DHCP failover' ([string]$f.Name) 'INFO' "Failover partner: $(Get-Prop $f 'PartnerServer'); mode: $(Get-Prop $f 'Mode')." 'Failover needs TCP 647 between partners. Do not create or remove it during the first 15 minutes.' }
    }

    if (-not $SkipLogging) {
        Invoke-Check 'DHCP audit logging' {
            $audit = Get-DhcpServerAuditLog
            if (-not [bool](Get-Prop $audit 'Enable')) {
                Add-Finding 'DHCP logging' $env:COMPUTERNAME 'HIGH' 'DHCP audit logging is off. Without it you cannot see leases, conflicts, pool exhaustion or rogue-server events, and Splunk gets nothing.' 'Enable it (this script); logs go to the audit log path as DhcpSrvLog-<Day>.log.'
                Invoke-Fix 'DHCP audit log' 'Enable DHCP audit logging' {
                    Save-State 'audit-log' $audit
                    Set-DhcpServerAuditLog -Enable $true
                    if (-not [bool](Get-Prop (Get-DhcpServerAuditLog) 'Enable')) { throw 'Readback does not show logging enabled.' }
                }
            } else { Add-Finding 'DHCP logging' $env:COMPUTERNAME 'OK' "Audit logging is on; path $([string](Get-Prop $audit 'Path'))." '' }
        }
    } else { Add-Finding 'DHCP logging' $env:COMPUTERNAME 'SKIPPED' 'Skipped by -SkipLogging.' '' }

    Invoke-Check 'DHCP scopes and options' {
        $scopes = @(Get-DhcpServerv4Scope -ErrorAction SilentlyContinue)
        if (-not $scopes.Count) { Add-Finding 'DHCP scopes' $env:COMPUTERNAME 'HIGH' 'No IPv4 scopes are defined. Clients cannot lease addresses (NCCDC 2018 to 2020 expect a pool of 10.X.X.101-150).' 'Restore the scopes from the latest export (Import-DhcpServer) or recreate them from the packet. This script never creates scopes.' }
        $levels = New-Object 'System.Collections.Generic.List[object]'
        $levels.Add([pscustomobject]@{ ScopeId = $null; Label = 'server' })
        foreach ($scope in $scopes) { $levels.Add([pscustomobject]@{ ScopeId = $scope.ScopeId; Label = [string]$scope.ScopeId }) }
        foreach ($scope in $scopes) {
            $id = [string]$scope.ScopeId
            $rangeText = "$($scope.StartRange)-$($scope.EndRange)"
            if ([string]$scope.State -ne 'Active') {
                Add-Finding 'DHCP scope' $id 'HIGH' "Scope '$($scope.Name)' ($rangeText) is $($scope.State). Clients on it cannot lease." 'Activate it only if the packet says it should be active: Set-DhcpServerv4Scope -ScopeId <id> -State Active. This script does not change scope state.'
            } else { Add-Finding 'DHCP scope' $id 'OK' "Scope '$($scope.Name)' $rangeText mask $($scope.SubnetMask) is Active; lease $($scope.LeaseDuration)." '' }
            if ($ExpectedRange.Count -and $rangeText -notin $ExpectedRange) {
                Add-Finding 'DHCP scope range' $id 'HIGH' "Scope range $rangeText is not one of the expected ranges: $($ExpectedRange -join ', ')." 'A changed pool can strand clients or hand out addresses the packet does not allow. Compare with the packet and the latest export; this script does not edit ranges.'
            }
            $statistics = Get-DhcpServerv4ScopeStatistics -ScopeId $scope.ScopeId -ErrorAction SilentlyContinue
            if ($statistics) {
                $used = [double](Get-Prop $statistics 'PercentageInUse')
                if ($used -ge 95) { Add-Finding 'DHCP pool' $id 'HIGH' ('Pool is {0:N0} percent used (free: {1}). New and renewing clients fail when it is full (DHCP starvation).' -f $used, (Get-Prop $statistics 'Free')) 'Check the leases for one MAC vendor or random MACs flooding the pool, block the source switch port or IP, and clear bad leases. Do not shrink the pool.' }
                elseif ($used -ge 80) { Add-Finding 'DHCP pool' $id 'REVIEW' ('Pool is {0:N0} percent used (free: {1}).' -f $used, (Get-Prop $statistics 'Free')) 'Watch for a starvation attack (many leases from unfamiliar MACs).' }
            }
            $bad = @(Get-DhcpServerv4Lease -ScopeId $scope.ScopeId -BadLeases -ErrorAction SilentlyContinue)
            if ($bad.Count) { Add-Finding 'DHCP bad leases' $id 'REVIEW' "$($bad.Count) bad lease(s): another host already uses those addresses (static squatting or a rogue DHCP server)." 'Find the host that owns each address and remove the bad lease after fixing the conflict.' }
            $exclusions = @(Get-DhcpServerv4ExclusionRange -ScopeId $scope.ScopeId -ErrorAction SilentlyContinue)
            if ($exclusions.Count) { Add-Finding 'DHCP exclusions' $id 'INFO' "Exclusions: $(($exclusions | ForEach-Object { "$($_.StartRange)-$($_.EndRange)" }) -join ', ')." 'Compare with the packet and the baseline; an attacker can exclude the whole pool.' }
            $reservations = @(Get-DhcpServerv4Reservation -ScopeId $scope.ScopeId -ErrorAction SilentlyContinue)
            if ($reservations.Count) { Add-Finding 'DHCP reservations' $id 'REVIEW' "$($reservations.Count) reservation(s): $(($reservations | Select-Object -First 8 | ForEach-Object { "$($_.IPAddress)=$($_.ClientId)" }) -join ', ')." 'Reservations pin an address to a MAC. Remove any nobody can explain.' }
            $policies = @(Get-DhcpServerv4Policy -ScopeId $scope.ScopeId -ErrorAction SilentlyContinue)
            if ($policies.Count) { Add-Finding 'DHCP policies' $id 'REVIEW' "$($policies.Count) policy(ies): $(($policies | ForEach-Object { $_.Name }) -join ', ')." 'Policies can hand different options (DNS, router) to selected clients. Confirm each one.' }
            $dnsSetting = Get-DhcpServerv4DnsSetting -ScopeId $scope.ScopeId -ErrorAction SilentlyContinue
            if ($dnsSetting) {
                $protected = [bool](Get-Prop $dnsSetting 'NameProtection')
                Add-Finding 'DHCP DNS update' $id 'INFO' "Dynamic updates: $(Get-Prop $dnsSetting 'DynamicUpdates'); name protection: $protected." 'Name protection stops one client taking over a name registered by another.'
                if (-not $protected -and (Get-Command Set-DhcpServerv4DnsSetting -ErrorAction SilentlyContinue)) {
                    if (Get-Choice 'NameProtection' $EnableNameProtection.IsPresent 'Turn on DHCP name protection for scopes?' 'A client that registered a name first keeps it. Test domain logons after enabling.') {
                        Invoke-Fix $id 'Enable DHCP name protection on this scope' {
                            Save-State 'name-protection' @{ ScopeId = $id; NameProtection = $protected }
                            Set-DhcpServerv4DnsSetting -ScopeId $scope.ScopeId -NameProtection $true
                            if (-not [bool](Get-Prop (Get-DhcpServerv4DnsSetting -ScopeId $scope.ScopeId) 'NameProtection')) { throw 'Readback failed.' }
                        }
                    }
                }
            }
        }
        $v6 = @(Get-DhcpServerv6Scope -ErrorAction SilentlyContinue)
        if ($v6.Count) { Add-Finding 'DHCPv6 scope' $env:COMPUTERNAME 'REVIEW' "$($v6.Count) DHCPv6 scope(s) exist: $(($v6 | ForEach-Object { $_.Prefix }) -join ', '). Competition networks are IPv4; a DHCPv6 scope can hand out an attacker-chosen DNS server." 'Confirm the packet needs DHCPv6, otherwise leave it for the team to remove.'
        }
        $filters = Get-DhcpServerv4FilterList -ErrorAction SilentlyContinue
        if ($filters) {
            $allow = [bool](Get-Prop $filters 'Allow'); $deny = [bool](Get-Prop $filters 'Deny')
            if ($allow) { Add-Finding 'DHCP filters' $env:COMPUTERNAME 'REVIEW' 'The MAC allow list is enabled: any client not on it gets no lease, including scored workstations.' 'Make sure every scored client is on the list or turn it off. This script does not change filters.' }
            elseif ($deny) { Add-Finding 'DHCP filters' $env:COMPUTERNAME 'INFO' 'The MAC deny list is enabled.' 'Review the entries with Get-DhcpServerv4Filter -List Deny.' }
        }

        # Options: DNS (6), router (3), WPAD (252) and boot-server options (66, 67, 150).
        foreach ($level in $levels) {
            foreach ($option in (Get-OptionList $level.ScopeId)) {
                $optionId = [int](Get-Prop $option 'OptionId')
                $values = @((Get-Prop $option 'Value') | Where-Object { $_ } | ForEach-Object { [string]$_ })
                $vendor = [string](Get-Prop $option 'VendorClass'); $userClass = [string](Get-Prop $option 'UserClass')
                $defaultClass = (-not $vendor) -and (-not $userClass)
                $label = "option $optionId ($($level.Label))"
                $scopeArgs = @{}
                if ($null -ne $level.ScopeId) { $scopeArgs['ScopeId'] = $level.ScopeId }
                if ($optionId -eq 6) {
                    $nonPrivate = @($values | Where-Object { (Test-IPv4 $_) -and -not (Test-PrivateIPv4 $_) })
                    if ($ExpectedDnsServers.Count -and $defaultClass) {
                        if (($values -join ',') -ne ($ExpectedDnsServers -join ',')) {
                            Add-Finding 'DHCP option 6 (DNS)' $label 'HIGH' "Clients are told to use DNS server(s) $($values -join ', '); expected $($ExpectedDnsServers -join ', '). A rogue DNS option redirects every client (like DNS poisoning) and breaks scored lookups and AD logon." 'Reset it (asked below, or -EnforceOptions) and check who changed it.'
                            if (Get-Choice 'EnforceOptions' $EnforceOptions.IsPresent 'Reset DHCP option 6 / 3 to the expected values where they differ?' 'Team DNS first, then 10.120.0.53 for NCCDC. Only say yes if the expected values you passed are exactly right.') {
                                Invoke-Fix $label "Set DNS servers to $($ExpectedDnsServers -join ', ')" {
                                    Save-State 'option-6' @{ Level = $label; Values = $values }
                                    Set-DhcpServerv4OptionValue @scopeArgs -DnsServer $ExpectedDnsServers -Force
                                }
                            }
                        } else { Add-Finding 'DHCP option 6 (DNS)' $label 'OK' "DNS servers: $($values -join ', ')." '' }
                    } else {
                        Add-Finding 'DHCP option 6 (DNS)' $label 'INFO' "DNS servers handed to clients: $($values -join ', ')." 'NCCDC: team DNS (10.X.X.5) first, then 10.120.0.53. Pass -ExpectedDnsServers to check it automatically.'
                    }
                    if ($nonPrivate.Count) { Add-Finding 'DHCP option 6 (DNS)' $label 'REVIEW' "Option 6 hands out non-private DNS server(s): $($nonPrivate -join ', ')." 'A public resolver here bypasses the team DNS and the scored zones; confirm it is intended.' }
                } elseif ($optionId -eq 3) {
                    if ($ExpectedRouters.Count -and $defaultClass) {
                        if (($values -join ',') -ne ($ExpectedRouters -join ',')) {
                            Add-Finding 'DHCP option 3 (router)' $label 'HIGH' "Clients get default gateway $($values -join ', '); expected $($ExpectedRouters -join ', '). A rogue gateway sends all client traffic through the attacker." 'Reset it (asked below, or -EnforceOptions).'
                            if (Get-Choice 'EnforceOptions' $EnforceOptions.IsPresent 'Reset DHCP option 6 / 3 to the expected values where they differ?' 'Team DNS first, then 10.120.0.53 for NCCDC. Only say yes if the expected values you passed are exactly right.') {
                                Invoke-Fix $label "Set router to $($ExpectedRouters -join ', ')" {
                                    Save-State 'option-3' @{ Level = $label; Values = $values }
                                    Set-DhcpServerv4OptionValue @scopeArgs -Router $ExpectedRouters -Force
                                }
                            }
                        } else { Add-Finding 'DHCP option 3 (router)' $label 'OK' "Router: $($values -join ', ')." '' }
                    } else { Add-Finding 'DHCP option 3 (router)' $label 'INFO' "Default gateway handed to clients: $($values -join ', ')." 'Compare with the team router. Pass -ExpectedRouters to check it automatically.' }
                } elseif ($optionId -in 252, 66, 67, 150) {
                    $risk = if ($optionId -eq 252) { 'HIGH' } else { 'REVIEW' }
                    $why = if ($optionId -eq 252) { 'WPAD proxy auto-config URL: clients fetch a proxy script from it (credential theft and traffic redirection).' } else { 'boot-server option (PXE/TFTP). Clients can be told to boot or download from an attacker host.' }
                    Add-Finding "DHCP option $optionId" $label $risk "Option $optionId is set to '$($values -join ', ')': $why" 'Remove it unless the packet or an inject requires it (asked below, or -RemoveSuspiciousOptions).'
                    if (Get-Choice 'RemoveOptions' $RemoveSuspiciousOptions.IsPresent 'Remove DHCP options 252, 66, 67 and 150 where they are set?' 'Say no if the packet uses PXE boot or a WPAD proxy.') {
                        Invoke-Fix $label "Remove DHCP option $optionId" {
                            Save-State "option-$optionId" @{ Level = $label; Values = $values; VendorClass = $vendor; UserClass = $userClass }
                            $removeArgs = @{ OptionId = $optionId }
                            if ($null -ne $level.ScopeId) { $removeArgs['ScopeId'] = $level.ScopeId }
                            if ($vendor) { $removeArgs['VendorClass'] = $vendor }
                            if ($userClass) { $removeArgs['UserClass'] = $userClass }
                            Remove-DhcpServerv4OptionValue @removeArgs
                        }
                    }
                }
            }
        }
    }

    Invoke-Check 'DHCP logs and events' {
        $audit = Get-DhcpServerAuditLog
        $logDirectory = [Environment]::ExpandEnvironmentVariables([string](Get-Prop $audit 'Path'))
        $day = (Get-Date).ToString('ddd', [Globalization.CultureInfo]::InvariantCulture)
        $logFile = Join-Path $logDirectory "DhcpSrvLog-$day.log"
        if (Test-Path -LiteralPath $logFile) {
            $counts = @{}
            foreach ($line in @(Get-Content -LiteralPath $logFile -Tail 5000)) {
                if ($line -match '^(\d{2}),') { $counts[$Matches[1]] = 1 + [int]$counts[$Matches[1]] }
            }
            $exhausted = [int]$counts['14']; $inUse = [int]$counts['13']; $stopped = [int]$counts['01']; $denied = [int]$counts['15']
            $rogue = 0; foreach ($code in 50..64) { $rogue += [int]$counts[('{0:D2}' -f $code)] }
            if ($exhausted) { Add-Finding 'DHCP log' $logFile 'HIGH' "$exhausted event(s) with ID 14: a lease request failed because the address pool was exhausted." 'Check for starvation (one MAC or many random MACs), then free the pool. Do not shrink it.' }
            if ($inUse -ge 5) { Add-Finding 'DHCP log' $logFile 'REVIEW' "$inUse event(s) with ID 13: an offered address was already in use on the network." 'A static host or rogue DHCP server is on the same range; find it with the bad-lease list and a broadcast probe.' }
            if ($stopped) { Add-Finding 'DHCP log' $logFile 'REVIEW' "$stopped service stop event(s) (ID 01) in today's log." 'Check who stopped DHCP (System log 7036/7040, Security 4688).' }
            if ($denied -ge 5) { Add-Finding 'DHCP log' $logFile 'REVIEW' "$denied lease(s) denied (ID 15)." 'A MAC filter, policy or NAP-style rule is refusing clients; confirm it is intended.' }
            if ($rogue) { Add-Finding 'DHCP log' $logFile 'REVIEW' "$rogue rogue-detection / authorization event(s) (IDs 50 to 64)." 'Read them in the log: they report other DHCP servers found and authorization failures.' }
            if (-not ($exhausted -or $inUse -ge 5 -or $stopped -or $denied -ge 5 -or $rogue)) { Add-Finding 'DHCP log' $logFile 'OK' 'No pool exhaustion, address-in-use bursts, stops or rogue-detection events in the last 5000 lines.' '' }
        } else { Add-Finding 'DHCP log' $logFile 'INFO' "No audit log file for today yet ($logFile)." 'Logging may have just been enabled, or the path differs.' }
        $events = @()
        try {
            # The provider name differs by Windows version (DhcpServer, Microsoft-Windows-DHCP-Server), so look it up.
            $providers = @(Get-WinEvent -ListProvider '*DHCP*Server*' -ErrorAction SilentlyContinue | ForEach-Object { $_.Name })
            if ($providers.Count) { $events = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; ProviderName = $providers; StartTime = (Get-Date).AddDays(-1) } -ErrorAction Stop) }
        }
        catch {
            if ($_.Exception.Message -notmatch 'No events were found') { Add-Finding 'DHCP events' 'System log' 'INFO' "Could not read DhcpServer events from the System log: $($_.Exception.Message)" 'Read them yourself with Get-WinEvent -LogName System and filter on the DhcpServer provider.' }
        }
        $problems = @($events | Where-Object { $_.Level -le 3 })
        if ($problems.Count) {
            $top = ($problems | Group-Object Id | Sort-Object Count -Descending | Select-Object -First 5 | ForEach-Object { "ID $($_.Name) x$($_.Count)" }) -join ', '
            Add-Finding 'DHCP events' 'System log' 'REVIEW' "$($problems.Count) DhcpServer warning/error event(s) in the last day: $top." 'Read them with Get-WinEvent -FilterHashtable @{LogName=''System'';ProviderName=''DhcpServer''}.'
        }
        $callout = @($events | Where-Object { try { $_.Message -match '(?i)callout' } catch { $false } } | Select-Object -First 3)
        if ($callout.Count) { Add-Finding 'DHCP events' 'System log' 'HIGH' "DhcpServer events mention a callout DLL: $(($callout | ForEach-Object { "ID $($_.Id) at $($_.TimeCreated)" }) -join '; ')." 'A callout DLL was loaded or failed to load. Check the CalloutDlls value and the file.' }
    }
}

# ---------------------------------------------------------------- Firewall rules this script creates
Invoke-Check 'DHCP firewall' {
    if ($dhcpService -and (Get-Command Get-NetFirewallRule -ErrorAction SilentlyContinue)) {
        $profiles = @(Get-NetFirewallProfile -PolicyStore ActiveStore -ErrorAction SilentlyContinue | Where-Object { "$($_.Enabled)" -eq 'True' -and "$($_.DefaultInboundAction)" -eq 'Block' })
        $allowRules = @(Get-NetFirewallPortFilter -PolicyStore ActiveStore -ErrorAction SilentlyContinue | Where-Object { "$($_.Protocol)" -in 'UDP', '17' -and @($_.LocalPort) -contains '67' } | Get-NetFirewallRule -ErrorAction SilentlyContinue | Where-Object { "$($_.Enabled)" -eq 'True' -and "$($_.Direction)" -eq 'Inbound' -and "$($_.Action)" -eq 'Allow' })
        if ($profiles.Count -and -not $allowRules.Count) {
            Add-Finding 'DHCP firewall' 'UDP 67' 'HIGH' 'Inbound is default-Block and no enabled inbound rule allows UDP 67, so clients get no leases. firewall.ps1 disables other inbound allowances, including the built-in DHCP Server rule.' 'Allow it with this script (asked below, or pass -AllowUdp67). Do not scope it by remote address.'
            if (Get-Choice 'AllowUdp67' $AllowUdp67.IsPresent 'Allow inbound UDP 67 so this server can hand out leases?' 'Opens UDP 67 from any source (a DHCPDISCOVER comes from 0.0.0.0). Only answer yes if this server must serve DHCP.') {
                $ruleName = 'CCDC Allow DHCP UDP 67 In'
                if (-not (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue)) {
                    Invoke-Fix 'UDP 67' 'Create inbound allow rule for UDP 67 (DHCP server)' {
                        Save-State 'allow-udp67' @{ Rule = $ruleName; Created = $true }
                        $null = New-NetFirewallRule -DisplayName $ruleName -Group 'CCDC DHCP' -Direction Inbound -Protocol UDP -LocalPort 67 -Action Allow -Profile Any
                    }
                } else {
                    Invoke-Fix 'UDP 67' 'Re-enable the existing inbound allow rule for UDP 67 (DHCP server)' {
                        Save-State 'allow-udp67' @{ Rule = $ruleName; Created = $false }
                        Get-NetFirewallRule -DisplayName $ruleName | Enable-NetFirewallRule
                    }
                }
            }
        } elseif ($allowRules.Count) { Add-Finding 'DHCP firewall' 'UDP 67' 'OK' "Inbound UDP 67 is allowed by: $(($allowRules | ForEach-Object { $_.DisplayName }) -join '; ')." 'Do not scope UDP 67 by remote address on this host (a DHCPDISCOVER comes from 0.0.0.0). Restrict outside sources on the perimeter firewall and block single attacker IPs only.' }
        else { Add-Finding 'DHCP firewall' 'UDP 67' 'INFO' 'Default inbound action is not Block on the enabled profiles, so UDP 67 is not filtered by default.' 'After firewall.ps1 sets default Block, rerun this script to open UDP 67 (-AllowUdp67).' }
        $watchers = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -match 'firewall\.ps1' -and $_.CommandLine -notmatch '-Once' -and $_.CommandLine -notmatch '-ListOnly' })
        if ($watchers.Count) {
            Add-Finding 'DHCP firewall' 'Watcher' 'HIGH' "A firewall.ps1 watcher is running (PID $(($watchers | ForEach-Object { $_.ProcessId }) -join ', ')). Every pass it disables inbound allow rules outside its port list, which includes the UDP 67 rule this script creates." 'Stop the watcher (Ctrl+C in its window), run firewall.ps1 with -Once, then rerun this script. Check Get-NetFirewallRule -DisplayName "CCDC Allow DHCP UDP 67 In" afterwards.'
        }
    }
    foreach ($ip in $BlockDhcpFromIPs) {
        $name = "CCDC Block DHCP from $ip"
        if (-not (Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue)) {
            Invoke-Fix $ip "Block inbound UDP 67 from the single IP $ip" {
                Save-State 'block-ip' @{ Rule = $name; Created = $true }
                $null = New-NetFirewallRule -DisplayName $name -Group 'CCDC DHCP' -Direction Inbound -Protocol UDP -LocalPort 67 -RemoteAddress $ip -Action Block
            }
        } else { Add-Finding 'DHCP firewall' $ip 'OK' "Block rule for $ip already exists." '' }
    }
    $v6Rules = @(
        @{ Name = 'CCDC Block DHCPv6 In'; Args = @{ Direction = 'Inbound'; Protocol = 'UDP'; LocalPort = '546' } },
        @{ Name = 'CCDC Block DHCPv6 Out'; Args = @{ Direction = 'Outbound'; Protocol = 'UDP'; RemotePort = '547' } },
        @{ Name = 'CCDC Block Router Advertisement In'; Args = @{ Direction = 'Inbound'; Protocol = 'ICMPv6'; IcmpType = '134' } }
    )
    $missing = @($v6Rules | Where-Object { -not (Get-NetFirewallRule -DisplayName $_.Name -ErrorAction SilentlyContinue) })
    if ($missing.Count) {
        Add-Finding 'DHCPv6 / mitm6' $env:COMPUTERNAME 'REVIEW' 'DHCPv6 and IPv6 router advertisements are not blocked. With IPv6 on and no DHCPv6 server, an attacker (mitm6) answers DHCPv6, becomes the DNS server and relays NTLM.' 'Block them (asked below). This does not disable IPv6; it only stops DHCPv6 and router advertisements.'
        if (Get-Choice 'BlockDhcpv6' $BlockDhcpv6.IsPresent 'Block DHCPv6 and IPv6 router advertisements on this host?' 'Stops IPv6 address autoconfiguration. Fine on IPv4-only competition networks; skip it if the packet uses IPv6.') {
            foreach ($rule in $missing) {
                $ruleArgs = $rule.Args
                Invoke-Fix $rule.Name "Create firewall block rule $($rule.Name)" {
                    Save-State 'dhcpv6-rule' @{ Rule = $rule.Name; Created = $true }
                    $null = New-NetFirewallRule -DisplayName $rule.Name -Group 'CCDC DHCP' -Action Block @ruleArgs
                }
            }
        }
    } else { Add-Finding 'DHCPv6 / mitm6' $env:COMPUTERNAME 'OK' 'DHCPv6 and router-advertisement block rules exist.' '' }
}

# ---------------------------------------------------------------- DHCP client (every host)
Invoke-Check 'DHCP client leases' {
    $approved = @($ApprovedDhcpServers)
    if ($script:ServerMode) { $approved += @($selfAddresses) }
    foreach ($adapter in @(Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True')) {
        $name = [string]$adapter.Description
        if (-not [bool]$adapter.DHCPEnabled) { Add-Finding 'DHCP client' $name 'INFO' 'Static address configuration (DHCP client off).' ''; continue }
        $server = [string]$adapter.DHCPServer
        if ($approved.Count -and $server -notin $approved) {
            Add-Finding 'DHCP client' $name 'HIGH' "Lease obtained from $server, which is not an approved DHCP server ($($approved -join ', ')). That is a rogue DHCP server, or the real server changed." 'Find the host with that address, block its IP only (-BlockDhcpFromIPs on the real DHCP server), then ipconfig /release and /renew. Compare with Get-DhcpServerInDC.'
        } else {
            Add-Finding 'DHCP client' $name 'INFO' "Lease from DHCP server $server (obtained $($adapter.DHCPLeaseObtained))." 'Pass -ApprovedDhcpServers with the real DHCP server IP(s) so a lease from any other server is flagged. From a workstation you can also probe: nmap --script broadcast-dhcp-discover.'
        }
    }
}

# ---------------------------------------------------------------- restart and after-checks
if ($script:RestartWanted -and $script:Changed -and $dhcpService) {
    if (Get-Choice 'RestartDhcp' $RestartDhcp.IsPresent 'Restart the DHCP Server service now so the callout DLL removal takes effect?' 'Leases already issued keep working, but new and renewing clients wait a few seconds.') {
        Invoke-Fix 'DHCPServer' 'Restart the DHCP Server service' {
            Restart-Service -Name DHCPServer -Force
            if ((Get-Service -Name DHCPServer).Status -ne 'Running') { throw 'DHCP Server did not return to Running.' }
        }
    } else {
        Add-Finding 'DHCP restart' 'DHCPServer' 'REVIEW' 'A change (callout DLL removal) takes effect only after the DHCP service restarts.' 'Run Restart-Service DHCPServer when a few seconds of lease delay is acceptable.'
    }
}
if ($Apply -and $script:Changed -and $script:ServerMode) {
    Invoke-Check 'DHCP health (after)' {
        $service = Get-Service -Name DHCPServer
        if ($service.Status -ne 'Running') { Add-Finding 'DHCP health (after)' 'DHCPServer' 'HIGH' "DHCP Server is $($service.Status) after the changes." 'Start it and restore from the saved recovery files if it will not stay up.' }
        else { Add-Finding 'DHCP health (after)' 'DHCPServer' 'OK' 'DHCP Server is Running after the changes.' '' }
        $scopesAfter = @(Get-DhcpServerv4Scope -ErrorAction SilentlyContinue | ForEach-Object { '{0}={1}' -f $_.ScopeId, $_.State })
        $lost = @($script:ScopesBefore | Where-Object { $_ -notin $scopesAfter })
        if ($lost.Count) { Add-Finding 'DHCP health (after)' 'scopes' 'HIGH' "Scope state changed or a scope disappeared: $($lost -join ', ')." 'Restore from the saved export with Import-DhcpServer.' }
        else { Add-Finding 'DHCP health (after)' 'scopes' 'OK' 'All scopes are still present in the same state.' 'From a workstation run ipconfig /renew and confirm gateway, DNS and suffix.' }
    }
}

# ---------------------------------------------------------------- report
Show-Report -Findings $script:Findings.ToArray()
if ($script:BackupDirectory) { Write-Host "Recovery files: $script:BackupDirectory" }
if ($PassThru) { $script:Findings.ToArray() }
if ($script:Failures) { throw "$script:Failures checks or changes failed. Review ERROR findings; the assessment is incomplete." }
