#Requires -Version 5.1
if (-not ('Competition.WdacMappedImages' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;

namespace Competition {
    public static class WdacMappedImages {
        [StructLayout(LayoutKind.Sequential)]
        private struct MemoryRegion {
            public IntPtr BaseAddress;
            public IntPtr AllocationBase;
            public uint AllocationProtect;
            public ushort PartitionId;
            public UIntPtr RegionSize;
            public uint State;
            public uint Protect;
            public uint Type;
        }
        [DllImport("kernel32.dll", SetLastError=true)]
        private static extern IntPtr OpenProcess(uint access, bool inherit, int processId);
        [DllImport("kernel32.dll", SetLastError=true)]
        private static extern UIntPtr VirtualQueryEx(IntPtr process, IntPtr address, out MemoryRegion region, UIntPtr length);
        [DllImport("psapi.dll", CharSet=CharSet.Unicode, SetLastError=true)]
        private static extern uint GetMappedFileNameW(IntPtr process, IntPtr address, StringBuilder name, uint length);
        [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
        private static extern uint QueryDosDeviceW(string device, StringBuilder target, int length);
        [DllImport("kernel32.dll")]
        private static extern bool CloseHandle(IntPtr handle);

        private static readonly Dictionary<string,string> Drives = BuildDrives();
        private static Dictionary<string,string> BuildDrives() {
            var result = new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
            foreach (string drive in Environment.GetLogicalDrives()) {
                var target = new StringBuilder(32768);
                if (QueryDosDeviceW(drive.Substring(0,2), target, target.Capacity) != 0)
                    result[target.ToString()] = drive.Substring(0,2);
            }
            return result;
        }
        private static string DosPath(string path) {
            foreach (var drive in Drives) {
                if (path.StartsWith(drive.Key + "\\", StringComparison.OrdinalIgnoreCase))
                    return drive.Value + path.Substring(drive.Key.Length);
            }
            if (path.StartsWith(@"\Device\Mup\", StringComparison.OrdinalIgnoreCase))
                return @"\\" + path.Substring(12);
            return path;
        }
        public static string[] GetPaths(int processId) {
            // Query image mappings only; no process-memory reads, writes, or code injection.
            IntPtr process = OpenProcess(0x0400, false, processId);
            if (process == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
            var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var allocations = new HashSet<IntPtr>();
            var name = new StringBuilder(32768);
            UIntPtr size = new UIntPtr((uint)Marshal.SizeOf(typeof(MemoryRegion)));
            ulong address = 0;
            try {
                MemoryRegion region;
                while (VirtualQueryEx(process, new IntPtr((long)address), out region, size) != UIntPtr.Zero) {
                    if (region.State == 0x1000 && region.Type == 0x1000000 && allocations.Add(region.AllocationBase)) {
                        name.Clear();
                        if (GetMappedFileNameW(process, region.BaseAddress, name, (uint)name.Capacity) != 0)
                            paths.Add(DosPath(name.ToString()));
                    }
                    ulong next = (ulong)region.BaseAddress.ToInt64() + region.RegionSize.ToUInt64();
                    if (next <= address || next > Int64.MaxValue) break;
                    address = next;
                }
            } finally { CloseHandle(process); }
            var result = new string[paths.Count];
            paths.CopyTo(result);
            return result;
        }
    }
}
'@
}
