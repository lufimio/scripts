#Requires -Version 5.1
function Read-WdacPolicy {
    param([string]$Path)
    $Path = (Get-Item -LiteralPath $Path -ErrorAction Stop).FullName
    $document = New-Object Xml.XmlDocument
    $document.XmlResolver = $null
    $document.Load($Path)
    if ($document.DocumentElement.LocalName -ne 'SiPolicy' -or $document.DocumentElement.NamespaceURI -ne 'urn:schemas-microsoft-com:sipolicy') {
        throw "Not a WDAC policy XML: $Path"
    }
    $document
}

function Get-WdacDenyKeys {
    param([xml]$Policy)
    $rules = @{}
    foreach ($node in $Policy.SelectNodes("//*[local-name()='FileRules']/*[local-name()='Deny']")) {
        $attributes = @($node.Attributes | Where-Object Name -notin 'ID','FriendlyName' | Sort-Object Name | ForEach-Object { $_.Name + '=' + $_.Value })
        $key = ($attributes -join '|') + '|' + $node.InnerXml
        $rules[$node.GetAttribute('ID')] = $key
        'Deny|' + $key
    }
    foreach ($scenario in $Policy.SelectNodes("//*[local-name()='SigningScenario']")) {
        foreach ($reference in $scenario.SelectNodes(".//*[local-name()='FileRuleRef']")) {
            $id = $reference.GetAttribute('RuleID')
            if ($rules.ContainsKey($id)) { 'Scenario|' + $scenario.GetAttribute('Value') + '|' + $rules[$id] }
        }
    }
}

function Test-WdacDeniesPreserved {
    param([xml]$Baseline, [xml]$Policy)
    $actual = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
    foreach ($key in @(Get-WdacDenyKeys $Policy)) { $null = $actual.Add($key) }
    foreach ($key in @(Get-WdacDenyKeys $Baseline)) {
        if (-not $actual.Contains($key)) { return $false }
    }
    return $true
}

function Assert-WdacDeniesPreserved {
    param([xml]$Baseline, [xml]$Policy)
    if (-not (Test-WdacDeniesPreserved $Baseline $Policy)) { throw 'A baseline deny rule or its signing-scenario reference was lost. No policy published.' }
}

function Set-WdacLegacyBlockVersions {
    param([xml]$Policy, [int]$Build)
    if ($Build -ne 14393) { return }
    $limits = @{ ID_DENY_MSXML3='8.110.14393.2550'; ID_DENY_MSXML6='6.30.14393.2550'; ID_DENY_JSCRIPT9='11.0.14393.2607' }
    foreach ($node in $Policy.SelectNodes("//*[local-name()='Deny']")) {
        foreach ($id in $limits.Keys) {
            if ($node.GetAttribute('ID') -match ('^' + $id + '(_\d+)*$')) { $node.SetAttribute('MaximumFileVersion', $limits[$id]) }
        }
    }
}

function Merge-WdacBlocklist {
    param([string]$BasePath, [string]$BlocklistPath, [string]$OutputPath)
    $baseline = Read-WdacPolicy $BasePath
    $blocks = Read-WdacPolicy $BlocklistPath
    $inputPath = Join-Path ([IO.Path]::GetTempPath()) ('wdac-blocks-' + [guid]::NewGuid().ToString('N') + '.xml')
    try {
        # Retain the base policy options; the deny snapshot has its own audit-mode settings.
        $rules = $baseline.DocumentElement.SelectSingleNode("*[local-name()='Rules']")
        $blockRules = $blocks.DocumentElement.SelectSingleNode("*[local-name()='Rules']")
        $null = $blockRules.ParentNode.ReplaceChild($blocks.ImportNode($rules, $true), $blockRules)
        $blocks.Save($inputPath)
        $null = Merge-CIPolicy -PolicyPaths @($BasePath, $inputPath) -OutputFilePath $OutputPath
        $merged = Read-WdacPolicy $OutputPath
        Assert-WdacDeniesPreserved (Read-WdacPolicy $BlocklistPath) $merged
        Assert-WdacDeniesPreserved $baseline $merged
    } finally { Remove-Item -LiteralPath $inputPath -Force -ErrorAction SilentlyContinue }
}
