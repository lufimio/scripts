#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string[]]$ExcludePath = @(),
    [string]$BlocklistPath = (Join-Path $PSScriptRoot 'rules.xml'),
    [string]$BasePolicyPath,
    [ValidateSet('FilePublisher','Publisher','Hash')][string]$RuleLevel = 'FilePublisher',
    [switch]$SkipDrivers,
    [string]$OutputDirectory = (Join-Path $PSScriptRoot ('host-policies\' + $env:COMPUTERNAME + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss')))
)
$ErrorActionPreference = 'Stop'
if ($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage') { throw 'Capture running programs before enabling WDAC, from FullLanguage PowerShell.' }
if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess) { throw 'Use 64-bit Windows PowerShell to enumerate loaded modules.' }
Import-Module ConfigCI
. (Join-Path $PSScriptRoot 'policy-common.ps1')
. (Join-Path $PSScriptRoot 'mapped-images.ps1')
$blocklist = Read-WdacPolicy $BlocklistPath
if (-not $BasePolicyPath) { $BasePolicyPath = Join-Path $env:windir 'schemas\CodeIntegrity\ExamplePolicies\AllowMicrosoft.xml' }
$baseline = Read-WdacPolicy $BasePolicyPath
$build = [int](Get-CimInstance Win32_OperatingSystem).BuildNumber
Set-WdacLegacyBlockVersions $blocklist $build
Set-WdacLegacyBlockVersions $baseline $build
$OutputDirectory = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputDirectory)
if (Test-Path -LiteralPath $OutputDirectory) { throw 'Choose a new OutputDirectory; previous captures will not be overwritten.' }
$null = New-Item -Path $OutputDirectory -ItemType Directory
$work = Join-Path $env:TEMP ('wdac-inventory-' + [guid]::NewGuid().ToString('N'))
$null = New-Item -Path $work -ItemType Directory
$paths = @{}
$issues = New-Object 'System.Collections.Generic.List[string]'
$commandWarnings = @()
$captureTime = [DateTime]::UtcNow.ToString('o')

function Add-RunningFile {
    param([string]$Path, [string]$Source)
    if ([string]::IsNullOrWhiteSpace($Path)) { return }
    $path = [Environment]::ExpandEnvironmentVariables($Path.Trim().Trim('"'))
    if ($path.StartsWith('\SystemRoot\', [StringComparison]::OrdinalIgnoreCase)) { $path = Join-Path $env:windir $path.Substring(12) }
    if ($path.StartsWith('\??\')) { $path = $path.Substring(4) }
    if ($path.StartsWith('system32\', [StringComparison]::OrdinalIgnoreCase)) { $path = Join-Path $env:windir $path }
    try {
        $path = [IO.Path]::GetFullPath($path)
        foreach ($exclude in $ExcludePath) {
            $excluded = [IO.Path]::GetFullPath($exclude).TrimEnd('\')
            if ($path -ieq $excluded -or $path.StartsWith($excluded + '\', [StringComparison]::OrdinalIgnoreCase)) { return }
        }
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw 'File no longer exists or is inaccessible.' }
        if (-not $paths.ContainsKey($path)) { $paths[$path] = New-Object 'System.Collections.Generic.HashSet[string]' }
        $null = $paths[$path].Add($Source)
    } catch { $issues.Add("$Source -- $Path -- $($_.Exception.Message)") }
}

try {
    Write-Host 'Capturing running executables and their loaded DLLs.'
    $processes = @(Get-CimInstance Win32_Process)
    foreach ($process in $processes) {
        Add-RunningFile $process.ExecutablePath ("Process:$($process.ProcessId):$($process.Name)")
        if ($process.ProcessId -eq 0) { continue }
        try {
            $running = Get-Process -Id $process.ProcessId -ErrorAction Stop
            foreach ($module in $running.Modules) { Add-RunningFile $module.FileName ("Module:$($process.ProcessId):$($process.Name)") }
        } catch { $issues.Add("Modules for $($process.Name) ($($process.ProcessId)) -- $($_.Exception.Message)") }
        try {
            foreach ($path in [Competition.WdacMappedImages]::GetPaths([int]$process.ProcessId)) {
                Add-RunningFile $path ("MappedImage:$($process.ProcessId):$($process.Name)")
            }
        } catch { $issues.Add("Mapped images for $($process.Name) ($($process.ProcessId)) -- $($_.Exception.Message)") }
    }
    if (-not $SkipDrivers) {
        foreach ($driver in Get-CimInstance Win32_SystemDriver -Filter "State='Running'") {
            Add-RunningFile $driver.PathName ("Driver:$($driver.Name)")
        }
    }
    $inventoryRows = @(foreach ($path in @($paths.Keys | Sort-Object)) {
        try {
            $hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
            $signature = Get-AuthenticodeSignature -LiteralPath $path
            $publisher = ''; $thumbprint = ''
            if ($null -ne $signature.SignerCertificate) { $publisher=$signature.SignerCertificate.Subject; $thumbprint=$signature.SignerCertificate.Thumbprint }
            [pscustomobject]@{ Path=$path; SHA256=$hash; SignatureStatus=[string]$signature.Status; Publisher=$publisher;
                CertificateThumbprint=$thumbprint; Sources=(@($paths[$path]) -join '; '); CapturedUtc=$captureTime }
        } catch { $issues.Add("Inventory for $path -- $($_.Exception.Message)") }
    })
    if (-not $inventoryRows.Count) { throw 'No readable files found for running programs; no policy generated.' }
    $filePaths = @($inventoryRows.Path)
    Write-Host "Generating WDAC hash allowances for $($filePaths.Count) active files from $($processes.Count) processes."
    $hashRules = New-CIPolicyRule -DriverFilePath $filePaths -Level Hash -ErrorAction Stop -WarningVariable +commandWarnings
    if (-not $hashRules.Count) { throw 'No WDAC hash rules generated.' }
    $rules = New-Object 'System.Collections.Generic.List[object]'
    foreach ($rule in $hashRules) { $rules.Add($rule) }
    if ($RuleLevel -ne 'Hash') {
        Write-Host "Generating $RuleLevel allowances, with hash fallback."
        $publisherRules = New-CIPolicyRule -DriverFilePath $filePaths -Level $RuleLevel -Fallback Hash -ErrorAction Stop -WarningVariable +commandWarnings
        foreach ($rule in $publisherRules) { $rules.Add($rule) }
    }
    foreach ($file in $inventoryRows) {
        if ((Get-FileHash -LiteralPath $file.Path -Algorithm SHA256).Hash -ne $file.SHA256) { throw "File changed during capture: $($file.Path). No policy published." }
    }
    $combined = Join-Path $work 'Baseline.xml'
    $baseline.Save((Join-Path $work 'Base.xml'))
    $blocklist.Save((Join-Path $work 'Blocks.xml'))
    Merge-WdacBlocklist (Join-Path $work 'Base.xml') (Join-Path $work 'Blocks.xml') $combined
    $pending = Join-Path $work 'Host.xml'
    $null = Merge-CIPolicy -PolicyPaths $combined -OutputFilePath $pending -Rules $rules.ToArray()
    $policy = Read-WdacPolicy $pending
    Assert-WdacDeniesPreserved $blocklist $policy
    Assert-WdacDeniesPreserved $baseline $policy
    $null = ConvertFrom-CIPolicy -XmlFilePath $pending -BinaryFilePath (Join-Path $work 'Validation.cip')
    $inventory = Join-Path $OutputDirectory 'inventory.csv'
    $inventoryRows | Export-Csv -LiteralPath $inventory -NoTypeInformation -Encoding UTF8
    foreach ($warning in $commandWarnings) { $issues.Add($warning.ToString()) }
    if ($issues.Count) {
        $issues | Set-Content -LiteralPath (Join-Path $OutputDirectory 'capture-warnings.txt') -Encoding UTF8
        Write-Warning "$($issues.Count) capture issue(s), including any protected/exited processes. Review capture-warnings.txt."
    }
    $output = Join-Path $OutputDirectory ($env:COMPUTERNAME + '.xml')
    Copy-Item -LiteralPath $pending -Destination $output
    Write-Host "Preserved $($blocklist.SelectNodes("//*[local-name()='Deny']").Count) blocklist denies."
    Write-Host "Host policy: $output"
    Write-Host 'Running-software policy generated and compiled for validation; nothing deployed.'
    [pscustomobject]@{ PolicyPath=$output; InventoryPath=$inventory; Processes=$processes.Count; Files=$filePaths.Count;
        RuleLevel=$RuleLevel; Warnings=$issues.Count; CapturedUtc=$captureTime; Deployed=$false }
} finally { Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue }
