#Requires -Version 5.1
param([hashtable]$Configuration)
$ErrorActionPreference = 'Stop'
. (Join-Path $Configuration.ControllerRoot 'runner-common.ps1')
$session = $null
$phase = 'Connect'
$index = 0
$remote = 'C:\ProgramData\CCDC\Central\' + $Configuration.RunId
try {
    [pscustomobject]@{ Kind='Stage'; Phase='Connect'; Target=$Configuration.Target; Script='' }
    $options = New-PSSessionOption -OpenTimeout ($Configuration.ConnectTimeoutSeconds * 1000) -CancelTimeout 1000
    $connection = @{
        ComputerName = $Configuration.Target; Credential = (Get-CentralCredential $Configuration.Credential $Configuration.Target)
        Authentication = 'Negotiate'; Port = $Configuration.Port
        SessionOption = $options; ErrorAction = 'Stop'
    }
    if ($Configuration.UseSSL) { $connection.UseSSL = $true }
    $session = New-PSSession @connection
    $phase = 'Deploy'
    [pscustomobject]@{ Kind='Stage'; Phase='Deploy'; Target=$Configuration.Target; Script='' }
    Invoke-Command -Session $session -ArgumentList $remote -ScriptBlock {
        param($directory)
        $ErrorActionPreference = 'Stop'
        $null = New-Item -Path $directory -ItemType Directory
        $acl = New-Object Security.AccessControl.DirectorySecurity
        $acl.SetAccessRuleProtection($true, $false)
        $current = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
        foreach ($sid in @($current, 'S-1-5-18', 'S-1-5-32-544')) {
            $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule(
                (New-Object Security.Principal.SecurityIdentifier($sid)), 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')))
        }
        Set-Acl -LiteralPath $directory -AclObject $acl
    } | Out-Null
    Copy-Item -LiteralPath $Configuration.Bundle -Destination "$remote\suite.zip" -ToSession $session
    Invoke-Command -Session $session -ArgumentList $remote -ScriptBlock {
        param($directory)
        Expand-Archive -LiteralPath "$directory\suite.zip" -DestinationPath "$directory\suite" -ErrorAction Stop
    } | Out-Null

    for ($index = 0; $index -lt $Configuration.Tasks.Count; $index++) {
        $task = $Configuration.Tasks[$index]
        $phase = 'Run'
        [pscustomobject]@{ Kind='Stage'; Phase='Run'; Target=$Configuration.Target; Script=$task.Path }
        $row = New-CentralResult $Configuration.Target $task $index 'Unconfirmed' $null $remote
        $safeTarget = $Configuration.Target -replace '[^A-Za-z0-9_.-]', '_'
        $row.Log = Join-Path $Configuration.OutputDirectory ("$safeTarget-$('{0:D3}' -f $index).log")
        $log = New-Object IO.StreamWriter($row.Log, $false, (New-Object Text.UTF8Encoding($false)))
        $final = $null
        try {
            Invoke-Command -Session $session -ArgumentList $remote, $index, $task.Path, $task.Parameters -ScriptBlock {
                param($directory, $number, $script, $parameters)
                $ErrorActionPreference = 'Stop'
                $ProgressPreference = 'SilentlyContinue'
                $requestPath = "$directory\$number-request.json"
                $resultPath = "$directory\$number-result.json"
                $request = @{ script_path = "$directory\suite\$script"; parameters = $parameters; result_path = $resultPath }
                $request | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $requestPath -Encoding UTF8
                Set-Location -LiteralPath "$directory\suite"
                & "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$directory\suite\central\invoke-script.ps1" -RequestPath $requestPath 2>&1 | ForEach-Object {
                    [pscustomobject]@{ Kind='Log'; Line=$_.ToString() }
                }
                $code = $LASTEXITCODE
                $details = Get-Content -LiteralPath $resultPath -Raw -ErrorAction Stop | ConvertFrom-Json
                [pscustomobject]@{ Kind='Final'; ExitCode=$code; Details=$details }
            } -ErrorAction Stop | ForEach-Object {
                if ($_.Kind -eq 'Log') { $log.WriteLine($_.Line); $log.Flush() }
                elseif ($_.Kind -eq 'Final') { $final = $_ }
            }
        } finally { $log.Dispose() }
        if ($null -eq $final) { throw 'Remote execution ended without a completion report.' }
        $row.ExitCode = $final.ExitCode
        $row.Details = $final.Details
        $row.Status = if ($final.ExitCode -eq 0 -and $final.Details.Status -eq 'Success') { 'Success' } else { 'Failed' }
        if ($row.Status -eq 'Failed') {
            $messages = @($final.Details.Errors) + @($final.Details.FailedSteps | ForEach-Object { "$($_.Step): $($_.Error)" })
            $row.Error = if ($messages.Count) { $messages -join '; ' } else { 'Script failed; review its log.' }
        }
        [pscustomobject]@{ Kind='Result'; Value=$row }
        if ($row.Status -ne 'Success' -and -not $Configuration.ContinueOnError) {
            $index++
            break
        }
    }
} catch {
    if ($index -lt $Configuration.Tasks.Count) {
        $status = switch ($phase) { 'Connect' { 'ConnectionFailed' }; 'Deploy' { 'DeploymentFailed' }; default { 'Unconfirmed' } }
        $row = New-CentralResult $Configuration.Target $Configuration.Tasks[$index] $index $status $_.Exception.Message $remote
        [pscustomobject]@{ Kind='Result'; Value=$row }
        $index++
    }
} finally {
    for (; $index -lt $Configuration.Tasks.Count; $index++) {
        $row = New-CentralResult $Configuration.Target $Configuration.Tasks[$index] $index 'NotRun' 'An earlier operation on this host failed.' $remote
        [pscustomobject]@{ Kind='Result'; Value=$row }
    }
    if ($null -ne $session) { Remove-PSSession -Session $session -ErrorAction SilentlyContinue }
}
