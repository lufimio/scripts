#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$SuiteRoot = (Split-Path -Parent $PSScriptRoot),
    [ValidateRange(1, 86400)][int]$TimeoutSeconds = 900,
    [ValidateRange(1, 300)][int]$ConnectTimeoutSeconds = 10,
    [string]$OutputDirectory,
    [switch]$ContinueOnError,
    [ValidateSet('DomainController')][string]$Preset,
    [string]$PresetFile,
    [hashtable]$ParametersByScript = @{}
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'dovetail-ui-common.ps1')
$SuiteRoot = [IO.Path]::GetFullPath((Resolve-Path -LiteralPath $SuiteRoot).ProviderPath).TrimEnd('\')
if (-not (Test-Path -LiteralPath (Join-Path $SuiteRoot 'central\invoke-script.ps1') -PathType Leaf)) { throw 'Keep the central folder inside the complete scripts folder.' }
$usingPreset = $Preset -or $PresetFile
if ($ParametersByScript.Count -and -not $usingPreset) { throw 'ParametersByScript requires Preset or PresetFile in the interactive runner.' }
if ($usingPreset) { $presetTasks = @(Get-CentralPresetTasks $SuiteRoot $Preset $PresetFile $ParametersByScript) }
Write-Host '=== Dovetail ===' -ForegroundColor Cyan
Write-Host 'IPs -> credentials -> scripts -> live output'
do {
    try { $targets = @(Get-CentralTargets @((Read-Host 'Target IPs or hostnames, separated by commas'))); break }
    catch { Write-Host $_.Exception.Message -ForegroundColor Red }
} while ($true)
$credential = Read-DovetailCredential
$connections = New-Object 'System.Collections.Generic.List[object]'
$skipped = New-Object 'System.Collections.Generic.List[object]'
$addedTrust = @()
$output = $OutputDirectory
if (-not $output) { $output = Join-Path (Get-Location).ProviderPath ('logs\' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0, 8)) }
$output = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($output)
if ($output -ieq $SuiteRoot) { throw 'Use a separate directory for results.' }
$exitCode = 1
try {
    if ((Get-Service WinRM).Status -ne 'Running') { Start-Service WinRM }
    $existing = @((Get-Item WSMan:\localhost\Client\TrustedHosts).Value -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
    if ('*' -notin $existing) {
        $addedTrust = @($targets | Where-Object { $_ -notin $existing })
        if ($addedTrust.Count) {
            Set-Item WSMan:\localhost\Client\TrustedHosts -Value ((@($existing) + $addedTrust) -join ',') -Force
            Write-Host "Temporarily trusting: $($addedTrust -join ', ')"
        }
    }
    foreach ($target in $targets) {
        $connection = Connect-DovetailInteractiveTarget $target $credential $ConnectTimeoutSeconds
        if ($null -ne $connection.Session) { $connections.Add($connection) }
        else { $skipped.Add([pscustomobject]@{ Target=$target; Status='Skipped'; Attempts=$connection.Attempts; Error=$connection.Error }) }
    }
    Set-DovetailPrivateDirectory $output
    @{ Results=@() } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $output 'results.json') -Encoding UTF8
    if ($connections.Count) {
        $tasksByHost = @{}
        if ($usingPreset) {
            $tasksByHost=Read-DovetailPresetPlan $SuiteRoot @($connections | ForEach-Object {$_.Target}) $presetTasks
            if ($null -eq $tasksByHost) { Write-Host 'Cancelled. No scripts were deployed or executed.'; return }
        } else {
            $prefix = $SuiteRoot + '\'
            $available = @(Get-ChildItem -LiteralPath $SuiteRoot -Recurse -Filter '*.ps1' -File |
                Where-Object { $_.FullName -notmatch '\\(central|vendor)\\' } |
                ForEach-Object { $_.FullName.Substring($prefix.Length) } | Sort-Object)
            Write-Host "`nAvailable scripts" -ForegroundColor Cyan
            for ($i=0; $i -lt $available.Count; $i++) { Write-Host ('{0,3}) {1}' -f ($i+1), $available[$i]) }
            $same = Read-Host 'Use the same scripts and parameters on every connected host? [Y/n]'
            if ($same -notmatch '^(n|no)$') {
                $tasks = @(Read-DovetailTasks $SuiteRoot $available 'All connected hosts')
                foreach ($connection in $connections) { $tasksByHost[$connection.Target] = $tasks }
            } else {
                foreach ($connection in $connections) { $tasksByHost[$connection.Target] = @(Read-DovetailTasks $SuiteRoot $available $connection.Target) }
            }
        }
        $mode = if ($usingPreset) { 'in preset order' } else { 'in parallel' }
        Write-Host "`nStarting scripts $mode on each host." -ForegroundColor Cyan
        $results = @(Invoke-DovetailLiveScripts -Connections $connections.ToArray() -TasksByHost $tasksByHost -SuiteRoot $SuiteRoot -OutputDirectory $output -TimeoutSeconds $TimeoutSeconds -ContinueOnError:$ContinueOnError -Sequential:$usingPreset)
        $results | Select-Object Target, Script, Status, ExitCode | Format-Table -AutoSize | Out-Host
        if (-not $skipped.Count -and -not @($results | Where-Object Status -ne 'Success').Count) { $exitCode = 0 }
    }
    if ($skipped.Count) {
        Write-Host 'Skipped hosts' -ForegroundColor Yellow
        $skipped | Format-Table Target, Attempts, Error -Wrap -AutoSize | Out-Host
    }
    ConvertTo-Json -InputObject @($skipped.ToArray()) -Depth 5 | Set-Content -LiteralPath (Join-Path $output 'skipped-hosts.json') -Encoding UTF8
    Write-Host "Logs and results: $output"
} finally {
    foreach ($connection in $connections) { Remove-PSSession -Session $connection.Session -ErrorAction SilentlyContinue }
    if ($addedTrust.Count) {
        $current = @((Get-Item WSMan:\localhost\Client\TrustedHosts).Value -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        $remaining = @($current | Where-Object { $_ -notin $addedTrust })
        Set-Item WSMan:\localhost\Client\TrustedHosts -Value ($remaining -join ',') -Force
    }
}
exit $exitCode
