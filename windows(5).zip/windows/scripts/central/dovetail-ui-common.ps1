#Requires -Version 5.1
. (Join-Path $PSScriptRoot 'runner-common.ps1')

function Read-DovetailCredential {
    param([string]$Label = 'Shared', [string]$DefaultUsername = 'localuser')
    $username = Read-Host "$Label username [$DefaultUsername]"
    if ([string]::IsNullOrWhiteSpace($username)) { $username = $DefaultUsername }
    $password = Read-Host "$Label password" -AsSecureString
    New-Object Management.Automation.PSCredential($username, $password)
}

function Test-DovetailAuthenticationError {
    param([Management.Automation.ErrorRecord]$Failure)
    $text = $Failure.FullyQualifiedErrorId + ' ' + $Failure.Exception.Message
    $text -match 'AccessDenied|LogonFailure|InvalidCredential|AuthenticationFailed|0x80070005|0x8007052e|0x8009030[cd]|access is denied|logon failure|credentials.*(rejected|invalid|incorrect)|user ?name or password|no elevated administrator token'
}

function Connect-DovetailInteractiveTarget {
    param([string]$Target, [pscredential]$Credential, [int]$ConnectTimeoutSeconds = 10)
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        $session = $null
        try {
            Write-Host "[$Target] Connecting ($attempt/3)..." -ForegroundColor Cyan
            $session = New-PSSession -ComputerName $Target -Credential (Get-CentralCredential $Credential $Target) -Authentication Negotiate -SessionOption (New-PSSessionOption -OpenTimeout ($ConnectTimeoutSeconds * 1000) -CancelTimeout 1000) -ErrorAction Stop
            Invoke-Command -Session $session -ErrorAction Stop -ScriptBlock {
                $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
                if (-not (New-Object Security.Principal.WindowsPrincipal($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
                    throw 'Authentication succeeded, but account has no elevated administrator token.'
                }
            } | Out-Null
            Write-Host "[$Target] Connected as $($Credential.UserName)." -ForegroundColor Green
            return [pscustomobject]@{ Target=$Target; Session=$session; Attempts=$attempt; Error=$null }
        } catch {
            if ($null -ne $session) { Remove-PSSession -Session $session -ErrorAction SilentlyContinue }
            $failure = $_
            Write-Host "[$Target] $($failure.Exception.Message)" -ForegroundColor Red
            if (-not (Test-DovetailAuthenticationError $failure) -or $attempt -eq 3) {
                Write-Host "[$Target] Skipped." -ForegroundColor Yellow
                return [pscustomobject]@{ Target=$Target; Session=$null; Attempts=$attempt; Error=$failure.Exception.Message }
            }
            $Credential = Read-DovetailCredential -Label "Retry for $Target" -DefaultUsername $Credential.UserName
        }
    }
}

function ConvertTo-DovetailParameterValue {
    param([string]$Text, [type]$Type)
    if ($Type -eq [switch] -or $Type -eq [bool]) {
        switch -Regex ($Text.Trim()) {
            '^(true|\$true|yes|y|1)$' { return $true }
            '^(false|\$false|no|n|0)$' { return $false }
            default { throw 'Enter true or false.' }
        }
    }
    if ($Type.IsArray) {
        $items = if ($Text.TrimStart().StartsWith('[')) { @($Text | ConvertFrom-Json -ErrorAction Stop) } else { @($Text -split ',' | ForEach-Object { $_.Trim() }) }
        return ,@($items | ForEach-Object { [Management.Automation.LanguagePrimitives]::ConvertTo($_, $Type.GetElementType()) })
    }
    if ($Type -eq [hashtable]) {
        $value = ConvertTo-CentralParameters ($Text | ConvertFrom-Json -ErrorAction Stop)
        if ($value -isnot [hashtable]) { throw 'Enter a JSON object for a hashtable parameter.' }
        return $value
    }
    if ($Type -in [securestring], [pscredential]) { throw 'SecureString/PSCredential script parameters cannot be sent through the JSON worker.' }
    [Management.Automation.LanguagePrimitives]::ConvertTo($Text, $Type)
}

function Get-DovetailScriptParameterMetadata {
    param([string]$SuiteRoot, [string]$Script)
    $prefix = [IO.Path]::GetFullPath((Resolve-Path -LiteralPath $SuiteRoot).ProviderPath).TrimEnd('\') + '\'
    $path = [IO.Path]::GetFullPath((Join-Path $prefix $Script))
    if ([IO.Path]::IsPathRooted($Script) -or -not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetExtension($path) -ne '.ps1' -or -not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Script not found inside suite: $Script"
    }
    $tokens=$null; $parseErrors=$null
    $ast = [Management.Automation.Language.Parser]::ParseFile($path, [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count) { throw "$Script contains syntax errors: $($parseErrors.Message -join '; ')" }
    $metadata = @(
        if ($null -ne $ast.ParamBlock) {
            foreach ($parameter in $ast.ParamBlock.Parameters) {
                $mandatory = $false; $choices = @()
                foreach ($attribute in $parameter.Attributes) {
                    if ($attribute -isnot [Management.Automation.Language.AttributeAst]) { continue }
                    if ($attribute.TypeName.FullName -match '(^|\.)Parameter(Attribute)?$') {
                        foreach ($argument in $attribute.NamedArguments) {
                            if ($argument.ArgumentName -ieq 'Mandatory') {
                                $mandatory = $argument.ExpressionOmitted -or $argument.Argument.SafeGetValue() -eq $true
                            }
                        }
                    } elseif ($attribute.TypeName.FullName -match '(^|\.)ValidateSet(Attribute)?$') {
                        $choices = @($attribute.PositionalArguments | ForEach-Object { $_.SafeGetValue() })
                    }
                }
                [pscustomobject]@{ Name=$parameter.Name.VariablePath.UserPath; Type=$parameter.StaticType;
                    Mandatory=$mandatory; Choices=$choices; Default=$parameter.DefaultValue.Extent.Text }
            }
        }
    )
    return $metadata
}

function Read-DovetailScriptParameters {
    param([string]$SuiteRoot, [string]$Script)
    $metadata = @(Get-DovetailScriptParameterMetadata $SuiteRoot $Script)
    $map = @{}
    if (-not $metadata.Count) {
        Write-Host "$Script has no script parameters; using defaults."
        return $map
    }
    Write-Host "`nParameters for $Script" -ForegroundColor Cyan
    for ($i=0; $i -lt $metadata.Count; $i++) {
        $p = $metadata[$i]
        $hint = if ($p.Mandatory) { 'required' } elseif ($p.Default) { 'default: ' + $p.Default } else { 'optional' }
        if ($p.Choices.Count) { $hint += '; choices: ' + ($p.Choices -join ', ') }
        Write-Host ('{0,3}) {1} [{2}] ({3})' -f ($i+1), $p.Name, $p.Type.Name, $hint)
    }
    while ($true) {
        try {
            $selection = Read-Host 'Parameters to set: names/numbers, JSON object, or Enter for defaults'
            if ($selection.TrimStart().StartsWith('{')) {
                $map = ConvertTo-CentralParameters ($selection | ConvertFrom-Json -ErrorAction Stop)
                if ($map -isnot [hashtable]) { throw 'Parameters must be a JSON object.' }
                foreach ($name in $map.Keys) { if ($name -notin $metadata.Name) { throw "Unknown parameter: $name" } }
                $selected = @($metadata | Where-Object { $_.Mandatory -and -not $map.ContainsKey($_.Name) })
            } else {
                $selected = @($metadata | Where-Object Mandatory)
                foreach ($token in @($selection -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })) {
                    $p = $null
                    if ($token -match '^\d+$') {
                        $number = [int]$token
                        if ($number -ge 1 -and $number -le $metadata.Count) { $p = $metadata[$number-1] }
                    } else { $p = $metadata | Where-Object Name -eq $token.TrimStart('-') | Select-Object -First 1 }
                    if ($null -eq $p) { throw "Unknown parameter: $token" }
                    if ($p.Name -notin $selected.Name) { $selected += $p }
                }
            }
            break
        } catch { Write-Host $_.Exception.Message -ForegroundColor Red }
    }
    foreach ($p in $selected) {
        while ($true) {
            try {
                $hint = if ($p.Type -eq [switch]) { 'true/false; Enter=true' } elseif ($p.Choices.Count) { $p.Choices -join ', ' } elseif ($p.Type.IsArray) { 'comma-separated values or JSON array' } else { $p.Type.Name }
                $text = Read-Host "$($p.Name) ($hint)"
                if ([string]::IsNullOrEmpty($text)) {
                    if ($p.Type -eq [switch]) { $text = 'true' }
                    elseif ($p.Mandatory) { throw "$($p.Name) is required." }
                    else { break }
                }
                $value = ConvertTo-DovetailParameterValue $text $p.Type
                if ($p.Choices.Count) {
                    foreach ($item in @($value)) { if ($item -notin $p.Choices) { throw "Choose one of: $($p.Choices -join ', ')" } }
                }
                $map[$p.Name] = $value
                break
            } catch { Write-Host $_.Exception.Message -ForegroundColor Red }
        }
    }
    return $map
}

function Read-DovetailTasks {
    param([string]$SuiteRoot, [string[]]$AvailableScripts, [string]$Label)
    while ($true) {
        try {
            $selection = Read-Host "$Label scripts: numbers or relative paths, comma-separated"
            if ([string]::IsNullOrWhiteSpace($selection)) { throw 'Choose at least one script.' }
            $paths = @($selection -split ',' | ForEach-Object {
                $name = $_.Trim()
                if ($name -match '^\d+$') {
                    $number = [int]$name
                    if ($number -lt 1 -or $number -gt $AvailableScripts.Count) { throw "Unknown script number: $number" }
                    $AvailableScripts[$number - 1]
                } elseif ($name) { $name }
            } | Select-Object -Unique)
            if (-not $paths.Count) { throw 'Choose at least one script.' }
            $parameters = @{}
            foreach ($path in $paths) { $parameters[$path] = Read-DovetailScriptParameters $SuiteRoot $path }
            return @(Get-CentralTasks $SuiteRoot $paths @{} $parameters)
        } catch { Write-Host $_.Exception.Message -ForegroundColor Red }
    }
}

function Show-DovetailTaskDefaults {
    param([string]$SuiteRoot, $Task)
    $metadata = @(Get-DovetailScriptParameterMetadata $SuiteRoot $Task.Path)
    for ($i=0; $i -lt $metadata.Count; $i++) {
        $p=$metadata[$i]
        if ($Task.Parameters.ContainsKey($p.Name)) {
            $value=ConvertTo-Json -InputObject $Task.Parameters[$p.Name] -Compress -Depth 8
            $source='set'
        } else {
            $value=if ($p.Default) {$p.Default} elseif ($p.Type -eq [switch] -or $p.Type -eq [bool]) {'$false'} elseif ($p.Mandatory) {'<required>'} else {'<not set>'}
            $source='script default'
        }
        Write-Host ('    {0,2}) {1} = {2} [{3}]' -f ($i+1),$p.Name,$value,$source)
    }
    if (-not $metadata.Count) { Write-Host '    No script parameters.' }
    if ($Task.Path -ieq 'first15\firewall.ps1') {
        $preset=if ($Task.Parameters.ContainsKey('Preset')) {$Task.Parameters.Preset} else {'Custom'}
        $tcp=@($Task.Parameters.AllowedTCPPorts | Where-Object {$_})
        $udp=@($Task.Parameters.AllowedUDPPorts | Where-Object {$_})
        if ($preset -eq 'DomainController') {
            # Read literal additions from the script rather than evaluating its body.
            $tokens=$null; $errors=$null
            $ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $SuiteRoot $Task.Path),[ref]$tokens,[ref]$errors)
            foreach ($assignment in $ast.FindAll({param($node) $node -is [Management.Automation.Language.AssignmentStatementAst] -and $node.Operator -eq 'PlusEquals'},$true)) {
                if ($assignment.Left.Extent.Text -notin '$AllowedTCPPorts','$AllowedUDPPorts') { continue }
                $rightText=$assignment.Right.Extent.Text.Trim()
                $expression=$assignment.Right.FindAll({param($node) $node -is [Management.Automation.Language.ArrayLiteralAst] -or $node -is [Management.Automation.Language.StringConstantExpressionAst]},$true) |
                    Where-Object {$_.Extent.Text.Trim() -ceq $rightText} | Select-Object -First 1
                if ($null -eq $expression) { throw 'Firewall preset additions must be literal port lists to preview them.' }
                $additions=@($expression.SafeGetValue())
                if ($assignment.Left.Extent.Text -eq '$AllowedTCPPorts') { $tcp+=$additions }
                if ($assignment.Left.Extent.Text -eq '$AllowedUDPPorts') { $udp+=$additions }
            }
            Write-Host '    DomainController adds AD ports. For an SQL-only host, change Preset to Custom.' -ForegroundColor Yellow
        }
        Write-Host "    Firewall TCP: $((@($tcp | Sort-Object -Unique)) -join ', '); UDP: $((@($udp | Sort-Object -Unique)) -join ', ')"
        Write-Host '    Existing SSH/RDP allowances are also retained unless AllowManagementPortBlock=true.'
    }
    Write-Host '    Default expressions are shown as written; target-dependent values resolve on the target.'
}

function Read-DovetailTaskEdits {
    param([string]$SuiteRoot, $Task)
    $edited=[pscustomobject]@{Path=$Task.Path;Parameters=(ConvertTo-CentralParameters $Task.Parameters)}
    while ($true) {
        Write-Host "`nEditing $($edited.Path)" -ForegroundColor Cyan
        Show-DovetailTaskDefaults $SuiteRoot $edited
        $selection=(Read-Host 'Parameter name/number; +name appends array values; -name restores default; Enter=done').Trim()
        if (-not $selection) { return $edited }
        try {
            $operation=if ($selection.StartsWith('+')) {'append'} elseif ($selection.StartsWith('-')) {'reset'} else {'set'}
            $name=$selection.TrimStart('+','-')
            $metadata=@(Get-DovetailScriptParameterMetadata $SuiteRoot $edited.Path)
            $parameter=$null
            if ($name -match '^\d+$') {
                $number=[int]$name
                if ($number -ge 1 -and $number -le $metadata.Count) { $parameter=$metadata[$number-1] }
            } else { $parameter=$metadata | Where-Object Name -eq $name | Select-Object -First 1 }
            if ($null -eq $parameter) { throw "Unknown parameter: $name" }
            if ($operation -eq 'reset') {
                if ($parameter.Mandatory) { throw 'A required parameter cannot be cleared.' }
                $edited.Parameters.Remove($parameter.Name)
            } else {
                if ($operation -eq 'append' -and -not $parameter.Type.IsArray) { throw 'Append is available only for array parameters.' }
                $hint=if ($parameter.Choices.Count) {$parameter.Choices -join ', '} elseif ($parameter.Type -in [switch],[bool]) {'true/false'} elseif ($parameter.Type.IsArray) {'comma-separated values or JSON array; [] clears'} else {$parameter.Type.Name}
                $text=Read-Host "$($parameter.Name) ($hint; Enter=keep current)"
                if ([string]::IsNullOrEmpty($text)) { continue }
                $value=ConvertTo-DovetailParameterValue $text $parameter.Type
                if ($parameter.Choices.Count) {
                    foreach ($item in @($value)) { if ($item -notin $parameter.Choices) { throw "Choose one of: $($parameter.Choices -join ', ')" } }
                }
                if ($operation -eq 'append') {
                    $base=@()
                    if ($edited.Parameters.ContainsKey($parameter.Name)) { $base=@($edited.Parameters[$parameter.Name]) }
                    elseif ($parameter.Default) {
                        # Only literal defaults may be used as an append base.
                        $tokens=$null; $errors=$null
                        $ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $SuiteRoot $edited.Path),[ref]$tokens,[ref]$errors)
                        $declaration=$ast.ParamBlock.Parameters | Where-Object {$_.Name.VariablePath.UserPath -eq $parameter.Name} | Select-Object -First 1
                        try { $base=@($declaration.DefaultValue.SafeGetValue()) } catch { throw 'This default depends on the target. Set the full value instead of appending.' }
                    }
                    $value=@(@($base) + @($value) | Select-Object -Unique)
                }
                $edited.Parameters[$parameter.Name]=$value
            }
            # Normalize central remoting defaults after restoring a script default.
            $normalized=@(Get-CentralTasks $SuiteRoot @($edited.Path) $edited.Parameters @{})
            $edited=$normalized[0]
        } catch { Write-Host $_.Exception.Message -ForegroundColor Red }
    }
}

function Read-DovetailPresetPlan {
    param([string]$SuiteRoot, [string[]]$Targets, [object[]]$Tasks)
    $byHost=@{}
    foreach ($target in $Targets) {
        $byHost[$target]=@(foreach ($task in $Tasks) {
            [pscustomobject]@{Path=$task.Path;Parameters=(ConvertTo-CentralParameters $task.Parameters)}
        })
    }
    while ($true) {
        Write-Host "`nReview preset defaults and per-host settings" -ForegroundColor Cyan
        for ($h=0; $h -lt $Targets.Count; $h++) {
            $target=$Targets[$h]
            Write-Host ("`nHost {0}) {1}" -f ($h+1),$target) -ForegroundColor Cyan
            $hostTasks=@($byHost[$target])
            for ($i=0; $i -lt $hostTasks.Count; $i++) {
                Write-Host ('  Script {0}) {1}' -f ($i+1),$hostTasks[$i].Path)
                Show-DovetailTaskDefaults $SuiteRoot $hostTasks[$i]
            }
        }
        $choice=(Read-Host 'Enter=run reviewed plan; host number=edit that host; Q=cancel').Trim()
        if (-not $choice) { return $byHost }
        if ($choice -match '^(q|quit|cancel)$') { return $null }
        if ($choice -notmatch '^\d+$' -or [int]$choice -lt 1 -or [int]$choice -gt $Targets.Count) { Write-Host 'Choose a displayed host number.' -ForegroundColor Red; continue }
        $target=$Targets[[int]$choice-1]
        $hostTasks=@($byHost[$target])
        while ($true) {
            Write-Host "`nEdit scripts for $target" -ForegroundColor Cyan
            for ($i=0; $i -lt $hostTasks.Count; $i++) { Write-Host ('  {0}) {1}' -f ($i+1),$hostTasks[$i].Path) }
            $scriptChoice=(Read-Host 'Script number to edit parameters; Enter=back to review').Trim()
            if (-not $scriptChoice) { break }
            if ($scriptChoice -notmatch '^\d+$' -or [int]$scriptChoice -lt 1 -or [int]$scriptChoice -gt $hostTasks.Count) { Write-Host 'Choose a displayed script number.' -ForegroundColor Red; continue }
            $index=[int]$scriptChoice-1
            $hostTasks[$index]=Read-DovetailTaskEdits $SuiteRoot $hostTasks[$index]
            $byHost[$target]=$hostTasks
        }
    }
}

function Set-DovetailPrivateDirectory {
    param([string]$Path)
    $null = New-Item -Path $Path -ItemType Directory -ErrorAction Stop
    $acl = New-Object Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($sid in @([Security.Principal.WindowsIdentity]::GetCurrent().User.Value, 'S-1-5-18', 'S-1-5-32-544')) {
        $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule(
            (New-Object Security.Principal.SecurityIdentifier($sid)), 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')))
    }
    Set-Acl -LiteralPath $Path -AclObject $acl
}

function Start-DovetailScriptJob {
    param($Session, [string]$RemoteDirectory, [int]$Index, $Task)
    Invoke-Command -Session $Session -AsJob -ErrorAction Stop -ArgumentList $RemoteDirectory, $Index, $Task.Path, $Task.Parameters -ScriptBlock {
        param($directory, $number, $script, $parameters)
        $ErrorActionPreference = 'Stop'
        $ProgressPreference = 'SilentlyContinue'
        $requestPath = "$directory\$number-request.json"
        $resultPath = "$directory\$number-result.json"
        @{ script_path="$directory\suite\$script"; parameters=$parameters; result_path=$resultPath } |
            ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $requestPath -Encoding UTF8
        Set-Location -LiteralPath "$directory\suite"
        & "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$directory\suite\central\invoke-script.ps1" -RequestPath $requestPath 2>&1 | ForEach-Object {
            [pscustomobject]@{ Kind='Log'; Line=$_.ToString() }
        }
        $code = $LASTEXITCODE
        $details = Get-Content -LiteralPath $resultPath -Raw | ConvertFrom-Json
        [pscustomobject]@{ Kind='Final'; ExitCode=$code; Details=$details }
    }
}

function New-DovetailBundle {
    param([string]$SuiteRoot, [string]$Bundle, [string]$OutputDirectory)
    Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
    $prefix = [IO.Path]::GetFullPath($SuiteRoot).TrimEnd('\') + '\'
    $outputPrefix = [IO.Path]::GetFullPath($OutputDirectory).TrimEnd('\') + '\'
    $archive = [IO.Compression.ZipFile]::Open($Bundle, [IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($file in Get-ChildItem -LiteralPath $SuiteRoot -Recurse -File -Force) {
            $path = [IO.Path]::GetFullPath($file.FullName)
            $relative = $path.Substring($prefix.Length)
            if ($relative -match '(^|\\)logs(\\|$)' -or $path.StartsWith($outputPrefix, [StringComparison]::OrdinalIgnoreCase)) { continue }
            $null = [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $path, $relative.Replace('\','/'), [IO.Compression.CompressionLevel]::Optimal)
        }
    } finally { $archive.Dispose() }
}

function Invoke-DovetailLiveScripts {
    param([object[]]$Connections, [hashtable]$TasksByHost, [string]$SuiteRoot, [string]$OutputDirectory,
        [int]$TimeoutSeconds = 900, [switch]$ContinueOnError, [switch]$Sequential)
    $runId = [guid]::NewGuid().ToString('N')
    $bundle = Join-Path $env:TEMP "dovetail-$runId.zip"
    $active = New-Object 'System.Collections.Generic.List[object]'
    $rows = New-Object 'System.Collections.Generic.List[object]'
    try {
        New-DovetailBundle $SuiteRoot $bundle $OutputDirectory
        foreach ($connection in $Connections) {
            $target = $connection.Target
            $tasks = @($TasksByHost[$target])
            $safeTarget = $target -replace '[^A-Za-z0-9_.-]', '_'
            $remote = "C:\ProgramData\Dovetail\$runId-$safeTarget"
            try {
                Write-Host "[$target] Copying script suite..." -ForegroundColor Cyan
                Invoke-Command -Session $connection.Session -ArgumentList $remote -ErrorAction Stop -ScriptBlock {
                    param($directory)
                    $ErrorActionPreference = 'Stop'
                    $null = New-Item -Path $directory -ItemType Directory
                    $acl = New-Object Security.AccessControl.DirectorySecurity
                    $acl.SetAccessRuleProtection($true, $false)
                    foreach ($sid in @([Security.Principal.WindowsIdentity]::GetCurrent().User.Value, 'S-1-5-18', 'S-1-5-32-544')) {
                        $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule(
                            (New-Object Security.Principal.SecurityIdentifier($sid)), 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')))
                    }
                    Set-Acl -LiteralPath $directory -AclObject $acl
                } | Out-Null
                Copy-Item -LiteralPath $bundle -Destination "$remote\suite.zip" -ToSession $connection.Session -ErrorAction Stop
                Invoke-Command -Session $connection.Session -ArgumentList $remote -ErrorAction Stop -ScriptBlock {
                    param($directory)
                    Expand-Archive -LiteralPath "$directory\suite.zip" -DestinationPath "$directory\suite" -ErrorAction Stop
                } | Out-Null
                $sessionCount = if ($Sequential) { [Math]::Min(1, $tasks.Count) } else { $tasks.Count }
                for ($i=0; $i -lt $sessionCount; $i++) {
                    try {
                        $scriptSession = $connection.Session
                        if ($i -gt 0) { $scriptSession = New-PSSession -Session $connection.Session -ErrorAction Stop }
                        $active.Add([pscustomobject]@{ Target=$target; Session=$scriptSession; OwnSession=($i -gt 0); Tasks=$tasks; Index=$i; Remote=$remote;
                            Job=$null; Row=$null; Writer=$null; Final=$null; StreamErrors=@(); Deadline=[DateTime]::MaxValue })
                    } catch {
                        $rows.Add((New-CentralResult $target $tasks[$i] $i 'ConnectionFailed' $_.Exception.Message $remote))
                        Write-Host "[$target][$($tasks[$i].Path)] Session failed: $($_.Exception.Message)" -ForegroundColor Red
                    }
                }
            } catch {
                for ($i=0; $i -lt $tasks.Count; $i++) {
                    $row = New-CentralResult $target $tasks[$i] $i 'DeploymentFailed' $_.Exception.Message $remote
                    $rows.Add($row)
                }
                Write-Host "[$target] Deployment failed: $($_.Exception.Message)" -ForegroundColor Red
            }
        }
        while ($active.Count) {
            foreach ($entry in @($active.ToArray())) {
                if ($null -eq $entry.Job) {
                    $entry.Row = New-CentralResult $entry.Target $entry.Tasks[$entry.Index] $entry.Index 'Unconfirmed' $null $entry.Remote
                    $safe = $entry.Target -replace '[^A-Za-z0-9_.-]', '_'
                    $entry.Row.Log = Join-Path $OutputDirectory ("$safe-$('{0:D3}' -f $entry.Index).log")
                    $entry.Writer = New-Object IO.StreamWriter($entry.Row.Log, $false, (New-Object Text.UTF8Encoding($false)))
                    $entry.Final = $null; $entry.StreamErrors = @()
                    Write-Host "[$($entry.Target)] RUN $($entry.Row.Script)" -ForegroundColor Cyan
                    try {
                        $entry.Job = Start-DovetailScriptJob $entry.Session $entry.Remote $entry.Index $entry.Tasks[$entry.Index]
                        $entry.Deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
                    } catch { $entry.StreamErrors += $_.Exception.Message }
                }
                if ($null -ne $entry.Job) {
                    foreach ($message in @(Receive-Job -Job $entry.Job -ErrorAction Continue 2>&1)) {
                        if ($message -is [Management.Automation.ErrorRecord]) {
                            $entry.StreamErrors += $message.ToString()
                            $line = 'ERROR: ' + $message.ToString()
                        } elseif ($message.Kind -eq 'Final') { $entry.Final = $message; continue }
                        elseif ($message.Kind -eq 'Log') { $line = $message.Line }
                        else { $line = $message.ToString() }
                        $entry.Writer.WriteLine($line); $entry.Writer.Flush()
                        Write-Host "[$($entry.Target)][$($entry.Row.Script)] $line"
                    }
                }
                $timedOut = [DateTime]::UtcNow -gt $entry.Deadline
                if ($null -ne $entry.Job -and $entry.Job.State -notin 'Completed','Failed','Stopped' -and -not $timedOut) { continue }
                # Drain once more on the next poll so a job finishing during Receive-Job cannot lose its final output.
                if ($null -ne $entry.Job -and $entry.Job.HasMoreData -and -not $timedOut) { continue }
                if ($timedOut) {
                    $entry.Row.Status = 'TimedOut'
                    $entry.StreamErrors += 'Timeout: remote child processes may still be running. Inspect the host before retrying.'
                    Stop-Job -Job $entry.Job -ErrorAction SilentlyContinue
                } elseif ($null -ne $entry.Final) {
                    $entry.Row.ExitCode = $entry.Final.ExitCode
                    $entry.Row.Details = $entry.Final.Details
                    $entry.Row.Status = if ($entry.Final.ExitCode -eq 0 -and $entry.Final.Details.Status -eq 'Success' -and -not $entry.StreamErrors.Count) { 'Success' } else { 'Failed' }
                    $entry.StreamErrors += @($entry.Final.Details.Errors) + @($entry.Final.Details.FailedSteps | ForEach-Object { "$($_.Step): $($_.Error)" })
                } else {
                    if ($null -ne $entry.Job -and $entry.Job.JobStateInfo.Reason) { $entry.StreamErrors += $entry.Job.JobStateInfo.Reason.Message }
                    $entry.StreamErrors += 'No completion report received; remote outcome is unconfirmed.'
                }
                $entry.Row.Error = ($entry.StreamErrors | Where-Object { $_ }) -join '; '
                if ($entry.Row.Error) { $entry.Writer.WriteLine($entry.Row.Error) }
                $entry.Writer.Dispose(); $entry.Writer = $null
                if ($null -ne $entry.Job) { Remove-Job -Job $entry.Job -Force -ErrorAction SilentlyContinue; $entry.Job = $null }
                $rows.Add($entry.Row)
                $color = if ($entry.Row.Status -eq 'Success') { 'Green' } else { 'Red' }
                Write-Host "[$($entry.Target)] $($entry.Row.Status): $($entry.Row.Script) $($entry.Row.Error)" -ForegroundColor $color
                if ($Sequential -and $entry.Index + 1 -lt $entry.Tasks.Count) {
                    if ($entry.Row.Status -eq 'Success' -or ($ContinueOnError -and $entry.Row.Status -eq 'Failed')) {
                        # Reuse the authenticated session, including after users.ps1 rotates the caller's password.
                        $entry.Index++
                        continue
                    }
                    for ($next=$entry.Index + 1; $next -lt $entry.Tasks.Count; $next++) {
                        $rows.Add((New-CentralResult $entry.Target $entry.Tasks[$next] $next 'NotRun' 'An earlier operation on this host failed.' $entry.Remote))
                    }
                }
                if ($entry.OwnSession) { Remove-PSSession -Session $entry.Session -ErrorAction SilentlyContinue }
                $null = $active.Remove($entry)
            }
            @{ RunId=$runId; Results=@($rows.ToArray()) } | ConvertTo-Json -Depth 14 | Set-Content -LiteralPath (Join-Path $OutputDirectory 'results.json') -Encoding UTF8
            if ($active.Count) { Start-Sleep -Milliseconds 100 }
        }
        @{ RunId=$runId; Results=@($rows.ToArray()) } | ConvertTo-Json -Depth 14 | Set-Content -LiteralPath (Join-Path $OutputDirectory 'results.json') -Encoding UTF8
        return $rows.ToArray()
    } finally {
        foreach ($entry in $active.ToArray()) {
            if ($null -ne $entry.Job) { Stop-Job -Job $entry.Job -ErrorAction SilentlyContinue; Remove-Job -Job $entry.Job -Force -ErrorAction SilentlyContinue }
            if ($null -ne $entry.Writer) { $entry.Writer.Dispose() }
            if ($entry.OwnSession) { Remove-PSSession -Session $entry.Session -ErrorAction SilentlyContinue }
        }
        Remove-Item -LiteralPath $bundle -Force -ErrorAction SilentlyContinue
    }
}
