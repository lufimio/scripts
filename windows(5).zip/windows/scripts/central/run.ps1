#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string[]]$ComputerName,
    [pscredential]$Credential,
    [hashtable]$CredentialByHost = @{},
    [string[]]$Script,
    [hashtable]$ScriptParameters = @{},
    [hashtable]$ParametersByScript = @{},
    [string]$SuiteRoot = (Split-Path -Parent $PSScriptRoot),
    [ValidateRange(1, 64)][int]$ThrottleLimit = 8,
    [ValidateRange(1, 86400)][int]$TimeoutSeconds = 900,
    [ValidateRange(1, 300)][int]$ConnectTimeoutSeconds = 15,
    [ValidateRange(1, 65535)][int]$Port = 5985,
    [switch]$UseSSL,
    [switch]$ContinueOnError,
    [switch]$PassThru,
    [string]$OutputDirectory,
    [ValidateSet('DomainController')][string]$Preset,
    [string]$PresetFile
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'runner-common.ps1')
$usingPreset = $Preset -or $PresetFile
if ($usingPreset -and ($Script.Count -or $ScriptParameters.Count)) { throw 'Use ParametersByScript to override a preset; do not combine it with Script or ScriptParameters.' }
$SuiteRoot = (Resolve-Path -LiteralPath $SuiteRoot).ProviderPath
if ($usingPreset) { $tasks = @(Get-CentralPresetTasks $SuiteRoot $Preset $PresetFile $ParametersByScript) }
$interactive = -not $PSBoundParameters.ContainsKey('ComputerName')
if ($interactive) { $ComputerName = @((Read-Host 'Target IPs, separated by commas')) }
$targets = @(Get-CentralTargets $ComputerName)
$needsDefault = @($targets | Where-Object { -not $CredentialByHost.ContainsKey($_) }).Count -gt 0
if ($needsDefault -and $null -eq $Credential) {
    $username = Read-Host 'Shared username [admin]'
    if ([string]::IsNullOrWhiteSpace($username)) { $username = 'admin' }
    $password = Read-Host 'Shared password' -AsSecureString
    $Credential = New-Object Management.Automation.PSCredential($username, $password)
}
foreach ($target in $CredentialByHost.Keys) {
    if ($CredentialByHost[$target] -isnot [pscredential]) { throw "CredentialByHost[$target] must be a PSCredential." }
}
if (-not $usingPreset -and -not $Script.Count) {
    $choice = Read-Host 'Script paths, comma-separated [first15\hardening.ps1]'
    if ([string]::IsNullOrWhiteSpace($choice)) { $choice = 'first15\hardening.ps1' }
    $Script = @($choice -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
}
if (-not $usingPreset -and $interactive -and $Script.Count -eq 1 -and -not $ScriptParameters.Count -and -not $ParametersByScript.Count) {
    $inputParameters = Read-Host 'Parameters as JSON, or Enter for defaults'
    if (-not [string]::IsNullOrWhiteSpace($inputParameters)) {
        $parsed = ConvertTo-CentralParameters ($inputParameters | ConvertFrom-Json)
        if ($parsed -isnot [hashtable]) { throw 'Parameters must be a JSON object, for example {"ASRMode":"Audit"}.' }
        $ScriptParameters = $parsed
    }
}
if (-not $usingPreset) { $tasks = @(Get-CentralTasks $SuiteRoot $Script $ScriptParameters $ParametersByScript) }
if ($usingPreset) {
    Write-Host 'Preset: scripts run in the listed order on each host; all unspecified script defaults apply.' -ForegroundColor Cyan
    foreach ($task in $tasks) { Write-Host ("  {0} {1}" -f $task.Path, ($task.Parameters | ConvertTo-Json -Compress -Depth 8)) }
}
if ($UseSSL -and -not $PSBoundParameters.ContainsKey('Port')) { $Port = 5986 }
$runId = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ') + '-' + [guid]::NewGuid().ToString('N').Substring(0, 12)
if (-not $OutputDirectory) { $OutputDirectory = Join-Path $env:USERPROFILE "CCDCResults\$runId" }
$OutputDirectory = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputDirectory)
if (Test-Path -LiteralPath $OutputDirectory) { throw 'Choose a new output directory; previous reports will not be overwritten.' }
if ($OutputDirectory.StartsWith($SuiteRoot.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Keep controller results outside the scripts folder.'
}
$null = New-Item -Path $OutputDirectory -ItemType Directory
$acl = New-Object Security.AccessControl.DirectorySecurity
$acl.SetAccessRuleProtection($true, $false)
foreach ($sid in @([Security.Principal.WindowsIdentity]::GetCurrent().User.Value, 'S-1-5-18', 'S-1-5-32-544')) {
    $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule(
        (New-Object Security.Principal.SecurityIdentifier($sid)), 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')))
}
Set-Acl -LiteralPath $OutputDirectory -AclObject $acl
$bundle = Join-Path $env:TEMP ("central-$runId.zip")
$rows = New-Object 'System.Collections.Generic.List[object]'
$active = New-Object 'System.Collections.Generic.List[object]'
$pending = New-Object 'System.Collections.Generic.Queue[string]'
foreach ($target in $targets) { $pending.Enqueue($target) }
$addedTrust = @()

function Save-CentralResults {
    $report = @{ RunId=$runId; Results=@($rows.ToArray()) }
    $temp = Join-Path $OutputDirectory 'results.tmp'
    $report | ConvertTo-Json -Depth 14 | Set-Content -LiteralPath $temp -Encoding UTF8
    Move-Item -LiteralPath $temp -Destination (Join-Path $OutputDirectory 'results.json') -Force
}

try {
    # IP/local-account remoting needs exact TrustedHosts entries. Preserve concurrent additions on cleanup.
    if (-not $UseSSL) {
        if ((Get-Service WinRM).Status -ne 'Running') { Start-Service WinRM }
        $existingTrust = @((Get-Item WSMan:\localhost\Client\TrustedHosts).Value -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        if ('*' -notin $existingTrust) {
            $addedTrust = @($targets | Where-Object { $_ -notin $existingTrust })
            if ($addedTrust.Count) {
                Set-Item WSMan:\localhost\Client\TrustedHosts -Value ((@($existingTrust) + $addedTrust) -join ',') -Force
                Write-Host "Temporarily trusting these WinRM targets: $($addedTrust -join ', ')"
            }
        }
    }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::CreateFromDirectory($SuiteRoot, $bundle)
    Write-Host "Running $($tasks.Count) script(s) on $($targets.Count) host(s); parallel limit $ThrottleLimit."
    while ($pending.Count -or $active.Count) {
        while ($pending.Count -and $active.Count -lt $ThrottleLimit) {
            $target = $pending.Dequeue()
            $hostCredential = if ($CredentialByHost.ContainsKey($target)) { $CredentialByHost[$target] } else { $Credential }
            $configuration = @{
                Target=$target; Credential=$hostCredential; Tasks=$tasks; Bundle=$bundle; ControllerRoot=$PSScriptRoot
                RunId=$runId; OutputDirectory=$OutputDirectory; Port=$Port; UseSSL=[bool]$UseSSL
                ContinueOnError=[bool]$ContinueOnError; ConnectTimeoutSeconds=$ConnectTimeoutSeconds
            }
            $job = Start-Job -FilePath (Join-Path $PSScriptRoot 'host-job.ps1') -ArgumentList $configuration
            $active.Add([pscustomobject]@{ Job=$job; Target=$target; Deadline=[DateTime]::UtcNow.AddSeconds([Math]::Max($TimeoutSeconds, 300)); Completed=(New-Object 'System.Collections.Generic.HashSet[int]'); Phase='Connect' })
        }
        foreach ($entry in @($active.ToArray())) {
            $messages = @(Receive-Job -Job $entry.Job -ErrorAction Continue 2>&1)
            foreach ($message in $messages) {
                if ($message -is [Management.Automation.ErrorRecord]) { Write-Warning $message.ToString(); continue }
                if ($message.Kind -eq 'Stage') {
                    $entry.Phase = $message.Phase
                    if ($message.Phase -eq 'Run') { $entry.Deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds) }
                    Write-Host "[$($entry.Target)] $($message.Phase) $($message.Script)"
                } elseif ($message.Kind -eq 'Result') {
                    $row = $message.Value
                    if ($entry.Completed.Add([int]$row.ScriptIndex)) {
                        $rows.Add($row)
                        Write-Host "[$($entry.Target)] $($row.Status) $($row.Script) $($row.Error)"
                        Save-CentralResults
                    }
                }
            }
            $timedOut = [DateTime]::UtcNow -gt $entry.Deadline
            if ($timedOut -or $entry.Job.State -in 'Completed','Failed','Stopped') {
                if ($timedOut) {
                    for ($i=0; $i -lt $tasks.Count; $i++) {
                        if ($entry.Completed.Contains($i)) { continue }
                        $row = New-CentralResult $entry.Target $tasks[$i] $i 'TimedOut' 'Timeout. Remote work may still be running; do not automatically retry.' ('C:\ProgramData\CCDC\Central\' + $runId)
                        $rows.Add($row)
                        $null = $entry.Completed.Add($i)
                        break
                    }
                    Stop-Job -Job $entry.Job -ErrorAction SilentlyContinue
                }
                # Drain output emitted between the receive above and job completion.
                foreach ($message in @(Receive-Job -Job $entry.Job -ErrorAction SilentlyContinue)) {
                    if ($message.Kind -eq 'Result' -and $entry.Completed.Add([int]$message.Value.ScriptIndex)) { $rows.Add($message.Value) }
                }
                $firstMissing = $true
                for ($i=0; $i -lt $tasks.Count; $i++) {
                    if ($entry.Completed.Contains($i)) { continue }
                    $status = if (-not $firstMissing) { 'NotRun' } elseif ($timedOut) { 'TimedOut' } elseif ($entry.Phase -eq 'Connect') { 'ConnectionFailed' } else { 'Unconfirmed' }
                    $reason = if ($timedOut) { 'Timeout. Remote work may still be running; do not automatically retry.' } else { 'Host job ended without a completion report.' }
                    $row = New-CentralResult $entry.Target $tasks[$i] $i $status $reason ('C:\ProgramData\CCDC\Central\' + $runId)
                    $rows.Add($row)
                    Write-Host "[$($entry.Target)] $status $($tasks[$i].Path)"
                    $firstMissing = $false
                }
                Save-CentralResults
                Remove-Job -Job $entry.Job -Force
                $null = $active.Remove($entry)
            }
        }
        if ($active.Count) { Start-Sleep -Milliseconds 200 }
    }
} finally {
    foreach ($entry in @($active.ToArray())) { Stop-Job -Job $entry.Job -ErrorAction SilentlyContinue; Remove-Job -Job $entry.Job -Force -ErrorAction SilentlyContinue }
    Remove-Item -LiteralPath $bundle -Force -ErrorAction SilentlyContinue
    if ($addedTrust.Count) {
        $current = @((Get-Item WSMan:\localhost\Client\TrustedHosts).Value -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        $remaining = @($current | Where-Object { $_ -notin $addedTrust })
        Set-Item WSMan:\localhost\Client\TrustedHosts -Value ($remaining -join ',') -Force
    }
}
$rows | Sort-Object Target, ScriptIndex | Format-Table Target, Script, Status, ExitCode -AutoSize | Out-Host
Write-Host "Logs and results: $OutputDirectory"
if ($PassThru) { $rows.ToArray() }
if (@($rows | Where-Object Status -ne 'Success').Count) { exit 1 }
exit 0
