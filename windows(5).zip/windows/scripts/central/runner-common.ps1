#Requires -Version 5.1
function Get-CentralCredential {
    param([pscredential]$Credential, [string]$Target)
    if ($Credential.UserName -match '[\\@]') { return $Credential }
    New-Object Management.Automation.PSCredential("$Target\$($Credential.UserName)", $Credential.Password)
}

function ConvertTo-CentralParameters {
    param([object]$Value)
    if ($Value -is [System.Collections.IDictionary]) {
        $copy = @{}
        foreach ($key in $Value.Keys) { $copy[$key] = ConvertTo-CentralParameters $Value[$key] }
        return $copy
    }
    if ($null -ne $Value -and $Value.GetType().FullName -eq 'System.Management.Automation.PSCustomObject') {
        $copy = @{}
        foreach ($property in $Value.PSObject.Properties) { $copy[$property.Name] = ConvertTo-CentralParameters $property.Value }
        return $copy
    }
    if ($Value -is [array]) {
        return ,@($Value | ForEach-Object { ConvertTo-CentralParameters $_ })
    }
    return $Value
}

function Get-CentralTargets {
    param([string[]]$Addresses)
    $targets = @($Addresses | ForEach-Object { $_ -split '[,\s]+' } | Where-Object { $_ } | Select-Object -Unique)
    if (-not $targets.Count) { throw 'Enter at least one IP address or hostname.' }
    foreach ($target in $targets) {
        if ($target -notmatch '^[a-zA-Z0-9][a-zA-Z0-9.:-]*$') { throw "Invalid target: $target" }
    }
    return $targets
}

function Get-CentralTasks {
    param([string]$SuiteRoot, [string[]]$Script, [hashtable]$ScriptParameters, [hashtable]$ParametersByScript)
    if ($Script.Count -gt 1 -and $ScriptParameters.Count) { throw 'Use ParametersByScript when selecting multiple scripts.' }
    $root = [IO.Path]::GetFullPath((Resolve-Path -LiteralPath $SuiteRoot).ProviderPath).TrimEnd('\') + '\'
    foreach ($name in $Script) {
        if ([IO.Path]::IsPathRooted($name)) { throw 'Script paths must be relative to the scripts folder.' }
        $path = [IO.Path]::GetFullPath((Join-Path $root $name))
        if (-not $path.StartsWith($root, [StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetExtension($path) -ne '.ps1' -or -not (Test-Path -LiteralPath $path -PathType Leaf)) {
            throw "Script not found inside suite: $name"
        }
        $tokens = $null; $parseErrors = $null
        $null = [Management.Automation.Language.Parser]::ParseFile($path, [ref]$tokens, [ref]$parseErrors)
        if ($parseErrors.Count) { throw "$name contains syntax errors: $($parseErrors.Message -join '; ')" }
        $relative = $path.Substring($root.Length)
        $parameters = @{}
        $selected = if ($Script.Count -eq 1) { $ScriptParameters } else { @{} }
        if ($ParametersByScript.ContainsKey($name)) { $selected = $ParametersByScript[$name] }
        elseif ($ParametersByScript.ContainsKey($relative)) { $selected = $ParametersByScript[$relative] }
        if ($selected -isnot [System.Collections.IDictionary]) { throw "Parameters for $name must be a hashtable." }
        foreach ($key in $selected.Keys) {
            if ($key -notmatch '^[A-Za-z_]\w*$') { throw "Invalid parameter name: $key" }
            $parameters[$key] = $selected[$key]
        }
        if ($relative -ieq 'first15\hardening.ps1') {
            foreach ($setting in @('KeepWinRM', 'KeepLocalAdminRemoting')) {
                if (-not $parameters.ContainsKey($setting)) {
                    $parameters[$setting] = $true
                    Write-Host "Central hardening: adding $setting=true so results and later runs remain reachable." -ForegroundColor Yellow
                }
            }
        }
        [pscustomobject]@{ Path = $relative; Parameters = $parameters }
    }
}

function Get-CentralPresetTasks {
    param([string]$SuiteRoot, [string]$Preset, [string]$PresetFile, [hashtable]$ParametersByScript = @{})
    if ($Preset -and $PresetFile) { throw 'Choose Preset or PresetFile, not both.' }
    if ($Preset) {
        if ($Preset -ne 'DomainController') { throw "Unknown preset: $Preset" }
        $PresetFile = Join-Path $PSScriptRoot "presets\$Preset.json"
    }
    if (-not $PresetFile) { throw 'Choose a preset name or JSON preset file.' }
    $definition = ConvertTo-CentralParameters (Get-Content -LiteralPath $PresetFile -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop)
    if ($definition -isnot [hashtable] -or -not $definition.ContainsKey('Tasks') -or -not @($definition.Tasks).Count) {
        throw 'A preset must be a JSON object with a nonempty Tasks array.'
    }
    $paths = @(); $parameters = @{}
    foreach ($task in @($definition.Tasks)) {
        if ($task -isnot [hashtable] -or $task.Path -isnot [string] -or [string]::IsNullOrWhiteSpace($task.Path)) { throw 'Every preset task needs a relative script Path.' }
        $path = $task.Path.Replace('/', '\')
        if ($path -in $paths) { throw "Duplicate preset task: $path" }
        $paths += $path
        $map = if ($task.ContainsKey('Parameters')) { $task.Parameters } else { @{} }
        if ($map -isnot [hashtable]) { throw "Parameters for $path must be a JSON object." }
        $parameters[$path] = ConvertTo-CentralParameters $map
    }
    foreach ($key in $ParametersByScript.Keys) {
        $path = $key.Replace('/', '\')
        if ($path -notin $paths) { throw "Override does not match a preset script: $key" }
        $overrides = $ParametersByScript[$key]
        if ($overrides -isnot [System.Collections.IDictionary]) { throw "Overrides for $key must be a hashtable." }
        foreach ($name in $overrides.Keys) { $parameters[$path][$name] = ConvertTo-CentralParameters $overrides[$name] }
    }
    $tasks = @(Get-CentralTasks $SuiteRoot $paths @{} $parameters)
    foreach ($task in $tasks) {
        $tokens=$null; $errors=$null
        $ast = [Management.Automation.Language.Parser]::ParseFile((Join-Path $SuiteRoot $task.Path), [ref]$tokens, [ref]$errors)
        $names = @($ast.ParamBlock.Parameters | ForEach-Object { $_.Name.VariablePath.UserPath })
        foreach ($name in $task.Parameters.Keys) {
            if ($name -notin $names) { throw "Unknown parameter in preset for $($task.Path): $name" }
        }
    }
    return $tasks
}

function New-CentralResult {
    param([string]$Target, [object]$Task, [int]$Index, [string]$Status, [string]$ErrorMessage, [string]$RemoteDirectory)
    [pscustomobject]@{
        Target = $Target; Script = $Task.Path; ScriptIndex = $Index
        Status = $Status; ExitCode = $null; Error = $ErrorMessage
        Details = $null; Log = $null; RemoteDirectory = $RemoteDirectory
    }
}
