#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory)][string]$RequestPath)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$centralRequest = Get-Content -LiteralPath $RequestPath -Raw | ConvertFrom-Json
$script:centralResult = [ordered]@{
    Status = 'Failed'
    ComputerName = $env:COMPUTERNAME
    Identity = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    StartedUtc = [DateTime]::UtcNow.ToString('o')
    FinishedUtc = $null
    FailedSteps = @()
    Errors = @()
    NativeExitCode = 0
}
$centralStreamErrors = New-Object 'System.Collections.Generic.List[string]'

function Invoke-CentralScript {
    param([string]$CentralScriptPath, [hashtable]$CentralParameters)
    $global:LASTEXITCODE = 0
    $CentralScriptPath = [IO.Path]::GetFullPath($CentralScriptPath)
    $PSScriptRoot = Split-Path -Parent $CentralScriptPath
    . $CentralScriptPath @CentralParameters
    # Dot-sourcing keeps the suite's collected failures visible in this worker.
    $centralFailures = Get-Variable -Name ToolFailures -Scope Script -ErrorAction SilentlyContinue
    if ($null -ne $centralFailures) {
        $script:centralResult.FailedSteps = @($centralFailures.Value | Select-Object Step, Error)
    }
    $centralAuditFailures = Get-Variable -Name Failures -Scope Script -ErrorAction SilentlyContinue
    if ($null -ne $centralAuditFailures -and [int]$centralAuditFailures.Value -gt 0) {
        $script:centralResult.Errors += "Script reported $($centralAuditFailures.Value) failed checks/changes."
    }
    $script:centralResult.NativeExitCode = $global:LASTEXITCODE
    if ($global:LASTEXITCODE -ne 0) {
        $script:centralResult.Errors += "Final native command exit code: $global:LASTEXITCODE"
    }
}

try {
    $centralIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
    if (-not (New-Object Security.Principal.WindowsPrincipal($centralIdentity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Remote account must have an elevated administrator token.'
    }
    $centralTokens = $null
    $centralParseErrors = $null
    $null = [System.Management.Automation.Language.Parser]::ParseFile(
        $centralRequest.script_path, [ref]$centralTokens, [ref]$centralParseErrors)
    if ($centralParseErrors.Count) { throw ($centralParseErrors.Message -join '; ') }
    $centralParameters = @{}
    foreach ($centralProperty in $centralRequest.parameters.PSObject.Properties) {
        $centralParameters[$centralProperty.Name] = $centralProperty.Value
    }
    Invoke-CentralScript $centralRequest.script_path $centralParameters *>&1 | ForEach-Object {
        if ($_ -is [System.Management.Automation.ErrorRecord]) { $centralStreamErrors.Add($_.ToString()) }
        $_ | Out-String -Width 200 | Write-Output
    }
    $script:centralResult.Errors += @($centralStreamErrors)
    if (-not $script:centralResult.FailedSteps.Count -and -not $script:centralResult.Errors.Count) {
        $script:centralResult.Status = 'Success'
    }
} catch {
    $script:centralResult.Errors += $_.Exception.Message
    Write-Output "Central runner: $($_.Exception.Message)"
} finally {
    $script:centralResult.FinishedUtc = [DateTime]::UtcNow.ToString('o')
    $script:centralResult | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $centralRequest.result_path -Encoding UTF8
}
if ($script:centralResult.Status -eq 'Success') { exit 0 }
exit 1
