#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param([string[]]$ControllerAddress, [switch]$AllowLocalAdmin)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'runner-common.ps1')
if (-not $ControllerAddress.Count) { $ControllerAddress = @((Read-Host 'Controller IP addresses, comma-separated')) }
$addresses = @(Get-CentralTargets $ControllerAddress)
Enable-PSRemoting -SkipNetworkProfileCheck -Force
$rules = @(Get-NetFirewallRule -Name 'WINRM-HTTP-In-TCP*' -ErrorAction Stop)
$rules | Set-NetFirewallRule -Enabled True -RemoteAddress $addresses
if ($AllowLocalAdmin) {
    $path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'
    $null = New-ItemProperty -Path $path -Name LocalAccountTokenFilterPolicy -PropertyType DWord -Value 1 -Force
    Write-Host 'Local administrator remote UAC filtering disabled; WinRM firewall rules are restricted to the controller addresses.'
}
Write-Host "Built-in PowerShell remoting enabled for: $($addresses -join ', '). No software was installed."
