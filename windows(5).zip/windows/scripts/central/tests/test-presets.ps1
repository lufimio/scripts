#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
$centralRoot = Split-Path -Parent $PSScriptRoot
$suiteRoot = Split-Path -Parent $centralRoot
. (Join-Path $centralRoot 'dovetail-ui-common.ps1')
$script:assertions=0
function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
    $script:assertions++
}
function Assert-Throws {
    param([scriptblock]$Action, [string]$Message)
    $threw=$false
    try { & $Action | Out-Null } catch { $threw=$true }
    Assert-True $threw $Message
}
$temp = Join-Path $env:TEMP ('preset-tests-' + [guid]::NewGuid().ToString('N'))
$null=New-Item -Path $temp -ItemType Directory
try {
    $tasks=@(Get-CentralPresetTasks $suiteRoot 'DomainController' '' @{})
    Assert-True (($tasks.Path -join ',') -eq 'first15\users.ps1,first15\firewall.ps1,first15\hardening.ps1') 'Preset script order changed.'
    Assert-True ($tasks[0].Parameters.Count -eq 0) 'Users must retain its current defaults.'
    Assert-True ($tasks[1].Parameters.Preset -eq 'DomainController' -and $tasks[1].Parameters.Once -eq $true -and @($tasks[1].Parameters.AllowedTCPPorts).Count -eq 1 -and $tasks[1].Parameters.AllowedTCPPorts[0] -eq '5985') 'DC firewall parameters changed.'
    Assert-True ($tasks[2].Parameters.Count -eq 2 -and $tasks[2].Parameters.KeepWinRM -and $tasks[2].Parameters.KeepLocalAdminRemoting) 'Hardening must keep only the requested remoting overrides.'
    $overrides=@{'first15/firewall.ps1'=@{AllowedTCPPorts=@('5986','3389')}; 'first15\hardening.ps1'=@{KeepDomainGpos=$true;KeepLocalAdminRemoting=$false}}
    $custom=@(Get-CentralPresetTasks $suiteRoot 'DomainController' '' $overrides)
    Assert-True (($custom[1].Parameters.AllowedTCPPorts -join ',') -eq '5986,3389' -and $custom[1].Parameters.Once) 'Port override must merge with, not replace, preset parameters.'
    Assert-True ($custom[2].Parameters.KeepDomainGpos -and -not $custom[2].Parameters.KeepLocalAdminRemoting -and $custom[2].Parameters.KeepWinRM) 'Explicit false override was overwritten.'
    Assert-True (-not $overrides['first15\hardening.ps1'].ContainsKey('KeepWinRM')) 'Caller override map was mutated.'
    Assert-Throws {Get-CentralPresetTasks $suiteRoot 'DomainController' '' @{'typo.ps1'=@{}}} 'Unmatched script override accepted.'
    Assert-Throws {Get-CentralPresetTasks $suiteRoot 'DomainController' '' @{'first15\hardening.ps1'=@{Typo=$true}}} 'Unknown parameter accepted.'
    Assert-Throws {Get-CentralPresetTasks $suiteRoot 'DomainController' 'other.json' @{}} 'Conflicting preset sources accepted.'
    Assert-Throws {Get-CentralPresetTasks $suiteRoot 'Unknown' '' @{}} 'Unknown preset accepted.'
    $file=Join-Path $temp 'environment.json'
    @{Tasks=@(@{Path='first15\users.ps1';Parameters=@{SkipPasswordReset=$true}})} | ConvertTo-Json -Depth 6 | Set-Content $file
    $custom=@(Get-CentralPresetTasks $suiteRoot '' $file @{})
    Assert-True ($custom.Count -eq 1 -and $custom[0].Parameters.SkipPasswordReset) 'Custom JSON preset did not load.'
    foreach ($invalid in @(
        '{"Tasks":[]}',
        '{"Tasks":[{"Path":"first15/users.ps1","Parameters":{}},{"Path":"first15/users.ps1"}]}',
        '{"Tasks":[{"Path":"../outside.ps1"}]}',
        '{"Tasks":[{"Path":"first15/users.ps1","Parameters":true}]}',
        '{bad json'
    )) {
        Set-Content $file $invalid
        Assert-Throws {Get-CentralPresetTasks $suiteRoot '' $file @{}} 'Invalid custom preset accepted.'
    }

    # Fake remote transport and completed jobs; no actual suite script is executed.
    function New-DovetailBundle {param($SuiteRoot,$Bundle,$OutputDirectory); Set-Content $Bundle 'fixture'}
    function Invoke-Command {[CmdletBinding()]param($Session,$ArgumentList,$ScriptBlock)}
    function Copy-Item {[CmdletBinding()]param($LiteralPath,$Destination,$ToSession)}
    function New-PSSession {[CmdletBinding()]param($Session); throw 'Sequential presets must reuse the existing session.'}
    function Remove-PSSession {[CmdletBinding()]param($Session); throw 'Caller-owned session must not be closed by the worker.'}
    function Start-DovetailScriptJob {
        param($Session,$RemoteDirectory,$Index,$Task)
        $script:starts.Add("$($Session.Target):$Index")
        [pscustomobject]@{Target=$Session.Target;Index=$Index;State=$(if($script:timeout){'Running'}else{'Completed'});HasMoreData=$false}
    }
    function Receive-Job {
        [CmdletBinding()]param($Job)
        if($script:timeout){return}
        $code=if($Job.Target -eq 'host-a' -and $Job.Index -eq $script:failAt){1}else{0}
        [pscustomobject]@{Kind='Final';ExitCode=$code;Details=@{Status=$(if($code){'Failed'}else{'Success'});Errors=@();FailedSteps=@()}}
    }
    function Remove-Job {[CmdletBinding()]param($Job,[switch]$Force)}
    function Stop-Job {[CmdletBinding()]param($Job)}
    $connections=@('host-a','host-b' | ForEach-Object {[pscustomobject]@{Target=$_;Session=[pscustomobject]@{Target=$_}}})
    $byHost=@{'host-a'=$tasks;'host-b'=$tasks}
    foreach($case in @(
        @{Name='success';Fail=-1;Continue=$false;Timeout=$false},
        @{Name='stop-on-error';Fail=0;Continue=$false;Timeout=$false},
        @{Name='continue';Fail=1;Continue=$true;Timeout=$false},
        @{Name='timeout';Fail=-1;Continue=$true;Timeout=$true}
    )) {
        $script:starts=New-Object 'System.Collections.Generic.List[string]'
        $script:failAt=$case.Fail;$script:timeout=$case.Timeout
        $output=Join-Path $temp $case.Name
        $null=New-Item $output -ItemType Directory
        $limit=if($case.Timeout){-1}else{60}
        $results=@(Invoke-DovetailLiveScripts -Connections $connections -TasksByHost $byHost -SuiteRoot $suiteRoot -OutputDirectory $output -TimeoutSeconds $limit -ContinueOnError:$case.Continue -Sequential)
        Assert-True ($results.Count -eq 6) "$($case.Name): missing script results."
        $a=@($results | Where-Object Target -eq 'host-a' | Sort-Object ScriptIndex)
        $b=@($results | Where-Object Target -eq 'host-b' | Sort-Object ScriptIndex)
        if($case.Timeout) {
            Assert-True (($a.Status -join ',') -eq 'TimedOut,NotRun,NotRun' -and ($b.Status -join ',') -eq 'TimedOut,NotRun,NotRun') 'A timeout must stop later scripts even with ContinueOnError.'
        } elseif($case.Fail -eq 0) {
            Assert-True (($a.Status -join ',') -eq 'Failed,NotRun,NotRun' -and ($b.Status -join ',') -eq 'Success,Success,Success') 'Failure must stop only its host sequence.'
        } elseif($case.Fail -eq 1) {
            Assert-True (($a.Status -join ',') -eq 'Success,Failed,Success') 'ContinueOnError did not advance after a reported failure.'
        } else {
            Assert-True (($a.Status -join ',') -eq 'Success,Success,Success' -and ($b.Status -join ',') -eq 'Success,Success,Success') 'Ordered preset did not complete.'
        }
        foreach($target in @('host-a','host-b')) {
            $indices=@($script:starts | Where-Object {$_ -like "$target`:*"} | ForEach-Object {($_ -split ':')[1]})
            Assert-True (($indices -join ',') -in @('0','0,1,2')) 'Scripts started out of order or were retried.'
        }
        $saved=Get-Content (Join-Path $output 'results.json') -Raw | ConvertFrom-Json
        Assert-True ($saved.Results.Count -eq 6) 'Controller results lost ordered or skipped script rows.'
    }
    Write-Host "$script:assertions preset assertions passed."
} finally {Remove-Item -LiteralPath $temp -Recurse -Force}
exit 0
