#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
. (Join-Path $root 'runner-common.ps1')
$script:assertions = 0
function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
    $script:assertions++
}
function Assert-Throws {
    param([scriptblock]$Action, [string]$Message)
    $threw = $false
    try { & $Action | Out-Null } catch { $threw = $true }
    Assert-True $threw $Message
}
$temp = Join-Path $env:TEMP ('central-tests-' + [guid]::NewGuid().ToString('N'))
$null = New-Item -Path "$temp\first15" -ItemType Directory
try {
    $targets = @(Get-CentralTargets @('10.0.0.1, 10.0.0.2', '10.0.0.1'))
    Assert-True ($targets.Count -eq 2 -and $targets[1] -eq '10.0.0.2') 'CSV targets/deduplication failed.'
    Assert-Throws { Get-CentralTargets @('*') } 'Wildcard targets must be rejected.'
    Assert-Throws { Get-CentralTargets @('') } 'Empty targets must be rejected.'
    $secret = ConvertTo-SecureString 'local-test-fixture' -AsPlainText -Force
    $bare = New-Object Management.Automation.PSCredential('admin', $secret)
    $qualified = Get-CentralCredential $bare '10.0.0.1'
    Assert-True ($qualified.UserName -eq '10.0.0.1\admin' -and $qualified.GetNetworkCredential().Password -eq 'local-test-fixture') 'Shared local credential was not qualified without changing its password.'
    foreach ($name in @('DOMAIN\admin', '.\admin')) {
        $credential = New-Object Management.Automation.PSCredential($name, $secret)
        Assert-True ((Get-CentralCredential $credential '10.0.0.1').UserName -eq $name) 'Explicit credential authority changed.'
    }
    $parameters = ConvertTo-CentralParameters ('{"Flag":false,"Names":["two words","other"],"Count":3}' | ConvertFrom-Json)
    Assert-True ($parameters -is [hashtable] -and $parameters.Flag -is [bool] -and -not $parameters.Flag) 'False switch lost its type.'
    Assert-True ($parameters.Names.Count -eq 2 -and $parameters.Names[0] -eq 'two words' -and $parameters.Count -eq 3) 'Array/int parameters changed.'
    Set-Content "$temp\first15\hardening.ps1" 'param([switch]$KeepWinRM)'
    $original = @{}
    $tasks = @(Get-CentralTasks $temp @('first15\hardening.ps1') $original @{})
    Assert-True ($tasks[0].Parameters.KeepWinRM -eq $true -and -not $original.ContainsKey('KeepWinRM')) 'Management argument/default parameter map was modified incorrectly.'
    Assert-True ($tasks[0].Parameters.KeepLocalAdminRemoting -eq $true) 'Local administrator remoting preservation was not selected.'
    $fileSystem = New-Object -ComObject Scripting.FileSystemObject
    try {
        $shortRoot = $fileSystem.GetFolder($temp).ShortPath
        $shortTasks = @(Get-CentralTasks $shortRoot @('first15\hardening.ps1') @{} @{})
        Assert-True ($shortTasks.Count -eq 1 -and $shortTasks[0].Path -eq 'first15\hardening.ps1') 'Short suite paths must resolve to the same relative script path.'
    } finally { $null = [Runtime.InteropServices.Marshal]::ReleaseComObject($fileSystem) }
    $tasks = @(Get-CentralTasks $temp @('first15\hardening.ps1') @{KeepWinRM=$false;KeepLocalAdminRemoting=$false} @{})
    Assert-True ($tasks[0].Parameters.ContainsKey('KeepWinRM') -and -not $tasks[0].Parameters.KeepWinRM -and -not $tasks[0].Parameters.KeepLocalAdminRemoting) 'Explicit false argument was overwritten.'
    Assert-Throws { Get-CentralTasks $temp @('..\outside.ps1') @{} @{} } 'Traversal was accepted.'
    Assert-Throws { Get-CentralTasks $temp @('missing.ps1') @{} @{} } 'Missing script was accepted.'
    Set-Content "$temp\invalid.ps1" 'if ( { invalid'
    Assert-Throws { Get-CentralTasks $temp @('invalid.ps1') @{} @{} } 'Syntax error was accepted.'
    Assert-Throws { Get-CentralTasks $temp @('first15\hardening.ps1','invalid.ps1') @{Flag=$true} @{} } 'Ambiguous multi-script parameters were accepted.'


    $tokens=$null; $errors=$null
    $hardening = Join-Path (Split-Path -Parent $root) 'first15\hardening.ps1'
    $ast = [Management.Automation.Language.Parser]::ParseFile($hardening, [ref]$tokens, [ref]$errors)
    $guards = @($ast.FindAll({ param($node) $node -is [Management.Automation.Language.IfStatementAst] -and $node.Extent.Text.StartsWith('if (-not $KeepLocalAdminRemoting)') }, $true))
    Assert-True ($guards.Count -eq 1) 'Hardening must explicitly guard the remote-UAC policy write.'
    $script:policyWrites = New-Object 'System.Collections.Generic.List[object]'
    function Set-RegistryValue { param($Path,$Name,$Value); $script:policyWrites.Add(@{Name=$Name;Value=$Value}) }
    $KeepLocalAdminRemoting = $false
    . ([scriptblock]::Create($guards[0].Extent.Text))
    Assert-True ($script:policyWrites.Count -eq 1 -and $script:policyWrites[0].Name -eq 'LocalAccountTokenFilterPolicy' -and $script:policyWrites[0].Value -eq 0) 'Standalone hardening default changed.'
    $script:policyWrites.Clear()
    $KeepLocalAdminRemoting = $true
    . ([scriptblock]::Create($guards[0].Extent.Text))
    Assert-True ($script:policyWrites.Count -eq 0) 'Central mode rewrote the existing local-admin policy.'

    $cases = @(
        @{ Name='success'; Body="Write-Output 'ok'"; Expected='Success' },
        @{ Name='paths'; Body='[CmdletBinding()]param([string]$BackupDirectory=(Join-Path $PSScriptRoot ''backups'')) if ($BackupDirectory -ne (Join-Path $PSScriptRoot ''backups'')) { throw ''Script-relative parameter default changed'' }'; Expected='Success' },
        @{ Name='arguments'; Body='param([switch]$Flag=$true,[string[]]$Names,[int]$Count) if ($Flag -or $Names.Count -ne 2 -or $Names[0] -ne ''two words'' -or $Count -ne 3) { throw ''Arguments changed'' }'; Parameters=$parameters; Expected='Success' },
        @{ Name='collected'; Body='$script:ToolFailures = @([pscustomobject]@{Step=''fixture'';Error=''expected collected failure''})'; Expected='Failed' },
        @{ Name='audit'; Body='$script:Failures=1'; Expected='Failed' },
        @{ Name='throw'; Body="throw 'expected terminating failure'"; Expected='Failed' },
        @{ Name='nonterminating'; Body="Write-Error 'expected nonterminating failure' -ErrorAction Continue; Write-Output 'done'"; Expected='Failed' },
        @{ Name='native'; Body='cmd.exe /c exit 7'; Expected='Failed' },
        @{ Name='syntax'; Body='if ( { invalid'; Expected='Failed' }
    )
    foreach ($case in $cases) {
        $scriptPath = Join-Path $temp ($case.Name + '.ps1')
        $requestPath = Join-Path $temp ($case.Name + '-request.json')
        $resultPath = Join-Path $temp ($case.Name + '-result.json')
        Set-Content -LiteralPath $scriptPath -Value $case.Body -Encoding UTF8
        $argsMap = if ($case.ContainsKey('Parameters')) { $case.Parameters } else { @{} }
        @{ script_path=$scriptPath; parameters=$argsMap; result_path=$resultPath } | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $requestPath -Encoding UTF8
        & "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $root 'invoke-script.ps1') -RequestPath $requestPath *> (Join-Path $temp ($case.Name + '.log'))
        $exitCode = $LASTEXITCODE
        $result = Get-Content -LiteralPath $resultPath -Raw | ConvertFrom-Json
        Assert-True ($result.Status -eq $case.Expected) "$($case.Name): wrong worker result. $($result.Errors -join '; ')"
        Assert-True (($exitCode -eq 0) -eq ($case.Expected -eq 'Success')) "$($case.Name): wrong worker exit code."
        if ($case.Name -eq 'collected') { Assert-True ($result.FailedSteps.Count -eq 1) 'Collected step failure was lost.' }
        if ($case.Name -eq 'native') { Assert-True ($result.NativeExitCode -eq 7) 'Native exit code was lost.' }
    }
    Write-Host "$script:assertions native PowerShell assertions passed."
} finally { Remove-Item -LiteralPath $temp -Recurse -Force }
exit 0
