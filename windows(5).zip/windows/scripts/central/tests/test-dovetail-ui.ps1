#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
. (Join-Path (Split-Path -Parent $PSScriptRoot) 'dovetail-ui-common.ps1')
$script:assertions = 0
function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
    $script:assertions++
}
$secret = ConvertTo-SecureString 'fixture-only' -AsPlainText -Force
$credential = New-Object Management.Automation.PSCredential('localuser', $secret)
function New-PSSessionOption { param($OpenTimeout, $CancelTimeout); @{} }
function New-PSSession {
    [CmdletBinding()]
    param($ComputerName, $Credential, $Authentication, $SessionOption)
    $script:connects++
    $script:username = $Credential.UserName
    if ($script:networkFailure) { throw [TimeoutException]::new('The WinRM client cannot connect to the destination.') }
    if ($script:connects -le $script:failures) { throw [UnauthorizedAccessException]::new('Access is denied.') }
    [pscustomobject]@{ ComputerName=$ComputerName }
}
function Invoke-Command {
    [CmdletBinding()]
    param($Session, $ScriptBlock)
    if ($script:denyAdmin -and $script:connects -eq 1) { throw 'Authentication succeeded, but account has no elevated administrator token.' }
}
function Remove-PSSession { param($Session, $ErrorAction); $script:removed++ }
function Read-DovetailCredential { param($Label, $DefaultUsername); $script:prompts++; $credential }
foreach ($case in @(
    @{ Failures=0; ExpectedAttempts=1; ExpectedPrompts=0; Connected=$true },
    @{ Failures=2; ExpectedAttempts=3; ExpectedPrompts=2; Connected=$true },
    @{ Failures=3; ExpectedAttempts=3; ExpectedPrompts=2; Connected=$false },
    @{ Failures=0; Network=$true; ExpectedAttempts=1; ExpectedPrompts=0; Connected=$false },
    @{ Failures=0; DenyAdmin=$true; ExpectedAttempts=2; ExpectedPrompts=1; Connected=$true }
)) {
    $script:connects=0; $script:prompts=0; $script:removed=0
    $script:failures=$case.Failures; $script:networkFailure=$case.Network; $script:denyAdmin=$case.DenyAdmin
    $result = Connect-DovetailInteractiveTarget '10.0.0.1' $credential 1
    Assert-True ($result.Attempts -eq $case.ExpectedAttempts -and $script:connects -eq $case.ExpectedAttempts) 'Incorrect connection attempt limit.'
    Assert-True ($script:prompts -eq $case.ExpectedPrompts) 'Incorrect credential reprompt count.'
    Assert-True (($null -ne $result.Session) -eq $case.Connected) 'Incorrect connected/skipped outcome.'
    Assert-True ($script:username -eq '10.0.0.1\localuser') 'Shared local account must be qualified for each target.'
    if ($case.DenyAdmin) { Assert-True ($script:removed -eq 1) 'Unprivileged sessions must be closed before retrying.' }
}
$temp = Join-Path $env:TEMP ('dovetail-ui-tests-' + [guid]::NewGuid().ToString('N'))
$null = New-Item -Path "$temp\first15" -ItemType Directory
function Read-Host {
    param($Prompt)
    if (-not $script:answers.Count) { throw "Unexpected prompt: $Prompt" }
    $script:answers.Dequeue()
}
try {
    Set-Content -LiteralPath "$temp\first15\inventory.ps1" -Value 'param([switch]$Flag,[string[]]$Names)'
    Set-Content -LiteralPath "$temp\first15\hardening.ps1" -Value 'param([switch]$KeepWinRM,[switch]$KeepLocalAdminRemoting)'
    $script:answers = New-Object 'System.Collections.Generic.Queue[string]'
    foreach ($answer in @('1,2','{"Flag":false,"Names":["two words","other"]}','')) { $script:answers.Enqueue($answer) }
    $tasks = @(Read-DovetailTasks $temp @('first15\inventory.ps1','first15\hardening.ps1') 'fixture')
    Assert-True ($tasks.Count -eq 2 -and $tasks[0].Path -eq 'first15\inventory.ps1') 'Numbered/multiple script selection failed.'
    Assert-True ($tasks[0].Parameters.Flag -is [bool] -and -not $tasks[0].Parameters.Flag -and $tasks[0].Parameters.Names[0] -eq 'two words') 'Interactive JSON parameter types changed.'
    Assert-True ($tasks[1].Parameters.KeepWinRM -and $tasks[1].Parameters.KeepLocalAdminRemoting) 'Interactive hardening must preserve remoting.'
    $script:answers.Enqueue('first15\inventory.ps1'); $script:answers.Enqueue('{bad json'); $script:answers.Enqueue('')
    $tasks = @(Read-DovetailTasks $temp @('first15\inventory.ps1') 'fixture')
    Assert-True ($tasks.Count -eq 1 -and -not $script:answers.Count) 'Invalid parameter JSON must reprompt.'
    Set-Content -LiteralPath "$temp\required.ps1" -Value 'param([Parameter(Mandatory)][string]$Name,[ValidateSet(''Custom'',''DomainController'')][string]$Preset=''Custom'',[switch]$Once,[string[]]$Ports)'
    foreach ($answer in @('required.ps1','Preset,Once,Ports','required-user','DomainController','','5985,5986')) { $script:answers.Enqueue($answer) }
    $tasks = @(Read-DovetailTasks $temp @('required.ps1') 'fixture')
    Assert-True ($tasks[0].Parameters.Name -eq 'required-user') 'Mandatory parameters must be requested automatically.'
    Assert-True ($tasks[0].Parameters.Preset -eq 'DomainController' -and $tasks[0].Parameters.Once -eq $true) 'Selected named parameters/switches changed.'
    Assert-True ($tasks[0].Parameters.Ports.Count -eq 2 -and $tasks[0].Parameters.Ports[0] -eq '5985') 'Comma-separated array parameters changed.'
    Set-Content -LiteralPath "$temp\noargs.ps1" -Value 'Write-Output ''ready'''
    $script:answers.Enqueue('noargs.ps1')
    $tasks = @(Read-DovetailTasks $temp @('noargs.ps1') 'fixture')
    Assert-True ($tasks.Count -eq 1 -and $tasks[0].Parameters.Count -eq 0 -and -not $script:answers.Count) 'Scripts without parameters must not prompt for arguments.'
    $null = New-Item -Path "$temp\central\logs\previous", "$temp\reports" -ItemType Directory -Force
    Set-Content -LiteralPath "$temp\central\logs\previous\private.log" -Value 'must stay on controller'
    Set-Content -LiteralPath "$temp\reports\results.json" -Value '{}'
    New-DovetailBundle $temp "$temp.zip" "$temp\reports"
    $archive = [IO.Compression.ZipFile]::OpenRead("$temp.zip")
    try {
        $names = @($archive.Entries.FullName)
        Assert-True ('first15/inventory.ps1' -in $names) 'The script bundle lost script files.'
        Assert-True (-not @($names | Where-Object { $_ -match '(^|/)logs/' }).Count) 'Controller logs must not be deployed.'
        Assert-True (-not @($names | Where-Object { $_ -like 'reports/*' }).Count) 'The active output directory must not be deployed.'
    } finally { $archive.Dispose() }
    Write-Host "$script:assertions Dovetail interactive assertions passed."
} finally {
    Remove-Item -LiteralPath $temp -Recurse -Force
    Remove-Item -LiteralPath "$temp.zip" -Force -ErrorAction SilentlyContinue
}
exit 0
