#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$temp = Join-Path $env:TEMP ('dovetail-tests-' + [guid]::NewGuid().ToString('N'))
$oldProgramData = $env:ProgramData
$oldSessions = $global:Sessions
$null = New-Item -Path "$temp\source" -ItemType Directory -Force
try {
    $env:ProgramData = $temp
    $global:Sessions = @([pscustomobject]@{ ComputerName='localhost'; State='Opened' })
    # Replace only the remote transport; actual file copying and background jobs run locally.
    function Copy-Item {
        [CmdletBinding()]
        param($LiteralPath, $Destination, $ToSession, [switch]$Recurse, [switch]$Force)
        Microsoft.PowerShell.Management\Copy-Item -LiteralPath $LiteralPath -Destination $Destination -Recurse:$Recurse -Force:$Force
    }
    function Invoke-Command {
        [CmdletBinding()]
        param($Session, [scriptblock]$ScriptBlock, [object[]]$ArgumentList, [switch]$AsJob)
        if ($AsJob) {
            Start-Job -InitializationScript { Set-ExecutionPolicy -Scope Process -ExecutionPolicy Restricted -Force } -ScriptBlock $ScriptBlock -ArgumentList $ArgumentList
        }
        else { & $ScriptBlock @ArgumentList }
    }
    Set-Content -LiteralPath "$temp\source\common.ps1" -Value '$siblingValue = ''helper-loaded'''
    Set-Content -LiteralPath "$temp\source\fixture.ps1" -Value @'
[CmdletBinding()]
param([switch]$Enabled=$true, [string[]]$Names, [int]$Count, [string]$Text,
    [string]$BackupDirectory=(Join-Path $PSScriptRoot 'backups'))
. (Join-Path $PSScriptRoot 'common.ps1')
if ($BackupDirectory -ne (Join-Path $PSScriptRoot 'backups')) { throw 'Script-relative default parameter changed.' }
if ($Enabled -or $Names.Count -ne 2 -or $Names[0] -ne 'two words' -or $Count -ne 3 -or $Text -ne '$([Environment]::Exit(99))') { throw 'Parameter values changed.' }
if ($siblingValue -ne 'helper-loaded') { throw 'Sibling helper not loaded.' }
function Write-FixtureResult { Write-Output 'function-call-ok' }
Write-Output 'parameters-and-helper-ok'
'@
    & (Join-Path $root 'dovetail.ps1') -Script "$temp\source\fixture.ps1" -Out "$temp\logs" -ScriptParameters @{
        Enabled=$false; Names=@('two words', "O'Brien"); Count=3; Text='$([Environment]::Exit(99))'
    } -FunctionCall 'Write-FixtureResult'
    $log = Get-ChildItem -LiteralPath "$temp\logs" -File | Get-Content -Raw
    if ($log -notmatch 'parameters-and-helper-ok' -or $log -notmatch 'function-call-ok') {
        throw "Dovetail parameter/helper/function-call check failed: $log"
    }
    Set-Content -LiteralPath "$temp\source\fixture.ps1" -Value "throw 'expected-dovetail-error'"
    & (Join-Path $root 'dovetail.ps1') -Script "$temp\source\fixture.ps1" -Out "$temp\failed-logs"
    $log = Get-ChildItem -LiteralPath "$temp\failed-logs" -File | Get-Content -Raw
    if ($log -notmatch 'expected-dovetail-error') { throw 'Failed-job error was not saved to the log.' }
    Write-Host 'Dovetail parameter, helper, function-call, and failure-log checks passed.'
} finally {
    $env:ProgramData = $oldProgramData
    $global:Sessions = $oldSessions
    Remove-Item -LiteralPath $temp -Recurse -Force
}
exit 0
