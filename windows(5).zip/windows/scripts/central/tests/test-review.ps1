#Requires -Version 5.1
$ErrorActionPreference='Stop'
$central=Split-Path -Parent $PSScriptRoot
$suite=Split-Path -Parent $central
. (Join-Path $central 'dovetail-ui-common.ps1')
$script:assertions=0
$script:lines=New-Object 'System.Collections.Generic.List[string]'
function Assert-True {param([bool]$Condition,[string]$Message);if(!$Condition){throw $Message};$script:assertions++}
function Write-Host {param($Object,$ForegroundColor,[switch]$NoNewline);$script:lines.Add([string]$Object)}
function Read-Host {param($Prompt);if(!$script:answers.Count){throw "Unexpected review prompt: $Prompt"};$script:answers.Dequeue()}
function Set-Answers {param([string[]]$Values);$script:answers=New-Object 'System.Collections.Generic.Queue[string]';foreach($value in $Values){$script:answers.Enqueue($value)}}
function Invoke-DovetailLiveScripts {throw 'Review must not execute scripts'}
function New-DovetailBundle {throw 'Review must not deploy scripts'}
$tasks=@(Get-CentralPresetTasks $suite 'DomainController' '' @{})
$original=$tasks | ConvertTo-Json -Depth 10 -Compress
# Accept unchanged, including actual script defaults and effective DC port additions.
Set-Answers @('')
$accepted=Read-DovetailPresetPlan $suite @('dc01','sql01') $tasks
Assert-True ($accepted.Keys.Count -eq 2 -and $accepted['sql01'].Count -eq 3) 'Accepting defaults lost tasks/hosts.'
Assert-True (($script:lines -join "`n") -match 'ResetPasswords = \$true \[script default\]') 'Declared user defaults were not printed.'
Assert-True (($script:lines -join "`n") -match 'KeepWinRM = true \[set\]') 'Explicit preset overrides were not printed.'
Assert-True (($script:lines -join "`n") -match 'Firewall TCP:.*49152-65535') 'Effective DC firewall port additions were hidden.'
# Change only SQL host: Custom preset, append SQL port, optional strict management choice.
Set-Answers @('bad host','2','99','2','Preset','WrongPreset','Preset','Custom','+AllowedTCPPorts','1433,5985','AllowManagementPortBlock','true','','','')
$reviewed=Read-DovetailPresetPlan $suite @('dc01','sql01') $tasks
$sql=$reviewed['sql01'][1].Parameters
$dc=$reviewed['dc01'][1].Parameters
Assert-True ($sql.Preset -eq 'Custom' -and ($sql.AllowedTCPPorts -join ',') -eq '5985,1433') 'SQL port was not appended while keeping WinRM.'
Assert-True ($sql.AllowManagementPortBlock -eq $true -and $sql.Once -eq $true) 'Adding a previously unset switch lost existing settings.'
Assert-True ($dc.Preset -eq 'DomainController' -and $dc.AllowedTCPPorts.Count -eq 1 -and !$dc.ContainsKey('AllowManagementPortBlock')) 'Editing SQL changed the DC host.'
Assert-True (($tasks | ConvertTo-Json -Depth 10 -Compress) -eq $original) 'Editing mutated the source preset.'
Assert-True ($script:answers.Count -eq 0) 'Review exited before processing all requested changes.'
$script:lines.Clear()
Show-DovetailTaskDefaults $suite $reviewed['sql01'][1]
Assert-True (($script:lines -join "`n") -match 'Firewall TCP: 1433, 5985; UDP:' -and ($script:lines -join "`n") -notmatch '49152-65535') 'Custom SQL preview still included the DC ports.'
# Add/change/remove hardening parameters; explicit false must survive normalization.
Set-Answers @('KeepDomainGpos','true','KeepWinRM','false','')
$hardening=Read-DovetailTaskEdits $suite $tasks[2]
Assert-True ($hardening.Parameters.KeepDomainGpos -and $hardening.Parameters.ContainsKey('KeepWinRM') -and !$hardening.Parameters.KeepWinRM) 'False switch or added hardening override was lost.'
Set-Answers @('-KeepDomainGpos','-KeepWinRM','')
$restored=Read-DovetailTaskEdits $suite $hardening
Assert-True (!$restored.Parameters.ContainsKey('KeepDomainGpos') -and $restored.Parameters.KeepWinRM) 'Restoring defaults failed to restore central remoting defaults.'
Set-Answers @('q')
$cancelled=Read-DovetailPresetPlan $suite @('dc01') $tasks
Assert-True ($null -eq $cancelled) 'Cancel did not return without a runnable plan.'
$temp=Join-Path $env:TEMP ('review-tests-'+[guid]::NewGuid().ToString('N'))
$null=New-Item $temp -ItemType Directory
try{
 @'
param(
 [string[]]$Names=@('base'),
 [ValidateSet('One','Two')][string]$Choice='One',
 [int]$Count=2,
 [switch]$Flag,
 [string[]]$Dynamic=(Set-Content -LiteralPath (Join-Path $PSScriptRoot 'unsafe.txt') -Value 'executed')
)
throw 'Fixture script must not execute'
'@ | Set-Content (Join-Path $temp 'fixture.ps1')
 $fixture=[pscustomobject]@{Path='fixture.ps1';Parameters=@{}}
 Set-Answers @('+Names','extra','Count','not a number','Count','3','Flag','false','+Dynamic','extra','')
 $edited=Read-DovetailTaskEdits $temp $fixture
 Assert-True (($edited.Parameters.Names -join ',') -eq 'base,extra') 'Append lost the literal script default.'
 Assert-True ($edited.Parameters.Count -eq 3 -and !$edited.Parameters.Flag) 'Typed edits were not validated or preserved.'
 Assert-True (!$edited.Parameters.ContainsKey('Dynamic') -and !(Test-Path (Join-Path $temp 'unsafe.txt'))) 'Review evaluated target-dependent default code.'
 Set-Answers @('Names','[]','')
 $cleared=Read-DovetailTaskEdits $temp $edited
 Assert-True ($cleared.Parameters.ContainsKey('Names') -and @($cleared.Parameters.Names).Count -eq 0) 'An empty array could not be set.'
 Set-Answers @('1','1','Names','only-this-host','','','q')
 $cancelled=Read-DovetailPresetPlan $temp @('host') @($fixture)
 Assert-True ($null -eq $cancelled -and $fixture.Parameters.Count -eq 0) 'Cancelling after edits mutated the original plan.'
}finally{Remove-Item $temp -Recurse -Force}
Microsoft.PowerShell.Utility\Write-Host "$script:assertions preset review assertions passed."
exit 0
