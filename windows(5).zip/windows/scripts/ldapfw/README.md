# LDAP Firewall — DACLPrevention

Standalone PowerShell wrapper using the exact
[DACLPrevention configuration you supplied](https://raw.githubusercontent.com/zeronetworks/ldapfw/refs/heads/master/example_configs/DACLPrevention_config.json).
The bundled JSON only removes the upstream trailing comma and changes formatting.
When writing the installed config, the wrapper replaces the example `OREZ\DC01$`
exemption with the local DC's actual `DOMAIN\COMPUTER$` account. It preserves the
SYSTEM exemption and all other rules.

Run in elevated **64-bit Windows PowerShell on the DC**:

```powershell
.\ldapfw.ps1
```

For a new installation:

```powershell
.\ldapfw.ps1 -Action Install
```

To replace the old audit-only config in an existing installation:

```powershell
.\ldapfw.ps1 -Action Configure
.\ldapfw.ps1 -Action Update
```

Rules apply in order, first match wins:

1. Allow the DC computer account and `NT AUTHORITY\SYSTEM`, without auditing.
2. Block subtree searches requesting the listed sensitive attributes, including
   `admincount`, `userpassword`, delegation, LAPS and SPN attributes.
3. Block subtree searches containing the `(samAccountType=805306368)` filter.
4. Block modifications to the upstream list of sensitive attributes: ACLs,
   delegation, SPNs, authentication keys, account flags/names, GPO paths/extensions,
   and the other attributes present in `config.json`.
5. Allow other searches without auditing.
6. Allow and audit remaining operations.

This is a **blocking config**, not the audit-only default. It can also block
legitimate LDAP administration and application lookups. Its blocks omit `audit`,
which means those blocked requests are not event-logged by default. The final
allow rule audits other operations; upstream events can include attribute values.
Omitted `operations` means any operation, as in the supplied example.

The config does not remove existing malicious group memberships or ACLs.
It does not explicitly block all add/delete operations or group `member` changes;
the file is preserved rather than silently adding stronger rules. LDAPFW covers
LDAP, not ADWS, SAMR, DRSUAPI/DCSync, or direct SYSVOL writes. Its DC/SYSTEM
exemptions also remain applicable when those identities are compromised.

The wrapper downloads the official **v1.0.1 x64** package, verifies its archive
and five binaries against pinned SHA-256 hashes, and installs under
`C:\ProgramData\CCDC\LDAPFW`. It validates the config and symbol offsets before
invoking the native installer and checking protection status. Installation loads
LDAPFW into LSASS and requires the VC++ 2015–2022 x64 runtime, Microsoft symbol
server access, and compatible existing ASR/LSA protections. The ActiveDirectory
PowerShell module supplies the local domain's NetBIOS name.

```powershell
.\ldapfw.ps1 -Action Status
.\ldapfw.ps1 -Action Validate
.\ldapfw.ps1 -Action Update
.\ldapfw.ps1 -Action Uninstall
```

Configure writes the bundled prevention policy beside `ldapFwManager.exe`; it
does not reload a running instance. Install and Update preserve an existing config
unless Configure was explicitly requested. Download fetches only the binaries.
Use `-InstallDirectory` consistently if changing the installation location.
No separate inventory reports, transcripts, WhatIf path, or test files are added.

Upstream: [documentation](https://github.com/zeronetworks/ldapfw),
[release](https://github.com/zeronetworks/ldapfw/releases/tag/v1.0.1).
