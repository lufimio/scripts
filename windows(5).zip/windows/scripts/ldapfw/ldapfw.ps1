#Requires -Version 5.1
<#
.SYNOPSIS
Standalone LDAP Firewall setup using the upstream DACLPrevention configuration.
.EXAMPLE
.\ldapfw.ps1
.EXAMPLE
.\ldapfw.ps1 -Action Install
.EXAMPLE
.\ldapfw.ps1 -Action Update
.EXAMPLE
.\ldapfw.ps1 -Action Uninstall
#>
[CmdletBinding()]
param(
    [ValidateSet('Menu','Configure','Download','Validate','Install','Update','Status','Uninstall')]
    [string]$Action='Menu',
    [string]$InstallDirectory=(Join-Path $env:ProgramData 'CCDC\LDAPFW')
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$script:ConfigPath=Join-Path $InstallDirectory 'config.json'
$script:ReleaseUri='https://github.com/zeronetworks/ldapfw/releases/download/v1.0.1/ldapfw_v1.0.1-x64.zip'
$script:ReleaseHash='5bc3103e6b8570bd0336d7a07ee8b1282b95d7925814ee824bb2062ef4a8995d'
$script:BinaryHashes=[ordered]@{
    'ldapFwManager.exe'='0383ab4b505f451adca79fa9621875e1626885bce1c3c51e0d16700885ec737f'
    'ldapFW.dll'='8931ac34bf73a55b77ac46aaef3b1912ea833ffd4eb064a24edfa767447830e2'
    'ldapMessages.dll'='6a8713f398f22050603b1af8b87b43417ceb61c645242dcd52141984fda156fb'
    'dbghelp.dll'='7d8aae264b44738cdae6e25ae0e7ed3a19651372e6c4e7f37bfbba402b94fbbf'
    'symsrv.dll'='526d7eab0b8e7c28ea5ea23470952a5ed5a10c60a93b9a73abad8f169f7cce3c'
}
function Assert-LdapfwEnvironment {
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
    $principal=New-Object Security.Principal.WindowsPrincipal($identity)
    if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Run in elevated Windows PowerShell.'}
    if(-not [Environment]::Is64BitProcess){throw 'Use 64-bit Windows PowerShell.'}
    if($InstallDirectory -notmatch '^[A-Za-z]:\\.+'){throw 'InstallDirectory must be a dedicated absolute local directory.'}
    $path=[IO.Path]::GetFullPath($InstallDirectory).TrimEnd('\')
    if($path -in @($env:SystemRoot,$env:ProgramData,$env:ProgramFiles)){throw 'Choose a dedicated LDAPFW subdirectory.'}
    $ancestor=[IO.DirectoryInfo]$path
    while($null -ne $ancestor){
        if($ancestor.Exists -and ($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'InstallDirectory contains a reparse point.'}
        $ancestor=$ancestor.Parent
    }
}
function Initialize-LdapfwDirectory {
    $null=New-Item -ItemType Directory -Path $InstallDirectory -Force
    $acl=New-Object Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true,$false)
    foreach($text in 'S-1-5-18','S-1-5-32-544'){
        $sid=New-Object Security.Principal.SecurityIdentifier($text)
        $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($sid,'FullControl','ContainerInherit,ObjectInherit','None','Allow')))
    }
    Set-Acl -LiteralPath $InstallDirectory -AclObject $acl
}
function Assert-LdapfwConfig {
    param($Config)
    if($Config.PSObject.Properties.Name -cnotcontains 'rules' -or $Config.rules -isnot [Array] -or $Config.rules.Count -eq 0){throw 'Config must contain a nonempty rules array.'}
    foreach($rule in $Config.rules){
        foreach($name in $rule.PSObject.Properties.Name){if($name -cnotin 'operations','users','ips','groups','action','audit','dn','attributes','oid','filter','scope'){throw "Unknown rule field: $name"}}
        $operations=$rule.PSObject.Properties['operations']
        if($null -ne $operations){
            if($operations.Value -isnot [Array] -or $operations.Value.Count -eq 0){throw 'Explicit operations must be a nonempty array.'}
            foreach($op in $operations.Value){if($op -notin '*','add','delete','modify','modifydn','search','compare','extended'){throw "Unknown operation: $op"}}
        }
        foreach($field in 'users','ips','groups','attributes'){
            $property=$rule.PSObject.Properties[$field]
            if($null -ne $property -and ($property.Value -isnot [Array] -or @($property.Value).Count -eq 0)){throw "$field must be a nonempty array."}
        }
        $property=$rule.PSObject.Properties['action']
        if($null -ne $property -and $property.Value -cnotin 'allow','block'){throw 'Invalid action; expected allow/block.'}
        $property=$rule.PSObject.Properties['audit']
        if($null -ne $property -and $property.Value -cnotin 'on','off'){throw 'Invalid audit value; expected on/off.'}
    }
}
function Set-LdapfwPreventionConfig {
    $source=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'config.json') -Raw
    $config=$source | ConvertFrom-Json
    Assert-LdapfwConfig $config
    $computer=Get-CimInstance Win32_ComputerSystem
    if($computer.DomainRole -notin 4,5){throw 'Configure DACLPrevention locally on the DC so its computer-account exemption is correct.'}
    Import-Module ActiveDirectory
    $domain=Get-ADDomain -Server $env:COMPUTERNAME
    # The upstream example hardcodes OREZ\DC01$; substitute this DC only.
    $config.rules[0].users=@(('{0}\{1}$' -f $domain.NetBIOSName,$env:COMPUTERNAME),'NT AUTHORITY\SYSTEM')
    $source=ConvertTo-Json -InputObject $config -Depth 12
    Initialize-LdapfwDirectory
    $temp=Join-Path $InstallDirectory ('config-'+[guid]::NewGuid().ToString('N')+'.tmp')
    try{
        [IO.File]::WriteAllText($temp,$source,(New-Object Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $temp -Destination $script:ConfigPath -Force
    }finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
}
function Assert-LdapfwBinaries {
    foreach($name in $script:BinaryHashes.Keys){
        $path=Join-Path $InstallDirectory $name
        if(-not(Test-Path -LiteralPath $path -PathType Leaf) -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ine $script:BinaryHashes[$name]){throw "Missing or changed binary: $name. Use -Action Download to restore the pinned package."}
    }
}
function Install-LdapfwPackage {
    if(Get-Service -Name 'LDAP Firewall' -ErrorAction SilentlyContinue){throw 'Uninstall LDAPFW before replacing its binaries.'}
    $temp=Join-Path $env:TEMP ('ccdc-ldapfw-'+[guid]::NewGuid().ToString('N'))
    try{
        $null=New-Item -ItemType Directory -Path $temp
        $zip=Join-Path $temp 'release.zip'
        $protocol=[Net.ServicePointManager]::SecurityProtocol
        try{[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;Invoke-WebRequest -UseBasicParsing -Uri $script:ReleaseUri -OutFile $zip}
        finally{[Net.ServicePointManager]::SecurityProtocol=$protocol}
        if((Get-FileHash $zip -Algorithm SHA256).Hash -ine $script:ReleaseHash){throw 'Release archive checksum mismatch.'}
        Expand-Archive -LiteralPath $zip -DestinationPath (Join-Path $temp 'package')
        Initialize-LdapfwDirectory
        foreach($name in $script:BinaryHashes.Keys){Copy-Item -LiteralPath (Join-Path $temp ('package\'+$name)) -Destination (Join-Path $InstallDirectory $name)}
        Assert-LdapfwBinaries
        Write-Host '[+] LDAPFW v1.0.1 downloaded and verified'
    }finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Recurse -Force}}
}
function Invoke-LdapfwNative {
    param([ValidateSet('/validate','/install','/update','/status','/uninstall')][string]$Command)
    Assert-LdapfwBinaries
    $missing=@(foreach($dll in 'MSVCP140.dll','VCRUNTIME140.dll','VCRUNTIME140_1.dll'){
        if(-not(Test-Path -LiteralPath (Join-Path $InstallDirectory $dll)) -and -not(Test-Path -LiteralPath (Join-Path $env:SystemRoot ('System32\'+$dll)))){$dll}
    })
    if($missing.Count){throw "Install the Microsoft VC++ 2015-2022 x64 runtime first. Missing: $($missing -join ', ')"}
    Push-Location $InstallDirectory
    try{
        $output=@(& (Join-Path $InstallDirectory 'ldapFwManager.exe') $Command 2>&1 | ForEach-Object {[string]$_})
        if($LASTEXITCODE -ne 0){
            $code=$LASTEXITCODE
            throw "LDAPFW $Command failed (exit $code). Verify the VC++ 2015-2022 x64 runtime and symbols prerequisites. $($output -join ' ')"
        }
        $output -join "`n"
    }finally{Pop-Location}
}
function Invoke-LdapfwAction {
    param([string]$SelectedAction)
    if($SelectedAction -eq 'Status'){
        $service=Get-Service -Name 'LDAP Firewall' -ErrorAction SilentlyContinue
        $state=if($null -ne $service){[string]$service.Status}else{'Not installed'}
        Write-Host "[+] LDAPFW service: $state"
        Write-Host "[+] Config: $script:ConfigPath"
        return
    }
    Assert-LdapfwEnvironment
    if($SelectedAction -eq 'Configure'){
        Set-LdapfwPreventionConfig
        Write-Host "[+] DACLPrevention saved: $script:ConfigPath"
        return
    }
    if($SelectedAction -eq 'Download'){Install-LdapfwPackage;return}
    if($SelectedAction -eq 'Uninstall'){
        $output=Invoke-LdapfwNative '/uninstall'
        if(Get-Service -Name 'LDAP Firewall' -ErrorAction SilentlyContinue){throw "Service still registered. $output"}
        $status=Invoke-LdapfwNative '/status'
        if($status -notmatch 'LDAPFW Installed:\s*False'){throw "Unloaded protection could not be confirmed. $status"}
        Write-Host '[+] LDAPFW uninstalled'
        return
    }
    $computer=Get-CimInstance Win32_ComputerSystem
    $os=Get-CimInstance Win32_OperatingSystem
    if($computer.DomainRole -notin 4,5 -or [int]$os.BuildNumber -lt 14393){throw 'Use a Windows Server 2016+ domain controller.'}
    $service=Get-Service -Name 'LDAP Firewall' -ErrorAction SilentlyContinue
    if($SelectedAction -eq 'Install' -and $null -ne $service){throw 'Already installed; use Update.'}
    if($SelectedAction -eq 'Update' -and ($null -eq $service -or $service.Status -ne 'Running')){throw 'LDAPFW must be running before Update.'}
    try{Assert-LdapfwBinaries}catch{
        if($SelectedAction -ne 'Install'){throw}
        Install-LdapfwPackage
    }
    if(-not(Test-Path -LiteralPath $script:ConfigPath)){
        if($SelectedAction -ne 'Install'){throw 'Configure first or install LDAPFW.'}
        Set-LdapfwPreventionConfig
    }
    Assert-LdapfwConfig (Get-Content -LiteralPath $script:ConfigPath -Raw | ConvertFrom-Json)
    $validation=Invoke-LdapfwNative '/validate'
    if($validation -notmatch 'Config file is valid'){throw "Native validation failed. $validation"}
    if($SelectedAction -eq 'Validate'){Write-Host '[+] Native config/symbol validation passed';return}
    $command=if($SelectedAction -eq 'Install'){'/install'}else{'/update'}
    $output=Invoke-LdapfwNative $command
    $status=Invoke-LdapfwNative '/status'
    if($status -notmatch 'LDAPFW Installed:\s*True' -or $status -notmatch 'Config valid:\s*True'){throw "Protection could not be confirmed. $output $status"}
    Write-Host "[+] LDAPFW $SelectedAction verified"
}
if($Action -ne 'Menu'){Invoke-LdapfwAction $Action;return}
while($true){
    Write-Host "`nLDAPFW | DACLPrevention"
    Write-Host '[1] Install (LSASS hook)  [2] Status  [3] Validate  [4] Reload  [5] Write DACLPrevention config  [6] Uninstall  [0] Exit'
    $choice=Read-Host 'Choose'
    try{
        $selected=switch($choice){'1'{'Install'};'2'{'Status'};'3'{'Validate'};'4'{'Update'};'5'{'Configure'};'6'{'Uninstall'};'0'{return};''{return};default{throw 'Choose a listed option.'}}
        if($choice -eq '0' -or $choice -eq ''){return}
        Invoke-LdapfwAction $selected
    }catch{Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Red}
}
