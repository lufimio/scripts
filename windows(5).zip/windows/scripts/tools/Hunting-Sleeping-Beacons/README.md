# Hunting Sleeping Beacons

64-bit Windows scanner built from [thefLink/Hunt-Sleeping-Beacons](https://github.com/thefLink/Hunt-Sleeping-Beacons), pinned to commit `84dd3a9213a236231274dce569c0a6c866f53094`, with fixes to argument handling and process enumeration.

Run from the `scripts/tools` folder in elevated Windows PowerShell. Replace `2596` with the process ID to inspect:

```powershell
.\Hunting-Sleeping-Beacons.exe --dotnet --pid 2596 --commandline
```

- `--dotnet` includes managed processes such as Apollo. Without it, .NET processes are excluded.
- `-p PID` / `--pid PID` scans only that PID, using the full 32-bit Windows PID.
- `--commandline` prints command lines for findings and for an explicitly selected process.
- `-h` / `--help` displays usage and exits without scanning.
- Missing/invalid PID values, duplicate PID options and unknown options exit with code 2 without scanning.
- A selected process that is absent, inaccessible, 32-bit or filtered out exits with code 3 and an explicit message. Privilege failures exit with code 1.

The scanner prints its effective PID scope and .NET setting without a startup banner. This build also fixes omission of the final process-list entry and releases the process-query buffer. Detection heuristics are unchanged. Scanning a process does not guarantee detection; .NET scanning can produce false positives. 32-bit processes remain unsupported.

## Verification

Built on 2026-11-12 with MSVC v143 (14.44.35207), x64 Release, static runtime.

Thirteen native CLI checks passed on Windows Server 2022: help; unknown options; missing, zero, negative, nonnumeric, partially numeric, overflowing and duplicate PIDs; default .NET exclusion; a PID above 65,535 without aliasing; targeted .NET scanning with command lines; and the short PID option with command lines disabled. The targeted scan selected Apollo PID 2596, scanned one process / 15 threads, and reported findings for that process. This validates the scanner's flags and this test case, not universal detection of Mythic agents.

The banner-free rebuild was rechecked against Apollo PID 2596: one process / 15 threads scanned, findings reported, both requested banner lines absent.
