# Firewall automation

## Install

Install the dependencies for the script you plan to run:

```text
python -m pip install -r requirements-build.txt
python -m pip install -r requirements-scan.txt
```

The scanner also requires `nmap` on `PATH` and root/Administrator privileges.
The firewall builder uses PyYAML and Jinja2 from `requirements-build.txt`.

## Commands

```text
python scan_network.py inputs/assumed.yaml [--policy policy.yaml] [--output-dir runs] [--remote-log]
python build_firewall.py ACTUAL_YAML FIREWALL_YAML [--output-dir runs] [--log]
```

The builder supports nftables, VyOS 1.5, pfSense CE 2.9.0, and OPNsense. It validates
the confirmed host ports and firewall interfaces, then writes artifacts to a
new timestamped directory under `runs/` (or the directory given by
`--output-dir`):

```text
runs/<timestamp>/
  console.txt
  configs/<firewall>/
    nftables.nft                 # nftables
    vyos.commands                # VyOS configuration commands
    vyos.sh                      # VyOS helper script
    aliases.xml, filter.xml      # pfSense XML fragments
    config.xml                   # OPNsense full config with generated rules and aliases
```

Only the files for the selected firewall type are written. Generated blocked
rules are logged by default. `--log` also logs generated allowed rules. VyOS
`manual_include` defaults to `inputs/manual/<firewall>.vyos`. If that file
exists, its `set`/`delete` commands are included in the generated VyOS output.

## YAML input examples

The values below illustrate syntax; replace them with values for your hosts,
networks, and firewall.

### `assumed.yaml`

The scanner requires a hostname mapping with an IPv4 address and a generic
role. Ports map quoted `port/protocol` keys to service names defined in
`policy.yaml`. Credentials and `os` are optional; use credentials appropriate to
the target host.

```yaml
web01:
  ip: 10.20.1.25
  generic: web
  os: linux
  username: scanuser
  password: replace-with-host-password
  ports:
    "80/tcp": http
    "443/tcp": https
```

### `actual.yaml`

The scanner writes this file after verifying the assumed services. The builder
requires each host to have an IPv4 address and confirmed ports; entries retain
the hostname and service mapping.

```yaml
web01:
  ip: 10.20.1.25
  generic: web
  os: linux
  ports:
    "80/tcp": http
    "443/tcp": https
```

### `firewall.yaml`

Each top-level entry names a firewall. Under `interfaces`, each key identifies
one interface and `generic_name` assigns it the role `wan`, `lan`, or `dmz`.
The address and range fields describe two different networks:

- `ip_addr` is the firewall's IPv4 address on this interface.
- `interface_range` is the IPv4 network directly attached to the interface. It
  must contain `ip_addr` and is used to match the interface in an OPNsense
  configuration.
- `down_range` is a list of IPv4 networks routed through the interface. These
  are the networks whose traffic the generated policy matches. It is required
  on every interface; use an empty list for WAN. LAN and DMZ interfaces need at
  least one downstream network.
- `ipv6_addr` and `ipv6_interface_range` describe the firewall's IPv6 address
  and its directly attached network. If provided, both are required, and the
  range must contain the address.
- `ipv6_range` is a list of IPv6 networks routed through the interface. All
  IPv6 fields are optional; omit them when IPv6 is not configured.

For example, the LAN interface below has a transit network directly attached
to the firewall (`interface_range`), while the client subnet routed through it
is listed in `down_range`:

```yaml
edge:
  type: opnsense
  options:
    config_file: path/to/full-exported-config.xml
  interfaces:
    outside0:
      generic_name: wan
      ip_addr: 198.51.100.2
      interface_range: 198.51.100.0/24
      down_range: []
    inside0:
      generic_name: lan
      ip_addr: 10.20.0.1
      interface_range: 10.20.0.0/30
      down_range: [10.20.1.0/24]
      ipv6_addr: 2001:db8:20:0::1
      ipv6_interface_range: 2001:db8:20:0::/64
      ipv6_range: [2001:db8:20:1::/64]
    dmz0:
      generic_name: dmz
      ip_addr: 10.20.2.1
      interface_range: 10.20.2.0/24
      down_range: [10.20.2.0/24]
```

WAN must have an empty `down_range`. LAN and DMZ downstream networks must not
overlap. Generated rules allow LAN-to-WAN traffic only on TCP 80/443, TCP and
UDP 53, UDP 123, TCP 853, and ICMP; LAN-to-LAN and LAN-to-DMZ traffic is
unrestricted. DMZ-to-LAN is allowed, while DMZ-to-WAN and WAN-to-DMZ are
denied. For OPNsense, `options.config_file` points to that firewall's complete
exported configuration; relative paths are resolved from the directory
containing `firewall.yaml`. Interface mapping fails if a required match is
missing or ambiguous.

### `policy.yaml`

The policy maps generic host roles to service definitions. Service ports are
lists of quoted `port/protocol` or `low-high/protocol` strings. `nmap_names`
and `process_names` are optional lists used to verify the service. `roles`
defines accepted names and aliases for the `generic` field in `assumed.yaml`.
The scanner uses `policy.yaml` by default; `--policy` selects another policy
file.

```yaml
web:
  http:
    ports: ["80/tcp"]
    nmap_names: [http]
    process_names: [apache2, httpd, nginx]
  https:
    ports: ["443/tcp"]
    nmap_names: [https]
    process_names: [apache2, httpd, nginx]

roles:
  web:
    description: Web server
    aliases: [webserver, web server]
```

### Other required files

An OPNsense firewall also needs its full exported configuration file, referenced
by `options.config_file`. The XML contents are not shown here. VyOS may also
use an optional manual include file; its contents are not shown here either.

## Workflow

`scan_network.py` scans only the ports declared in `assumed.yaml`, verifies
services, and writes `actual.yaml` and scan artifacts to a unique run folder.
`build_firewall.py` consumes the scanner's `actual.yaml` and the operator's
`firewall.yaml`, then generates inbound WAN-to-host rules for confirmed
services whose host addresses fall within a configured LAN downstream
network. LAN-to-WAN access is limited to the ports and ICMP listed above, while
LAN-to-LAN and LAN-to-DMZ traffic is unrestricted. WAN inbound service rules
are attached to WAN; LAN rules and their fallback denies are attached to each
source LAN interface. DMZ interfaces can reach LAN networks, and their other
traffic is denied. For OPNsense, the builder replaces the rules
and aliases sections in the supplied full config and preserves the other
configuration sections. Interface names are resolved from the input config and
`firewall.yaml`; missing or ambiguous matches are fatal. Each run includes a
console log and a summary of generated files and warnings. It does not apply
the configuration to a live firewall; generated artifacts must be reviewed and
applied using the vendor's supported process.
