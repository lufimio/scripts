"""Small YAML helpers kept compatible with Python 3.6."""

try:
    import yaml
except ImportError:
    yaml = None


class InputError(Exception):
    """Raised when an input file cannot be used safely."""


def load_yaml(path, label):
    if yaml is None:
        raise InputError("PyYAML is not installed; install requirements-scan.txt")
    try:
        with open(path, "r") as input_file:
            data = yaml.safe_load(input_file)
    except (IOError, OSError) as exc:
        raise InputError("cannot read %s: %s" % (label, exc))
    except yaml.YAMLError as exc:
        raise InputError("invalid YAML in %s: %s" % (label, exc))
    return data


def dump_yaml(path, data):
    if yaml is None:
        raise InputError("PyYAML is not installed; install requirements-scan.txt")
    with open(path, "w") as output_file:
        yaml.safe_dump(data, output_file, sort_keys=False,
                       default_flow_style=False)
