"""Helpers shared by firewall automation entry points."""
