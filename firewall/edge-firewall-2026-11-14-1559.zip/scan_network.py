#!/usr/bin/env python
"""Scan assumed hosts and write validated service inventory."""

from scanner.scan import main


if __name__ == "__main__":
    raise SystemExit(main())
