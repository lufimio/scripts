"""Firewall configuration generation."""
