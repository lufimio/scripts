#!/usr/bin/env python
"""Generate firewall configuration artifacts from actual.yaml and firewall.yaml."""

from builder.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
