"""Network scanner implementation."""
