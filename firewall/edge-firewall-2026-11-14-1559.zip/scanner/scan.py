"""Network scanning and remote service verification."""

import argparse
import ctypes
import datetime
import ipaddress
import os
import re
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ElementTree

try:
    import paramiko
except ImportError:
    paramiko = None

try:
    import winrm
except ImportError:
    winrm = None

from common.yaml_utils import InputError, dump_yaml, load_yaml


PORT_RE = re.compile(r"^(\d+)/(tcp|udp)$", re.IGNORECASE)
POLICY_PORT_RE = re.compile(r"^(\d+)(?:-(\d+))?/(tcp|udp)$", re.IGNORECASE)
LINUX_PROCESS_RE = re.compile(r'\(\("([^"]+)"')
LINUX_PID_RE = re.compile(r"\b\d+/([^\s]+)$")
WINDOWS_PID_RE = re.compile(r"\s+(\d+)\s*$")


class ScanError(Exception):
    """Raised for fatal scan or validation errors."""


def redact_remote_text(host, value):
    text = str(value)
    password = host.get("password") if host else None
    if password:
        text = text.replace(password, "[REDACTED]")
    return text


class Reporter(object):
    def __init__(self, log_path):
        self.warnings = []
        self.files_written = [log_path]
        self.log_file = open(log_path, "x", encoding="utf-8")

    def close(self):
        self.log_file.close()

    def _emit(self, message, stream):
        print(message, file=stream)
        self.log_file.write(message + "\n")
        self.log_file.flush()

    def info(self, message):
        self._emit("INFO: %s" % message, sys.stdout)

    def warning(self, message):
        self.warnings.append(message)
        self._emit("WARNING: %s" % message, sys.stdout)

    def error(self, message):
        self._emit("ERROR: %s" % message, sys.stderr)

    def summary(self, status):
        self.info("Summary: %s" % status)
        for warning in self.warnings:
            self.warning_summary(warning)
        if self.files_written:
            self.info("Files written:")
            for path in self.files_written:
                self.info("  %s" % path)
        else:
            self.info("Files written: none")

    def warning_summary(self, message):
        self._emit("WARNING: %s" % message, sys.stdout)


class RemoteLogger(object):
    """Write delimited SSH and WinRM diagnostics without printing them."""

    def __init__(self, path):
        self.path = path
        self.log_file = open(path, "x", encoding="utf-8")
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass

    def close(self):
        self.log_file.close()

    def record(self, host, method, event, details):
        timestamp = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
        body = redact_remote_text(host, details)
        self.log_file.write("=" * 78 + "\n")
        self.log_file.write("START %s\n" % timestamp)
        self.log_file.write("host: %s (%s)\n" %
                            (host.get("name", "unknown"), host.get("ip", "unknown")))
        self.log_file.write("method: %s\nevent: %s\n" % (method, event))
        self.log_file.write("-" * 78 + "\n")
        self.log_file.write(body.rstrip() + "\n")
        self.log_file.write("END %s\n" % event)
        self.log_file.write("=" * 78 + "\n\n")
        self.log_file.flush()


def is_administrator():
    if hasattr(os, "geteuid"):
        return os.geteuid() == 0
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except (AttributeError, OSError):
        return False


def parse_port_key(value, label):
    if not isinstance(value, str):
        raise InputError("%s must be a string in port/protocol form" % label)
    match = PORT_RE.match(value)
    if not match:
        raise InputError("%s must have the form <port>/tcp or <port>/udp" % label)
    port = int(match.group(1))
    if port < 1 or port > 65535:
        raise InputError("%s has a port outside 1-65535" % label)
    return port, match.group(2).lower()


def parse_policy_port(value, label):
    if not isinstance(value, str):
        raise InputError("%s must be a string" % label)
    match = POLICY_PORT_RE.match(value)
    if not match:
        raise InputError("%s must have the form port/protocol or low-high/protocol" % label)
    low = int(match.group(1))
    high = int(match.group(2) or low)
    if low < 1 or high > 65535 or low > high:
        raise InputError("%s has an invalid port or range" % label)
    return low, high, match.group(3).lower()


def as_string_list(value, label, optional=False):
    if value is None and optional:
        return []
    if not isinstance(value, list):
        raise InputError("%s must be a list" % label)
    result = []
    for item in value:
        if not isinstance(item, str) or not item:
            raise InputError("%s entries must be non-empty strings" % label)
        result.append(item.lower())
    return result


def load_policy(path):
    policy = load_yaml(path, "nmap policy")
    if not isinstance(policy, dict):
        raise InputError("nmap policy must contain generic service mappings")
    roles = policy.get("roles", {})
    if not isinstance(roles, dict):
        raise InputError("nmap policy roles must be a mapping")

    role_names = {}
    for role, details in roles.items():
        if not isinstance(role, str) or not isinstance(details, dict):
            raise InputError("each nmap policy role must be a named mapping")
        role_names[role.lower()] = role
        aliases = as_string_list(details.get("aliases", []),
                                 "role %s aliases" % role, optional=True)
        for alias in aliases:
            role_names[alias] = role

    generics = {}
    for generic, services in policy.items():
        if generic == "roles":
            continue
        if not isinstance(generic, str) or not isinstance(services, dict):
            raise InputError("nmap policy generic entries must be mappings")
        normalized_services = {}
        for service, details in services.items():
            if not isinstance(service, str) or not isinstance(details, dict):
                raise InputError("services under %s must be named mappings" % generic)
            ports = details.get("ports", [])
            if not isinstance(ports, list):
                raise InputError("ports for %s/%s must be a list" % (generic, service))
            parsed_ports = []
            for policy_port in ports:
                parsed_ports.append(parse_policy_port(
                    policy_port, "port for %s/%s" % (generic, service)))
            normalized_services[service.lower()] = {
                "ports": parsed_ports,
                "nmap_names": as_string_list(
                    details.get("nmap_names", []),
                    "%s/%s nmap_names" % (generic, service), optional=True),
                "process_names": as_string_list(
                    details.get("process_names", []),
                    "%s/%s process_names" % (generic, service), optional=True),
            }
        generics[generic.lower()] = normalized_services

    return {"generics": generics, "roles": roles, "role_names": role_names}


def normalize_generics(value, policy, host):
    values = value if isinstance(value, list) else [value]
    if not values or any(not isinstance(item, str) or not item for item in values):
        raise InputError("host %s generic must be a name or a list of names" % host)
    result = []
    for item in values:
        normalized = policy["role_names"].get(item.lower(), item.lower())
        if (normalized not in policy["generics"] and
                normalized.lower() not in policy["roles"]):
            raise InputError("host %s has unknown generic role %s" % (host, item))
        normalized = normalized.lower()
        if normalized not in result:
            result.append(normalized)
    return result


def service_definitions(policy, generics, service):
    matching_groups = [policy["generics"][generic] for generic in generics
                       if generic in policy["generics"]]
    return [group[service] for group in matching_groups if service in group]


def load_assumptions(path, policy):
    data = load_yaml(path, "assumed YAML")
    if not isinstance(data, dict) or not data:
        raise InputError("assumed YAML must be a non-empty host mapping")
    hosts = {}
    seen_ips = {}
    for name, entry in data.items():
        if not isinstance(name, str) or not name:
            raise InputError("host names must be non-empty strings")
        if not isinstance(entry, dict):
            raise InputError("host %s must have a mapping of fields" % name)
        if "ip" not in entry:
            raise InputError("host %s is missing required ip" % name)
        try:
            address = str(ipaddress.IPv4Address(str(entry["ip"])))
        except ipaddress.AddressValueError:
            raise InputError("host %s has an invalid IPv4 address" % name)
        if address in seen_ips:
            raise InputError("hosts %s and %s use the same IP %s" %
                             (seen_ips[address], name, address))
        seen_ips[address] = name

        if "generic" not in entry:
            raise InputError("host %s is missing required generic" % name)
        generics = normalize_generics(entry["generic"], policy, name)
        ports = entry.get("ports", {})
        if not isinstance(ports, dict):
            raise InputError("ports for host %s must be a mapping" % name)
        parsed_ports = []
        for key, service in ports.items():
            port, protocol = parse_port_key(key, "host %s port key" % name)
            if not isinstance(service, str) or not service:
                raise InputError("service for host %s port %s must be a name" % (name, key))
            service_key = service.lower()
            if not service_definitions(policy, generics, service_key):
                raise InputError("host %s service %s is not defined for generic %s" %
                                 (name, service, ", ".join(generics)))
            parsed_ports.append({"key": key, "number": port,
                                 "protocol": protocol, "service": service_key})
        parsed_ports.sort(key=lambda item: (item["number"],
                                           0 if item["protocol"] == "tcp" else 1))

        host_os = entry.get("os")
        if host_os is not None:
            if not isinstance(host_os, str) or host_os.lower() not in (
                    "windows", "linux", "mac"):
                raise InputError("host %s os must be windows, linux, or mac" % name)
            host_os = host_os.lower()
        username = entry.get("username") or entry.get("user")
        password = entry.get("password")
        if username is not None and not isinstance(username, str):
            raise InputError("host %s username must be a string" % name)
        if password is not None and not isinstance(password, str):
            raise InputError("host %s password must be a string" % name)

        hosts[name] = {"name": name, "data": dict(entry), "ip": address, "os": host_os,
                       "username": username, "password": password,
                       "generics": generics, "ports": parsed_ports}
    return hosts


def make_run_directory(base):
    if not os.path.isdir(base):
        os.makedirs(base)
    stamp = datetime.datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    suffix = 0
    while True:
        name = stamp if suffix == 0 else "%s_%d" % (stamp, suffix)
        path = os.path.join(base, name)
        try:
            os.mkdir(path)
            return path
        except OSError:
            if not os.path.exists(path):
                raise
            suffix += 1


def write_targets(hosts):
    handle = tempfile.NamedTemporaryFile(mode="w", delete=False,
                                         prefix="fwgen-targets-", suffix=".txt")
    try:
        for host in hosts.values():
            handle.write(host["ip"] + "\n")
    finally:
        handle.close()
    return handle.name


def run_nmap(command, reporter, description):
    reporter.info("Starting %s scan" % description)
    try:
        process = subprocess.Popen(command, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT,
                                   universal_newlines=True)
    except OSError as exc:
        raise ScanError("could not start nmap: %s" % exc)
    for line in process.stdout:
        line = line.strip()
        if line:
            reporter.info(line)
    status = process.wait()
    if status != 0:
        raise ScanError("nmap %s scan exited with status %d" % (description, status))


def parse_nmap_xml(path):
    try:
        root = ElementTree.parse(path).getroot()
    except (IOError, OSError, ElementTree.ParseError) as exc:
        raise ScanError("cannot parse nmap output %s: %s" % (path, exc))
    results = {}
    for host_node in root.findall("host"):
        address = None
        for address_node in host_node.findall("address"):
            if address_node.get("addrtype") == "ipv4":
                address = address_node.get("addr")
                break
        if not address:
            continue
        for port_node in host_node.findall("ports/port"):
            state_node = port_node.find("state")
            if state_node is None or state_node.get("state") not in ("open", "open|filtered"):
                continue
            protocol = (port_node.get("protocol") or "").lower()
            port_text = port_node.get("portid") or ""
            try:
                port = int(port_text)
            except ValueError:
                continue
            service_node = port_node.find("service")
            service_name = ""
            if service_node is not None:
                service_name = (service_node.get("name") or "").lower()
            results.setdefault(address, {})[(port, protocol)] = {
                "service": service_name,
                "state": state_node.get("state"),
            }
    return results


def linux_process_names(output, host_ip, wanted_ports):
    found = {}
    for line in output.splitlines():
        fields = line.split()
        if len(fields) < 5:
            continue
        protocol = fields[0].lower()
        if not (protocol.startswith("tcp") or protocol.startswith("udp")):
            continue
        local = fields[3]
        if ":" not in local:
            continue
        local_address, port_text = local.rsplit(":", 1)
        local_address = normalize_local_address(local_address)
        try:
            port = int(port_text)
        except ValueError:
            continue
        if port not in wanted_ports or local_address not in (
                host_ip, "0.0.0.0", "*", "::"):
            continue
        process_name = ""
        match = LINUX_PROCESS_RE.search(line)
        if match:
            process_name = match.group(1)
        else:
            match = LINUX_PID_RE.search(fields[-1])
            if match:
                process_name = match.group(1)
        if process_name:
            found.setdefault(port, set()).add(os.path.basename(process_name).lower())
    return found


def normalize_local_address(address):
    address = address.strip("[]")
    if "%" in address:
        address = address.split("%", 1)[0]
    return address


def linux_ss_process_names(output, host_ip, wanted_ports):
    found = {}
    for line in output.splitlines():
        fields = line.split()
        if len(fields) < 6:
            continue
        protocol = fields[0].lower()
        if not (protocol.startswith("tcp") or protocol.startswith("udp")):
            continue
        local = fields[4]
        if ":" not in local:
            continue
        local_address, port_text = local.rsplit(":", 1)
        local_address = normalize_local_address(local_address)
        try:
            port = int(port_text)
        except ValueError:
            continue
        if port not in wanted_ports or local_address not in (host_ip, "0.0.0.0", "*", "::"):
            continue
        for match in LINUX_PROCESS_RE.finditer(line):
            process_name = os.path.basename(match.group(1)).lower()
            found.setdefault(port, set()).add(process_name)
    return found


def parse_windows_netstat(output, host_ip, wanted_ports):
    pids = {}
    for line in output.splitlines():
        fields = line.split()
        if len(fields) < 4 or fields[0].lower() not in ("tcp", "tcp6", "udp", "udp6"):
            continue
        local = fields[1]
        if ":" not in local:
            continue
        local_address, port_text = local.rsplit(":", 1)
        local_address = local_address.strip("[]")
        try:
            port = int(port_text)
        except ValueError:
            continue
        if port not in wanted_ports or local_address not in (
                host_ip, "0.0.0.0", "*", "::"):
            continue
        if fields[0].lower().startswith("tcp") and "LISTENING" not in line.upper():
            continue
        match = WINDOWS_PID_RE.search(line)
        if match:
            pids.setdefault(port, set()).add(match.group(1))
    return pids


def process_aliases_for(host, port_record, policy):
    service = port_record["service"]
    aliases = set()
    for details in service_definitions(policy, host["generics"], service):
        aliases.update(details["process_names"])
    return aliases


def run_ssh_command(client, command, password=None, use_sudo=False,
                    remote_logger=None, host=None, method="SSH/Paramiko"):
    if use_sudo:
        if password:
            command = "sudo -S -p '' " + command
        else:
            command = "sudo -n " + command
    if remote_logger:
        remote_logger.record(host, method, "COMMAND STARTED", command)
    try:
        stdin, stdout, stderr = client.exec_command(command, timeout=8,
                                                     get_pty=False)
    except Exception as exc:
        if remote_logger:
            remote_logger.record(host, method, "COMMAND FAILED TO START",
                                 "%s\nerror: %s" % (command, exc))
        raise
    if use_sudo and password:
        stdin.write(password + "\n")
        stdin.flush()
        stdin.channel.shutdown_write()
    output = stdout.read().decode("utf-8", "replace")
    error_output = stderr.read().decode("utf-8", "replace")
    status = stdout.channel.recv_exit_status()
    if remote_logger:
        remote_logger.record(
            host, method, "COMMAND RESULT",
            "%s\nexit status: %d\nstdout:\n%s\nstderr:\n%s" %
            (command, status, output.rstrip(), error_output.rstrip()))
    if status != 0:
        diagnostic = "\n".join(part.strip() for part in (error_output, output)
                                if part.strip())
        if password:
            diagnostic = diagnostic.replace(password, "[redacted]")
        raise ScanError("remote command failed with status %d: %s" %
                        (status, diagnostic or command))
    return output


def ssh_connect(host, timeout, remote_logger=None, method="SSH/Paramiko"):
    client = paramiko.SSHClient()
    if remote_logger:
        remote_logger.record(
            host, method, "CONNECTION ATTEMPT",
            "target: %s\nusername: %s\nauthentication: username/password" %
            (host["ip"], host["username"]))
    try:
        client.load_system_host_keys()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(host["ip"], username=host["username"],
                       password=host["password"], timeout=timeout,
                       banner_timeout=timeout, auth_timeout=timeout,
                       look_for_keys=False, allow_agent=False)
    except Exception as exc:
        client.close()
        if remote_logger:
            remote_logger.record(host, method, "CONNECTION FAILED", exc)
        raise
    if remote_logger:
        remote_logger.record(host, method, "CONNECTION SUCCEEDED",
                             "connected to %s" % host["ip"])
    return client


def enumerate_linux(host, wanted_ports, timeout, reporter, remote_logger=None):
    client = ssh_connect(host, timeout, remote_logger)
    try:
        try:
            output = run_ssh_command(
                client, "ss -tulpn", host["password"], True,
                remote_logger, host)
            processes = linux_ss_process_names(output, host["ip"], wanted_ports)
            if processes:
                reporter.info("ss parse succeeded for %s; matched listener ports: %s" %
                              (host["ip"], ", ".join(
                                  str(port) for port in sorted(processes))))
            else:
                reporter.warning("ss parse found no matching assumed listeners for %s" %
                                 host["ip"])
            return processes
        except Exception as ss_error:
            reporter.info("ss failed for %s; falling back to netstat: %s" %
                          (host["ip"], redact_remote_text(host, ss_error)))
            output = run_ssh_command(
                client, "netstat -tulpn", host["password"], True,
                remote_logger, host)
            processes = linux_process_names(output, host["ip"], wanted_ports)
            if processes:
                reporter.info("netstat parse succeeded for %s; matched listener ports: %s" %
                              (host["ip"], ", ".join(
                                  str(port) for port in sorted(processes))))
            else:
                reporter.warning("netstat parse found no matching assumed listeners for %s" %
                                 host["ip"])
            return processes
    finally:
        client.close()


def winrm_endpoint(host, nmap_results):
    ports = nmap_results.get(host["ip"], {})
    if (5986, "tcp") in ports:
        return "https://%s:5986/wsman" % host["ip"]
    return "http://%s:5985/wsman" % host["ip"]


def winrm_session(host, nmap_results):
    return winrm.Session(
        winrm_endpoint(host, nmap_results),
        auth=(host["username"], host["password"]), transport="ntlm",
        operation_timeout_sec=5, read_timeout_sec=10)


def winrm_command(session, command, arguments=None, remote_logger=None,
                  host=None):
    command_text = " ".join([command] + (arguments or []))
    if remote_logger:
        remote_logger.record(host, "WinRM", "COMMAND STARTED", command_text)
    try:
        result = session.run_cmd(command, arguments or [])
    except Exception as exc:
        if remote_logger:
            remote_logger.record(host, "WinRM", "COMMAND FAILED TO START",
                                 "%s\nerror: %s" % (command_text, exc))
        raise
    output = result.std_out.decode("utf-8", "replace")
    error_output = result.std_err.decode("utf-8", "replace")
    if remote_logger:
        remote_logger.record(
            host, "WinRM", "COMMAND RESULT",
            "%s\nexit status: %d\nstdout:\n%s\nstderr:\n%s" %
            (command_text, result.status_code, output.rstrip(), error_output.rstrip()))
    if result.status_code != 0:
        raise ScanError("WinRM command failed: %s" %
                        (error_output.strip() or command_text))
    return output


def enumerate_windows_ssh(host, wanted_ports, timeout, remote_logger=None):
    method = "SSH/Paramiko (Windows)"
    client = ssh_connect(host, timeout, remote_logger, method)
    try:
        output = run_ssh_command(client, "netstat -ano", remote_logger=remote_logger,
                                 host=host, method=method)
        pids = parse_windows_netstat(output, host["ip"], wanted_ports)
        names = {}
        for port, port_pids in pids.items():
            for pid in port_pids:
                task_output = run_ssh_command(
                    client, 'tasklist /fi "pid eq %s"' % pid,
                    remote_logger=remote_logger, host=host, method=method)
                names.setdefault(port, set()).update(parse_tasklist(task_output))
        return names
    finally:
        client.close()


def parse_tasklist(output):
    names = set()
    for line in output.splitlines():
        stripped = line.strip()
        if not stripped or stripped.lower().startswith(("image name", "info:")):
            continue
        fields = re.split(r"\s{2,}", stripped)
        if len(fields) >= 2 and fields[1].isdigit():
            names.add(fields[0].lower())
    return names


def enumerate_windows_winrm(host, wanted_ports, nmap_results,
                            remote_logger=None):
    endpoint = winrm_endpoint(host, nmap_results)
    if remote_logger:
        remote_logger.record(
            host, "WinRM", "CONNECTION ATTEMPT",
            "endpoint: %s\nusername: %s\nauthentication: NTLM" %
            (endpoint, host["username"]))
    try:
        session = winrm_session(host, nmap_results)
        output = winrm_command(session, "netstat.exe", ["-ano"],
                               remote_logger, host)
        if remote_logger:
            remote_logger.record(host, "WinRM", "CONNECTION SUCCEEDED",
                                 "connected to %s" % endpoint)
        pids = parse_windows_netstat(output, host["ip"], wanted_ports)
        names = {}
        for port, port_pids in pids.items():
            for pid in port_pids:
                task_output = winrm_command(
                    session, "tasklist.exe", ["/fi", "pid eq %s" % pid],
                    remote_logger, host)
                names.setdefault(port, set()).update(parse_tasklist(task_output))
        return names
    except Exception as exc:
        if remote_logger:
            remote_logger.record(host, "WinRM", "CONNECTION FAILED", exc)
        raise


def enumerate_processes(host, nmap_results, reporter, timeout,
                        remote_logger=None):
    if host["os"] == "mac":
        reporter.warning("host %s is macOS; process enumeration is not specified" %
                         host["ip"])
        if remote_logger:
            remote_logger.record(host, "remote", "ENUMERATION SKIPPED",
                                 "macOS process enumeration is not specified")
        return {}
    if not host["os"]:
        reporter.warning("host %s has no os; skipping remote process enumeration" %
                         host["ip"])
        if remote_logger:
            remote_logger.record(host, "remote", "ENUMERATION SKIPPED",
                                 "host operating system is not specified")
        return {}
    if not host["username"] or host["password"] is None:
        reporter.warning("host %s lacks remote credentials; skipping process enumeration" %
                         host["ip"])
        if remote_logger:
            remote_logger.record(host, "remote", "ENUMERATION SKIPPED",
                                 "username or password is missing")
        return {}
    wanted_ports = set(record["number"] for record in host["ports"])
    if not wanted_ports:
        if remote_logger:
            remote_logger.record(host, "remote", "ENUMERATION SKIPPED",
                                 "host has no declared ports")
        return {}
    if paramiko is None:
        if host["os"] == "windows" and winrm is not None:
            try:
                return enumerate_windows_winrm(
                    host, wanted_ports, nmap_results, remote_logger)
            except Exception as exc:
                reporter.warning("WinRM process enumeration failed for %s: %s" %
                                 (host["ip"], redact_remote_text(host, exc)))
                return {}
        reporter.warning("Paramiko is unavailable; install requirements-scan.txt")
        if remote_logger:
            remote_logger.record(host, "remote", "ENUMERATION SKIPPED",
                                 "Paramiko is unavailable")
        return {}
    try:
        if host["os"] == "linux":
            return enumerate_linux(host, wanted_ports, timeout, reporter,
                                   remote_logger)
        try:
            return enumerate_windows_ssh(host, wanted_ports, timeout,
                                         remote_logger)
        except Exception as ssh_error:
            reporter.warning("SSH process enumeration failed for %s: %s" %
                             (host["ip"], redact_remote_text(host, ssh_error)))
            if winrm is None:
                reporter.warning("pywinrm is unavailable; install requirements-scan.txt")
                if remote_logger:
                    remote_logger.record(host, "WinRM", "ATTEMPT SKIPPED",
                                         "pywinrm is unavailable")
                return {}
            return enumerate_windows_winrm(host, wanted_ports, nmap_results,
                                           remote_logger)
    except Exception as exc:
        reporter.warning("remote process enumeration failed for %s: %s" %
                         (host["ip"], redact_remote_text(host, exc)))
        return {}


def validate_ports(hosts, policy, nmap_results, reporter, timeout,
                   remote_logger=None):
    actual = {}
    fatal = []
    for host_name, host in hosts.items():
        valid_ports = {}
        processes = enumerate_processes(host, nmap_results, reporter, timeout,
                                        remote_logger)
        scan = nmap_results.get(host["ip"], {})
        for record in host["ports"]:
            port = record["number"]
            protocol = record["protocol"]
            key = record["key"]
            service = record["service"]
            result = scan.get((port, protocol))
            if result is None:
                mail_service = service in ("imap", "imaps", "pop3", "pop3s")
                if "mail" in host["generics"] and mail_service:
                    reporter.warning("host %s is missing optional mail port %s" %
                                     (host_name, key))
                else:
                    fatal.append("host %s is missing assumed port %s" % (host_name, key))
                continue

            definitions = service_definitions(policy, host["generics"], service)
            expected_names = set()
            expected_port = False
            for details in definitions:
                expected_names.update(details["nmap_names"])
                for low, high, expected_protocol in details["ports"]:
                    if expected_protocol == protocol and low <= port <= high:
                        expected_port = True
            if (result["service"] and expected_port and
                    result["service"] in expected_names):
                valid_ports[key] = service
                continue

            process_names = process_aliases_for(host, record, policy)
            observed = processes.get(port, set())
            if process_names.intersection(observed):
                valid_ports[key] = service
                continue
            fatal.append("host %s port %s service mismatch: nmap reported %s; "
                         "process names were %s" %
                         (host_name, key, result["service"] or "unknown",
                          ", ".join(sorted(observed)) or "unavailable"))

        updated = dict(host["data"])
        updated["ports"] = dict((record["key"], valid_ports[record["key"]])
                                for record in host["ports"]
                                if record["key"] in valid_ports)
        actual[host_name] = updated

    if fatal:
        raise ScanError("port validation failed: " + "; ".join(fatal))
    return actual


def parse_args(argv):
    parser = argparse.ArgumentParser(
        description="Scan assumed hosts and validate their declared services.")
    parser.add_argument("assumed_yaml", help="host assumptions YAML file")
    parser.add_argument("--policy", default="policy.yaml",
                        help="service and role policy YAML (default: policy.yaml)")
    parser.add_argument("--output-dir", default="runs",
                        help="base directory for timestamped results (default: runs)")
    parser.add_argument("--remote-log", action="store_true",
                        help="write delimited SSH/WinRM attempts and command output")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    try:
        run_directory = make_run_directory(args.output_dir)
        reporter = Reporter(os.path.join(run_directory, "console.txt"))
    except (IOError, OSError) as exc:
        print("ERROR: cannot create run directory or console log: %s" % exc,
              file=sys.stderr)
        return 1

    reporter.info("Created run directory %s" % run_directory)
    target_file = None
    remote_logger = None
    try:
        if args.remote_log:
            remote_log_path = os.path.join(run_directory, "remote-io.txt")
            remote_logger = RemoteLogger(remote_log_path)
            reporter.files_written.append(remote_log_path)
            reporter.info("Detailed remote logging enabled: %s" % remote_log_path)
        if not is_administrator():
            raise ScanError("root or Administrator privileges are required; run elevated")
        if not shutil.which("nmap"):
            raise ScanError("nmap is not on PATH")

        policy = load_policy(args.policy)
        hosts = load_assumptions(args.assumed_yaml, policy)
        tcp_ports = sorted(set(record["number"] for host in hosts.values()
                               for record in host["ports"]
                               if record["protocol"] == "tcp"))
        udp_ports = sorted(set(record["number"] for host in hosts.values()
                               for record in host["ports"]
                               if record["protocol"] == "udp"))
        nmap_directory = os.path.join(run_directory, "nmap")
        os.mkdir(nmap_directory)
        target_file = write_targets(hosts)

        nmap_results = {}
        if tcp_ports:
            tcp_xml = os.path.join(nmap_directory, "tcp.xml")
            tcp_command = [
                "nmap", "-v", "-Pn", "-n", "-sS", "-sV", "--version-light",
                "-p", ",".join(str(port) for port in tcp_ports), "-T4",
                "--min-rate", "2000", "--max-retries", "2", "--open",
                "-iL", target_file, "-oX", tcp_xml,
            ]
            run_nmap(tcp_command, reporter, "targeted TCP")
            reporter.files_written.append(tcp_xml)
            nmap_results = parse_nmap_xml(tcp_xml)
        else:
            reporter.info("No assumed TCP ports; skipping TCP scan")

        if udp_ports:
            udp_xml = os.path.join(nmap_directory, "udp.xml")
            udp_command = [
                "nmap", "-v", "-Pn", "-n", "-sU", "-p",
                ",".join(str(port) for port in udp_ports), "-T4",
                "--max-retries", "1", "-iL", target_file, "-oX", udp_xml,
            ]
            run_nmap(udp_command, reporter, "UDP")
            reporter.files_written.append(udp_xml)
            udp_results = parse_nmap_xml(udp_xml)
            for address, ports in udp_results.items():
                nmap_results.setdefault(address, {}).update(ports)
        else:
            reporter.info("No assumed UDP ports; skipping UDP scan")

        for host_name, host in hosts.items():
            reporter.info("Verifying declared ports for %s (%s)" %
                          (host_name, host["ip"]))
        actual = validate_ports(hosts, policy, nmap_results, reporter, 5,
                                remote_logger)
        actual_path = os.path.join(run_directory, "actual.yaml")
        dump_yaml(actual_path, actual)
        try:
            os.chmod(actual_path, 0o600)
        except OSError:
            pass
        reporter.files_written.append(actual_path)
        reporter.summary("completed successfully")
        return 0
    except (InputError, ScanError) as exc:
        reporter.error(str(exc))
        reporter.summary("failed")
        return 1
    except (IOError, OSError) as exc:
        reporter.error("filesystem error: %s" % exc)
        reporter.summary("failed")
        return 1
    finally:
        if target_file and os.path.exists(target_file):
            try:
                os.unlink(target_file)
            except OSError:
                pass
        if remote_logger:
            remote_logger.close()
        reporter.close()
