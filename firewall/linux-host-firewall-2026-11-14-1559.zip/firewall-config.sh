#!/bin/sh

# Build a simple inbound firewall from the services declared by the operator.

WARNINGS=
RUN_DIR=
LOG_FILE=
TMP_LISTEN=
TMP_MATCH=
TMP_DECLARATIONS=
TMP_ALLOWED=
TMP_GROUPS=
TMP_OBSERVED=

log_info()
{
    printf 'INFO: %s\n' "$*"
    if [ -n "$LOG_FILE" ]; then
        printf 'INFO: %s\n' "$*" >> "$LOG_FILE"
    fi
}

log_warning()
{
    printf 'WARNING: %s\n' "$*"
    if [ -n "$LOG_FILE" ]; then
        printf 'WARNING: %s\n' "$*" >> "$LOG_FILE"
    fi
    WARNINGS="${WARNINGS}${WARNINGS:+
}WARNING: $*"
}

log_error()
{
    printf 'ERROR: %s\n' "$*" >&2
    if [ -n "$LOG_FILE" ]; then
        printf 'ERROR: %s\n' "$*" >> "$LOG_FILE"
    fi
}

cleanup()
{
    [ -z "$TMP_LISTEN" ] || rm -f "$TMP_LISTEN"
    [ -z "$TMP_MATCH" ] || rm -f "$TMP_MATCH"
    [ -z "$TMP_DECLARATIONS" ] || rm -f "$TMP_DECLARATIONS"
    [ -z "$TMP_ALLOWED" ] || rm -f "$TMP_ALLOWED"
    [ -z "$TMP_GROUPS" ] || rm -f "$TMP_GROUPS"
    [ -z "$TMP_OBSERVED" ] || rm -f "$TMP_OBSERVED"
}
trap cleanup 0
trap 'exit 1' HUP INT TERM

fail()
{
    log_error "$*"
    finish 1
}

finish()
{
    status=$1
    printf 'SUMMARY: completed with status %s\n' "$status"
    if [ -n "$LOG_FILE" ]; then
        printf 'SUMMARY: completed with status %s\n' "$status" >> "$LOG_FILE"
    fi
    if [ -n "$WARNINGS" ]; then
        printf '%s\n' "$WARNINGS"
        if [ -n "$LOG_FILE" ]; then
            printf '%s\n' "$WARNINGS" >> "$LOG_FILE"
        fi
    fi
    exit "$status"
}

if [ "$(id -u 2>/dev/null)" != 0 ]; then
    printf 'ERROR: sudo is required.\n' >&2
    exit 1
fi

if [ "$#" -eq 0 ]; then
    printf 'ERROR: provide one or more port,protocol,service arguments.\n' >&2
    exit 1
fi

SCRIPT_DIR=$(CDPATH= cd "$(dirname "$0")" 2>/dev/null && pwd) || {
    printf 'ERROR: cannot determine the script directory.\n' >&2
    exit 1
}
RUNS_DIR=$SCRIPT_DIR/runs
if [ ! -d "$RUNS_DIR" ] && ! mkdir "$RUNS_DIR" 2>/dev/null; then
    printf 'ERROR: cannot create runs directory.\n' >&2
    exit 1
fi

run_number=1
while :; do
    RUN_DIR=$RUNS_DIR/$run_number
    if mkdir "$RUN_DIR" 2>/dev/null; then
        break
    fi
    if [ -e "$RUN_DIR" ]; then
        run_number=$((run_number + 1))
    else
        printf 'ERROR: cannot create run directory %s.\n' "$RUN_DIR" >&2
        exit 1
    fi
done
LOG_FILE=$RUN_DIR/console.log
: > "$LOG_FILE" || {
    printf 'ERROR: cannot create console log.\n' >&2
    exit 1
}

TMP_LISTEN=$RUN_DIR/.listeners.tmp
TMP_MATCH=$RUN_DIR/.matches.tmp
TMP_DECLARATIONS=$RUN_DIR/.declarations.tmp
TMP_ALLOWED=$RUN_DIR/.allowed.tmp
TMP_GROUPS=$RUN_DIR/.groups.tmp
TMP_OBSERVED=$RUN_DIR/.observed.tmp
: > "$TMP_LISTEN" || fail 'cannot create listener scratch file.'
: > "$TMP_MATCH" || fail 'cannot create match scratch file.'
: > "$TMP_DECLARATIONS" || fail 'cannot create declaration scratch file.'
: > "$TMP_ALLOWED" || fail 'cannot create allowed-port scratch file.'

log_info "Run output: $RUN_DIR"

valid_port()
{
    case $1 in
        ''|*[!0-9]*) return 1 ;;
    esac
    [ "$1" -ge 1 ] 2>/dev/null && [ "$1" -le 65535 ] 2>/dev/null
}

valid_protocol()
{
    case $1 in
        tcp|udp) return 0 ;;
        *) return 1 ;;
    esac
}

for declaration in "$@"; do
    case $declaration in
        *,*,*) ;;
        *) fail "invalid argument '$declaration'; expected port,protocol,service." ;;
    esac
    port=${declaration%%,*}
    remainder=${declaration#*,}
    protocol=${remainder%%,*}
    service=${remainder#*,}
    case $service in *,*) fail "invalid service in '$declaration'." ;; esac
    valid_port "$port" || fail "invalid port in '$declaration'."
    valid_protocol "$protocol" || fail "protocol must be tcp or udp in '$declaration'."
    [ -n "$service" ] || fail "service cannot be empty in '$declaration'."
    printf '%s|%s|%s\n' "$protocol" "$service" "$port" >> "$TMP_DECLARATIONS"
done
duplicate_count=$(awk -F '|' 'seen[tolower($1) "|" tolower($2) "|" $3]++ { n++ } END { print n+0 }' "$TMP_DECLARATIONS")
[ "$duplicate_count" -eq 0 ] || fail 'duplicate port,protocol,service arguments are ambiguous.'

# Capture listeners in a normalized pipe-delimited form:
# protocol|port|address|process details
if command -v ss >/dev/null 2>&1; then
    LIST_CMD=ss
elif command -v netstat >/dev/null 2>&1; then
    LIST_CMD=netstat
    log_warning 'ss is unavailable; install iproute2 for preferred socket discovery. Using netstat.'
else
    fail 'neither ss nor netstat is installed; install iproute2 or net-tools.'
fi

if [ "$LIST_CMD" = ss ]; then
    ss -tulpn 2>/dev/null | awk '
        NR == 1 { next }
        {
            proto = $1
            state = $2
            local = $5
            if (proto ~ /^tcp/ && state != "LISTEN") next
            if (proto !~ /^tcp/ && proto !~ /^udp/) next
            print proto "|" local "|" $0
        }' > "$TMP_LISTEN"
else
    netstat -tulpn 2>/dev/null | awk '
        NR <= 2 { next }
        {
            proto = $1
            if (proto !~ /^tcp/ && proto !~ /^udp/) next
            if (proto ~ /^tcp/ && $6 != "LISTEN") next
            print proto "|" $4 "|" $0
        }' > "$TMP_LISTEN"
fi

while IFS='|' read -r raw_proto endpoint raw_line; do
    [ -n "$raw_proto" ] || continue
    case $endpoint in
        *:*) address=${endpoint%:*}; listen_port=${endpoint##*:} ;;
        *) continue ;;
    esac
    case $address in
        ''|\*|0.0.0.0|\[\:\]|::) ;;
        127.*|\[\:\:1\]|::1|localhost) continue ;;
        *) ;;
    esac
    valid_port "$listen_port" || continue
    case $raw_proto in tcp*) proto=tcp ;; udp*) proto=udp ;; *) continue ;; esac

    pid=$(printf '%s\n' "$raw_line" | sed -n 's/.*pid=\([0-9][0-9]*\).*/\1/p')
    process_details=
    if [ -n "$pid" ] && [ -r "/proc/$pid/comm" ]; then
        process_details=$(cat "/proc/$pid/comm" 2>/dev/null)
        if [ -r "/proc/$pid/cmdline" ]; then
            command_line=$(tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null)
            process_details="$process_details $command_line"
        fi
    else
        process_details=$raw_line
        # netstat commonly reports PID/program in its final field.
        process_details=$(printf '%s\n' "$raw_line" | awk '{print $NF}')
    fi
    printf '%s|%s|%s|%s\n' "$proto" "$listen_port" "$address" "$process_details" >> "$TMP_MATCH"
done < "$TMP_LISTEN"

# IPv6 inbound rules are enabled only if an interface has a non-link-local address.
HAVE_NONLINKLOCAL_IPV6=no
if command -v ip >/dev/null 2>&1; then
    if ip -6 addr show 2>/dev/null | awk '/inet6 / { if ($2 !~ /^fe80:/ && $2 !~ /^::1\//) found=1 } END { exit !found }'; then
        HAVE_NONLINKLOCAL_IPV6=yes
    fi
else
    log_warning 'ip is unavailable; IPv6 inbound traffic will remain denied. Install iproute2 to detect assigned IPv6 addresses.'
fi

awk -F '|' '!seen[tolower($1) "|" tolower($2)]++ { print $1 "|" $2 }' "$TMP_DECLARATIONS" > "$TMP_GROUPS" || fail 'could not group declarations.'
FAILURES=0
while IFS='|' read -r protocol service; do
    [ -n "$protocol" ] || continue
    service_lower=$(printf '%s' "$service" | tr '[:upper:]' '[:lower:]')
    awk -F '|' -v p="$protocol" -v s="$service_lower" \
        'tolower($1) == tolower(p) && index(tolower($4), s) > 0 { if (!seen[$2]++) print $2 }' \
        "$TMP_MATCH" > "$TMP_OBSERVED" || fail 'could not inspect matching listeners.'
    declared_count=$(awk -F '|' -v p="$protocol" -v s="$service_lower" \
        'tolower($1) == tolower(p) && tolower($2) == s { n++ } END { print n+0 }' "$TMP_DECLARATIONS")
    observed_count=$(awk 'END { print NR+0 }' "$TMP_OBSERVED")
    exact_count=0
    missing_declared=
    while IFS='|' read -r declared_proto declared_service declared_port; do
        [ "$declared_proto" = "$protocol" ] || continue
        [ "$(printf '%s' "$declared_service" | tr '[:upper:]' '[:lower:]')" = "$service_lower" ] || continue
        if grep -F -x "$declared_port" "$TMP_OBSERVED" >/dev/null 2>&1; then
            exact_count=$((exact_count + 1))
            printf '%s|%s\n' "$protocol" "$declared_port" >> "$TMP_ALLOWED"
        else
            missing_declared=${missing_declared}${missing_declared:+,}$declared_port
        fi
    done < "$TMP_DECLARATIONS"

    log_info "Checking $service ($protocol; declared port(s): $(awk -F '|' -v p="$protocol" -v s="$service_lower" 'tolower($1)==tolower(p) && tolower($2)==s { printf "%s%s", sep, $3; sep="," }' "$TMP_DECLARATIONS"))"
    if [ "$exact_count" -eq "$declared_count" ]; then
        if [ "$observed_count" -gt "$declared_count" ]; then
            extra_ports=$(awk 'NR > declared { printf "%s%s", sep, $0; sep="," }' declared="$declared_count" "$TMP_OBSERVED")
            log_warning "$service has additional matching listener port(s) $extra_ports; they will not be allowed."
        fi
        continue
    fi

    if [ "$declared_count" -eq "$observed_count" ] && \
       [ $((declared_count - exact_count)) -eq 1 ] && \
       [ $((observed_count - exact_count)) -eq 1 ]; then
        actual_port=$(while IFS= read -r candidate_port; do
            if ! grep -F -x "$protocol|$candidate_port" "$TMP_ALLOWED" >/dev/null 2>&1; then
                printf '%s\n' "$candidate_port"
            fi
        done < "$TMP_OBSERVED")
        log_warning "$service has one moved $protocol port (declared $missing_declared, listening $actual_port); allowing the observed port."
        printf '%s|%s\n' "$protocol" "$actual_port" >> "$TMP_ALLOWED"
    else
        log_error "$service ($protocol) has $declared_count declared port(s), $observed_count matching listener(s), and $exact_count exact match(es); matching is incomplete or ambiguous."
        FAILURES=$((FAILURES + 1))
    fi
done < "$TMP_GROUPS"

if [ "$FAILURES" -gt 0 ]; then
    finish 1
fi

sort -u "$TMP_ALLOWED" > "$TMP_OBSERVED" || fail 'could not prepare allowed ports.'

RULES_FILE=$RUN_DIR/rules.sh
{
    printf '#!/bin/sh\n'
    printf 'set -e\n'
    printf 'iptables -P INPUT DROP\n'
    printf 'iptables -P FORWARD DROP\n'
    printf 'iptables -P OUTPUT ACCEPT\n'
    printf 'iptables -F\n'
    printf 'iptables -X\n'
    printf 'iptables -A INPUT -i lo -j ACCEPT\n'
    printf 'iptables -A INPUT -p icmp -j ACCEPT\n'
    printf 'iptables -A OUTPUT -p icmp -j ACCEPT\n'
    printf 'iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT\n'
    printf 'iptables -A INPUT -p icmp -j ACCEPT\n'
    printf 'iptables -A OUTPUT -p icmp -j ACCEPT\n'
    printf 'iptables -A INPUT -p tcp --tcp-flags ALL NONE -j DROP\n'
    printf 'iptables -A INPUT -p tcp --tcp-flags ALL ALL -j DROP\n'
    printf 'iptables -A INPUT -p tcp --tcp-flags SYN,RST SYN,RST -j DROP\n'
    printf 'iptables -A INPUT -p tcp --tcp-flags SYN,FIN SYN,FIN -j DROP\n'
    printf 'iptables -A INPUT -f -j DROP\n'
    printf 'iptables -A INPUT -p tcp --syn -m hashlimit \
    --hashlimit-above 25/sec --hashlimit-burst 50 \
    --hashlimit-mode srcip --hashlimit-name syn_scan \
    --hashlimit-htable-expire 30000 -j DROP\n'

    # Drop invalid state packets (malformed/scan artifacts)
    iptables -A INPUT -m conntrack --ctstate INVALID -j DROP
    while IFS='|' read -r rule_proto rule_port; do
        [ -n "$rule_proto" ] || continue
        printf 'iptables -A INPUT -p %s --dport %s -m conntrack --ctstate NEW -j LOG --log-prefix "IPT-INPUT4-ACCEPT-%s: "\n' "$rule_proto" "$rule_port" "$rule_port"
        printf 'iptables -A INPUT -p %s --dport %s -m conntrack --ctstate NEW -j ACCEPT\n' "$rule_proto" "$rule_port"
    done < "$TMP_OBSERVED"
    printf 'iptables -A INPUT -m limit --limit 5/min --limit-burst 10 -j LOG --log-prefix "IPT-INPUT4-DEFAULT-DROP: "'
    printf '\n'
    printf 'if command -v ip6tables >/dev/null 2>&1; then\n'
    printf '    ip6tables -P INPUT DROP\n'
    printf '    ip6tables -P FORWARD DROP\n'
    printf '    ip6tables -P OUTPUT ACCEPT\n'
    printf '    ip6tables -F\n'
    printf '    ip6tables -X\n'
    printf '    ip6tables -A INPUT -i lo -j ACCEPT\n'
    printf '    ip6tables -A INPUT -p ipv6-icmp -j ACCEPT\n'
    printf '    ip6tables -A OUTPUT -p ipv6-icmp -j ACCEPT\n'
    printf '    ip6tables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT\n'
    printf '    ip6tables -A INPUT -p tcp --tcp-flags ALL NONE -j DROP\n'
    printf '    ip6tables -A INPUT -p tcp --tcp-flags ALL ALL -j DROP\n'
    printf '    ip6tables -A INPUT -p tcp --tcp-flags SYN,RST SYN,RST -j DROP\n'
    printf '    ip6tables -A INPUT -p tcp --tcp-flags SYN,FIN SYN,FIN -j DROP\n'
    printf '    ip6tables -A INPUT -m frag -j DROP\n'
    printf '    ip6tables -A INPUT -p tcp --syn -m hashlimit \
    --hashlimit-above 25/sec --hashlimit-burst 50 \
    --hashlimit-mode srcip --hashlimit-name syn_scan \
    --hashlimit-htable-expire 30000 -j DROP\n'
    if [ "$HAVE_NONLINKLOCAL_IPV6" = yes ]; then
        while IFS='|' read -r rule_proto rule_port; do
            [ -n "$rule_proto" ] || continue
            printf '    ip6tables -A INPUT -p %s --dport %s -m conntrack --ctstate NEW -j LOG --log-prefix "IPT-INPUT6-ACCEPT-%s: "\n' "$rule_proto" "$rule_port" "$rule_port"
            printf '    ip6tables -A INPUT -p %s --dport %s -m conntrack --ctstate NEW -j ACCEPT\n' "$rule_proto" "$rule_port"
        done < "$TMP_OBSERVED"
    fi
    printf 'ip6tables -A INPUT -m limit --limit 5/min --limit-burst 10 -j LOG --log-prefix "IPT-INPUT6-DEFAULT-DROP: "\n'
    printf 'fi\n'
} > "$RULES_FILE" || fail 'could not write rules.sh.'
chmod 700 "$RULES_FILE" || fail 'could not make rules.sh executable.'

log_info "Generated applying firewall script: $RULES_FILE"
log_info "Make sure to run sudo netfilter-persistent save (install iptables-persistent) to apply rules to startup"
finish 0
