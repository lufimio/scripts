# Standalone conntrack display

Extracted from VyOS `src/op_mode/conntrack.py`, with the VyOS process,
VRF lookup, and command dispatch helpers replaced by standalone Python code.
Copy this entire directory to a Linux machine. No VyOS installation is required.

Requires Python 3.11+, the `conntrack` executable (conntrack-tools), and `sudo`
when run as an unprivileged user. VRF lookup also requires `ip` (iproute2).
Reading conntrack requires appropriate privileges, normally root or CAP_NET_ADMIN.

On Debian/Ubuntu, install the system commands with:

```sh
sudo apt-get install conntrack iproute2 sudo python3-venv
```

Install the Python dependencies from this directory:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

Run from this directory:

```sh
.venv/bin/python conntrack.py show --family inet
.venv/bin/python conntrack.py show --family inet6
.venv/bin/python conntrack.py show --family inet --vrf BLUE
.venv/bin/python conntrack.py show_statistics
.venv/bin/python conntrack.py show --family inet --raw
```

The script invokes `sudo conntrack` when it is not already running as root.
`--vrf` preserves VyOS's mapping of VRF table IDs to conntrack zones; it only
matches connections if the host uses that same zone mapping.
`--raw` outputs the parsed data as JSON, without VyOS field-name normalization.

The original display formatting is retained. CLI XML definitions, configuration
scripts, and the rest of the VyOS Python library are not needed for this copy.
The script retains its upstream copyright and GPL notice; see `LICENSE.GPL`.
