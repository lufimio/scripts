# KRBTGT rotation

Run this interactive step after `scripts\first15\users.ps1` has finished and any
reported failures are resolved, before firewall/hardening. Run locally in elevated
Windows PowerShell on a writable DC, using the new credential for fresh
authentication if `users.ps1` changed your password. From the Windows folder:

```powershell
powershell.exe -NoProfile -File .\scripts\krbtgt\New-KrbtgtKeys.ps1
```

The separate PowerShell process isolates upstream console settings and `EXIT`
statements. Do not dot-source it. It requires the ActiveDirectory and GroupPolicy
modules and an interactive Windows console. It writes its own timestamped log
beside the script. Keep the folder and logs restricted to administrators.

Select your intended forest/domain and account scope in the upstream prompts:

| Mode | Action |
| --- | --- |
| 1 | Information mode; no password reset |
| 2 | Create/delete a temporary canary to test replication |
| 3 | Reset test KRBTGT accounts only |
| 4 | Reset production KRBTGT accounts once and monitor replication |
| 8 / 9 | Create / delete test KRBTGT accounts |

Mode 4 performs **one reset** of the selected production account(s) per invocation.
For the normal writable-DC account choose the all-RWDC scope. RODCs have separate
KRBTGT accounts and scopes. Inspect every DC's reachability/replication outcome:
upstream skips verification for unreachable DCs, so an overall script exit is not
proof that every DC received the new key.

To invalidate both old KRBTGT keys, perform two coordinated production resets.
Verify replication after the first and wait at least the configured maximum user
and service ticket lifetimes before the second (10 hours with defaults; allow
for clock skew). Do not override the upstream early-reset warning for the routine
workflow. Confirm effective policy yourself: this snapshot reads Default Domain
Policy and can fall back to default timing when policy lookup fails.
See [Microsoft's reset procedure](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/forest-recovery-guide/ad-forest-recovery-reset-the-krbtgt-password).

`users.ps1` disables reversible encryption first and rotates exposed ordinary
accounts automatically. Its ordinary cleanup excludes the domain RID-502 KRBTGT
account and RODC ticket accounts identified by `msDS-SecondaryKrbTgtNumber`.
This tool remains a separate interactive step, outside Dovetail's unattended preset.

## Source

`New-KrbtgtKeys.ps1` and `LICENSE` are copied without modification from:

```text
other-teams-repos/mwrepo-main.zip
  mwrepo-main/Windows/New-KrbtgtKeys.ps1-master/New-KrbtgtKeys.ps1
  mwrepo-main/Windows/New-KrbtgtKeys.ps1-master/LICENSE
```

Script version: v2.5, 2020-02-17. Original work by Jared Poeppelman (Microsoft),
rewritten/enhanced by Jorge de Almeida Pinto. The archive supplies the included
MIT license. This is the repository snapshot, not a claim of current upstream
support or live-domain validation.

SHA-256 of the unmodified script:
`6f47fdcd6aab1b21f7ff1d101632ba4301d215c9ee03af21dfafca85f8383c4f`.

## DCSync coverage in this repository

`scripts\first15\dc-impacket-hardening.ps1` already audits unusual directory
permissions, including replication rights and broader control paths. Run its
`-Interactive` permissions menu to inspect and remove selected explicit grants.

The command-line `-Apply -RemoveReplicationGrantFrom '<SID>'` option removes
explicit replication/all-extended-right ACEs for a specified trustee on the domain
root. It guards core administrator/replication SIDs and DC computer accounts,
backs up the ACL, and leaves GenericAll and inherited grants for separate review.
Group nesting, ownership and write-DACL paths still require assessment. `-Apply`
alone does not select replication trustees for removal.

These are permission mitigations; DCSync uses legitimate AD replication and has
no universal patch that disables abuse while retaining normal DC replication.
See [Microsoft's guidance on removing DCSync permissions](https://learn.microsoft.com/en-us/defender-for-identity/security-posture-assessments/accounts#remove-non-admin-accounts-with-dcsync-permissions).
KRBTGT rotation does not revoke replication permissions. No live-domain DCSync
or patch state is established by inspecting these scripts.
