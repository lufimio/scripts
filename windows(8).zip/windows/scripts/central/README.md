# Central Windows presets

From an elevated Windows PowerShell session in the Windows folder, run:

```powershell
.\scripts\central\dovetail-tui.ps1 -Preset DomainController
```

Enter target IPs/hostnames and credentials. Dovetail prints every script's
declared defaults and preset values for each connected host, then offers a
review/edit screen before deploying or executing scripts. For domain accounts, use an explicit name such as
`MWCCDC\sysadmin` or `sysadmin@mwccdc.test`.

The preset runs these commands **in order on each host**:

```powershell
.\users.ps1
.\firewall.ps1 -Preset DomainController -AllowedTCPPorts 5985 -Once
.\hardening.ps1 -KeepWinRM -KeepLocalAdminRemoting
```

## Review and edit one host

The initial screen shows parameter numbers, names, values and whether each value
is set by the plan or comes from the script default. Target-dependent default
expressions are shown as written, without evaluating them on the controller.
The firewall summary also shows the ports added by its `DomainController` preset.

At `Enter=run reviewed plan; host number=edit that host; Q=cancel`:

- Press Enter to run the displayed plan.
- Enter a host number, then a script number, to edit only that host's parameters.
- Enter `Q` to cancel without deploying or executing scripts.

In the parameter editor, use a parameter name or displayed number to set its
value. This can also add a parameter not previously set by the preset. Use
`+AllowedTCPPorts` to append ports while preserving existing entries, or
`-ParameterName` to remove its override and restore the default. `[]` clears an
array; booleans accept explicit `true`/`false`. Types and ValidateSet choices are
checked as you edit. Central hardening remoting defaults are restored when their
overrides are removed; use explicit false to override those defaults.

For example, with a DC as host 1 and an SQL server as host 2:

```text
Enter=run reviewed plan; host number=edit that host; Q=cancel: 2
Script number to edit parameters; Enter=back to review: 2
Parameter name/number; +name appends array values; -name restores default; Enter=done: Preset
Preset (Custom, DomainController; Enter=keep current): Custom
Parameter name/number; +name appends array values; -name restores default; Enter=done: +AllowedTCPPorts
AllowedTCPPorts (comma-separated values or JSON array; [] clears; Enter=keep current): 1433
```

Press Enter to finish editing, then Enter to return to the full review. The SQL
host now uses `Preset=Custom`, TCP `5985,1433`, and `Once=true`; host 1 retains its
DC firewall settings. Use the SQL instance's actual configured port if different.
Changing the firewall preset to `Custom` is what removes the AD port additions;
adding 1433 alone would keep them. Existing SSH/RDP firewall allowances still
follow `firewall.ps1`'s default behavior; set `AllowManagementPortBlock=true` if
those should also be limited to your selected list.

You can keep editing before the final Enter starts execution. Edits affect the
current run and selected host; the preset JSON file remains unchanged. The
`run.ps1` command remains the batch entry point with explicit parameters; use
`dovetail-tui.ps1` for this interactive review.

Different hosts can progress concurrently. Each host reuses its existing
authenticated session across the three steps. By default, a failed step leaves
later steps on that host marked `NotRun`; other hosts continue. `-ContinueOnError`
allows the next step after a reported script failure, but a timeout or unconfirmed
outcome always stops the sequence. Reports and live logs use the existing central
runner output directory.

All other script defaults remain in effect. In particular, `users.ps1` performs
its existing group cleanup and resets the executing account's password when it is
in scope, plus domain accounts allowing reversible encryption at discovery through
their flag or effective password policy. `-SkipPasswordReset` disables both kinds
of reset. New credentials appear in its protected log. KRBTGT/RODC ticket keys
use the separate interactive [KRBTGT tool](../krbtgt/README.md). To insert that
tool between users and firewall/hardening, run those steps manually; this preset
continues directly to the next script and does not launch or pause for the tool.
Current hardening defaults
disable domain GPOs, delete shadow copies, and remove root scheduled tasks,
including `CCDC-YARA-Windows-Scan` if installed. Creating or selecting a preset
does not itself change a host; running the preset executes these scripts.

For a command with explicit targets and a credential object:

```powershell
$credential = Get-Credential 'MWCCDC\sysadmin'
.\scripts\central\run.ps1 -Preset DomainController `
    -ComputerName 10.4.10.10 -Credential $credential
```

`run.ps1` also accepts its existing `-CredentialByHost`, `-ThrottleLimit`,
`-UseSSL`, `-Port`, timeout, and output options. Neither runner stores passwords
in the preset.

## Change environment settings

Override just the parameters that differ. Overrides merge with the preset;
explicit `false` values are preserved. The same override syntax works with
`dovetail-tui.ps1` and `run.ps1`:

```powershell
$overrides = @{
    'first15\firewall.ps1' = @{
        AllowedTCPPorts = @('5985', '3389')
        RemoteAddress = @('10.4.10.0/24')
    }
    'first15\users.ps1' = @{ SkipPasswordReset = $true }
    'first15\hardening.ps1' = @{ KeepDomainGpos = $true }
}
.\scripts\central\dovetail-tui.ps1 -Preset DomainController `
    -ParametersByScript $overrides
```

The example source-address override applies to the firewall script's rules,
including DC service ports; use the ranges required by that environment. The
built-in preset keeps the firewall script's default address scope (`Any`).
For WinRM HTTPS, include TCP 5986 in your firewall override as well as passing
`-UseSSL` to `run.ps1`; transport options do not rewrite firewall presets.

For a reusable environment definition, copy
[`presets/DomainController.json`](presets/DomainController.json), edit its ordered
`Tasks` and `Parameters`, and load the copy:

```powershell
.\scripts\central\dovetail-tui.ps1 -PresetFile C:\CCDC\lab-dc.json
# Or:
.\scripts\central\run.ps1 -PresetFile C:\CCDC\lab-dc.json `
    -ComputerName 10.4.10.10 -Credential $credential
```

Use a JSON object containing a nonempty `Tasks` array. Each task has a script
`Path` relative to the scripts folder and an optional `Parameters` object. Paths,
duplicate tasks, parameter names, and override script names are checked before
connecting. Use either `-Preset` or `-PresetFile`. In `run.ps1`, choose either a
preset or explicit `-Script`/`-ScriptParameters` selection. `-ParametersByScript`
also works with custom presets.

Starting `dovetail-tui.ps1` without a preset keeps its existing manual selection
and parallel execution behavior.
