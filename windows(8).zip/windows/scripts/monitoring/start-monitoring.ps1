#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess) {
    throw 'Run in 64-bit Windows PowerShell.'
}

$securityWatch = Join-Path $PSScriptRoot 'security-watch.ps1'
$sysmon = Join-Path (Split-Path -Parent $PSScriptRoot) 'sysmon\sysmon.ps1'
$persistenceBaseline = Join-Path $env:ProgramData 'HostTools\Monitoring\persistence-baseline.xml'
$watchers = @($securityWatch)
if (Test-Path -LiteralPath $persistenceBaseline -PathType Leaf) {
    $watchers += Join-Path $PSScriptRoot 'persistence.ps1'
} else {
    Write-Host 'Persistence monitoring skipped because no baseline exists.'
}

foreach ($path in ($watchers + $sysmon)) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Required script missing: $path"
    }
}

$powershell = Join-Path $env:windir 'System32\WindowsPowerShell\v1.0\powershell.exe'
foreach ($watcher in $watchers) {
    # Keep the console open so startup errors remain visible.
    Start-Process -FilePath $powershell -ArgumentList @('-NoProfile', '-NoExit', '-File', ('"{0}"' -f $watcher))
}

& $sysmon -Monitor
