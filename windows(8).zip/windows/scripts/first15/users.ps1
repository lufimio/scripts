#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [switch]$ResetPasswords = $true,
    [switch]$ResetAllPasswords,
    [switch]$SkipPasswordReset,
    [switch]$PassThru,
    [string[]]$AdditionalPrivilegedGroups = @()
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

# Preserve existing remoting membership by SID, including renamed/localized groups.
# Apply to both nesting cleanup and direct-account cleanup/verification.
$preservedGroupSids = @(
    'S-1-5-32-580' # Remote Management Users
    'S-1-5-32-555' # Remote Desktop Users
)

# READABLE PASSWORD SETTINGS: edit this word list or change $PassphraseWordCount.
# Three capitalized words plus two digits (00-99) are selected with the system crypto RNG.
$PassphraseWordCount = 3
$PassphraseWords = @(
    'apple', 'banana', 'cherry', 'lemon', 'mango', 'orange', 'peach', 'pear', 'plum', 'grape',
    'bear', 'bird', 'bunny', 'cat', 'deer', 'dog', 'duck', 'fox', 'horse', 'lion',
    'tiger', 'turtle', 'whale', 'zebra', 'panda', 'mouse', 'sheep', 'goat', 'wolf', 'otter',
    'beach', 'brook', 'cloud', 'forest', 'hill', 'lake', 'moon', 'ocean', 'rain', 'river',
    'rock', 'sand', 'snow', 'star', 'stone', 'sun', 'tree', 'valley', 'wind', 'garden',
    'bread', 'butter', 'cake', 'candy', 'cheese', 'cookie', 'honey', 'muffin', 'pizza', 'waffle',
    'book', 'chair', 'clock', 'door', 'house', 'lamp', 'paper', 'pencil', 'pillow', 'table',
    'blue', 'green', 'purple', 'silver', 'yellow', 'bright', 'happy', 'kind', 'lucky', 'sunny',
    'boat', 'bridge', 'castle', 'drum', 'feather', 'flower', 'kite', 'lantern', 'maple', 'meadow',
    'music', 'pebble', 'pocket', 'rainbow', 'ribbon', 'rocket', 'shell', 'spoon', 'window', 'winter'
)

function Get-PassphraseRandomIndex {
    param([Security.Cryptography.RandomNumberGenerator]$Generator, [int]$Maximum)
    if ($Maximum -lt 1) { throw 'Passphrase selection requires at least one value.' }
    $bytes = New-Object byte[] 4
    $limit = [uint64]4294967296 - ([uint64]4294967296 % [uint64]$Maximum)
    do {
        $Generator.GetBytes($bytes)
        $value = [uint64][BitConverter]::ToUInt32($bytes, 0)
    } while ($value -ge $limit)
    [int]($value % $Maximum)
}

function New-ReadablePassphrase {
    $generator = [Security.Cryptography.RandomNumberGenerator]::Create()
    try {
        $parts = @(for ($i = 0; $i -lt $PassphraseWordCount; $i++) {
            $word = $PassphraseWords[(Get-PassphraseRandomIndex $generator $PassphraseWords.Count)]
            $word.Substring(0,1).ToUpperInvariant() + $word.Substring(1)
        })
        $digits = (Get-PassphraseRandomIndex $generator 100).ToString('D2')
        $parts[-1] += $digits
        $parts -join '-'
    } finally { $generator.Dispose() }
}

function Test-KrbtgtAccount {
    param($Account)
    # RODC ticket accounts have their own keys and must use the KRBTGT workflow too.
    $secondaryNumber = $Account.PSObject.Properties['msDS-SecondaryKrbTgtNumber']
    return ($Account.SID.Value -match '-502$' -or ($null -ne $secondaryNumber -and $null -ne $secondaryNumber.Value))
}

function Assert-ReversibleEncryptionDisabled {
    param($Account)
    $freshAccount = Get-ADUser -Identity $Account -Server $server -Properties AllowReversiblePasswordEncryption
    if ($freshAccount.AllowReversiblePasswordEncryption) {
        throw 'Password reset blocked: account still allows reversible encryption.'
    }
    $effectivePolicy = Get-ADUserResultantPasswordPolicy -Identity $Account -Server $server
    if ($null -eq $effectivePolicy) {
        $effectivePolicy = Get-ADDefaultDomainPasswordPolicy -Identity $domain.DNSRoot -Server $server
    }
    if ($effectivePolicy.ReversibleEncryptionEnabled) {
        throw 'Password reset blocked: effective password policy still allows reversible encryption.'
    }
}

function Test-WindowsDefaultGroupSid {
    param([string]$Sid, [string]$DomainSid)
    # BUILTIN aliases have stable SIDs, even when renamed/localized.
    if ($Sid -match '^S-1-5-32-\d+$') { return $true }
    # Default AD groups outside BUILTIN. Never infer custom groups from names or RID ranges.
    $domainGroupRids = @(498, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 525, 526, 527, 553, 571, 572)
    if ($DomainSid) {
        return $Sid -in @($domainGroupRids | ForEach-Object { "$DomainSid-$_" })
    }
    return $false
}

function Test-PrivilegedGroupSid {
    param([string]$Sid, [string]$DomainSid)
    # Explicit privilege targets, NOT every default group: e.g. Denied RODC Password
    # Replication must keep its nested groups to protect their passwords.
    $builtinRids = @(544, 548, 549, 550, 551, 552, 555, 556, 562, 569, 573, 574, 575, 576, 578, 580, 582)
    if ($Sid -in @($builtinRids | ForEach-Object { "S-1-5-32-$_" })) { return $true }
    $domainRids = @(512, 517, 518, 519, 520, 526, 527)
    return ($DomainSid -and $Sid -in @($domainRids | ForEach-Object { "$DomainSid-$_" }))
}

function Remove-PrivilegedGroupNesting {
    # Remove the immediate group-to-privileged-group edge, which also cuts paths
    # through arbitrarily deep custom nesting. Never flatten recursive user lists.
    # Read all targets and preserve the runner BEFORE the first group removal.
    $plans = @(foreach ($group in $privilegedGroups) {
        $members = if ($isDC) {
            @(Get-ADGroupMember -Identity $group -Server $server)
        } else {
            @(Get-LocalGroupMember -Group $group)
        }
        if (@($members | Where-Object { $_.ObjectClass -eq 'foreignSecurityPrincipal' }).Count) {
            throw "Unresolved foreign principals in $($group.Name); resolve them before nested-group cleanup."
        }
        [pscustomobject]@{ Group = $group; Members = $members }
    })
    $effectiveSids = if ($isDC) {
        @(Get-ADAccountAuthorizationGroup -Identity $currentSid -Server $server | ForEach-Object { $_.SID.Value })
    } else {
        @($identity.Groups | ForEach-Object { $_.Value })
    }
    foreach ($plan in $plans) {
        $group = $plan.Group
        if ($group.SID.Value -notin $effectiveSids -or $currentSid -in @($plan.Members | ForEach-Object { $_.SID.Value })) { continue }
        Write-ToolStatus "Preserve executing account's access directly in $($group.Name) before removing nested groups" 'WARN'
        if ($isDC) {
            Add-ADGroupMember -Identity $group -Members $currentSid -Server $server
            $verifiedMembers = @(Get-ADGroupMember -Identity $group -Server $server)
        } else {
            Add-LocalGroupMember -Group $group -Member $currentSid
            $verifiedMembers = @(Get-LocalGroupMember -Group $group)
        }
        if ($currentSid -notin @($verifiedMembers | ForEach-Object { $_.SID.Value })) {
            throw "Could not verify executing account's direct membership in $($group.Name); nested-group cleanup stopped."
        }
    }
    foreach ($plan in $plans) {
        $group = $plan.Group
        foreach ($member in @($plan.Members | Where-Object { $_.ObjectClass -eq 'group' })) {
            Invoke-ToolStep "Remove nested group $($member.Name) from $($group.Name)" {
                if ($isDC) {
                    Remove-ADGroupMember -Identity $group -Members $member -Server $server -Confirm:$false
                    $remainingMembers = @(Get-ADGroupMember -Identity $group -Server $server)
                } else {
                    Remove-LocalGroupMember -Group $group -Member $member
                    $remainingMembers = @(Get-LocalGroupMember -Group $group)
                }
                if ($member.SID.Value -in @($remainingMembers | ForEach-Object { $_.SID.Value })) {
                    throw 'Nested group membership remains after removal.'
                }
            }
        }
        Invoke-ToolStep "Verify no nested groups remain in $($group.Name)" {
            $remainingMembers = if ($isDC) {
                @(Get-ADGroupMember -Identity $group -Server $server)
            } else {
                @(Get-LocalGroupMember -Group $group)
            }
            if (@($remainingMembers | Where-Object { $_.ObjectClass -in 'group', 'foreignSecurityPrincipal' }).Count) {
                throw 'Nested groups or unresolved foreign principals remain.'
            }
        }
    }
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$currentSid = $identity.User.Value
Write-ToolStatus "Preserving group memberships for executing account: $($identity.Name) [$currentSid]. Its password is included when it belongs to the managed account scope."
$computer = Get-CimInstance Win32_ComputerSystem
$isDC = $computer.DomainRole -in 4, 5
$reversiblePasswordAccounts = @{}
# Discovery is a prerequisite: never modify an unidentified account scope.
if ($isDC) {
    Import-Module ActiveDirectory
    $domain = Get-ADDomain
    $server = $domain.PDCEmulator
    $dc = Get-ADDomainController -Identity $env:COMPUTERNAME
    if ($dc.IsReadOnly) { throw 'Use a writable domain controller.' }
    $ordinaryGroup = Get-ADGroup -Identity "$($domain.DomainSID.Value)-513" -Properties MemberOf -Server $server
    $domainGroups = @(Get-ADGroup -Filter * -Server $server)
    $privilegedGroups = @($domainGroups | Where-Object {
        (Test-PrivilegedGroupSid -Sid $_.SID.Value -DomainSid $domain.DomainSID.Value) -or $_.SamAccountName -in 'DnsAdmins', 'DHCP Administrators'
    })
    $privilegedGroups += @(foreach ($groupName in $AdditionalPrivilegedGroups) {
        Get-ADGroup -Identity $groupName -Server $server
    })
    $privilegedGroups = @($privilegedGroups | Where-Object { $_.SID.Value -notin $preservedGroupSids } | Sort-Object { $_.SID.Value } -Unique)
    $defaultGroupDNs = @($domainGroups | Where-Object {
        (Test-WindowsDefaultGroupSid -Sid $_.SID.Value -DomainSid $domain.DomainSID.Value) -and $_.SID.Value -notin $preservedGroupSids
    } | ForEach-Object { $_.DistinguishedName })
    $domainUsers = @(Get-ADUser -Filter * -Server $server -Properties MemberOf, PrimaryGroupID, Enabled, AllowReversiblePasswordEncryption, 'msDS-SecondaryKrbTgtNumber')
    # Snapshot exposure BEFORE clearing account flags or changing password policies.
    $initialDefaultPolicy = Get-ADDefaultDomainPasswordPolicy -Identity $domain.DNSRoot -Server $server
    $initialFineGrainedPolicies = @(Get-ADFineGrainedPasswordPolicy -Filter * -Server $server)
    $policyExposure = $initialDefaultPolicy.ReversibleEncryptionEnabled -or @($initialFineGrainedPolicies | Where-Object ReversibleEncryptionEnabled).Count -gt 0
    foreach ($user in $domainUsers) {
        $wasReversible = [bool]$user.AllowReversiblePasswordEncryption
        if ($policyExposure) {
            $effectivePolicy = Get-ADUserResultantPasswordPolicy -Identity $user -Server $server
            if ($null -eq $effectivePolicy) { $effectivePolicy = $initialDefaultPolicy }
            $wasReversible = $wasReversible -or $effectivePolicy.ReversibleEncryptionEnabled
        }
        if ($wasReversible) { $reversiblePasswordAccounts[$user.SID.Value] = $true }
    }
    . Invoke-ToolStep 'Disable reversible encryption in the default domain password policy' {
        $policy = Get-ADDefaultDomainPasswordPolicy -Identity $domain.DNSRoot -Server $server
        if ($policy.ReversibleEncryptionEnabled) {
            Set-ADDefaultDomainPasswordPolicy -Identity $domain.DNSRoot -Server $server -ReversibleEncryptionEnabled $false
            if ((Get-ADDefaultDomainPasswordPolicy -Identity $domain.DNSRoot -Server $server).ReversibleEncryptionEnabled) { throw 'Default domain password policy still allows reversible encryption.' }
        }
    }
    foreach ($policy in $initialFineGrainedPolicies) {
        Invoke-ToolStep "Disable reversible encryption in password policy $($policy.Name)" {
            if ($policy.ReversibleEncryptionEnabled) {
                Set-ADFineGrainedPasswordPolicy -Identity $policy -Server $server -ReversibleEncryptionEnabled $false
                if ((Get-ADFineGrainedPasswordPolicy -Identity $policy -Server $server).ReversibleEncryptionEnabled) { throw 'Fine-grained password policy still allows reversible encryption.' }
            }
        }
    }
    foreach ($user in $domainUsers) {
        Invoke-ToolStep "Disable reversible password encryption for $($user.SamAccountName)" {
            if ($user.AllowReversiblePasswordEncryption) {
                Set-ADUser -Identity $user -Server $server -AllowReversiblePasswordEncryption $false
                if ((Get-ADUser -Identity $user -Server $server -Properties AllowReversiblePasswordEncryption).AllowReversiblePasswordEncryption) { throw 'Account still allows reversible password encryption.' }
            }
        }
    }
    $accounts = @($domainUsers | Where-Object { -not (Test-KrbtgtAccount $_) })
    Write-ToolStatus "Domain: $($domain.DNSRoot). Baseline: $($ordinaryGroup.Name); custom groups are preserved. KRBTGT/RODC ticket accounts use scripts\krbtgt\New-KrbtgtKeys.ps1 for password rotation; their memberships are skipped."
    if (@($domainUsers | Where-Object { (Test-KrbtgtAccount $_) -and $reversiblePasswordAccounts.ContainsKey($_.SID.Value) }).Count) {
        Write-Warning 'Reversible encryption exposure includes a KRBTGT account. Complete the separate KRBTGT rotation after this script; its key is not reset here.'
    }
    Write-Warning 'Accounts allowing reversible encryption through their flag or effective policy at discovery are included in password resets. Previously cleared flags cannot reveal old stored passwords; use -ResetAllPasswords to cover earlier exposure.'
} else {
    Import-Module Microsoft.PowerShell.LocalAccounts
    $ordinaryGroup = Get-LocalGroup -SID 'S-1-5-32-545'
    $allLocalGroups = @(Get-LocalGroup)
    $localGroups = @($allLocalGroups | Where-Object {
        (Test-WindowsDefaultGroupSid -Sid $_.SID.Value) -and $_.SID.Value -notin $preservedGroupSids
    })
    $privilegedGroups = @($allLocalGroups | Where-Object {
        (Test-PrivilegedGroupSid -Sid $_.SID.Value) -or $_.Name -in 'DnsAdmins', 'DHCP Administrators'
    })
    $privilegedGroups += @(foreach ($groupName in $AdditionalPrivilegedGroups) {
        Get-LocalGroup -Name $groupName
    })
    $privilegedGroups = @($privilegedGroups | Where-Object { $_.SID.Value -notin $preservedGroupSids } | Sort-Object { $_.SID.Value } -Unique)
    $accounts = @(Get-LocalUser)
    Write-ToolStatus "Local accounts on $env:COMPUTERNAME. Baseline: $($ordinaryGroup.Name); custom groups are preserved. Domain accounts are managed on a DC."
}
# Reset the executing account last so earlier domain operations use its existing credentials.
$accounts = @($accounts | Sort-Object { $_.SID.Value -eq $currentSid })
Write-Host "Accounts to process: $($accounts.Count). Password reset: $($ResetPasswords -and -not $SkipPasswordReset). Include other accounts: $ResetAllPasswords. Enabled/disabled status is preserved."
Write-ToolStatus 'Preserving existing Remote Management Users and Remote Desktop Users memberships, including nested groups. Previously removed memberships are not restored.'
Write-Warning 'Removing other Windows default group memberships and nesting in privileged groups can remove admin, RDP, remote management and service access. Remote Management Users / Remote Desktop Users memberships and custom memberships outside those nesting targets are preserved. Existing sign-ins retain old tokens until they sign in again.'
if ($ResetPasswords -and -not $SkipPasswordReset) {
    $passwordScope = if ($ResetAllPasswords) { 'all managed accounts, including the executing user' } else { 'the executing user and domain accounts allowing reversible encryption at discovery' }
    Write-Warning "Passwords will change for $passwordScope. Each successful reset prints its new credential immediately and again as username,password at the end. Update dependent services and scoring credentials."
    if (-not $ResetAllPasswords -and $currentSid -notin @($accounts | ForEach-Object { $_.SID.Value })) {
        Write-Warning 'The executing identity is outside the managed account scope. Its password will not be reset; exposed domain accounts remain eligible for automatic rotation.'
    }
} elseif ($reversiblePasswordAccounts.Count) {
    Write-Warning 'Password resets are disabled for this run. Clearing reversible-encryption settings does not remove existing reversibly stored passwords; rotate the affected accounts separately.'
}
$successfulCredentials = New-Object 'System.Collections.Generic.List[object]'
$mandatoryExceptions = New-Object 'System.Collections.Generic.List[string]'
try {
Invoke-ToolStep 'Remove groups nested in privileged groups (preserve executing account directly first)' {
    Remove-PrivilegedGroupNesting
}
foreach ($account in $accounts) {
    $name = if ($isDC) { $account.SamAccountName } else { $account.Name }
    $isExecutingUser = $account.SID.Value -eq $currentSid
    $builtInAdministrator = $account.SID.Value -match '-500$'
    $mandatoryGroup = $null
    if ($builtInAdministrator -and -not $isExecutingUser) {
        $mandatoryGroup = if ($isDC) { (Get-ADGroup -Identity 'S-1-5-32-544' -Server $server).DistinguishedName } else { 'S-1-5-32-544' }
        $mandatoryExceptions.Add($name)
        Write-ToolStatus "$name is the built-in Administrator. Windows requires its Administrators membership; that exception remains. Other default groups and password are still processed." 'WARN'
    }
    Write-ToolStatus "Account: $name"
    if (-not $isExecutingUser) {
        # Preserve custom primary groups; replace only Windows default primary groups.
        $expectedPrimaryGroupID = if ($isDC) { $account.PrimaryGroupID } else { $null }
        if ($isDC -and (Test-WindowsDefaultGroupSid -Sid "$($domain.DomainSID.Value)-$expectedPrimaryGroupID" -DomainSid $domain.DomainSID.Value)) {
            $expectedPrimaryGroupID = 513
        }
        # Establish and verify ordinary-user membership BEFORE removing anything.
        $baselineReady = $false
        . Invoke-ToolStep "Ensure ordinary-user membership for $name" {
            if ($isDC) {
                if ($account.PrimaryGroupID -ne 513) {
                    Add-ADGroupMember -Identity $ordinaryGroup -Members $account -Server $server
                    if ($expectedPrimaryGroupID -eq 513) {
                        Set-ADUser -Identity $account -Replace @{ primaryGroupID = 513 } -Server $server
                    }
                }
                $fresh = Get-ADUser -Identity $account -Properties MemberOf, PrimaryGroupID -Server $server
                if ($fresh.PrimaryGroupID -ne $expectedPrimaryGroupID -or ($fresh.PrimaryGroupID -ne 513 -and $ordinaryGroup.DistinguishedName -notin @($fresh.MemberOf))) { throw 'Ordinary/primary group verification failed; other memberships will be retained.' }
            } else {
                $members = @(Get-LocalGroupMember -Group $ordinaryGroup)
                if ($account.SID.Value -notin @($members | ForEach-Object { $_.SID.Value })) {
                    Add-LocalGroupMember -Group $ordinaryGroup -Member $account
                }
                $members = @(Get-LocalGroupMember -Group $ordinaryGroup)
                if ($account.SID.Value -notin @($members | ForEach-Object { $_.SID.Value })) { throw 'Users membership verification failed.' }
            }
            $baselineReady = $true
        }
        if (-not $baselineReady) { Write-Warning "Keeping other memberships for $name because ordinary-user membership was not verified." }
        elseif ($isDC) {
            # Refetch because changing the primary group makes the old primary a direct membership.
            $groupsToRemove = @($fresh.MemberOf | Where-Object { $_ -in $defaultGroupDNs })
            foreach ($groupDN in $groupsToRemove | Sort-Object -Unique | Where-Object { $_ -ne $ordinaryGroup.DistinguishedName }) {
                if ($builtInAdministrator -and $groupDN -eq $mandatoryGroup) { continue }
                Invoke-ToolStep "Remove $name from $groupDN" {
                    Remove-ADGroupMember -Identity $groupDN -Members $account -Server $server -Confirm:$false
                }
            }
        } else {
            foreach ($group in $localGroups | Where-Object { $_.SID.Value -ne $ordinaryGroup.SID.Value }) {
                if ($builtInAdministrator -and $group.SID.Value -eq $mandatoryGroup) { continue }
                Invoke-ToolStep "Check/remove $name from $($group.Name)" {
                    $members = @(Get-LocalGroupMember -Group $group)
                    if ($account.SID.Value -in @($members | ForEach-Object { $_.SID.Value })) {
                        Remove-LocalGroupMember -Group $group -Member $account
                    }
                }
            }
        }
    }
    if ($ResetPasswords -and -not $SkipPasswordReset -and ($isExecutingUser -or $ResetAllPasswords -or $reversiblePasswordAccounts.ContainsKey($account.SID.Value))) {
        . Invoke-ToolStep "Reset password for $name" {
            $plain = New-ReadablePassphrase
            $secure = ConvertTo-SecureString $plain -AsPlainText -Force
            try {
                if ($isDC) {
                    Assert-ReversibleEncryptionDisabled $account
                    Set-ADAccountPassword -Identity $account -Reset -NewPassword $secure -Server $server
                }
                else { Set-LocalUser -InputObject $account -Password $secure }
                # Retain a pair only after Windows confirms the reset succeeded.
                $successfulCredentials.Add([pscustomobject]@{ Username=$name; Password=$plain })
                Write-Host ('Password changed successfully. New credential: {0},{1}' -f $name, $plain) -ForegroundColor Yellow
            } finally { $secure.Dispose(); $plain = $null }
        }
    }
    if (-not $isExecutingUser) {
        Invoke-ToolStep "Verify remaining groups for $name" {
            if ($isDC) {
                $verified = Get-ADUser -Identity $account -Properties MemberOf, PrimaryGroupID -Server $server
                $remaining = @($verified.MemberOf | Where-Object { $_ -in $defaultGroupDNs -and $_ -ne $ordinaryGroup.DistinguishedName -and $_ -ne $mandatoryGroup })
                if ($verified.PrimaryGroupID -ne $expectedPrimaryGroupID -or ($verified.PrimaryGroupID -ne 513 -and $ordinaryGroup.DistinguishedName -notin @($verified.MemberOf)) -or $remaining.Count) { throw "Unexpected primary/baseline membership or remaining default groups: $($remaining -join ', ')" }
            } else {
                $remaining = @(foreach ($group in $localGroups | Where-Object { $_.SID.Value -ne $ordinaryGroup.SID.Value }) {
                    if ($builtInAdministrator -and $group.SID.Value -eq $mandatoryGroup) { continue }
                    $members = @(Get-LocalGroupMember -Group $group)
                    if ($account.SID.Value -in @($members | ForEach-Object { $_.SID.Value })) { $group.Name }
                })
                if ($remaining.Count) { throw "Account still has other default groups: $($remaining -join ', ')" }
            }
        }
    }
}
if ($mandatoryExceptions.Count) { Write-ToolStatus "Mandatory built-in Administrators membership retained for: $($mandatoryExceptions -join ', '). These accounts are still administrators." 'WARN' }
if ($isDC) { Write-ToolStatus 'Next: run scripts\krbtgt\New-KrbtgtKeys.ps1 interactively after resolving failures and before firewall/hardening. Use the new credential for fresh authentication.' }
Show-ToolSummary

if ($PassThru) { [pscustomobject]@{ ProcessedAccounts=$accounts.Count; SuccessfulResets=$successfulCredentials.Count; FailedSteps=$script:ToolFailures.Count } }
} finally {
    # The credential block is last, after every progress message and summary.
    # No export, transcript or credential file is created by this script.
    try {
        if ($successfulCredentials.Count) {
            Write-Host ''
            Write-Host 'Successful password resets (username,password):'
            foreach ($entry in $successfulCredentials) {
                Write-Host ('{0},{1}' -f $entry.Username, $entry.Password)
            }
        }
    } finally { $successfulCredentials.Clear() }
}
