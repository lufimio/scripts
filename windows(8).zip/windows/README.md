# Windows

For a saved users → DC firewall → hardening workflow, run
`scripts\central\dovetail-tui.ps1 -Preset DomainController` in elevated Windows
PowerShell. It asks for targets and credentials, prints defaults, and lets you
edit parameters per host before running the scripts in order. See [central presets](scripts/central/README.md)
for exact defaults, environment overrides, and custom JSON presets.

`scripts\first15\users.ps1` preserves existing **Remote Management Users**
and **Remote Desktop Users** memberships by SID, including direct users and nested
groups such as Domain Users, on both DCs and member/standalone servers. This exception also applies if either
group is listed in `-AdditionalPrivilegedGroups`. Other default-group cleanup
still applies. This preserves existing membership; it does not grant access or
restore membership removed by an earlier run.

On a DC, `users.ps1` captures accounts allowing reversible password encryption
before disabling it in account flags, the domain policy, and fine-grained policies.
By default it resets the executing user's password **and those exposed accounts**,
including disabled accounts, without changing enabled/disabled status. Effective
fine-grained policies take precedence over the domain default. Each reset verifies
the account flag and effective policy are disabled first; a failed check blocks
that reset and is reported. Successful new credentials print immediately and again
at the end. Update services/scoring that use changed credentials.
`-SkipPasswordReset` or `-ResetPasswords:$false` disables all these resets;
`-ResetAllPasswords` includes all managed accounts. Exposure from flags/policies
cleared by an earlier run cannot be inferred; rotate those passwords explicitly
or use `-ResetAllPasswords`.

After `users.ps1`, resolve reported failures, then run the other team's interactive
KRBTGT tool **before firewall/hardening** from the Windows folder:

```powershell
powershell.exe -NoProfile -File .\scripts\krbtgt\New-KrbtgtKeys.ps1
```

Use the new credential for fresh authentication after `users.ps1`. KRBTGT and RODC
ticket accounts are excluded from ordinary password/group cleanup. The separate
tool handles their keys and replication; it is not launched by the unattended
Dovetail preset. See [KRBTGT modes, source and reset timing](scripts/krbtgt/README.md).

The **Windows competition ZIP** GitHub Actions workflow runs when Windows files
change and can also be started from **Actions → Windows competition ZIP → Run workflow**.
It checks all PowerShell scripts, modules, and manifests with the Windows
PowerShell 5.1 parser and checks JSON/XML files.
Any syntax error fails the workflow before packaging or uploading.

Download the single `windows.zip` artifact from a successful run. It contains the
entire tracked `subteams/windows` tree under `windows/`, including scripts,
checklists, documentation, vendored modules, and bundled tools. Syntax checks do
not execute the scripts or verify their behavior on competition hosts.

For the standalone LDAP Firewall wrapper and upstream DACLPrevention blocking config, see
[scripts/ldapfw](scripts/ldapfw/README.md). Run `scripts\ldapfw\ldapfw.ps1` in an
elevated PowerShell session on the DC to open its menu.

The compiled [Hunting Sleeping Beacons scanner](scripts/tools/Hunting-Sleeping-Beacons.exe)
is in `scripts/tools`. See its [usage and rebuild instructions](scripts/tools/Hunting-Sleeping-Beacons/README.md).

Run the interactive directory console in an elevated Windows PowerShell session
on a writable domain controller:

```powershell
.\scripts\first15\dc-impacket-hardening.ps1 -Interactive
```

The full audit (menu A) checks the original DC baseline plus unusual permissions,
non-DC delegation, AS-REP accounts, user SPNs, machine creation and trust settings.
It shows named targets and concrete effects, then offers a numbered fix list.
The permissions/delegation/SPN menus also scan and display results immediately.
At a removal prompt, enter `1,3` or `2-5` to apply those displayed actions; there
is no extra R/APPLY prompt. Enter returns without changing anything.

Default output uses short Cable-style blocks. `D <number>` shows a finding's
evidence and impact; `D` in the full audit expands the audit details. Routine
progress messages and repeated explanations are hidden from the default view.

Default audits and console browsing write no CSVs, reports or transcripts.
Recovery for console changes stays in memory, and menu 9 can undo verified
changes while the session remains open. Exiting discards those records.
Use `-SaveRecovery` only if you want encrypted disk recovery; it is tied to the
same Windows identity/machine. `-SaveLogs` explicitly enables transcripts and an
audit CSV. Bulk command-line `-Apply` still creates encrypted backups for actual
changes, and requested service-password rotation stores its generated recovery
credential. `-BackupRoot` changes the location of explicitly saved material.

The default permission scan filters routine password-change rights, expected
operator delegations, expected Key Admin key-credential grants and repeated
inherited ACEs. Explicit sources in domain containers/OUs are scanned so inherited
paths are reviewed at their origin. It retains unusual control grants by ordinary
accounts/groups. Option I in the permissions menu inspects the full ACL when
needed. Findings are review candidates rather than a complete effective-access
calculation. Core administrator/DC/SELF/current-operator removal is guarded.

ACL removal checks tolerate AD's equivalent descriptor formatting, mapped generic
rights and reordered consecutive Allow or Deny entries. They still check every
grant, scope, inheritance/protection setting and Allow/Deny ordering. Verified
recovery records retain the actual server readback for undo. If a removal reports
a readback mismatch, refresh Permissions first: the selected grant may already be
gone even though another ACL difference prevented verification. Refreshed list
numbers can change; choose from the new list.

Menu 7 explains trust settings and offers machine-quota, selective-authentication,
external SID-quarantine and forest SID-filtering hardening where applicable.
Actions state their authentication/migration impact before selection. Same-forest
child trusts are not treated as broken because quarantine/selective-authentication
flags are false. Forest SID-history relaxation is assessed from the raw
`trustAttributes` bits, not inferred from the confusing property names.
See [Microsoft trust attribute definitions](https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-adts/e9a2d23c-c31e-4a6f-88a0-6646fdb51a3c).

Without `-Interactive`, the existing audit and explicit command-line `-Apply`
workflow remain available. Interactive mode cannot be combined with bulk
remediation parameters. Fixing a malicious value does not remove underlying
unauthorized write permissions; check the related ACL as well.

Validated on Windows PowerShell 5.1 on a writable lab DC using temporary disabled
accounts and groups. Verification covers targeted removals, undo, stale selections,
trust-flag calculations, and the default no-file workflow. Generated test scripts,
fixtures, and validation uploads are removed before delivery.
