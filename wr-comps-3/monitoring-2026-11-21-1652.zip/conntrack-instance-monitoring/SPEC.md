# SPEC.md

Read `AGENTS.md` first (conventions, scope, Python rules). Both `pfctl_instance.py` should be single Python files (keeping as closs to the style requirements in AGENTS.md). This SPEC is not a rigid outline, make minor design decisions as needed but as on major changes. I'm giving the overall goal of the project and a few defined design decisions.

## 1. Purpose and workflow
Operator is firewall admin in a competition: host IPs and ports and services are known. The purpose of this script is to take in current `pfctl -ss` output and given a configuration file containing the lan address range and ips of the internal clients and an argument for the IP, filter out closing/ closed connection states, filter out traffic between lan devices, then apply a reverse dns lookup (fall back to team cmyru asn lookup) to attempt to give some more context to the IP. This script is to be mainly used on opnsense/pfsense routers, so most of the traffic will be routed through the router.

Use `pfctl -ss`.

## 2. Scope
The program will be a self contained Python 3.8+ compatible script with no dependencies. Copy dependency code as needed to minimize the use of standard Python. The code must be functionality first, human readable second, length third. This script requires root

## 3. Output
The output must be compact horizontally and vertically as to not overflow a small console window. The output must include a general summary of currently active/ new connections to and from the device. It will also include a more detailed section on each ip connecting to and from the device and any further information associated with it. The output must be neat and human readable as much as possible. Only deal with destination ports on inbound and outbound traffic. All output must also be logged to a folder next to the script called `pfctl-output-logs`. Create it as needed.
