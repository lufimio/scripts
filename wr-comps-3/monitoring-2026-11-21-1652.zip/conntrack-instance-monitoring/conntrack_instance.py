#!/usr/bin/env python3
"""Report one host's retained conntrack connections using only the standard library."""

import argparse
from collections import Counter, defaultdict
from datetime import datetime
import ipaddress
import json
import multiprocessing
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import textwrap


CLOSING = {
    "FIN_WAIT", "CLOSE_WAIT", "LAST_ACK", "TIME_WAIT", "CLOSE", "CLOSED",
    "SHUTDOWN_SENT", "SHUTDOWN_RECD", "SHUTDOWN_ACK_SENT",
    "CLOSEREQ", "CLOSING", "TIMEWAIT",
}
NEW = {"SYN_SENT", "SYN_RECV", "COOKIE_WAIT", "COOKIE_ECHOED", "REQUEST"}


def load_config(path):
    with open(path, encoding="utf-8") as stream:
        raw = json.load(stream)
    if not isinstance(raw, dict):
        raise ValueError("Configuration must be a JSON object.")
    config = {"lan": [], "clients": set(), "excluded": []}
    for suffix, version in (("", 4), ("_v6", 6)):
        for name, destination in (("lan_cidrs", "lan"),
                                  ("internal_clients", "clients"),
                                  ("excluded_ips", "excluded")):
            key = name + suffix
            if not suffix and key not in raw:
                raise ValueError("Missing configuration field: " + key)
            values = raw.get(key, [])
            if not isinstance(values, list):
                raise ValueError(key + " must be a list.")
            for value in values:
                if not isinstance(value, str):
                    raise ValueError(key + " entries must be strings.")
                item = (ipaddress.ip_address(value) if destination == "clients"
                        else ipaddress.ip_network(value, strict=False))
                if item.version != version:
                    raise ValueError("Wrong address family in " + key + ": " + value)
                if destination == "clients":
                    config[destination].add(item)
                else:
                    config[destination].append(item)
    return config


def in_networks(address, networks):
    return any(address.version == network.version and address in network
               for network in networks)


def parse_connections(output):
    for number, line in enumerate(output.splitlines(), 1):
        # conntrack's footer and a copied shell prompt contain no tuple.
        if "src=" not in line:
            continue
        try:
            prefix, original, reply = line.split("src=", 2)
            tuples = []
            for part in (original, reply):
                fields = dict(re.findall(r"\b(src|dst|sport|dport)=([^\s]+)",
                                         "src=" + part))
                fields["src"] = ipaddress.ip_address(fields["src"])
                fields["dst"] = ipaddress.ip_address(fields["dst"])
                for key in ("sport", "dport"):
                    if key in fields:
                        fields[key] = int(fields[key])
                        if not 0 <= fields[key] <= 65535:
                            raise ValueError("Invalid port")
                tuples.append(fields)
            words = prefix.split()
            if words[0] in ("ipv4", "ipv6"):
                words = words[2:]
            protocol = words[0]
            state = next((word for word in words[1:] if word.isupper()), "")
            yield protocol, state, "[UNREPLIED]" in line, tuples[0], tuples[1]
        except (ValueError, KeyError, IndexError) as error:
            raise ValueError("Cannot parse conntrack line {}: {}".format(number, error))


def filter_connections(output, target, config):
    retained = []

    def internal(address):
        return (address == target or address in config["clients"]
                or in_networks(address, config["lan"]))

    for protocol, state, unreplied, original, reply in parse_connections(output):
        if state in CLOSING:
            continue
        if target in (original["src"], reply["dst"]):
            direction, peer = "OUT", original["dst"]
            port = original.get("dport")
        elif target in (original["dst"], reply["src"]):
            direction, peer = "IN", original["src"]
            port = (reply.get("sport") if target == reply["src"]
                    else original.get("dport"))
        else:
            continue
        # Both endpoint views matter when NAT translates an internal address.
        source_internal = internal(original["src"]) or internal(reply["dst"])
        destination_internal = internal(original["dst"]) or internal(reply["src"])
        if source_internal and destination_internal:
            continue
        if in_networks(peer, config["excluded"]):
            continue
        status = "new" if state in NEW or unreplied else "active"
        retained.append((peer, direction, protocol, port, status))
    return retained


def lookup_worker(kind, address, pipe):
    try:
        if kind == "ptr":
            result = socket.gethostbyaddr(address)[0]
        else:
            # Team Cymru's verbose single-address WHOIS query works for both families.
            with socket.create_connection(("whois.cymru.com", 43), timeout=3) as sock:
                sock.sendall((" -v " + address + "\r\n").encode("ascii"))
                chunks = []
                size = 0
                while size < 65536:
                    chunk = sock.recv(4096)
                    if not chunk:
                        break
                    chunks.append(chunk)
                    size += len(chunk)
            result = None
            for line in b"".join(chunks).decode("utf-8", "replace").splitlines():
                fields = [field.strip() for field in line.split("|")]
                if len(fields) >= 7 and fields[0].isdigit():
                    if ipaddress.ip_address(fields[1]) == ipaddress.ip_address(address):
                        result = "AS{} {} ({})".format(fields[0], fields[6], fields[3])
                        break
        pipe.send(result)
    except (OSError, ValueError):
        pipe.send(None)
    finally:
        pipe.close()


def bounded_lookup(kind, address):
    # Resolver calls do not honor socket timeouts reliably; bound the worker itself.
    reader, writer = multiprocessing.Pipe(duplex=False)
    process = multiprocessing.Process(target=lookup_worker,
                                      args=(kind, str(address), writer))
    try:
        process.start()
        writer.close()
        if reader.poll(4):
            try:
                return reader.recv()
            except EOFError:
                return None
        return None
    finally:
        if process.pid is not None:
            if process.is_alive():
                process.terminate()
            process.join()
        reader.close()
        writer.close()


def render_report(target, retained):
    width = max(20, min(78, shutil.get_terminal_size((78, 24)).columns))
    lines = []

    def emit(message):
        # Remove control characters from network-provided names before displaying them.
        message = "".join(char if char.isprintable() else " " for char in message)
        lines.extend(textwrap.wrap(message, width=width, subsequent_indent="  ",
                                   break_long_words=True, break_on_hyphens=False) or [""])

    emit("Target: " + str(target))
    emit("Retained connections: {}".format(len(retained)))
    for direction in ("IN", "OUT"):
        counts = Counter(row[4] for row in retained if row[1] == direction)
        emit("{}: {} active, {} new".format(direction, counts["active"], counts["new"]))
    sections = {"Connections": defaultdict(Counter), "UDP": defaultdict(Counter)}
    for peer, direction, protocol, port, status in retained:
        section = "UDP" if protocol == "udp" else "Connections"
        sections[section][peer][direction, protocol, port, status] += 1
    contexts = {}
    for section, peers in sections.items():
        emit("")
        emit(section + ":")
        if not peers:
            emit("None")
        for peer in sorted(peers, key=lambda address: (address.version, int(address))):
            emit("")
            emit(str(peer))
            if peer not in contexts:
                contexts[peer] = (bounded_lookup("ptr", peer)
                                  or bounded_lookup("asn", peer) or "Lookup unavailable")
            emit(contexts[peer])
            for (direction, protocol, port, status), count in sorted(
                    peers[peer].items(), key=lambda item: (item[0][0], item[0][1],
                                                         -1 if item[0][2] is None else item[0][2],
                                                         item[0][3])):
                service = protocol if port is None else "{}/{}".format(port, protocol)
                emit("{} {} {} x{}".format(direction, service, status, count))
    return "\n".join(lines) + "\n"


def create_run_directory():
    root = Path(__file__).resolve().parent / "conntrack-output-logs"
    root.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    suffix = 0
    while True:
        directory = root / (stamp if not suffix else "{}-{}".format(stamp, suffix))
        try:
            directory.mkdir()
            return directory
        except FileExistsError:
            suffix += 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", help="JSON configuration path")
    parser.add_argument("target", help="IPv4 or IPv6 address to inspect")
    args = parser.parse_args()
    directory = None
    try:
        config = load_config(args.config)
        target = ipaddress.ip_address(args.target)
        directory = create_run_directory()
        if not hasattr(os, "geteuid") or os.geteuid() != 0:
            raise ValueError("Run this script as root on the router.")
        command = ["conntrack", "-L"]
        if target.version == 6:
            command.extend(["-f", "ipv6"])
        try:
            collected = subprocess.run(command, capture_output=True, text=True,
                                       timeout=30, check=False)
        except FileNotFoundError:
            raise ValueError("conntrack is not installed or is not on PATH.")
        if collected.returncode:
            raise ValueError("conntrack failed: " + collected.stderr.strip())
        report = render_report(target, filter_connections(collected.stdout, target, config))
        with (directory / "report.txt").open("x", encoding="utf-8") as stream:
            stream.write(report)
        print(report, end="")
        return 0
    except (OSError, ValueError, subprocess.TimeoutExpired) as error:
        message = "Error: {}\n".format(error)
        if directory is not None:
            try:
                with (directory / "report.txt").open("x", encoding="utf-8") as stream:
                    stream.write(message)
            except OSError as log_error:
                print("Error logging report: " + str(log_error), file=sys.stderr)
        print(message, end="", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
