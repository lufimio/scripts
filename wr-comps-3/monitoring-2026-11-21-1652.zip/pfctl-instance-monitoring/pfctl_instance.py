#!/usr/bin/env python3
"""Report one host's retained PF states using only the standard library."""

import argparse
from collections import Counter, defaultdict
from datetime import datetime
import ipaddress
import json
import multiprocessing
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import textwrap


CLOSING = {
    "FIN_WAIT", "FIN_WAIT_1", "FIN_WAIT_2", "CLOSE_WAIT", "LAST_ACK",
    "TIME_WAIT", "CLOSE", "CLOSING", "TIMEWAIT", "SHUTDOWN_SENT",
    "SHUTDOWN_RECD", "SHUTDOWN_RECEIVED", "SHUTDOWN_ACK_SENT",
    "SHUTDOWN_PENDING", "CLOSEREQ",
}
NEW = {"SYN_SENT", "SYN_RCVD", "SYN_RECV", "COOKIE_WAIT", "COOKIE_ECHOED",
       "REQUEST", "PROXY"}
STATE_LINE = re.compile(
    r"\S+\s+(?P<protocol>\S+)\s+"
    r"(?P<left>\S+(?:\s+\([^()\s]+\))?)\s+"
    r"(?P<arrow>->|<-)\s+"
    r"(?P<right>\S+(?:\s+\([^()\s]+\))?)\s+"
    r"(?P<states>[A-Za-z0-9_]+:[A-Za-z0-9_]+)"
)


def load_config(path):
    with open(path, encoding="utf-8") as stream:
        raw = json.load(stream)
    if not isinstance(raw, dict):
        raise ValueError("Configuration must be a JSON object.")
    config = {"lan": [], "clients": set(), "excluded": []}
    for suffix, version in (("", 4), ("_v6", 6)):
        for name, destination in (("lan_cidrs", "lan"),
                                  ("internal_clients", "clients"),
                                  ("excluded_ips", "excluded")):
            key = name + suffix
            if not suffix and key not in raw:
                raise ValueError("Missing configuration field: " + key)
            values = raw.get(key, [])
            if not isinstance(values, list):
                raise ValueError(key + " must be a list.")
            for value in values:
                if not isinstance(value, str):
                    raise ValueError(key + " entries must be strings.")
                item = (ipaddress.ip_address(value) if destination == "clients"
                        else ipaddress.ip_network(value, strict=False))
                if item.version != version:
                    raise ValueError("Wrong address family in " + key + ": " + value)
                if destination == "clients":
                    config[destination].add(item)
                else:
                    config[destination].append(item)
    return config


def in_networks(address, networks):
    return any(address.version == network.version and address in network
               for network in networks)


def parse_endpoint(text):
    port = None
    if text.endswith("]"):
        # PF prints IPv6 ports after the address: 2001:db8::1[443].
        address, port_text = text[:-1].rsplit("[", 1)
        port = int(port_text)
    elif text.count(":") == 1:
        address, port_text = text.rsplit(":", 1)
        port = int(port_text)
    else:
        address = text
    address = ipaddress.ip_address(address)
    if port is not None and not 0 <= port <= 65535:
        raise ValueError("Invalid port or ICMP identifier")
    return address, port


def parse_connections(output):
    # Format reference: FreeBSD sbin/pfctl/pf_print_state.c, print_state/print_host.
    for number, line in enumerate(output.splitlines(), 1):
        if not line.strip():
            continue
        try:
            match = STATE_LINE.fullmatch(line.strip())
            if match is None:
                raise ValueError("Unrecognized PF state format")
            sides = []
            for name in ("left", "right"):
                # Primary endpoint, then its pre-translation endpoint if present.
                endpoints = [parse_endpoint(part.strip("()"))
                             for part in match[name].split()]
                sides.append(endpoints)
            source, destination = sides if match["arrow"] == "->" else sides[::-1]
            protocol = match["protocol"].lower()
            protocol = {"6": "tcp", "17": "udp", "1": "icmp", "58": "icmpv6",
                        "icmp6": "icmpv6", "ipv6-icmp": "icmpv6"}.get(protocol, protocol)
            yield protocol, match["states"].split(":"), source, destination
        except (ValueError, IndexError) as error:
            raise ValueError("Cannot parse pfctl line {}: {}".format(number, error))


def filter_connections(output, target, config):
    retained = []

    def internal(endpoint):
        address = endpoint[0]
        return (address == target or address in config["clients"]
                or in_networks(address, config["lan"]))

    for protocol, states, source, destination in parse_connections(output):
        if any(state in CLOSING for state in states):
            continue
        starting = any(state in NEW for state in states)
        # CLOSED can mean no reply yet, not just a completed TCP connection.
        if "CLOSED" in states and not (protocol == "tcp" and starting):
            continue
        if any(address == target for address, port in source):
            direction, peer = "OUT", destination[-1][0]
            port = destination[-1][1]
        elif any(address == target for address, port in destination):
            direction, peer = "IN", source[-1][0]
            port = next(port for address, port in destination if address == target)
        else:
            continue
        if any(internal(endpoint) for endpoint in source) and any(
                internal(endpoint) for endpoint in destination):
            continue
        if in_networks(peer, config["excluded"]):
            continue
        if protocol in ("icmp", "icmpv6"):
            port, status = None, "active"
        else:
            status = "new" if starting or "NO_TRAFFIC" in states else "active"
        retained.append((peer, direction, protocol, port, status))
    return retained


def lookup_worker(kind, address, pipe):
    try:
        if kind == "ptr":
            result = socket.gethostbyaddr(address)[0]
        else:
            with socket.create_connection(("whois.cymru.com", 43), timeout=3) as sock:
                sock.sendall((" -v " + address + "\r\n").encode("ascii"))
                chunks = []
                size = 0
                while size < 65536:
                    chunk = sock.recv(4096)
                    if not chunk:
                        break
                    chunks.append(chunk)
                    size += len(chunk)
            result = None
            for line in b"".join(chunks).decode("utf-8", "replace").splitlines():
                fields = [field.strip() for field in line.split("|")]
                if len(fields) >= 7 and fields[0].isdigit():
                    if ipaddress.ip_address(fields[1]) == ipaddress.ip_address(address):
                        result = "AS{} {} ({})".format(fields[0], fields[6], fields[3])
                        break
        pipe.send(result)
    except (OSError, ValueError):
        pipe.send(None)
    finally:
        pipe.close()


def bounded_lookup(kind, address):
    # Resolver calls do not honor socket timeouts reliably; bound the worker itself.
    reader, writer = multiprocessing.Pipe(duplex=False)
    process = multiprocessing.Process(target=lookup_worker,
                                      args=(kind, str(address), writer))
    try:
        process.start()
        writer.close()
        if reader.poll(4):
            try:
                return reader.recv()
            except EOFError:
                return None
        return None
    finally:
        if process.pid is not None:
            if process.is_alive():
                process.terminate()
            process.join()
        reader.close()
        writer.close()


def render_report(target, retained):
    width = max(20, min(78, shutil.get_terminal_size((78, 24)).columns))
    lines = []

    def emit(message):
        message = "".join(char if char.isprintable() else " " for char in message)
        lines.extend(textwrap.wrap(message, width=width, subsequent_indent="  ",
                                   break_long_words=True, break_on_hyphens=False) or [""])

    emit("Target: " + str(target))
    emit("Retained connections: {}".format(len(retained)))
    for direction in ("IN", "OUT"):
        counts = Counter(row[4] for row in retained if row[1] == direction)
        emit("{}: {} active, {} new".format(direction, counts["active"], counts["new"]))
    sections = {"Connections": defaultdict(Counter), "UDP": defaultdict(Counter),
                "ICMP": defaultdict(Counter)}
    for peer, direction, protocol, port, status in retained:
        section = ("UDP" if protocol == "udp" else
                   "ICMP" if protocol in ("icmp", "icmpv6") else "Connections")
        sections[section][peer][direction, protocol, port, status] += 1
    contexts = {}
    for section, peers in sections.items():
        emit("")
        emit(section + ":")
        if not peers:
            emit("None")
        for peer in sorted(peers, key=lambda address: (address.version, int(address))):
            emit("")
            emit(str(peer))
            if peer not in contexts:
                contexts[peer] = (bounded_lookup("ptr", peer)
                                  or bounded_lookup("asn", peer) or "Lookup unavailable")
            emit(contexts[peer])
            for (direction, protocol, port, status), count in sorted(
                    peers[peer].items(), key=lambda item: (item[0][0], item[0][1],
                                                         -1 if item[0][2] is None else item[0][2],
                                                         item[0][3])):
                service = protocol if port is None else "{}/{}".format(port, protocol)
                emit("{} {} {} x{}".format(direction, service, status, count))
    return "\n".join(lines) + "\n"


def create_run_directory():
    root = Path(__file__).resolve().parent / "pfctl-output-logs"
    root.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    suffix = 0
    while True:
        directory = root / (stamp if not suffix else "{}-{}".format(stamp, suffix))
        try:
            directory.mkdir()
            return directory
        except FileExistsError:
            suffix += 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", help="JSON configuration path")
    parser.add_argument("target", help="IPv4 or IPv6 address to inspect")
    args = parser.parse_args()
    directory = None
    try:
        config = load_config(args.config)
        target = ipaddress.ip_address(args.target)
        directory = create_run_directory()
        if not hasattr(os, "geteuid") or os.geteuid() != 0:
            raise ValueError("Run this script as root on the router.")
        try:
            collected = subprocess.run(["pfctl", "-ss"], capture_output=True, text=True,
                                       timeout=30, check=False)
        except FileNotFoundError:
            raise ValueError("pfctl is not installed or is not on PATH.")
        if collected.returncode:
            raise ValueError("pfctl failed: " + collected.stderr.strip())
        report = render_report(target, filter_connections(collected.stdout, target, config))
        with (directory / "report.txt").open("x", encoding="utf-8") as stream:
            stream.write(report)
        print(report, end="")
        return 0
    except (OSError, ValueError, subprocess.TimeoutExpired) as error:
        message = "Error: {}\n".format(error)
        if directory is not None:
            try:
                with (directory / "report.txt").open("x", encoding="utf-8") as stream:
                    stream.write(message)
            except OSError as log_error:
                print("Error logging report: " + str(log_error), file=sys.stderr)
        print(message, end="", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
