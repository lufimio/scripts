Coraza (an opensource WAF) is implemented with Caddy to "service-erize" it and in a reverse proxy setup. Follow steps.txt. Works on debian based routers (VYOS and certain nftable configs). Impossible to implement on proprietary firewalls such as PAN and Cisco.

After implementing Coraza, add nat rule at the top (or redirect) that redirects all http traffic destined to a internal ip to localhost port. May have to allow net.ipv4.conf.all.route_localnet=1 to allow nat redirect to localhost on linux.


TODO:
- Turn steps.txt into seperate scripts for further automation.
- Figure out how to implement on FreeBSD (pfsense and opnsense) and non debian distros.