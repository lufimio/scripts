# Caddy + Coraza setup script

## Goal

Create one POSIX `/bin/sh` script that installs and builds Caddy with the Coraza Caddy module on Debian-based systems, then configures Caddy as a reverse proxy for the webserver IP addresses supplied as arguments.

## Inputs and platform

- Require root; otherwise exit with a clear message to run with `sudo`.
- Accept one or more IPv4 addresses as positional arguments, one backend webserver per argument.
- Reject missing or malformed addresses before making system changes.
- Target Debian-based Linux systems with systemd.

## Installation and configuration

- Install Go and `xcaddy`, then build Caddy with `github.com/corazawaf/coraza-caddy/v2`.
- Refresh the host's existing APT sources and install dependencies from them. Do not add a third-party APT source.
- Install the resulting Caddy binary and configure the Caddy system user, service, and `/etc/caddy/Caddyfile` as needed.
- Generate one reverse-proxy site for each supplied backend, using the Caddy WAF configuration pattern in `caddyfile-waf.txt`.
- Proxy each backend to port 80. Assign local listener ports starting at `127.0.0.1:8081`, increasing by one for each argument, in argument order.
- Write each backend's JSON access log under `/var/log/coraza/`, using its IP address with dots replaced by underscores in the filename.
- Configure Coraza to load CRS rules from `/etc/coraza/crs/rules/*.conf`. Do not download, install, or edit Coraza/CRS rules; the operator manages them.
- Enable and restart the Caddy systemd service after configuration.

## Out of scope

- Do not configure iptables/nftables, NAT, redirects, or `route_localnet`.
- Do not configure the backend webservers or write Coraza rules.
- Do not support non-Debian distributions, FreeBSD, VyOS-specific firewall setup, or proprietary firewalls.
- Do not add tests, mocks, sample inputs, CI, Docker, packaging, or linter configuration.

## Open implementation details

- Use the Go version and download/build approach from `steps.txt` unless it is unavailable or incompatible; do not remove an existing Go installation as part of setup.
- Preserve existing collected data and avoid silently overwriting existing Caddy configuration or log files. If safe configuration replacement cannot be determined, stop and report the issue.
- Report progress and warnings in plain text, and finish with a summary that repeats warnings.
- Mirror the complete console output live to a unique timestamped log file under a `runs` directory next to the script.
