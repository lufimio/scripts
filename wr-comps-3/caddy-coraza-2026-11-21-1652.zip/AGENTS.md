# AGENTS.md

Read this file fully first before `SPEC.md`. This file is how to behave; `SPEC.md` is what to build. For this project, DO NOT access or edit another other files besides the ones in this directory and its subdirectories. Make minor design decision to conform with overall goal of project. Pause developement and ask for any major changes.

## Project
A bash script for automatically configuring host based firwall rules through iptables. Priorities: correctness, speed, readability.

## Scope
- Build only what `SPEC.md` lists. No tests, mocks, sample inputs, CI, Docker, packaging, linter config. No extra flags, keys or outputs; mention ideas in the final message instead.
- Stop and ask (question in the final message) when the spec is ambiguous, a required fixture is missing, or exact vendor syntax is uncertain. Never invent vendor syntax.
- See Bash heading below. POSIX compliance is the #1 priority in terms of design, however, still make an attempt to ensure readability as much as possible (2nd priority), even at the cost of length (3rd priority).

## Bash
- A single .sh file in strictly POSIX sh (#!/bin/sh). No bashisms: no arrays, [[ ]], mapfile, associative arrays or process substitution. It must work on bash 3, dash, busybox and very old distros.
- Use only old, common tools and flags as much as possible. Avoid GNU-only options such as stat -c, grep --exclude-dir, sed \r, date %F, and curl --noproxy. If a tool is missing, fall back to another (for example ss then netstat) and print one warning that says what to install. Don't fail.
- If it isn't root, terminate and say sudo is required.
- Cover every case. Don't rely on known program names, because the thing being looked for may be hidden or disguised. Discover it from the system itself (/proc, sockets, processes), then add detail for known cases as a bonus.
- Be fast. Run slow checks (network probes, timeouts) in parallel and skip clearly dead targets quickly. Use short timeouts. Handle legacy TLS by retrying with older settings only when the failure suggests it.
- Be robust to odd cases (empty files, missing tools, processes that vanish mid-scan), but not over-engineered. It should read like a person wrote it: simple, linear, lightly commented, easy to debug. No clever one-liners.
- Clean up temp files with a trap. Don't leave processes running: no background loops, watchers or daemons. The one exception is a revert timer in a `risk: lockout` script: a single `sleep`, then it restores the backup unless a marker file says a new login was confirmed.
- Print a readable report grouped per item, with warnings for suspicious things, and a one-line summary at the end.

## Data safety
- Never delete or overwrite collected data.

## Console
`logging`: INFO progress, WARNING for operator attention (prefix `WARNING:`), ERROR for fatal. Plain text, no emoji or colors. End each run with a summary repeating every WARNING.

## Final message
List: files created; deviations from `SPEC.md` and why; questions you stopped on; VERIFY items you could not confirm.
