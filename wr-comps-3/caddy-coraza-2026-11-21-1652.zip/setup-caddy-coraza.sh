#!/bin/sh

# Build Caddy with Coraza and configure one loopback proxy per backend IP.

GO_VERSION=1.27.3
GO_ARCHIVE="go${GO_VERSION}.linux-amd64.tar.gz"
GO_URL="https://go.dev/dl/${GO_ARCHIVE}"
GO_SHA256=65efbc80fdc1fa2cd2631cad5b481777a68e8725f34e89f50fc6ac714e379b40
GO_HOME="/usr/local/go-${GO_VERSION}"
CADDY_BINARY=/usr/bin/caddy
CADDYFILE=/etc/caddy/Caddyfile
SERVICE_FILE=/etc/systemd/system/caddy.service
LOG_DIR=/var/log/coraza
CORAZA_CONFIG=/etc/coraza/coraza.conf
CRS_DIR=/etc/coraza/crs
CRS_RULES_DIR=/etc/coraza/crs/rules

TEMP_DIR=
LOG_TEMP_DIR=
LOG_FIFO=
RUN_LOG=
TEE_PID=
WARNINGS=
WARNING_COUNT=0

info() {
    printf 'INFO: %s\n' "$1"
}

warn() {
    printf 'WARNING: %s\n' "$1"
    WARNING_COUNT=$((WARNING_COUNT + 1))
    WARNINGS="${WARNINGS}
- $1"
}

finish() {
    result=$?
    trap - 0 HUP INT TERM

    if [ -n "$TEMP_DIR" ] && [ -d "$TEMP_DIR" ]; then
        rm -rf "$TEMP_DIR"
    fi

    if [ "$result" -eq 0 ]; then
        printf 'Summary: Caddy with Coraza configured for %s backend(s).' "$BACKEND_COUNT"
    else
        printf 'Summary: setup stopped with an error.'
    fi

    if [ "$WARNING_COUNT" -eq 0 ]; then
        printf ' Warnings: none.\n'
    else
        printf ' Warnings (%s):%s\n' "$WARNING_COUNT" "$WARNINGS"
    fi

    exec 1>&3 2>&4
    if [ -n "$TEE_PID" ]; then
        wait "$TEE_PID"
    fi
    if [ -n "$LOG_TEMP_DIR" ] && [ -d "$LOG_TEMP_DIR" ]; then
        rm -rf "$LOG_TEMP_DIR"
    fi

    exit "$result"
}

fail() {
    printf 'ERROR: %s\n' "$1" >&2
    exit 1
}

path_exists() {
    ls -d "$1" >/dev/null 2>&1
}

start_console_capture() {
    script_file=$0

    case "$script_file" in
        */*)
            ;;
        *)
            script_file=$(command -v "$script_file") || return 1
            ;;
    esac

    case "$script_file" in
        /*)
            ;;
        *)
            script_file="$PWD/$script_file"
            ;;
    esac

    script_dir=$(dirname "$script_file") || return 1
    run_dir="$script_dir/runs"
    mkdir -p "$run_dir" || return 1

    timestamp=$(date '+%Y%m%d-%H%M%S' 2>/dev/null) || timestamp=unknown
    RUN_LOG="$run_dir/setup-${timestamp}-$$.log"
    (umask 077; set -C; : > "$RUN_LOG") 2>/dev/null || return 1

    if ! command -v tee >/dev/null 2>&1; then
        return 1
    fi

    LOG_TEMP_DIR=$(mktemp -d /tmp/caddy-coraza-log.XXXXXX) || return 1
    LOG_FIFO="$LOG_TEMP_DIR/console"
    mkfifo "$LOG_FIFO" || return 1

    exec 3>&1 4>&2
    tee -a "$RUN_LOG" < "$LOG_FIFO" &
    TEE_PID=$!
    exec > "$LOG_FIFO" 2>&1
    return 0
}

validate_ipv4() {
    address=$1

    case "$address" in
        ''|.*|*..*|*.)
            return 1
            ;;
        *[!0-9.]*)
            return 1
            ;;
    esac

    saved_ifs=$IFS
    IFS=.
    set -- $address
    IFS=$saved_ifs

    if [ "$#" -ne 4 ]; then
        return 1
    fi

    for octet do
        case "$octet" in
            ''|*[!0-9]*)
                return 1
                ;;
            0|[1-9]|[1-9][0-9]|[1-9][0-9][0-9])
                ;;
            *)
                return 1
                ;;
        esac

        if [ "$octet" -gt 255 ]; then
            return 1
        fi
    done

    return 0
}

if ! start_console_capture; then
    if [ -n "$LOG_TEMP_DIR" ] && [ -d "$LOG_TEMP_DIR" ]; then
        rm -rf "$LOG_TEMP_DIR"
    fi
    printf 'ERROR: Could not create a console transcript under the script directory.\n' >&2
    exit 1
fi

trap finish 0
trap 'exit 1' HUP INT TERM

info "Console transcript: $RUN_LOG"

if [ "$(id -u)" -ne 0 ]; then
    fail 'Run this script with sudo or as root.'
fi

if [ "$#" -eq 0 ]; then
    fail 'Provide one or more backend IPv4 addresses as arguments.'
fi

# Validate inputs before installing packages or changing system files.
set -f
BACKEND_COUNT=0
BACKENDS=' '

for backend_ip do
    if ! validate_ipv4 "$backend_ip"; then
        fail "Invalid IPv4 address: $backend_ip"
    fi

    case "$BACKENDS" in
        *" $backend_ip "*)
            fail "Duplicate backend IPv4 address: $backend_ip"
            ;;
    esac

    BACKENDS="${BACKENDS}${backend_ip} "
    BACKEND_COUNT=$((BACKEND_COUNT + 1))
done

if [ "$BACKEND_COUNT" -gt 57455 ]; then
    fail 'Too many backend addresses for listener ports starting at 8081.'
fi

if [ ! -r /etc/os-release ]; then
    fail 'Cannot identify the operating system; expected a Debian-based Linux host.'
fi

. /etc/os-release
case "${ID:-}" in
    debian|ubuntu|linuxmint|pop|raspbian|kali|devuan|elementary|zorin)
        ;;
    *)
        case " ${ID_LIKE:-} " in
            *' debian '*)
                ;;
            *)
                fail 'This script supports Debian-based Linux systems only.'
                ;;
        esac
        ;;
esac

if ! command -v systemctl >/dev/null 2>&1; then
    fail 'systemctl is required; this host must use systemd.'
fi

if ! command -v apt-get >/dev/null 2>&1; then
    fail 'apt-get is required on the target Debian-based system.'
fi

if path_exists "$CADDYFILE"; then
    fail "$CADDYFILE already exists; preserve or review it before running setup."
fi

if path_exists "$SERVICE_FILE"; then
    fail "$SERVICE_FILE already exists; preserve or review it before running setup."
fi

if path_exists "$CADDY_BINARY"; then
    fail "$CADDY_BINARY already exists; it will not be replaced automatically."
fi

if [ -d "$CADDYFILE" ] || [ -d "$SERVICE_FILE" ]; then
    fail 'A Caddy configuration target is a directory; no files were changed.'
fi

if path_exists "$GO_HOME"; then
    if [ ! -x "$GO_HOME/bin/go" ]; then
        fail "$GO_HOME exists but does not contain an executable Go installation."
    fi
    if ! "$GO_HOME/bin/go" version | grep "go${GO_VERSION}" >/dev/null 2>&1; then
        fail "$GO_HOME exists with a different Go version; it will not be replaced."
    fi
fi

case "$(uname -m)" in
    x86_64|amd64)
        ;;
    *)
        fail 'The configured Go download is for Linux x86-64 only.'
        ;;
esac

TEMP_DIR=$(mktemp -d /tmp/caddy-coraza.XXXXXX) || fail 'Could not create a temporary work directory.'
trap 'exit 1' HUP INT TERM

info 'Installing required build and download tools.'
apt-get update || fail 'apt-get update failed.'
apt-get install -y ca-certificates curl git tar coreutils || fail 'Could not install required tools.'

if ! command -v sha256sum >/dev/null 2>&1; then
    fail 'sha256sum is required to verify the Go download; install coreutils.'
fi

if ! path_exists "$GO_HOME"; then
    info "Downloading Go ${GO_VERSION}."
    curl -fL "$GO_URL" -o "$TEMP_DIR/$GO_ARCHIVE" || fail 'Go download failed.'

    actual_sha256=$(sha256sum "$TEMP_DIR/$GO_ARCHIVE" | awk '{print $1}')
    if [ "$actual_sha256" != "$GO_SHA256" ]; then
        fail 'The Go archive checksum did not match the published checksum.'
    fi

    tar -xzf "$TEMP_DIR/$GO_ARCHIVE" -C "$TEMP_DIR" || fail 'Could not extract Go.'
    mv "$TEMP_DIR/go" "$GO_HOME" || fail "Could not install Go under $GO_HOME."
fi

export PATH="$GO_HOME/bin:$TEMP_DIR/bin:$PATH"
export GOBIN="$TEMP_DIR/bin"

info 'Installing xcaddy and building Caddy with the Coraza module.'
mkdir -p "$GOBIN" || fail 'Could not create the temporary Go binary directory.'
go install github.com/caddyserver/xcaddy/cmd/xcaddy@latest || fail 'Could not install xcaddy.'
(
    cd "$TEMP_DIR" || exit 1
    "$GOBIN/xcaddy" build --with github.com/corazawaf/coraza-caddy/v2
) || fail 'Caddy build failed.'

if [ ! -x "$TEMP_DIR/caddy" ]; then
    fail 'xcaddy completed without producing the expected caddy binary.'
fi

info 'Preparing Coraza configuration and CRS rules.'
mkdir -p /etc/coraza || fail 'Could not create the Coraza configuration directory.'

if path_exists "$CORAZA_CONFIG"; then
    info "Preserving existing $CORAZA_CONFIG."
else
    curl -fL --connect-timeout 10 --max-time 60 \
        https://raw.githubusercontent.com/corazawaf/coraza/v2/master/coraza.conf-recommended \
        -o "$TEMP_DIR/coraza.conf" || fail 'Could not download the recommended Coraza configuration.'
    (set -C; cat "$TEMP_DIR/coraza.conf" > "$CORAZA_CONFIG") ||
        fail "Could not create $CORAZA_CONFIG without replacing an existing file."
    chmod 0644 "$CORAZA_CONFIG" || fail 'Could not set Coraza configuration permissions.'
    warn 'The downloaded Coraza configuration uses DetectionOnly mode; requests are logged rather than blocked.'
fi

if path_exists "$CRS_DIR"; then
    info "Preserving existing $CRS_DIR."
else
    git clone https://github.com/coreruleset/coreruleset "$TEMP_DIR/crs" ||
        fail 'Could not download the Core Rule Set.'
    # Refuse to merge into a directory created while the download was running.
    mkdir "$CRS_DIR" || fail "Could not create $CRS_DIR; existing rules will not be replaced."
    cp -R "$TEMP_DIR/crs/." "$CRS_DIR/" || fail 'Could not install the downloaded CRS files.'
fi

if ! path_exists "$CRS_DIR/crs-setup.conf"; then
    if [ ! -s "$CRS_DIR/crs-setup.conf.example" ]; then
        fail "Missing $CRS_DIR/crs-setup.conf.example; existing CRS files were preserved."
    fi
    (set -C; cat "$CRS_DIR/crs-setup.conf.example" > "$CRS_DIR/crs-setup.conf") ||
        fail 'Could not create the CRS setup configuration without replacing an existing file.'
fi

if [ ! -s "$CORAZA_CONFIG" ] || [ ! -s "$CRS_DIR/crs-setup.conf" ] ||
    [ ! -d "$CRS_RULES_DIR" ]; then
    fail 'Coraza configuration or CRS rules are missing or incomplete; review the preserved files.'
fi

info 'Creating the Caddy service account when it is missing.'
if ! getent group caddy >/dev/null 2>&1; then
    groupadd --system caddy || fail 'Could not create the caddy group.'
fi

if ! id caddy >/dev/null 2>&1; then
    useradd --system \
        --gid caddy \
        --create-home \
        --home-dir /var/lib/caddy \
        --shell /usr/sbin/nologin \
        --comment 'Caddy web server' \
        caddy || fail 'Could not create the caddy user.'
fi

if ! getent group caddy >/dev/null 2>&1 || ! id caddy >/dev/null 2>&1; then
    fail 'The caddy user and group must both exist.'
fi

info 'Preparing the generated Caddyfile and systemd unit.'
mkdir -p /etc/caddy "$LOG_DIR" || fail 'Could not create Caddy or Coraza log directories.'

STAGED_CADDYFILE="$TEMP_DIR/Caddyfile"
{
    cat <<EOF
{
    order coraza_waf first
    admin off
    auto_https off
    servers {
        protocols h1 h2
    }
}

(waf) {
    log {
        output file /var/log/coraza/access-{args[0]}.log
        format json
    }

    coraza_waf {
        directives \`
            Include ${CORAZA_CONFIG}
            Include ${CRS_DIR}/crs-setup.conf
            Include ${CRS_RULES_DIR}/*.conf
        \`
    }
}
EOF

    listener_port=8081
    for backend_ip do
        log_name=$(printf '%s' "$backend_ip" | tr '.' '_')
        printf '\nhttp://:%s {\n' "$listener_port"
        printf '    import waf %s\n' "$log_name"
        printf '    reverse_proxy %s:80\n' "$backend_ip"
        printf '}\n'
        listener_port=$((listener_port + 1))
    done
} > "$STAGED_CADDYFILE" || fail 'Could not write the staged Caddyfile.'

STAGED_SERVICE="$TEMP_DIR/caddy.service"
cat > "$STAGED_SERVICE" <<'EOF'
[Unit]
Description=Caddy
Documentation=https://caddyserver.com/docs/
After=network.target network-online.target
Requires=network-online.target

[Service]
Type=notify
User=caddy
Group=caddy
ExecStart=/usr/bin/caddy run --environ --config /etc/caddy/Caddyfile
ExecReload=/usr/bin/caddy reload --config /etc/caddy/Caddyfile --force
TimeoutStopSec=5s
LimitNOFILE=1048576
PrivateTmp=true
ProtectSystem=full
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE

[Install]
WantedBy=multi-user.target
EOF

info 'Validating the generated Caddyfile.'
"$TEMP_DIR/caddy" validate --config "$STAGED_CADDYFILE" || fail 'Caddy rejected the generated configuration.'

info 'Installing the Caddy binary, configuration, logs, and service unit.'
install -m 0755 "$TEMP_DIR/caddy" "$CADDY_BINARY" || fail 'Could not install the Caddy binary.'
install -m 0644 "$STAGED_CADDYFILE" "$CADDYFILE" || fail 'Could not install the Caddyfile.'
install -m 0644 "$STAGED_SERVICE" "$SERVICE_FILE" || fail 'Could not install the systemd service unit.'

for backend_ip do
    log_name=$(printf '%s' "$backend_ip" | tr '.' '_')
    log_file="$LOG_DIR/access-${log_name}.log"
    if ! path_exists "$log_file"; then
        (umask 077; : > "$log_file") || fail "Could not create $log_file."
    fi
    chown caddy:caddy "$log_file" || fail "Could not set ownership on $log_file."
done

chown caddy:caddy "$LOG_DIR" || fail "Could not set ownership on $LOG_DIR."

info 'Enabling and restarting the Caddy service.'
systemctl daemon-reload || fail 'systemd could not reload service definitions.'
systemctl enable caddy || fail 'Could not enable the Caddy service.'
systemctl restart caddy || fail 'Could not restart the Caddy service.'

info 'Caddy with Coraza is ready.'
exit 0
