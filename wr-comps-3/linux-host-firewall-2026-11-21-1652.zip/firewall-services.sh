#!/bin/sh

# Back up competing firewall state, disable those managers, and enable iptables.

WARNINGS=
RUN_DIR=
LOG_FILE=

log_info()
{
    printf 'INFO: %s\n' "$*"
    [ -z "$LOG_FILE" ] || printf 'INFO: %s\n' "$*" >> "$LOG_FILE"
}

log_warning()
{
    printf 'WARNING: %s\n' "$*"
    [ -z "$LOG_FILE" ] || printf 'WARNING: %s\n' "$*" >> "$LOG_FILE"
    WARNINGS="${WARNINGS}${WARNINGS:+
}WARNING: $*"
}

finish()
{
    result=$1
    printf 'SUMMARY: completed with status %s\n' "$result"
    [ -z "$LOG_FILE" ] || printf 'SUMMARY: completed with status %s\n' "$result" >> "$LOG_FILE"
    if [ -n "$WARNINGS" ]; then
        printf '%s\n' "$WARNINGS"
        [ -z "$LOG_FILE" ] || printf '%s\n' "$WARNINGS" >> "$LOG_FILE"
    fi
    exit "$result"
}

fail()
{
    printf 'ERROR: %s\n' "$*" >&2
    [ -z "$LOG_FILE" ] || printf 'ERROR: %s\n' "$*" >> "$LOG_FILE"
    finish 1
}

if [ "$(id -u 2>/dev/null)" != 0 ]; then
    printf 'ERROR: sudo is required.\n' >&2
    exit 1
fi

SCRIPT_DIR=$(CDPATH= cd "$(dirname "$0")" 2>/dev/null && pwd) || {
    printf 'ERROR: cannot determine the script directory.\n' >&2
    exit 1
}
RUNS_DIR=$SCRIPT_DIR/runs
if [ ! -d "$RUNS_DIR" ] && ! mkdir "$RUNS_DIR" 2>/dev/null; then
    printf 'ERROR: cannot create runs directory.\n' >&2
    exit 1
fi

run_number=1
while :; do
    RUN_DIR=$RUNS_DIR/$run_number
    if mkdir "$RUN_DIR" 2>/dev/null; then
        break
    fi
    if [ -e "$RUN_DIR" ]; then
        run_number=$((run_number + 1))
    else
        printf 'ERROR: cannot create run directory %s.\n' "$RUN_DIR" >&2
        exit 1
    fi
done
LOG_FILE=$RUN_DIR/console.log
: > "$LOG_FILE" || {
    printf 'ERROR: cannot create console log.\n' >&2
    exit 1
}
log_info "Run output: $RUN_DIR"

copy_if_present()
{
    source_path=$1
    destination=$2
    if [ -e "$source_path" ]; then
        cp -R "$source_path" "$destination" 2>/dev/null || return 1
    fi
    return 0
}

systemd_has_unit()
{
    command -v systemctl >/dev/null 2>&1 || return 1
    systemctl list-unit-files 2>/dev/null |
        awk -v wanted="$1" '$1 == wanted { found=1 } END { exit !found }'
}

stop_disable_service()
{
    unit=$1
    service_name=$2

    if systemd_has_unit "$unit.service"; then
        if systemctl is-active --quiet "$unit.service" 2>/dev/null; then
            systemctl stop "$unit.service" || return 1
        fi
        systemctl disable "$unit.service" >/dev/null 2>&1 || return 1
        return 0
    fi

    if command -v rc-service >/dev/null 2>&1 && [ -x "/etc/init.d/$service_name" ]; then
        rc-service "$service_name" stop >/dev/null 2>&1 || return 1
        rc-update del "$service_name" default >/dev/null 2>&1 || return 1
        return 0
    fi

    if command -v service >/dev/null 2>&1 && [ -x "/etc/init.d/$service_name" ]; then
        service "$service_name" stop >/dev/null 2>&1 || return 1
        if command -v chkconfig >/dev/null 2>&1; then
            chkconfig "$service_name" off >/dev/null 2>&1 || return 1
        elif command -v update-rc.d >/dev/null 2>&1; then
            update-rc.d "$service_name" disable >/dev/null 2>&1 || return 1
        else
            return 1
        fi
        return 0
    fi
    return 2
}

disable_competitor()
{
    service_name=$1
    if stop_disable_service "$service_name" "$service_name"; then
        log_info "Stopped and disabled $service_name."
    else
        service_status=$?
        if [ "$service_status" -eq 2 ]; then
            log_warning "No manageable $service_name service was found; its live rules will be cleared where possible."
        else
            fail "could not stop and disable $service_name."
        fi
    fi
}

# Save current iptables state before changing any firewall manager.
command -v iptables-save >/dev/null 2>&1 || fail 'iptables-save is missing; install the iptables package.'
iptables-save > "$RUN_DIR/iptables.bak" 2>/dev/null || fail 'could not back up current IPv4 iptables rules.'
if command -v ip6tables-save >/dev/null 2>&1; then
    ip6tables-save > "$RUN_DIR/ip6tables.bak" 2>/dev/null || fail 'could not back up current IPv6 iptables rules.'
fi
mkdir "$RUN_DIR/iptables-config" || fail 'cannot create iptables config backup directory.'
copy_if_present /etc/iptables "$RUN_DIR/iptables-config/" || fail 'could not back up /etc/iptables.'
copy_if_present /etc/sysconfig/iptables "$RUN_DIR/iptables-config/" || fail 'could not back up /etc/sysconfig/iptables.'
copy_if_present /etc/sysconfig/ip6tables "$RUN_DIR/iptables-config/" || fail 'could not back up /etc/sysconfig/ip6tables.'

HAVE_NFT=no
HAVE_UFW=no
HAVE_FIREWALLD=no
if command -v nft >/dev/null 2>&1; then
    HAVE_NFT=yes
    nft list ruleset > "$RUN_DIR/nftables.bak" 2>/dev/null || fail 'could not back up live nftables rules.'
    mkdir "$RUN_DIR/nftables-config" || fail 'cannot create nftables config backup directory.'
    copy_if_present /etc/nftables.conf "$RUN_DIR/nftables-config/" || fail 'could not back up /etc/nftables.conf.'
    copy_if_present /etc/nftables "$RUN_DIR/nftables-config/" || fail 'could not back up /etc/nftables.'
fi

if command -v ufw >/dev/null 2>&1; then
    HAVE_UFW=yes
    ufw status verbose > "$RUN_DIR/ufw.bak" 2>/dev/null || fail 'could not back up live ufw status.'
    mkdir "$RUN_DIR/ufw-config" || fail 'cannot create ufw config backup directory.'
    copy_if_present /etc/ufw "$RUN_DIR/ufw-config/" || fail 'could not back up /etc/ufw.'
fi

if command -v firewall-cmd >/dev/null 2>&1; then
    HAVE_FIREWALLD=yes
    if firewall-cmd --state > "$RUN_DIR/firewalld.bak" 2>/dev/null; then
        firewall-cmd --list-all-zones >> "$RUN_DIR/firewalld.bak" 2>/dev/null || fail 'could not back up live firewalld zones.'
    else
        : > "$RUN_DIR/firewalld.bak"
    fi
    mkdir "$RUN_DIR/firewalld-config" || fail 'cannot create firewalld config backup directory.'
    copy_if_present /etc/firewalld "$RUN_DIR/firewalld-config/" || fail 'could not back up /etc/firewalld.'
fi

# Take every backup above before stopping any manager or changing live rules.
if [ "$HAVE_NFT" = yes ]; then
    disable_competitor nftables
    nft flush ruleset || fail 'could not clear the nftables ruleset.'
fi

if [ "$HAVE_UFW" = yes ]; then
    ufw disable >/dev/null 2>&1 || fail 'could not disable ufw.'
fi

if [ "$HAVE_FIREWALLD" = yes ]; then
    stop_disable_service firewalld firewalld
    service_status=$?
    if [ "$service_status" -ne 0 ]; then
        if [ "$service_status" -eq 2 ] && ! firewall-cmd --state >/dev/null 2>&1; then
            log_warning 'No manageable firewalld service was found; firewalld is not active.'
        else
            fail 'could not stop and disable firewalld.'
        fi
    fi
fi

start_systemd_unit()
{
    systemctl enable "$1" >/dev/null 2>&1 || return 1
    systemctl start "$1" || return 1
    log_info "Enabled and started $1."
    return 0
}

start_openrc_service()
{
    service_name=$1
    rc-update add "$service_name" default >/dev/null 2>&1 || return 1
    rc-service "$service_name" start || return 1
    log_info "Enabled and started $service_name."
    return 0
}

start_sysv_service()
{
    service_name=$1
    if command -v chkconfig >/dev/null 2>&1; then
        chkconfig "$service_name" on >/dev/null 2>&1 || return 1
    elif command -v update-rc.d >/dev/null 2>&1; then
        update-rc.d "$service_name" defaults >/dev/null 2>&1 || return 1
    else
        return 1
    fi
    service "$service_name" start || return 1
    log_info "Enabled and started $service_name."
    return 0
}

OS_ID=
if [ -r /etc/os-release ]; then
    OS_ID=$(awk -F= '$1 == "ID" { gsub(/"/, "", $2); gsub(/\047/, "", $2); print $2; exit }' /etc/os-release)
fi
IPTABLES_STARTED=no
IPTABLES_V4_STARTED=no

if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then
    case $OS_ID in
        debian|ubuntu|linuxmint|pop)
            if systemd_has_unit netfilter-persistent.service; then
                start_systemd_unit netfilter-persistent.service || fail 'could not enable and start netfilter-persistent.'
                IPTABLES_STARTED=yes
                IPTABLES_V4_STARTED=yes
            fi
            ;;
    esac
    if [ "$IPTABLES_STARTED" = no ]; then
        for unit in iptables.service ip6tables.service; do
            if systemd_has_unit "$unit"; then
                start_systemd_unit "$unit" || fail "could not enable and start $unit."
                IPTABLES_STARTED=yes
                if [ "$unit" = iptables.service ]; then
                    IPTABLES_V4_STARTED=yes
                fi
            fi
        done
    fi
    if [ "$IPTABLES_V4_STARTED" = no ]; then
        fail 'no iptables persistence service is installed; install netfilter-persistent on Debian/Ubuntu or iptables-services on RHEL-family systems.'
    fi
elif command -v rc-service >/dev/null 2>&1 && command -v rc-update >/dev/null 2>&1; then
    if [ -x /etc/init.d/iptables ]; then
        start_openrc_service iptables || fail 'could not enable and start the OpenRC iptables service.'
        IPTABLES_STARTED=yes
        IPTABLES_V4_STARTED=yes
    fi
    if [ -x /etc/init.d/ip6tables ]; then
        start_openrc_service ip6tables || fail 'could not enable and start the OpenRC ip6tables service.'
        IPTABLES_STARTED=yes
    fi
    [ "$IPTABLES_V4_STARTED" = yes ] || fail 'no OpenRC IPv4 iptables service is installed; install the distribution iptables init scripts.'
elif command -v service >/dev/null 2>&1; then
    for service_name in iptables ip6tables; do
        if [ -x "/etc/init.d/$service_name" ]; then
            start_sysv_service "$service_name" || fail "could not enable and start the $service_name service."
            IPTABLES_STARTED=yes
            if [ "$service_name" = iptables ]; then
                IPTABLES_V4_STARTED=yes
            fi
        fi
    done
    [ "$IPTABLES_V4_STARTED" = yes ] || fail 'no SysV IPv4 iptables service is installed; install the distribution iptables service package.'
else
    fail 'no supported service manager was found for iptables.'
fi

log_info 'Firewall service preparation completed.'
finish 0
