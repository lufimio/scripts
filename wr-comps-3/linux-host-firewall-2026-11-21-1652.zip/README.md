# Linux Host Firewall Automation

`firewall-services.sh` backs up current firewall state, disables competing firewall managers, and enables and starts an available iptables persistence service. `firewall-config.sh` checks listening services against the ports you expect, then writes a separate script to apply inbound firewall rules.

## Usage

Run the service preparation script first, then run the config script as root:

```sh
sudo sh ./firewall-services.sh
sudo sh ./firewall-config.sh 80,tcp,apache 53,udp,dns
```

`firewall-services.sh` takes no arguments. It backs up firewall state, disables competing firewall managers, and starts an available iptables persistence service. If the persistence system doesn't exist, it'll tell you to install one.

For `firewall-config.sh`, each argument is `port,protocol,service`. Protocol must be `tcp` or `udp`. The service descriptor is matched case-insensitively as a literal substring of process details, so matching is best-effort.

The config script checks listeners with `ss`, falling back to `netstat`. It ignores loopback listeners and considers non-loopback host addresses and wildcard listeners. IPv6 inbound rules are allowed only when an interface has a non-link-local IPv6 address; otherwise, IPv6 inbound traffic is denied.

## Logging

This script configures logging on new connections, allowed and blocked. Network connections similar to scans are not logged. Specific search strings:
- `INPUT[4|6]` for inbound connections for ipv4/ipv6
- `OUTPUT[4|6]` for outbound connections for ipv4/ipv6
- `IPT` for all iptables log output (ipv4 and ipv6)

## Review and apply

Each script creates a new numbered folder under `runs/` beside the scripts. The service script stores backups there, including current iptables rules and detected nftables, ufw, and firewalld state. The config script stores its log and generated `rules.sh` in its own run folder.

Review the generated script, then apply it as root using the path printed by the config script. For example:

```sh
sudo sh ./runs/1/rules.sh
```

The run number will vary. The generated script allows loopback, established or related traffic, and the matched TCP or UDP ports; it drops other inbound traffic and allows outbound traffic.

## Potential Errors

If a shell reports `not found` or syntax errors at the start of a script, it may have Windows CRLF line endings. Install `dos2unix` and run `dos2unix [file]`.
