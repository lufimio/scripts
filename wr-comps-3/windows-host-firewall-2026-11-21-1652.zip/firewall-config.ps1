# Generate Windows Firewall rules from declared ports without checking listeners or applying them.
# Run elevated: .\firewall-config.ps1 '22,tcp,ssh' '53,udp,dns'

$ErrorActionPreference = 'Stop'
$LogFile = $null
$Warnings = [System.Collections.Generic.List[string]]::new()
$Status = 1

function Write-Log {
    param([string]$Level, [string]$Message)
    $line = "${Level}: $Message"
    Write-Host $line
    if ($LogFile) {
        Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
    }
    if ($Level -eq 'WARNING') {
        $Warnings.Add($line)
    }
}

function Write-NewFile {
    param([string]$Path, [string]$Content)
    # CreateNew refuses to overwrite a file, including a previous run's data.
    $stream = [System.IO.File]::Open($Path, 'CreateNew', 'Write', 'None')
    $writer = [System.IO.StreamWriter]::new($stream, [System.Text.UTF8Encoding]::new($true))
    try {
        $writer.Write($Content)
    } finally {
        $writer.Dispose()
    }
}

# Shared by the generated apply and restore scripts; neither needs this generator.
$ScriptHeader = @'
$ErrorActionPreference = 'Stop'
$LogFile = Join-Path $PSScriptRoot 'console.log'
$Status = 1
function Write-Log {
    param([string]$Level, [string]$Message)
    $line = "${Level}: $Message"
    Write-Host $line
    Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
}
try {
    $principal = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Run this script as Administrator.'
    }
'@
$ScriptFooter = @'
    $Status = 0
} catch {
    Write-Log ERROR $_.Exception.Message
} finally {
    Write-Log SUMMARY "completed with status $Status"
}
exit $Status
'@

try {
    $principal = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Run this script as Administrator.'
    }

    $runsDirectory = Join-Path $PSScriptRoot 'runs'
    [void][System.IO.Directory]::CreateDirectory($runsDirectory)
    $runNumber = 1
    while ($true) {
        $runDirectory = Join-Path $runsDirectory ([string]$runNumber)
        try {
            New-Item -Path $runDirectory -ItemType Directory -ErrorAction Stop | Out-Null
            break
        } catch {
            if (-not (Test-Path -LiteralPath $runDirectory)) { throw }
            $runNumber++
        }
    }
    $consolePath = Join-Path $runDirectory 'console.log'
    Write-NewFile $consolePath ''
    $LogFile = $consolePath
    Write-Log INFO "Run output: $runDirectory"

    # Back up before argument validation can fail.
    $backupPath = Join-Path $runDirectory 'firewall-backup.wfw'
    Write-Log INFO 'Backing up the current Windows Firewall policy.'
    $backupOutput = & netsh.exe advfirewall export $backupPath 2>&1
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $backupPath) -or
        (Get-Item -LiteralPath $backupPath).Length -eq 0) {
        throw "Firewall backup failed: $($backupOutput -join ' ')"
    }
    $restoreBody = @'
    $backupPath = Join-Path $PSScriptRoot 'firewall-backup.wfw'
    if (-not (Test-Path -LiteralPath $backupPath)) { throw 'Firewall backup is missing.' }
    Write-Log INFO 'Restoring the saved Windows Firewall policy.'
    $output = & netsh.exe advfirewall import $backupPath 2>&1
    if ($LASTEXITCODE -ne 0) { throw "Firewall restore failed: $($output -join ' ')" }
    Write-Log INFO 'Saved firewall policy restored.'
'@
    Write-NewFile (Join-Path $runDirectory 'restore.ps1') ($ScriptHeader + "`r`n" + $restoreBody + "`r`n" + $ScriptFooter)

    if ($args.Count -eq 0) { throw 'Provide one or more port,protocol,service arguments.' }
    $declarations = [System.Collections.Generic.List[object]]::new()
    $seenDeclarations = @{}
    foreach ($argument in $args) {
        # PowerShell may pass an unquoted comma expression as an array.
        $text = @($argument) -join ','
        $parts = $text.Split(',')
        $port = 0
        if ($parts.Count -ne 3 -or -not [int]::TryParse($parts[0], [ref]$port) -or
            $port -lt 1 -or $port -gt 65535) {
            throw "Invalid argument '$text'; expected port,protocol,service with port 1-65535."
        }
        $protocol = $parts[1].Trim().ToLowerInvariant()
        $service = $parts[2].Trim().ToLowerInvariant()
        if ($protocol -notin @('tcp', 'udp')) { throw "Invalid protocol in '$text'; use tcp or udp." }
        if (-not $service) { throw "Service cannot be empty in '$text'." }
        $key = "$protocol|$service|$port"
        if ($seenDeclarations.ContainsKey($key)) { throw "Duplicate declaration '$text'." }
        $seenDeclarations[$key] = $true
        $declarations.Add([pscustomobject]@{ Protocol = $protocol; Service = $service; Port = $port })
    }

    # Trust the operator's declared ports; Windows may report shared or kernel owners.
    $allowed = @{}
    foreach ($declaration in $declarations) {
        $allowed["$($declaration.Protocol)|$($declaration.Port)"] = $declaration
    }

    $applyBody = @'
    if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'firewall-backup.wfw'))) {
        throw 'Firewall backup is missing.'
    }
    # Centrally managed rules cannot be removed from the local policy store.
    $managedRules = @(Get-NetFirewallRule -PolicyStore ActiveStore -TracePolicyStore | Where-Object {
        $_.Enabled -eq 'True' -and $_.PolicyStoreSourceType -eq 'GroupPolicy'
    })
    if ($managedRules.Count -gt 0) { throw 'Group Policy firewall rules prevent replacement of the local allowlist.' }

    Write-Log INFO 'Resetting local firewall policy and replacing rules across all profiles.'
    $output = & netsh.exe advfirewall reset 2>&1
    if ($LASTEXITCODE -ne 0) { throw "Firewall reset failed: $($output -join ' ')" }
    # Block unsolicited inbound traffic while replacing the default rules.
    Set-NetFirewallProfile -All -PolicyStore PersistentStore -Enabled True -DefaultInboundAction Block -DefaultOutboundAction Allow -AllowInboundRules False
    Remove-NetFirewallRule -All -PolicyStore PersistentStore
'@
    $ruleLines = foreach ($rule in ($allowed.Values | Sort-Object Protocol, Port)) {
        "    New-NetFirewallRule -DisplayName 'Allow $($rule.Protocol) $($rule.Port)' -PolicyStore PersistentStore -Profile Any -Enabled True -Direction Inbound -Action Allow -Protocol $($rule.Protocol) -LocalPort $($rule.Port) | Out-Null"
    }
    $applyEnd = @'
    Set-NetFirewallProfile -All -PolicyStore PersistentStore -AllowInboundRules True -AllowLocalFirewallRules True
    $profiles = @(Get-NetFirewallProfile -PolicyStore ActiveStore)
    if ($profiles.Count -ne 3 -or @($profiles | Where-Object {
        $_.Enabled -ne 'True' -or $_.DefaultInboundAction -ne 'Block' -or
        $_.DefaultOutboundAction -ne 'Allow' -or $_.AllowInboundRules -eq 'False' -or
        $_.AllowLocalFirewallRules -eq 'False' -or $_.DisabledInterfaceAliases.Count -gt 0
    }).Count -gt 0) {
        throw 'Effective firewall profiles do not match the requested policy. Check Group Policy; restore.ps1 can restore the backup.'
    }
    Write-Log INFO 'Firewall rules applied to all profiles.'
'@
    $rulesContent = @($ScriptHeader, $applyBody, ($ruleLines -join "`r`n"), $applyEnd, $ScriptFooter) -join "`r`n"
    $rulesPath = Join-Path $runDirectory 'rules.ps1'
    Write-NewFile $rulesPath $rulesContent
    Write-Log INFO "Generated firewall script: $rulesPath"
    Write-Log INFO 'Run rules.ps1 as Administrator to apply; run restore.ps1 to restore the saved policy.'
    $Status = 0
} catch {
    Write-Log ERROR $_.Exception.Message
} finally {
    Write-Log SUMMARY "completed with status $Status"
    foreach ($warning in $Warnings) {
        Write-Host $warning
        if ($LogFile) { Add-Content -LiteralPath $LogFile -Value $warning -Encoding UTF8 }
    }
}
exit $Status
