# AGENTS.md

Read this file fully first before `SPEC.md`. This file is how to behave; `SPEC.md` is what to build. For this project, DO NOT access or edit another other files besides the ones in this directory and its subdirectories. Make minor design decision to conform with overall goal of project. Pause developement and ask for any major changes.

## Project
A bash script for automatically configuring host based firwall rules through iptables. Priorities: correctness, speed, readability.

## Scope
- Build only what `SPEC.md` lists. No tests, mocks, sample inputs, CI, Docker, packaging, linter config. No extra flags, keys or outputs; mention ideas in the final message instead.
- Stop and ask (question in the final message) when the spec is ambiguous, a required fixture is missing, or exact vendor syntax is uncertain. Never invent vendor syntax.
- 1st priority is readability and second priority is length.

## Data safety
- Never delete or overwrite collected data.

## Console
`logging`: INFO progress, WARNING for operator attention (prefix `WARNING:`), ERROR for fatal. Plain text, no emoji or colors. End each run with a summary repeating every WARNING.

## Final message
List: files created; deviations from `SPEC.md` and why; questions you stopped on; VERIFY items you could not confirm.
