# SPEC.md

Read AGENTS.md fully first before this file (convention and scope). `firewall-config.psh` should be a single shell file with not dependent files.

## Purpose

Operator refers to the user running the script. It will be run on a linux virtual machine in a red vs blue team cybersecurity competition. The operator will provide arguments to the script detailing the assumed port(s) and protocol(s) in use by known services on the device. The script must parse these arguments and attempt to match them to the actual listening ports. It will identify which ports have exist or don't exist (see below for more specific steps). It will then use this to create stateful iptables rules allowing inbound requests to these ports and blocking all others in a seperate shell file (allow all outbound requests). Make minor design decisions as needed and ask on major changes. If there is an ambigous port matching rule (see below), ask.

## Script arguments

The execution of the script will look like this ```./firewall-config.psh 80,tcp,ssh 53,udp,dns```. The arguments are formatted `port,protocol,service`. The service nam will be the general descriptor. For example, even though SSH may be running on the sshd daemon or ftp as vsftpd (an example from Linux but same general concept applies), the script should be able to match based on the general descriptor (use airtight, simple patternmatching - do not compare against a list of known services).

## Details

Script is required to run as sudo. Throw an error if not.

Only ports being listened to on the machine's private address will be considered (host ip, 0.0.0.0, or "::"). Ignore all ports listening on localhost addresses. At the start of the script, backup the existing configuration seperately (see output). The goal is to have, after running `rules.psh` that the firewall rules are implemented.. 

For port matching (assuming that the address stipulation above holds):
1. If the port and service given matches the actual ports and services, pass it.
2. In the case that there is ONE port for a service given and ONE port exists for that service, but is on a different port, assume the port moved and give a warning error.
    - In the case that all but one port matches (2 out of 3 ports/proto/service match), assume the port moved and give a warning error. 
        - If more than 1 port doesn't match, throw an error.
3. If there are more ports for a given service then are given (and the given matches), give a warning that these additional ports exist but do not use them.
4. If there are less ports for a given service then are given, throw an error.
5. In any other case, throw an error.

Informational and warning errors do not cause the script to fail. "Error" errors do.

Keep the outputted iptables as simple as possible while meeting the previous requirements. A person with a basic understanding of iptables should be able to understand.

## Command heirarchy

The script will use `netstat -ano` and coorelate to `tasklist /svc`.

## Output

1. All outputs will be put in a `runs/` folder with subfolders from each run of the script `1, 2, 3, etc.` as they exist in that `runs/` folder.
2. The script will output the firewall rules as another powershell file (`rules.psh`). The script will output the console log to another file.
3. The backed up rules will be in powershell re-implementable format. 

## Other
- Read `firewall-config.sh` for the linux implementation of this. This script is for Windows Firewall.