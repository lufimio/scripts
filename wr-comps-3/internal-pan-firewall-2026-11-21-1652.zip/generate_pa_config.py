#!/usr/bin/env python3
"""Apply the reference security profiles to a PAN-OS XML configuration."""

import argparse
import base64
import copy
import logging
import sys
import xml.etree.ElementTree as ET
import zlib
from datetime import datetime
from pathlib import Path

try:
    import yaml
except ImportError:
    yaml = None


ZONE_PROFILE_NAME = "wan-to-lan-zone"
VULNERABILITY_PROFILES = {
    "internal-to-external": "lan-to-wan-vuln",
    "external-to-internal": "wan_to_lan_vuln",
}
SECURITY_PROFILES = {
    "virus": "custom-av-policy",
    "spyware": "custom-spyware-policy",
    "url-filtering": "custom-url-filtering",
}

# Compressed XML subtrees copied exactly from the supplied reference config.
# This keeps the script usable when reference_config.xml is not beside it.
EMBEDDED_REFERENCE_XML = (
    'eNrtHF1v4zbsvb/C6LvgtncohoOXl9uGDbhhN/SGPR4UWYm1ypInyUmzXz/KH0mcSLbTtE3iukDRRiIpkqIoklIUESlmbD6J'
    'YrpghOpJRIVRq0kkqFlK9TiJMiVnjNue/6SgCD4aSgyTAlU9FUogcEp/vF5igYxEHP5Y+OvJVdD4iWZcyni3FdoNyZBeif0e'
    '6FM0drVDD+ZYpUhhQye3N/AThVstHhTgfgHdTaxGoxsxxU8sxbwE+VjiNdpcrIce3kFpeArKEzIKq3/3dRJ6lRLlcTaqahvZ'
    'qZCIkXTUUwPZrZFCUYv7UVW7qnLpJJImoQqx0bIayD6tRKHT59stBjGhs3I7cVBUOadBuE+uHTHSBLuobe9SP9zc3F47JcUe'
    'ZqoJpMrsc1Ry5ceMmDBULTCf3IFR1f+7AE2iqE4kj+1Ug/tff3Sou9yoO+W8O4WctzdvL+iHQU5oFLrMOYoZNKsYVhvSmZSz'
    'yYrqKNxrbUGbKTwvFvRu295yMooRY7tJQsljOdJuo28gcDczqVIaI5kV2mzwudfrI1MNp2WuCLg9mRsm5k1abhAfQXBImrbS'
    'c0L4yMkFVRxnGcCgImaj8xSmE6VMp9iQpEm6E/rKZRhR6A3Aw02QHq4D94VebcL5DcAi54IqPGWcmdVe7P7dyO8Qu3+3UNce'
    'l6w9W8SGEBg5NQFRzAQJmyfXLZubb2lC95RL8ujZZWv957CXWRr3sLjWH/zwRmEgOV1NynmFBVk3+JgI27lo8xLQu6AilrAn'
    'xl76KU2nVE2wWMH+XP7vGaiDVqQpmJWd046h7LQwgnnXeO30IrKgLyCUl0rhObFB1qBKQtsNbpREajPR4IypisLig4d1iH/m'
    'EpZFQXf9yQ2cgYFAvEFwZnJFJxoWLYdVWLTCwmv2OvcRz/61s2YKOztmuRSLDhHOgKp7S7tIc7UaGU31rEx1iZUIUhbrZ1pq'
    'S9R1kSYKAQzL09FIn2Ok9MnALEAEWDW8pJ3GdIZzbgIul8+01JrCcGwVdDEa6ll509rGmLC5UBHBYj7aa0W+oZWBWm4B+0pm'
    'CzmnrdcdZbBQF3SnfVEKiQSiYs4gMW0klqgsE8ad1v/w55fgN/FPmdH6rJ4JbkfIJGdkhSobLqIIW35x9B2xHD/LNMUiPjFT'
    'YISHqnZdJ9iWhpfHcfZU7riUXrM0A/dXpheoziGPSlWmUDAekKcaeF5dzvzlba9Nwz06vx6Y0Q44ux6GwZa55ZhoDz/RfmV7'
    'fc1EuzLZMgMbg4Ox6H5hvrYy3DE4GEvvF2WwY3AwVuHPLzgYy0UXVS4Kd26ELJjKdbOKRHJtZIrwomLRVUaKKZGxe0k0aCXG'
    'ZB0eq6pid/igJePxjCmKdrF2OzwXJDmIs4u63XiEUVgZ74YupE5faSI3sdQ5iAk3Zgdvr5nMPgxdxtnw3Y5Op4MTEa71+TaW'
    'cqBqz7O3G6dYQwjTN5T4m0HcudTBz0+U5MbieO+zFAM1d+dylEquF4smvsolVQ8J5Tx4gJJBZoLbM+Tp7uQ8beYs+MLEI42D'
    'X4pT4pMz9vvDH7MZfJHu5IwUE/b2XFQE+i9KiBt1YVV2JMI0zKtNz4IpFSRJsXoMiISUl2FbGt2G9YezZfyqsxXcU6POQLbq'
    'a4lmDzsUPXHB842LkM/IYc+5lnLKqt8bVuIGNmtHlb7ebN5epCY1sJk7/T23U9w9e+NJfIlrX+7pO9Vl2re74HqBU+UvuYKT'
    's1+XjWWK4SuzTqKcaaM9vDouqoJn4BJzuFUWC1/G1GkMdkIhcIevQlKfPXRZxFGabDf70KuSCGRGdZCKqolmtI/6MriDV2Ej'
    'HBdfPANP61cgl3PEwVL5JoneNHVovVee/3oKbJGckPcmcdy6TIYp81zhIsN6b3LDF5rfo9gZ5Ok0fndSJ0wn79CFw3fJn1bv'
    'TWhFCXQNUmqoq/UPatZhm++YO1t8hPAmhhRbT6wCa3hUh48sgwPvbSgvofs1yKdPtwXSfRsSBPZe3uB7/B2BcONyQl0g7HuW'
    '8Ou3b1+D+iqA/f0soVfyIKb2sQapzuGqgmXy7uy5fHj4cvY8/iUehVwK9O3z14vh9a+fzpDX5r2VjlW3KfGva/u54vaQAR7g'
    'sa+zuEr9DQhXpR+eXYAnsSpJwPeVT7Xste4jEngsCwZkAEdtoYhQ+4iLU/wUDjA96q2ceOx7hMiHWmw460JGXWdsNF753lTx'
    'nQpV99umuT2xiVU+1x2VlBojLo94e4CS0gKR/SWlBfZDnON0CpMx7wld5R/9oJMyFe8HXIX4/YDrELEf9L851UWxsTyJ64Gh'
    'sNAy7c/PkuJMitZprV68ca3VvhZf2Ka9A4WSWKGn2axeUzutHYhghgrhuR1iH3+rs4OMojOqQNZ9GnWPm4A1TwgVYJgMxkFS'
    '8FXxXpav78p9w9btEOoDuVVmJMRdCk47W2+Vbh8EIcX0Yx/g0iv0Bhd0yVeglDkUv0AvcRUr9UGF+ihHhqU2yqtep/Kj2WcP'
    'nYrxe6dDfVNvz/RMv3SIVzrEJx3gkQ7wR4d4o0N90WGeqLcf8nihTQiws/Nvv4C2vghQPIC2/rh+4Tis3jz+H1ocLqI='
)


class ConfigurationError(Exception):
    """Raised when an input does not contain the structures we need."""


class WarningCollector(logging.Handler):
    def __init__(self):
        logging.Handler.__init__(self, logging.WARNING)
        self.messages = []
        self.collecting = True

    def emit(self, record):
        if self.collecting:
            self.messages.append(record.getMessage())


def create_run_directory(base_path):
    runs_path = base_path / "runs"
    runs_path.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    candidate = runs_path / timestamp
    suffix = 1
    while candidate.exists():
        candidate = runs_path / "{}_{}".format(timestamp, suffix)
        suffix += 1
    candidate.mkdir()
    return candidate


def configure_logging(run_directory):
    logger = logging.getLogger("generate_pa_config")
    logger.setLevel(logging.INFO)
    logger.propagate = False

    formatter = logging.Formatter("%(levelname)s: %(message)s")
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    file_handler = logging.FileHandler(run_directory / "run.log", encoding="utf-8")
    file_handler.setFormatter(formatter)
    warning_collector = WarningCollector()

    logger.handlers = []
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    logger.addHandler(warning_collector)
    return logger, warning_collector


def finish_run(logger, warning_collector, status):
    warning_collector.collecting = False
    logger.info("Run summary: {} warning(s).".format(len(warning_collector.messages)))
    for message in warning_collector.messages:
        logger.warning("%s", message)
    logger.info("Run {}.".format("completed" if status == 0 else "stopped with an error"))


def load_zone_types(yaml_path):
    if yaml is None:
        raise ConfigurationError(
            "PyYAML is required to read firewall.yaml; install the 'PyYAML' package."
        )

    try:
        with yaml_path.open("r", encoding="utf-8") as yaml_file:
            config = yaml.safe_load(yaml_file)
    except yaml.YAMLError as exc:
        raise ConfigurationError("Could not parse firewall YAML: {}".format(exc))

    if not isinstance(config, dict):
        raise ConfigurationError("firewall.yaml must contain a YAML mapping.")
    pan_firewall = config.get("pan_firewall")
    if not isinstance(pan_firewall, dict):
        raise ConfigurationError("firewall.yaml must contain a pan_firewall mapping.")
    interfaces = pan_firewall.get("interfaces")
    if not isinstance(interfaces, dict) or not interfaces:
        raise ConfigurationError("pan_firewall.interfaces must be a non-empty mapping.")

    zone_types = {}
    for interface_name, interface in interfaces.items():
        if not isinstance(interface, dict):
            raise ConfigurationError(
                "Interface {!r} must have a mapping of properties.".format(interface_name)
            )
        zone_name = interface.get("zone_name")
        generic_type = interface.get("generic_type")
        if not isinstance(zone_name, str) or not isinstance(generic_type, str):
            raise ConfigurationError(
                "Interface {!r} must define string zone_name and generic_type values."
                .format(interface_name)
            )

        normalized_type = generic_type.strip().lower()
        previous_type = zone_types.get(zone_name)
        if previous_type is not None and previous_type != normalized_type:
            raise ConfigurationError(
                "Zone {!r} maps to multiple generic_type values.".format(zone_name)
            )
        zone_types[zone_name] = normalized_type

    return zone_types


def find_entry(parent, name):
    if parent is None:
        return None
    for child in parent.findall("entry"):
        if child.get("name") == name:
            return child
    return None


def require_entry(parent, name, description):
    entry = find_entry(parent, name)
    if entry is None:
        raise ConfigurationError(
            "Reference XML is missing {} {!r}.".format(description, name)
        )
    return entry


def ensure_path(parent, path):
    current = parent
    for tag in path.split("/"):
        child = current.find(tag)
        if child is None:
            child = ET.SubElement(current, tag)
        current = child
    return current


def clone_with_parent_spacing(source, parent, old_entry=None):
    clone = copy.deepcopy(source)
    if old_entry is not None:
        clone.tail = old_entry.tail
    elif len(parent):
        clone.tail = parent[-1].tail
    else:
        clone.tail = parent.text
    return clone


def upsert_entry(parent, source):
    name = source.get("name")
    old_entry = find_entry(parent, name)
    clone = clone_with_parent_spacing(source, parent, old_entry)
    if old_entry is None:
        parent.append(clone)
    else:
        parent[parent.index(old_entry)] = clone


def profile_signature(element, is_root=True):
    attributes = element.attrib
    if is_root:
        attributes = {
            key: value for key, value in element.attrib.items() if key != "name"
        }
    return (
        element.tag,
        tuple(sorted(attributes.items())),
        (element.text or "").strip(),
        tuple(profile_signature(child, False) for child in list(element)),
    )


def profile_sources(reference_root):
    devices = reference_root.findall("./devices/entry")
    reference_device = devices[0] if devices else None
    device_profiles = (
        reference_device.find("./network/profiles") if reference_device is not None else None
    )
    zone_profiles = (
        device_profiles.find("zone-protection-profile")
        if device_profiles is not None
        else None
    )
    zone_entries = zone_profiles.findall("entry") if zone_profiles is not None else []

    # Prefer a profile already used by a zone, but do not depend on its name.
    assigned_names = []
    if reference_device is not None:
        for vsys in reference_device.findall("./vsys/entry"):
            for zone in vsys.findall("./zone/entry"):
                assigned_name = zone.findtext("./network/zone-protection-profile")
                if assigned_name and assigned_name not in assigned_names:
                    assigned_names.append(assigned_name)
    zone_profile = next(
        (find_entry(zone_profiles, name) for name in assigned_names
         if find_entry(zone_profiles, name) is not None),
        None,
    )
    if zone_profile is None and zone_entries:
        zone_profile = find_entry(zone_profiles, ZONE_PROFILE_NAME) or zone_entries[0]

    embedded_root = embedded_reference_root()
    if zone_profile is None:
        embedded_device = embedded_root.find("./devices/entry")
        embedded_zone_profiles = embedded_device.find(
            "./network/profiles/zone-protection-profile"
        )
        zone_profile = require_entry(
            embedded_zone_profiles, ZONE_PROFILE_NAME, "embedded zone protection profile"
        )

    reference_vsys = (
        reference_device.find("./vsys/entry") if reference_device is not None else None
    )
    reference_profiles = reference_vsys.find("profiles") if reference_vsys is not None else None
    if reference_profiles is None:
        embedded_device = embedded_root.find("./devices/entry")
        reference_profiles = embedded_device.find("./vsys/entry/profiles")

    zone_profile_name = zone_profile.get("name") or ZONE_PROFILE_NAME
    sources = {"zone-protection-profile": {zone_profile_name: zone_profile}}
    profile_names = dict(SECURITY_PROFILES)
    profile_names["vulnerability-internal-to-external"] = VULNERABILITY_PROFILES[
        "internal-to-external"
    ]
    profile_names["vulnerability-external-to-internal"] = VULNERABILITY_PROFILES[
        "external-to-internal"
    ]
    for profile_type, profile_name in profile_names.items():
        if profile_type.startswith("vulnerability-"):
            category = "vulnerability"
        else:
            category = profile_type
        container = reference_profiles.find(category)
        entry = find_entry(container, profile_name)
        if entry is None:
            embedded_device = embedded_root.find("./devices/entry")
            embedded_profiles = embedded_device.find("./vsys/entry/profiles")
            embedded_container = embedded_profiles.find(category)
            entry = require_entry(
                embedded_container,
                profile_name,
                "embedded {} profile".format(category),
            )
        sources.setdefault(category, {})[profile_name] = entry
    return sources


def copy_profiles_to_device(device, sources):
    target_profiles = ensure_path(device, "network/profiles")
    zone_container = ensure_path(target_profiles, "zone-protection-profile")
    source_zone_profile = next(iter(sources["zone-protection-profile"].values()))
    source_zone_name = source_zone_profile.get("name") or ZONE_PROFILE_NAME
    same_name = find_entry(zone_container, source_zone_name)
    if same_name is not None:
        upsert_entry(zone_container, source_zone_profile)
        zone_profile_name = source_zone_name
    else:
        source_signature = profile_signature(source_zone_profile)
        equivalent = next(
            (
                entry
                for entry in zone_container.findall("entry")
                if profile_signature(entry) == source_signature
            ),
            None,
        )
        if equivalent is not None:
            zone_profile_name = equivalent.get("name")
        else:
            upsert_entry(zone_container, source_zone_profile)
            zone_profile_name = source_zone_name

    for vsys in device.findall("./vsys/entry"):
        vsys_profiles = ensure_path(vsys, "profiles")
        for category in ("vulnerability", "virus", "spyware", "url-filtering"):
            target_container = ensure_path(vsys_profiles, category)
            for source in sources[category].values():
                upsert_entry(target_container, source)
    return zone_profile_name


def zone_members(rule, direction):
    container = rule.find(direction)
    if container is None:
        return []
    return [member.text.strip() for member in container.findall("member") if member.text]


def get_vulnerability_profile(rule, zone_types, logger):
    sources = zone_members(rule, "from")
    destinations = zone_members(rule, "to")
    if not sources or not destinations:
        return None
    if "any" in sources or "any" in destinations:
        return None

    unknown = [zone for zone in sources + destinations if zone not in zone_types]
    if unknown:
        logger.warning(
            "Rule {!r} references zone(s) not mapped in firewall.yaml; skipped.".format(
                rule.get("name", "unnamed")
            )
        )
        return None

    directions = set()
    has_non_target_pair = False
    for source in sources:
        for destination in destinations:
            source_type = zone_types[source]
            destination_type = zone_types[destination]
            if source_type == "internal" and destination_type == "external":
                directions.add("internal-to-external")
            elif source_type == "external" and destination_type == "internal":
                directions.add("external-to-internal")
            else:
                has_non_target_pair = True

    if not directions:
        return None
    if has_non_target_pair or len(directions) != 1:
        logger.warning(
            "Rule {!r} mixes zone directions or generic types; skipped.".format(
                rule.get("name", "unnamed")
            )
        )
        return None
    return VULNERABILITY_PROFILES[next(iter(directions))]


def set_security_profile(rule, profile_type, profile_name):
    profile_setting = rule.find("profile-setting")
    if profile_setting is None:
        profile_setting = ET.SubElement(rule, "profile-setting")
    profiles = profile_setting.find("profiles")
    if profiles is None:
        profiles = ET.SubElement(profile_setting, "profiles")
    category = profiles.find(profile_type)
    if category is None:
        category = ET.SubElement(profiles, profile_type)
    for child in list(category):
        category.remove(child)
    member = ET.SubElement(category, "member")
    member.text = profile_name


def update_security_rules(vsys, zone_types, logger):
    rules = vsys.findall("./rulebase/security/rules/entry")
    updated = 0
    for rule in rules:
        vulnerability_profile = get_vulnerability_profile(rule, zone_types, logger)
        if vulnerability_profile is None:
            continue
        set_security_profile(rule, "virus", SECURITY_PROFILES["virus"])
        set_security_profile(rule, "spyware", SECURITY_PROFILES["spyware"])
        set_security_profile(rule, "url-filtering", SECURITY_PROFILES["url-filtering"])
        set_security_profile(rule, "vulnerability", vulnerability_profile)
        updated += 1
    return updated


def assign_zone_profiles(vsys, zone_profile_name):
    zones = vsys.findall("./zone/entry")
    for zone in zones:
        network = ensure_path(zone, "network")
        profile = network.find("zone-protection-profile")
        if profile is None:
            profile = ET.SubElement(network, "zone-protection-profile")
        profile.text = zone_profile_name
    return len(zones)


def parse_xml(path):
    parser = ET.XMLParser(
        target=ET.TreeBuilder(insert_comments=True, insert_pis=True)
    )
    return ET.parse(path, parser=parser)


def embedded_reference_root():
    compressed_xml = base64.b64decode(EMBEDDED_REFERENCE_XML)
    return ET.fromstring(zlib.decompress(compressed_xml))


def process_config(xml_path, yaml_path, reference_path, output_path, logger):
    zone_types = load_zone_types(yaml_path)
    try:
        tree = parse_xml(xml_path)
    except ET.ParseError as exc:
        raise ConfigurationError("Could not parse XML: {}".format(exc))

    if reference_path is not None and reference_path.is_file():
        try:
            reference_root = parse_xml(reference_path).getroot()
        except ET.ParseError as exc:
            raise ConfigurationError("Could not parse reference XML: {}".format(exc))
        logger.info("Using profile definitions from {}.".format(reference_path))
    else:
        reference_root = embedded_reference_root()
        logger.warning(
            "reference_config.xml is unavailable; using the embedded profile definitions."
        )

    root = tree.getroot()
    sources = profile_sources(reference_root)
    devices = root.findall("./devices/entry")
    if not devices:
        raise ConfigurationError("Input XML has no devices/entry configuration.")

    updated_rules = 0
    assigned_zones = 0
    for device in devices:
        zone_profile_name = copy_profiles_to_device(device, sources)
        for vsys in device.findall("./vsys/entry"):
            updated_rules += update_security_rules(vsys, zone_types, logger)
            assigned_zones += assign_zone_profiles(vsys, zone_profile_name)

    tree.write(str(output_path), encoding="utf-8", xml_declaration=True)
    logger.info("Updated {} security rule(s).".format(updated_rules))
    logger.info("Assigned zone protection to {} zone(s).".format(assigned_zones))
    logger.info("Updated XML written to {}.".format(output_path))


def parse_arguments():
    parser = argparse.ArgumentParser(
        description="Apply reference security profiles to a PAN-OS XML export."
    )
    parser.add_argument("panos_xml", type=Path, help="PAN-OS export XML file")
    parser.add_argument("firewall_yaml", type=Path, help="firewall.yaml file")
    return parser.parse_args()


def main():
    arguments = parse_arguments()
    run_directory = create_run_directory(Path(__file__).resolve().parent)
    logger, warning_collector = configure_logging(run_directory)
    status = 0
    try:
        for input_path in (arguments.panos_xml, arguments.firewall_yaml):
            if not input_path.is_file():
                raise ConfigurationError("Required input file does not exist: {}".format(input_path))
        script_directory = Path(__file__).resolve().parent
        reference_path = next(
            (
                path
                for path in (
                    script_directory / "configured_reference.xml",
                    script_directory / "reference_config.xml",
                )
                if path.is_file()
            ),
            None,
        )

        logger.info("Reading PAN-OS XML from {}.".format(arguments.panos_xml))
        logger.info("Reading firewall settings from {}.".format(arguments.firewall_yaml))
        output_path = run_directory / "updated_config.xml"
        process_config(
            arguments.panos_xml,
            arguments.firewall_yaml,
            reference_path,
            output_path,
            logger,
        )
    except Exception as exc:
        logger.error("Fatal error: {}".format(exc))
        status = 1
    finally:
        finish_run(logger, warning_collector, status)
    return status


if __name__ == "__main__":
    sys.exit(main())
