# PAN-OS Internal Firewall Configuration

`generate_pa_config.py` updates a PAN-OS XML configuration with the security profiles in the supplied reference configuration. It uses `firewall.yaml` to identify internal and external zones.

## Requirements

- Python 3.8 or newer
- PyYAML, installed with:

  ```text
  python -m pip install -r requirements.txt
  ```

## Usage

Run the script with the PAN-OS XML export and firewall YAML file as positional arguments:

```text
python generate_pa_config.py path/to/panos-export.xml path/to/firewall.yaml
```

The YAML must define `pan_firewall.interfaces`. Each interface entry needs a `zone_name` that matches a zone in the PAN-OS XML and a `generic_type`, such as `internal` or `external`. Other YAML fields are ignored.

```yaml
pan_firewall:
  interfaces:
    ethernet1/1:
      zone_name: outside
      generic_type: external
    ethernet1/2:
      zone_name: inside
      generic_type: internal
```

## What it changes

- For existing security rules between internal and external zones, sets the AV, anti-spyware, URL filtering, and direction-specific vulnerability profiles. Internal-to-external rules use `lan-to-wan-vuln`; external-to-internal rules use `wan_to_lan_vuln`.
- Reuses a content-matching zone protection profile regardless of its name. If none exists, it replaces a same-named profile or adds the reference profile, then assigns the selected profile to every existing zone.
- Adds missing profile containers, rule profile-setting containers, and zone network containers as needed. Existing same-named profile definitions are replaced with the reference definitions.
- Does not add security rules. Rules with `any`, unmapped zones, or mixed directions are skipped where the direction cannot be determined; operator-attention cases are logged as warnings.

The script uses `configured_reference.xml` beside itself when available, then falls back to `reference_config.xml`. If neither file is present, it uses the profile definitions embedded in the script and logs a warning.

## Output and logs

The input files are preserved. Each run creates a new timestamped directory under `runs/`, next to the script, and writes:

- `updated_config.xml`: the updated PAN-OS configuration
- `run.log`: the run messages also printed to the console

If a timestamped directory already exists, the script adds a numeric suffix. The summary at the end repeats any warnings raised during that run.
