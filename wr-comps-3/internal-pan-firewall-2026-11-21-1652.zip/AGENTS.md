# AGENTS.md

Read this file fully first before `SPEC.md`. This file is how to behave; `SPEC.md` is what to build. For this project, DO NOT access or edit another other files besides the ones in this directory and its subdirectories. Make minor design decision to conform with overall goal of project. Pause developement and ask for any major changes.

## Project
A python script for automatically configuring internal firewall security for palo alto firewalls.

## Scope
- Build only what `SPEC.md` lists. No tests, mocks, sample inputs, CI, Docker, packaging, linter config. No extra flags, keys or outputs; mention ideas in the final message instead.
- Stop and ask (question in the final message) when the spec is ambiguous, a required fixture is missing, or exact vendor syntax is uncertain. Never invent vendor syntax.

## Stylistic Requirements
- Use the minimal amount of external packages as needed.
- Priority is readability/maintability of the codebase > minimal amount of packages needed > length.
- Avoid using very modern python. Have it be able to run on Python 3.8.

## Data safety
- Never delete or overwrite collected data: every run gets a new timestamped folder; if a path exists, add a numeric suffix.

## Console
`logging`: INFO progress, WARNING for operator attention (prefix `WARNING:`), ERROR for fatal. Plain text, no emoji or colors. End each run with a summary repeating every WARNING.

## Final message
List: files created; deviations from `SPEC.md` and why; questions you stopped on; VERIFY items you could not confirm.
