# SPEC.md

Read `AGENTS.md` first (conventions, scope, Python rules). Both `generate_pa_config.py` should be single Python files (keeping as closs to the style requirements in AGENTS.md). This SPEC is not a rigid outline, make minor design decisions as needed but as on major changes. I'm giving the overall goal of the project and a few defined design decisions.

## 1. General
Operator is firewall admin in a competition. The goal of this script is to take a current configuration for a palo alto firewall and edit the file to include a default security policy that I've already created containing a custom AV, anti spyware, vulnerability protection, and url filtering to each security rule and zone protection profile to each zone. For the security rules, it should, for the most part, be the same except for the vuln protection (it differs if the rule is internal to external or vice versa, see the reference xml). Ignore the security profile's name in the reference xml unless there are multiple custom ones (they were a artifact of misunderstandings). This should be applied to each existing rule that is between interfaces of different generic_types. Assume all ip, security rule, and zone configurations are valid.

## 2. Requirements
Take the PAN-OS export XML and the firewall.yaml as arguments.

Firewall.yaml
```
pan_firewall:
  type: pan          
  options: {jump_rule: 500}    
  interfaces:
    eth1/1: {zone_name: outside, generic_type: external, ip_addr: 192.168.1.166, ip_range: 192.168.1.0/24}
    eth1/2: {zone_name: inside, generic_type: internal, ip_addr: 10.100.2.1, ip_range: 10.100.2.0/24}
```

`Firewall.yaml` may contain information that is irrelevant. The only relevant things are the interfaces key and each interface. Zone_name is the actual zone name as seen in the provided xml. Generic_type is in relation to the lan. External is the interface pointing upstream while internal points downstream. Use this to map out the lan-to-wan and wan-to-lan policies for the vulnerability protection. 

## 3. Logging
Log all messages to the console in a runs folder. Information and warning keep the script running. Error stops it. 