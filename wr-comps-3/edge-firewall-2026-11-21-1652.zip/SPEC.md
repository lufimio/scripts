# SPEC.md

Read `AGENTS.md` first (conventions, scope, Python rules). Both `scan_network.py` and `build_firewall.py` should be single Python files (keeping as closs to the style requirements in AGENTS.md). This SPEC is not a rigid outline, make minor design decisions as needed but as on major changes. I'm giving the overall goal of the project and a few defined design decisions.

## 1. Purpose and workflow
Operator is firewall admin in a competition: host IPs and services are known, ports are not.
```
inputs/assumed.yaml -> scan_network.py -> runs/<ts>/actual.yaml, nmap/*.xml
runs/<ts>/actual.yaml + inputs/firewall.yaml -> build_firewall.py -> runs/<ts>/configs/<fw>/...
```
Both scripts run as root on an internal machine and should either give a configuration that automatically applies the firewall rules (in the case of nftables, pfsense, vyos, and opnsense) through config files or through the ansible playbooks (cisco ftd and pan-os).

## 2. Scope
The goal of this project is to generate inbound firewall rules allowing traffic to required services on the LAN for a variety of vendors (nftables, pfsense, opnsense, vyos, palo alto, and cisco ftd). It will also allow LAN-to-WAN traffic on TCP ports 80 and 443, TCP and UDP port 53, UDP port 123, and TCP port 853, to any destination; allow outbound ICMP; allow unrestricted traffic between LAN networks; and allow unrestricted traffic in both directions between LAN and DMZ networks. DMZ-to-WAN and WAN-to-DMZ traffic is denied. This project is to be written to be compatible with 3.8+ Python and require 0 external dependencies. If dependencies are needed, they must be self-contained within the project.

## 3. Targets
pfSense CE 2.9.0 (config `<version>24.6</version>`); VyOS 1.5 (circinus); nftables 1.1.7; nmap on PATH. Script 1 MUST exit 1 with a clear message unless `os.geteuid() == 0` (and Windows equivalent). Pin PyYAML in `requirements-scan.txt` to a release that installs on 3.6 (6.0). The builder bundles pure-Python PyYAML 6.0.2, Jinja2 3.1.6, and MarkupSafe 2.1.5 sources and licenses in `builder/_vendor/`. It requires no package installation, network access, or compiled extensions; `requirements-build.txt` is informational only. Scanner dependencies are unchanged.

## 4. Layout
```
scan_network.py  build_firewall.py          thin entry points
common/  # Put common python files between both scanner and builder here
scanner/ # Put scanner specific python files here
builder/ vendors/{__init__,nftables,vyos,pfsense,opnsense,openwrt}.py # Put other firewall rule builder specific python files here. vendors/ is for each specific vendor
builder/_vendor/{yaml,jinja2,markupsafe}/ # Bundled builder runtime dependencies and licenses
templates/{nftables,vyos,pfsense,openwrt}/   (pfsense/aliases.xml & pfsense/filter.xml provided)
requirements-scan.txt  requirements-build.txt  README.md
```
Each package has `__init__.py`. `inputs/` and `runs/` are created by the operator/scripts. `README.md` is short: install, the two command lines, schema summary (section 5), workflow (section 1).

## 5. Data formats

### 5.1 `assumed.yaml`
```yaml
sql01:
  os: windows
  ip: 10.100.2.100
  generic: db
  username: username
  password: password
  ports:
    "3306/tcp": mysql
```
- Port key `"<port>/<tcp|udp>"` (string); value = service name. `ports` may be empty.
- Os key `os` determines which general category the os is (windows/ linux/ mac)
- Copy `ip` and any extra keys unchanged. Duplicate IPs are an error.
- Sort ports by number then protocol (tcp first). Dump with `yaml.safe_dump(..., sort_keys=False, default_flow_style=False)`.

### 5.2 `firewall.yaml`
```yaml
fw_core:
  type: vyos                      # pfsense | vyos | nftables | opnsense | openwrt
  options: {jump_rule: 500}       # optional, vendor-specific (section 8)
  interfaces:
    eth0:
      generic_name: wan
      ip_addr: 203.0.113.2
      interface_range: 203.0.113.0/24
      down_range: []
    eth1:
      generic_name: lan
      ip_addr: 10.0.0.1
      interface_range: 10.0.0.0/30
      down_range: [10.0.1.0/24]
    eth2:
      generic_name: dmz
      ip_addr: 10.0.2.1
      interface_range: 10.0.2.0/24
      down_range: [10.0.2.0/24]
```
- Top keys are firewall hostnames; `type` and `interfaces` are required. `generic_name` is `wan` (outside), `lan` (inside), or `dmz`. Types may differ per firewall.
- Interface keys are unique labels used to associate address ranges with `generic_name`; they are not emitted or used as firewall match conditions. The key names represent the actual interface names as would be seen in `ifconfig` or pfsense `interface` assignments.
- `ip_addr` is the interface's IPv4 address. `interface_range` is the IPv4 network attached to that interface and must contain `ip_addr`. `down_range` is a list of IPv4 networks routed through the interface; it is included for every interface and may be empty for WAN interfaces. Multiple interfaces may point to the same downstream network.
- Optional IPv6 keys are `ipv6_addr`, `ipv6_interface_range`, and `ipv6_range`. `ipv6_addr` is the interface's IPv6 address; `ipv6_interface_range` is the attached IPv6 network and must contain `ipv6_addr`; `ipv6_range` is a list of IPv6 networks routed through the interface. Omit IPv6 keys when the interface has no IPv6 configuration.
- Validate addresses and networks by family, required keys, and known types. LAN and DMZ downstream networks for each firewall must not overlap across roles. `panos`/`ftd` fail with an error naming supported types and saying they are planned, not implemented.
- pfSense and OPNsense entries require `options.config_file`, the path to that firewall's complete exported `config.xml`; relative paths are resolved from the directory containing `firewall.yaml`. nftables and VyOS do not require an exported configuration.
- OpenWrt entries require `options.config_file` (copied `/etc/config/firewall`) and `options.openwrt_network_file` (copied `/etc/config/network`). Resolve both relative to `firewall.yaml`; retain the existing interface schema. No other OpenWrt options or CLI flags are added.


### 5.3 `policy.yaml`
The scanner loads `policy.yaml` by default; `--policy` may select another file with the same schema. Top-level keys (except `roles`) are generic host roles. Each role maps service names to definitions:
```yaml
web:
  http:
    ports: ["80/tcp"]
    nmap_names: [http]
    process_names: [apache2, httpd, nginx]
  https:
    ports: ["443/tcp"]
    nmap_names: [https]
    process_names: [apache2, httpd, nginx]
roles:
  web:
    description: Web server
    aliases: [webserver, web server]
```
- Each service definition requires `ports`, a list of quoted `port/protocol` or `low-high/protocol` strings. `nmap_names` and `process_names` are optional lists of service names reported by Nmap and executable names used to verify a service.
- `roles.<name>.aliases` lists accepted names for that role in the `generic` field of `assumed.yaml`; a host may specify one role or a list. `description` is optional metadata.
- `fixed_ports` is not part of this schema.

## 6. Script 1: `scan_network.py ASSUMED_YAML [--policy policy.yaml] [--output-dir runs]`
Exit 0 ok, 1 fatal (bad input, not root, nmap missing).

**Steps:** 

- Load assumed.yaml. Scan each host using nmap commands below. Initially start with a targetted scan at the given ports. Afterwards, attempt to ssh into the host with the credentials in `assumed.yaml`. For windows hosts, if ssh fails, attempt winrm. If successful, on Linux list all of the currently open ports (initially use ss, if it fails, fall back to netstat). On Windows, use the command below to determine which process is running on ports if they meet the following conditions: local address is the machine's ip or 0.0.0.0 and local port is in `assumed.yaml`. Only attempt to connect using each method once. All methods must use administrator/ sudo. Use username and password.

- Using the data collected from the nmap scans and attempts at process enumeration, determine if the port in `assumed.yaml` actually exists. Do it in this method. 1. If the port in assumed.yaml shows up in the nmap scan with the service matching as per `policy.yaml` (each section of ports is what should fall under the generic), it passes. 2. If the port in assumed.yaml shows up in the nmap scan but the serviec is not listed, check the process enumeration returns, and if it matches, pass it. If not, throw and error and fail. The only exception is for webmail where not all of the ports may be there (IMAP may be enabled but POP3 disabled - unknown until checked). If a port is missing, pass an error and continue 

- Generate a `actual.yaml` containing the updated list of ports from `assumed.yaml`. Unknown ports should not be added, only ports that do not exist on the netweork should be removed.

**Nmap Commands:**
```
nmap -v -Pn -n -sS -sV --version-light -p [PORTS] -T4 --min-rate 2000 --max-retries 2 --open -iL targets.txt -oX nmap/tcp.xml
nmap -v -Pn -n -sU -p <UDP_PORT_LIST> -T4 --max-retries 1 -iL targets.txt -oX nmap/udp.xml
```

**Windows process identifer commands:**
```
netstat -ano 
tasklist /fi "pid eq 0000"
```

**Linux process identifer commands:**
```
ss -tulpn
netstat -tulpn
```

## 7. Script 2: `build_firewall.py ACTUAL_YAML FIREWALL_YAML [--output-dir DIR] [--log]`
The following rules must be applied regardless of vendor (in no particular order):

- Allow all established, related traffic on all ports.
- Block invalid traffic.
- IPv6 inbound is by default blocked unless `firewall.yaml` includes it in the firewall interfaces.
- Block all traffic inbound originating on the WAN from a network that already exists in a LAN or DMZ downstream network.
- Allow IPv4 ICMP from WAN to configured LAN downstream networks after anti-spoofing checks. Allow outbound and internal ICMP. WAN-to-DMZ remains denied.
- Allow ICMPv6 echo requests (IPv6 ping) from WAN to configured LAN `ipv6_range` networks after anti-spoofing checks, with stateful replies. Deny other new inbound IPv6 traffic and WAN-to-DMZ IPv6 traffic.
- Allow lan->wan traffic with restrictions above.
- Allow all traffic between LAN interfaces and all LAN destination networks.
- Allow all traffic in both directions between LAN and DMZ downstream networks. Deny all traffic in both directions between DMZ and WAN.
- All rules must be stateful.
- Log denied traffic.
- Default deny on all other forwarded traffic at very end.

**Steps for wan-> lan traffic (vendor non-specific)**:

- Load and validate that the input yaml file is valid and has at a minimum `ip` and port keys.
- Load and validate that the firewall yaml file is valid as per above outline.
- Generate firewall rules and other configurations as per above.
- Generate a firewall address group for each host using the overarching host name in the input yaml file. There should only be 1 ip address in each group. This is for easier debugging.
- Generate a firewall port group for each host based on the ports in the input yaml. Ensure that the name is consistent across all port groups and is descriptive.
- Implement firewall rules to only allow new, inbound access to lan ips on select ports when forwarding. Use seperate chains as much as possible to group these firewall rules.

**Misc.**

- There may be times where the edge firewall is not directly connected to the lan network (such as there being 2 intermediate firewalls, each holding diff
erent hosts). In any case, the inbound rules should be based off which interface they come in on, not by ip.
- New firewall rules will fully replace all old ones, except OpenWrt: preserve its complete supplied configuration and insert the generated forwarding policy first (section 8.5).
- Apply rules from most specific to most general.

## 8. Vendors
All: templates in `templates/<vendor>/`, one file per construct, numeric prefix sets order. Output deterministic, starts with a generated header comment (sources, firewall, `--log` flag, no timestamp). This section is for any vendor specific intracacies as well as sample commands.

### 8.1 nftables
Output `nftables.nft`, replacing the curent `nftables.nft` configuraiton. Use `flush`/`rebuild` commands. Fully replace al existing firewall configuration.

Illustrative: `add set inet filter h_web { type ipv4_addr; }`, `add element inet filter h_web { 10.0.1.10 }`, `add rule inet filter fw_allow ip saddr @h_x ip daddr @h_y tcp dport @p_z_tcp accept comment "z_tcp"`.

### 8.2 VyOS 1.5
Output `vyos.commands`: `set`/`delete` lines only, no `commit`/`save`. The only supported option is `jump_rule` (default 500). Generate `vyos.sh` with a hard-coded vbash script header and the generated commands; do not load a boilerplate file or manual includes.

Known shapes: `set firewall group address-group h_web address 10.0.1.10`; `set firewall group network-group LAN_NET network 10.0.1.0/24`; `set firewall group port-group p_x_tcp port 80`; `... port 49152-65535`; `set firewall ipv4 name FW_INTERNAL rule 10 action accept`; `set firewall ipv4 forward filter rule 500 action jump`; `... rule 500 jump-target FW_INTERNAL`; `set firewall ipv4 forward filter rule 100 source group network-group BLOCKED_HOSTS`; `set firewall ipv4 forward filter rule 100 destination group network-group SENSITIVE_PORTS`. Statefulness rules must use `global-options`.

### 8.3 pfSense CE 2.9.0
Read the complete config from the per-firewall `options.config_file` and output a complete `config.xml`. Match interfaces by their IPv4 address and directly attached network; use the exported `wan` assignment as fallback for WAN when no static match exists. Missing, ambiguous, or reused interface mappings are fatal. Replace all top-level `filter` and `aliases` contents with the generated policy and preserve all other configuration sections. XML formatting may change during serialization. Use the existing numbered Jinja templates for generated element names and order; the reference `templates/pfsense/filter.xml` and `templates/pfsense/aliases.xml` are development aids, not runtime inputs.

**Ownership:** every generated alias/rule `<descr>` starts with `fwgen:` (`GENERATED_MARKER`); descriptions use only letters, digits, spaces, `_`, `-`, `:`.

**Aliases** (appended to `<aliases>`): host groups `type host`, `address` = space-separated IPs; network groups `type network`, `address` = space-separated LAN/internal IPv4 or IPv6 prefixes; port groups `type port`, space-separated, ranges `low:high`; `detail` `||`-separated, one per member. Names: letters, digits, `_`, <=31 chars, not starting with a digit.

**Rules** are attached to the interface where traffic enters. On each WAN interface, emit spoofed LAN/DMZ source blocks and WAN-to-DMZ blocks first, then an IPv4 ICMP allow to LAN networks and an ICMPv6 echo-request allow to configured LAN IPv6 networks, followed by an IPv6 default block, service-specific inbound allows, and a final IPv4 deny. On each LAN/internal interface, emit pass rules to all LAN/internal networks, then a pass rule to destinations outside those networks, then logged IPv4 and configured IPv6 default denies. The inside pass rules are unrestricted by protocol or port; ICMP is therefore allowed internally and outbound. `--log` logs pass rules and leaves deny actions intact. Each rule has a unique numeric `<tracker>` and `<created>`/`<updated>` values with username `fwgen`.

**Insertion point:** `<filter>` is flat and rules evaluate top down in document order for each interface. `<aliases>` is flat and aliases evaluate top down in document order for network, port, and host types.

### 8.4 OPNsense
Read the complete config from the per-firewall `options.config_file`. Resolve LAN/internal interfaces by matching `firewall.yaml` IPv4 address and network to the OPNsense interface configuration. Resolve WAN by its generic role when it cannot be matched by a static address. A missing or ambiguous mapping is fatal.

Replace all entries in `OPNsense/Firewall/Filter/rules` and `OPNsense/Firewall/Alias/aliases`; preserve all other configuration sections and the existing component metadata. Emit the complete modified config as `config.xml`. Alias UUIDs are generated deterministically. Rule sequence values are unique and increase in execution order within each interface.

Generate stateful WAN inbound service allows and logged default-deny rules; allow inbound ICMP in the generated rules. Generate unrestricted LAN/internal-to-LAN/internal and LAN/internal-to-WAN rules, followed by logged default-deny rules on each inside interface. Use configured IPv6 ranges for LAN/internal IPv6 allows and deny other inbound IPv6 traffic. OPNsense's automatic IPv6 control-message rules remain intact because only the filter rules and aliases sections are replaced. The full-config renderer edits the XML model directly and does not use Jinja templates.

### 8.5 OpenWrt 25.12.6 (firewall4)

Output `firewall` and `fwgen.nft` in the per-firewall run directory. The first
retains the complete input firewall file verbatim and appends a generated UCI
`config include` with type `nftables`, path `/etc/fwgen.nft`, and position
`ruleset-append`. Preserve NAT, masquerading, filtering rules, zones, defaults,
includes, unknown sections, comments, and original ordering. Parse UCI without
executing it, using only the standard library. Preserve the source files.

Read the network export to resolve interfaces by IPv4 address/attached range,
then configured device and zone membership. WAN without a static match may
match by YAML network/device name, then by a unique device in the `wan` zone.
Resolve explicit bridge devices and network aliases; do not invent runtime
device names for PPP/tunnels or implicit legacy bridges. Missing, ambiguous,
cyclic, or duplicate device mappings and malformed UCI are fatal. Reject
input already containing the fwgen include and request the original export.

The nftables output creates only prefixed sets and a dedicated regular chain
within `inet fw4`. Reset only those generated sets/chain on reload. Insert its
jump at the beginning of firewall4's `forward` chain, ahead of ordinary rules
and automatic DNAT acceptance. Never emit `flush ruleset` or flush/delete the
existing table. Generate the established policy from section 7, including
state tracking, invalid drops, anti-spoofing, confirmed inbound IPv4 services,
WAN-to-LAN ICMP/IPv6 ping, restricted LAN egress, internal permissions, DMZ/WAN
denies, and logged final deny. Match confirmed destinations after DNAT. Keep
input/output policies and existing NAT definitions intact. `--log` logs allows
in addition to denied traffic. Counts include the inserted jump.

Deploy `firewall` to `/etc/config/firewall` and `fwgen.nft` to `/etc/fwgen.nft`;
both must be installed before reload. Do not apply configuration automatically.
Warn that all existing configuration is preserved for manual audit, including
external includes, package integrations, offloading, and shadowed policies.
No guarantee is made about external runtime rules beyond the generated jump
in firewall4's forwarding chain. Existing vendor behavior is unchanged.

## 9. Templates
Jinja2 `Environment`: `StrictUndefined`, `trim_blocks=True`, `lstrip_blocks=True`, `keep_trailing_newline=True`; autoescape on for XML, off for text. One file per construct, number-prefixed, ending in target type (e.g. `30_host_sets.nft.j2`); the renderer discovers and orders them, no hard-coded count. Templates get the `Ruleset` and `Firewall` and contain no policy logic (no filtering, dedup, decisions); Python prepares everything.

## 10. Console
Plain `LEVEL: message`. Both scripts end with a summary repeating every WARNING and listing files written. Script 2 prints per firewall: type, counts of host groups, port groups, rules, output files. Never print secrets.

## 11. Output
Log all output on the console to a text file.

## 12. Prerequisites
The builder requires its bundled dependencies and the selected vendor's runtime `.j2` templates (nftables, VyOS, pfSense, and OpenWrt). It does not require `policy.yaml`, development reference XML, or the VyOS boilerplate. Each configured pfSense, OPNsense, or OpenWrt firewall requires its own complete exported config via `options.config_file`; OpenWrt additionally requires `options.openwrt_network_file`. The scanner still requires its service policy file.
