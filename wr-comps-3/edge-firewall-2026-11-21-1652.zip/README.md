# Firewall automation

## Install

The builder runs on Python 3.8+ with no package installation or network access.
Its pure-Python dependencies (PyYAML, Jinja2, and MarkupSafe) are bundled in
`builder/_vendor/`. Keep `build_firewall.py`, the complete `builder/` directory,
and `templates/` together when copying the project. `requirements-build.txt`
is informational and installs nothing.

## Commands

```text
python build_firewall.py HOSTS_YAML FIREWALL_YAML [--output-dir runs] [--log]
```

For example, with host and firewall inventories in the current directory:

```text
python build_firewall.py hosts.yaml firewall.yaml
```

The builder supports nftables, VyOS 1.5, pfSense CE 2.9.0, OPNsense, and
OpenWrt 25.12.6 (firewall4). It validates the confirmed host ports and firewall
interfaces, then writes artifacts to a
new timestamped directory under `runs/` (or the directory given by
`--output-dir`):

```text
runs/<timestamp>/
  console.txt
  configs/<firewall>/
    nftables.nft                 # nftables
    vyos.commands                # VyOS configuration commands
    vyos.sh                      # VyOS helper script
    config.xml                   # pfSense or OPNsense full configuration
    firewall                     # OpenWrt complete UCI firewall configuration
    fwgen.nft                    # OpenWrt generated forwarding policy
```

Only the files for the selected firewall type are written. Generated blocked
rules are logged by default. `--log` also logs generated allowed rules.
VyOS's helper script is generated directly; no boilerplate or manual include
file is read. VyOS accepts only the optional `jump_rule` setting (default 500).

Each top-level entry in `firewall.yaml` is built. Its `type` determines which
options and source configuration files are required:

| `type` | `options` | Output | Existing configuration |
| --- | --- | --- | --- |
| `nftables` | None | `nftables.nft` | Replaces the firewall ruleset when applied |
| `vyos` | Optional `jump_rule` | `vyos.commands`, `vyos.sh` | Deletes and rebuilds firewall configuration when applied |
| `pfsense` | Required `config_file` | `config.xml` | Replaces rules and aliases; preserves other sections |
| `opnsense` | Required `config_file` | `config.xml` | Replaces rules and aliases; preserves other sections |
| `openwrt` | Required `config_file`, `openwrt_network_file` | `firewall`, `fwgen.nft` | Preserves all original configuration and inserts generated forwarding policy first |

All source paths in `options` are resolved relative to the directory containing
`firewall.yaml`. An exported config is required only for entries whose type
needs it. The builder generates files locally; it does not connect to or
configure a live firewall.

## YAML input examples

The values below illustrate syntax; replace them with values for your hosts,
networks, and firewall.

### `hosts.yaml`

The builder requires each host to have an IPv4 address and confirmed ports;
entries retain the hostname and service mapping.

```yaml
web01:
  ip: 10.20.1.25
  generic: web
  os: linux
  ports:
    "80/tcp": http
    "443/tcp": https
```

### `firewall.yaml`

Each top-level entry names a firewall. Under `interfaces`, each key identifies
one interface and `generic_name` assigns it the role `wan`, `lan`, or `dmz`.
The address and range fields describe two different networks:

- `ip_addr` is the firewall's IPv4 address on this interface.
- `interface_range` is the IPv4 network directly attached to the interface. It
  must contain `ip_addr` and is used to match the interface in pfSense, OPNsense,
  or OpenWrt exports.
- `down_range` is a list of IPv4 networks routed through the interface. These
  are the networks whose traffic the generated policy matches. It is required
  on every interface; use an empty list for WAN. LAN and DMZ interfaces need at
  least one downstream network.
- `ipv6_addr` and `ipv6_interface_range` describe the firewall's IPv6 address
  and its directly attached network. If provided, both are required, and the
  range must contain the address.
- `ipv6_range` is a list of IPv6 networks routed through the interface. All
  IPv6 fields are optional; omit them when IPv6 is not configured.

For example, the LAN interface below has a transit network directly attached
to the firewall (`interface_range`), while the client subnet routed through it
is listed in `down_range`:

```yaml
edge:
  type: opnsense
  options:
    config_file: path/to/full-exported-config.xml
  interfaces:
    outside0:
      generic_name: wan
      ip_addr: 198.51.100.2
      interface_range: 198.51.100.0/24
      down_range: []
    inside0:
      generic_name: lan
      ip_addr: 10.20.0.1
      interface_range: 10.20.0.0/30
      down_range: [10.20.1.0/24]
      ipv6_addr: 2001:db8:20:0::1
      ipv6_interface_range: 2001:db8:20:0::/64
      ipv6_range: [2001:db8:20:1::/64]
    dmz0:
      generic_name: dmz
      ip_addr: 10.20.2.1
      interface_range: 10.20.2.0/24
      down_range: [10.20.2.0/24]
```

WAN must have an empty `down_range`. LAN and DMZ downstream networks must not
overlap. Generated rules allow LAN-to-WAN traffic only on TCP 80/443, TCP and
UDP 53, UDP 123, TCP 853, and ICMP; LAN-to-LAN and LAN-to-DMZ traffic is
unrestricted. DMZ-to-LAN is allowed, while DMZ-to-WAN and WAN-to-DMZ are
denied. IPv4 ICMP from WAN to configured LAN downstream networks is allowed
after WAN anti-spoofing checks. IPv6 ping (ICMPv6 echo requests) from WAN is
also allowed to configured LAN `ipv6_range` networks, with stateful replies.
For pfSense and OPNsense, `options.config_file` points to that firewall's complete
exported configuration; relative paths are resolved from the directory
containing `firewall.yaml`. Interface mapping fails if a required match is
missing or ambiguous. WAN falls back to the exported `wan` assignment when
no static address/network match exists. nftables and VyOS do not require an
exported configuration.

### Other required files

A pfSense or OPNsense firewall needs its full exported configuration file,
referenced by `options.config_file`. The builder does not require `policy.yaml`
or the development reference XML/boilerplate files. The numbered `.j2`
templates remain runtime inputs for nftables, VyOS, pfSense, and OpenWrt.

### OpenWrt

Use `type: openwrt` with both required options: `config_file` points to a copy
of `/etc/config/firewall`, and `openwrt_network_file` points to a copy of
`/etc/config/network`. Both paths are resolved relative to `firewall.yaml`.
Use the same `interfaces` schema shown above. Only OpenWrt entries require
`openwrt_network_file`; no additional command-line flags or packages are needed.

In the existing firewall entry, use the following type and options, retaining
its `interfaces` mapping:

```yaml
type: openwrt
options:
  config_file: exports/openwrt/firewall
  openwrt_network_file: exports/openwrt/network
```

Here, `exports/openwrt/firewall` is the original `/etc/config/firewall` copy,
and `exports/openwrt/network` is the corresponding `/etc/config/network` copy
from the same router. These paths are relative to `firewall.yaml`. Generate
the files with the same builder command shown above.

The builder matches IPv4 interface addresses and attached networks to the
network export, then resolves their configured devices and firewall zones.
For WAN without a static address match, it tries the YAML interface key as a
network/device name, then an unambiguous device in the `wan` zone. A bridge
must have an explicit device such as `br-lan`. Protocols that create runtime
devices (for example PPP or tunnels), legacy implicit bridges, missing device
names, duplicate device mappings, and ambiguous zones fail rather than guess.
The network export is read only; it is not generated or deployed.

The `firewall` output retains every original byte, including NAT, rules,
zones, defaults, comments, unknown sections, and existing includes. It appends
one nftables include referencing `/etc/fwgen.nft` at `ruleset-append`.
The `fwgen.nft` output creates prefixed host/port sets and a forwarding chain
inside `inet fw4`, then inserts a jump at the start of firewall4's `forward`
chain. On reload, only the generated sets and chain are reset; no ruleset or
table is flushed by the generated file. Original forwarding rules remain but
may be shadowed by generated allows and the final deny. Router input/output
rules are retained. NAT translations are retained, while generated service
permissions match the translated host address and port.

After manual review, install **both** outputs on the corresponding router:

| Generated file | Destination |
| --- | --- |
| `fwgen.nft` | `/etc/fwgen.nft` |
| `firewall` | `/etc/config/firewall` |

Install `fwgen.nft` before activating the new firewall configuration, then
reload using OpenWrt's supported process. Keep the original exports for future
builds. The builder does not apply the files. Audit external includes,
package rules, and offloading manually; their configuration is preserved and
their effective runtime behavior is not inferred. Input already containing
the generator's include is rejected: rebuild from the original export.
OpenWrt uses the numbered templates in `templates/openwrt/` at runtime.

## Workflow

`build_firewall.py` consumes the host inventory (`hosts.yaml`, or the scanner's
`actual.yaml`) and the operator's `firewall.yaml`, then generates inbound WAN-to-host rules for confirmed
services whose host addresses fall within a configured LAN downstream
network. LAN-to-WAN access is limited to the ports and ICMP listed above, while
LAN-to-LAN and LAN-to-DMZ traffic is unrestricted. WAN inbound service rules
are attached to WAN; LAN rules and their fallback denies are attached to each
source LAN interface. DMZ interfaces can reach LAN networks, and their other
traffic is denied. For pfSense and OPNsense, the builder replaces all rules
and aliases in the supplied full config and preserves the other
configuration sections. pfSense replaces the top-level `filter` and `aliases`
contents; OPNsense replaces `OPNsense/Firewall/Filter/rules` and
`OPNsense/Firewall/Alias/aliases`. XML formatting may change during serialization.
OpenWrt preserves its complete source firewall configuration and appends an
include for the separate generated policy; its network export is read only.
Interface names are resolved from the input config and
`firewall.yaml`; missing or ambiguous matches are fatal. Each run includes a
console log and a summary of generated files and warnings. It does not apply
the configuration to a live firewall; generated artifacts must be reviewed and
applied using the vendor's supported process.
