"""Firewall configuration generation."""

import os
import sys

# Prefer the bundled, pure-Python dependencies over system-installed packages.
_vendor_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_vendor")
if _vendor_dir not in sys.path:
    sys.path.insert(0, _vendor_dir)
