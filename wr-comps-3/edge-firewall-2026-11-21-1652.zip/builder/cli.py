"""Command-line orchestration for firewall builders."""

import argparse
import ipaddress
import logging
import os
import sys

from builder.core import BuildError, load_yaml, validate_actual, validate_firewalls, unique_run_dir
from builder.vendors import nftables, opnsense, openwrt, pfsense, vyos


class WarningCollector(logging.Handler):
    def __init__(self):
        logging.Handler.__init__(self, logging.WARNING)
        self.messages = []

    def emit(self, record):
        self.messages.append(record.getMessage())


def _parser():
    parser = argparse.ArgumentParser(description="Generate inbound firewall configuration artifacts")
    parser.add_argument("actual_yaml")
    parser.add_argument("firewall_yaml")
    parser.add_argument("--output-dir", default="runs")
    parser.add_argument("--log", action="store_true",
                        help="log all generated rules; by default only blocked rules are logged")
    return parser


def main(argv=None):
    args = _parser().parse_args(argv)
    try:
        run_dir = unique_run_dir(args.output_dir)
    except (IOError, OSError) as exc:
        print("ERROR: cannot create run directory: %s" % exc, file=sys.stderr)
        return 1

    root_logger = logging.getLogger()
    root_logger.handlers[:] = []
    root_logger.setLevel(logging.INFO)
    formatter = logging.Formatter("%(levelname)s: %(message)s")
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    logfile = logging.FileHandler(os.path.join(run_dir, "console.txt"), encoding="utf-8")
    logfile.setFormatter(formatter)
    warnings = WarningCollector()
    root_logger.addHandler(console)
    root_logger.addHandler(logfile)
    root_logger.addHandler(warnings)

    output_files = []
    try:
        actual_raw = load_yaml(args.actual_yaml, "actual YAML")
        firewall_raw = load_yaml(args.firewall_yaml, "firewall YAML")
        hosts = validate_actual(actual_raw)
        firewalls = validate_firewalls(firewall_raw)
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        renderers = {"nftables": nftables.render, "vyos": vyos.render,
                     "pfsense": pfsense.render, "opnsense": opnsense.render,
                     "openwrt": openwrt.render}
        logging.info("Run directory: %s" % run_dir)
        for firewall in firewalls:
            firewall["actual_source"] = os.path.basename(args.actual_yaml).replace("-", "_")
            firewall["source"] = os.path.basename(args.firewall_yaml).replace("-", "_")
            path_keys = []
            if firewall["type"] in ("opnsense", "pfsense", "openwrt"):
                path_keys.append("config_file")
            if firewall["type"] == "openwrt":
                path_keys.append("openwrt_network_file")
            for key in path_keys:
                config_file = firewall[key]
                if not os.path.isabs(config_file):
                    config_file = os.path.join(os.path.dirname(os.path.abspath(args.firewall_yaml)), config_file)
                firewall[key] = os.path.abspath(config_file)
                if not os.path.isfile(firewall[key]):
                    raise BuildError("firewall %s %s %s does not exist: %s" %
                                     (firewall["name"], firewall["type"], key, firewall[key]))
            destination = os.path.join(run_dir, "configs", firewall["name"])
            os.makedirs(destination)
            for host in hosts:
                if not any(ipaddress.ip_address(host["ip"]) in ipaddress.ip_network(network)
                           for iface in firewall["inside_interfaces"]
                           for network in iface["networks"]):
                    logging.warning("host %s (%s) is outside firewall %s LAN networks; no allow rule generated" %
                                    (host["name"], host["ip"], firewall["name"]))
            renderer = renderers[firewall["type"]]
            written, host_groups, port_groups, rule_count = renderer(
                root, destination, hosts, firewall, args.log)
            logging.info("Firewall %s: type=%s host_groups=%d port_groups=%d rules=%d" %
                         (firewall["name"], firewall["type"], host_groups, port_groups, rule_count))
            for filename in written:
                path = os.path.join(destination, filename)
                output_files.append(path)
                logging.info("Wrote: %s" % path)
    except (BuildError, IOError, OSError, ValueError) as exc:
        logging.error(str(exc))
        _summary(run_dir, output_files, warnings.messages)
        return 1
    except Exception as exc:
        logging.error("fatal builder error: %s" % exc)
        _summary(run_dir, output_files, warnings.messages)
        return 1
    _summary(run_dir, output_files, warnings.messages)
    return 0


def _summary(run_dir, files, warning_messages):
    logging.info("Summary: run directory %s" % run_dir)
    for message in list(warning_messages):
        logging.warning(message)
    logging.info("Files written:")
    for path in files:
        logging.info("  %s" % path)
    logging.info("  %s" % os.path.join(run_dir, "console.txt"))
