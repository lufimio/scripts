"""Input validation, policy model, output paths, and template rendering."""

from __future__ import print_function

import datetime
import hashlib
import ipaddress
import os
import re
import sys

import yaml
from jinja2 import Environment, FileSystemLoader, StrictUndefined, select_autoescape


class BuildError(Exception):
    pass


def load_yaml(path, label):
    try:
        with open(path, "r") as stream:
            value = yaml.safe_load(stream)
    except (IOError, OSError, yaml.YAMLError) as exc:
        raise BuildError("cannot load %s: %s" % (label, exc))
    if not isinstance(value, dict) or not value:
        raise BuildError("%s must contain a non-empty mapping" % label)
    return value


def _port(value, host):
    if not isinstance(value, str):
        raise BuildError("host %s has a non-string port key" % host)
    match = re.match(r"^(\d{1,5})(?:-(\d{1,5}))?/(tcp|udp)$", value)
    if not match:
        raise BuildError("host %s has invalid port %r; expected port/proto" % (host, value))
    low, high = int(match.group(1)), int(match.group(2) or match.group(1))
    if low < 1 or high > 65535 or low > high:
        raise BuildError("host %s has invalid port range %r" % (host, value))
    return {"key": value, "low": low, "high": high, "proto": match.group(3)}


def validate_actual(data):
    hosts = []
    seen = set()
    for name, raw in data.items():
        if not isinstance(name, str) or not name or re.search(r"[\x00-\x1f\x7f]", name):
            raise BuildError("invalid host name %r in actual YAML" % (name,))
        if not isinstance(raw, dict) or "ip" not in raw or "ports" not in raw:
            raise BuildError("host %s must contain ip and ports" % name)
        try:
            address = ipaddress.ip_address(str(raw["ip"]))
        except ValueError:
            raise BuildError("host %s has invalid IP address %r" % (name, raw["ip"]))
        if address.version != 4:
            raise BuildError("host %s has IPv6 address; actual.yaml hosts must be IPv4" % name)
        if str(address) in seen:
            raise BuildError("duplicate host IP address %s" % address)
        seen.add(str(address))
        if not isinstance(raw["ports"], dict):
            raise BuildError("host %s ports must be a mapping" % name)
        ports = [_port(key, name) for key in raw["ports"]]
        ports.sort(key=lambda item: (item["low"], 0 if item["proto"] == "tcp" else 1,
                                     item["high"]))
        hosts.append({"name": name, "ip": str(address), "ports": ports})
    return hosts


def validate_firewalls(data):
    result = []
    supported = ("nftables", "vyos", "pfsense", "opnsense", "openwrt")
    for name, raw in data.items():
        if not isinstance(name, str) or not re.match(r"^[A-Za-z0-9_-]+$", name):
            raise BuildError("invalid firewall name %r" % (name,))
        if not isinstance(raw, dict) or "type" not in raw or "interfaces" not in raw:
            raise BuildError("firewall %s must have type and interfaces" % name)
        vendor = raw["type"]
        if vendor in ("panos", "ftd"):
            raise BuildError("firewall %s uses %s; supported types are %s; %s is planned, not implemented" % (name, vendor, ", ".join(supported), vendor))
        if vendor not in supported:
            raise BuildError("firewall %s has unsupported type %r; supported types: %s" % (name, vendor, ", ".join(supported)))
        options = raw.get("options", {})
        interfaces = raw["interfaces"]
        if not isinstance(options, dict) or not isinstance(interfaces, dict) or not interfaces:
            raise BuildError("firewall %s options/interfaces must be mappings, with at least one interface" % name)
        parsed = []
        roles = {"wan": [], "lan": [], "dmz": []}
        for ifname, item in interfaces.items():
            if not isinstance(ifname, str) or not re.match(r"^[A-Za-z0-9_.:-]+$", ifname):
                raise BuildError("firewall %s has invalid interface name" % name)
            if not isinstance(item, dict) or not all(k in item for k in
                                                      ("generic_name", "ip_addr", "interface_range", "down_range")):
                raise BuildError("firewall %s interface %s needs generic_name, ip_addr, interface_range, down_range" %
                                 (name, ifname))
            role = item["generic_name"]
            if role not in roles:
                raise BuildError("firewall %s interface %s has unknown generic_name %r" % (name, ifname, role))
            try:
                interface_network = ipaddress.ip_network(str(item["interface_range"]), strict=False)
                address = ipaddress.ip_address(str(item["ip_addr"]))
            except ValueError as exc:
                raise BuildError("firewall %s interface %s has invalid IPv4 interface address/range: %s" %
                                 (name, ifname, exc))
            if interface_network.version != 4 or address.version != 4 or address not in interface_network:
                raise BuildError("firewall %s interface %s ip_addr must be IPv4 inside interface_range" %
                                 (name, ifname))
            down_values = item["down_range"]
            if not isinstance(down_values, list):
                raise BuildError("firewall %s interface %s down_range must be a list" % (name, ifname))
            networks = []
            for value in down_values:
                try:
                    network = ipaddress.ip_network(str(value), strict=False)
                except ValueError as exc:
                    raise BuildError("firewall %s interface %s has invalid downstream IPv4 network: %s" %
                                     (name, ifname, exc))
                if network.version != 4:
                    raise BuildError("firewall %s interface %s down_range must contain IPv4 networks" %
                                     (name, ifname))
                networks.append(str(network))
            if role == "wan" and networks:
                raise BuildError("firewall %s WAN interface %s down_range must be empty" % (name, ifname))
            if role in ("lan", "dmz") and not networks:
                raise BuildError("firewall %s interface %s must have at least one down_range network" %
                                 (name, ifname))

            v6_addr_value = item.get("ipv6_addr")
            v6_interface_value = item.get("ipv6_interface_range")
            if bool(v6_addr_value) != bool(v6_interface_value):
                raise BuildError("firewall %s interface %s must provide both ipv6_addr and ipv6_interface_range" %
                                 (name, ifname))
            v6_address = None
            v6_interface_network = None
            if v6_addr_value:
                try:
                    v6_address = ipaddress.ip_address(str(v6_addr_value))
                    v6_interface_network = ipaddress.ip_network(str(v6_interface_value), strict=False)
                except ValueError as exc:
                    raise BuildError("firewall %s interface %s has invalid IPv6 interface address/range: %s" %
                                     (name, ifname, exc))
                if (v6_address.version != 6 or v6_interface_network.version != 6 or
                        v6_address not in v6_interface_network):
                    raise BuildError("firewall %s interface %s ipv6_addr must be IPv6 inside ipv6_interface_range" %
                                     (name, ifname))
            v6_values = item.get("ipv6_range", [])
            if not isinstance(v6_values, list):
                raise BuildError("firewall %s interface %s ipv6_range must be a list" % (name, ifname))
            v6 = []
            for value in v6_values:
                try:
                    net6 = ipaddress.ip_network(str(value), strict=False)
                except ValueError as exc:
                    raise BuildError("firewall %s interface %s has invalid downstream IPv6 network: %s" %
                                     (name, ifname, exc))
                if net6.version != 6:
                    raise BuildError("firewall %s interface %s ipv6_range must contain IPv6 networks" %
                                     (name, ifname))
                v6.append(str(net6))
            iface = {"name": ifname, "role": role, "address": str(address),
                     "interface_range": str(interface_network), "networks": networks,
                     "ipv6_address": str(v6_address) if v6_address else None,
                     "ipv6_interface_range": str(v6_interface_network) if v6_interface_network else None,
                     "ipv6": v6}
            parsed.append(iface)
            roles[role].append(iface)
        if not roles["wan"]:
            raise BuildError("firewall %s must define a wan interface" % name)
        if not roles["lan"]:
            raise BuildError("firewall %s must define at least one lan interface" % name)
        for left in roles["dmz"]:
            for lan in roles["lan"]:
                for dmz_network in left["networks"]:
                    for lan_network in lan["networks"]:
                        if ipaddress.ip_network(dmz_network).overlaps(ipaddress.ip_network(lan_network)):
                            raise BuildError("firewall %s has overlapping LAN and DMZ downstream networks" % name)
                for dmz_network in left["ipv6"]:
                    for lan_network in lan["ipv6"]:
                        if ipaddress.ip_network(dmz_network).overlaps(ipaddress.ip_network(lan_network)):
                            raise BuildError("firewall %s has overlapping LAN and DMZ downstream IPv6 networks" % name)
        if vendor == "vyos":
            unknown_options = set(options) - set(("jump_rule",))
            if unknown_options:
                raise BuildError("firewall %s has unsupported VyOS options: %s" %
                                 (name, ", ".join(sorted(unknown_options))))
            jump = options.get("jump_rule", 500)
            if isinstance(jump, bool) or not isinstance(jump, int) or jump < 1 or jump > 999995:
                raise BuildError("firewall %s jump_rule must be between 1 and 999995" % name)
            config_file = None
        elif vendor in ("opnsense", "pfsense", "openwrt"):
            required_options = ("config_file", "openwrt_network_file") if vendor == "openwrt" else ("config_file",)
            unknown_options = set(options) - set(required_options)
            if unknown_options:
                raise BuildError("firewall %s has unsupported %s options: %s" %
                                 (name, vendor, ", ".join(sorted(unknown_options))))
            for key in required_options:
                if not isinstance(options.get(key), str) or not options[key].strip():
                    raise BuildError("firewall %s %s options must include %s" % (name, vendor, key))
            config_file = options["config_file"]
            jump = None
        else:
            jump = None
            config_file = None
            if options:
                raise BuildError("firewall %s type %s does not accept options" % (name, vendor))
        entry = {"name": name, "type": vendor, "interfaces": parsed,
                 "wan_interfaces": roles["wan"],
                 "lan_interfaces": roles["lan"],
                 "dmz_interfaces": roles["dmz"],
                 "inside_interfaces": roles["lan"],
                 "jump_rule": jump,
                 "config_file": config_file}
        if vendor == "openwrt":
            entry["openwrt_network_file"] = options["openwrt_network_file"]
        result.append(entry)
    return result


def resolve_config_interfaces(root, firewall, vendor):
    """Map YAML interfaces to the logical names in a pfSense/OPNsense export."""
    interfaces_node = root.find("interfaces")
    if interfaces_node is None:
        raise BuildError("%s config has no interfaces section" % vendor)
    configured = []
    for node in interfaces_node:
        if not isinstance(node.tag, str):
            continue
        address = (node.findtext("ipaddr") or "").strip()
        prefix = (node.findtext("subnet") or "").strip()
        try:
            interface = ipaddress.ip_interface("%s/%s" % (address, prefix))
        except ValueError:
            interface = None
        configured.append((node.tag, interface))

    used = set()
    for wanted in firewall["interfaces"]:
        address = ipaddress.ip_address(wanted["address"])
        network = ipaddress.ip_network(wanted["interface_range"])
        matches = [name for name, interface in configured
                   if interface is not None and interface.ip == address
                   and interface.network == network]
        if not matches and wanted["role"] == "wan":
            matches = [name for name, unused in configured if name == "wan"]
        if len(matches) != 1:
            reason = "no matching" if not matches else "ambiguous"
            raise BuildError("firewall %s interface %s (%s) has %s %s interface match" %
                             (firewall["name"], wanted["name"], wanted["role"], reason, vendor))
        name = matches[0]
        if name in used:
            raise BuildError("firewall %s maps multiple firewall.yaml interfaces to %s interface %s" %
                             (firewall["name"], vendor, name))
        used.add(name)
        wanted["config_name"] = name


def build_ruleset(hosts, firewall, log_all):
    inside_networks = firewall["inside_interfaces"]
    eligible = []
    all_hosts = []
    for host in hosts:
        containing = [iface for iface in inside_networks
                      if any(ipaddress.ip_address(host["ip"]) in ipaddress.ip_network(network)
                             for network in iface["networks"])]
        entry = dict(host, alias="h_" + _safe(host["name"]),
                     port_aliases=[], eligible=bool(containing))
        all_hosts.append(entry)
        if containing:
            eligible.append(entry)
    aliases = []
    for host in all_hosts:
        aliases.append({"name": host["alias"], "type": "host", "address": [host["ip"]],
                        "details": ["Host %s" % host["name"]], "description": "fwgen:host:%s" % _safe(host["name"])})
        grouped = {}
        for port in host["ports"]:
            grouped.setdefault(port["proto"], []).append(port)
        for proto, members in sorted(grouped.items()):
            alias_name = "p_%s_%s" % (_safe(host["name"]), proto)
            host["port_aliases"].append({"proto": proto, "name": alias_name})
            vals = [str(p["low"]) if p["low"] == p["high"] else "%s:%s" % (p["low"], p["high"]) for p in members]
            aliases.append({"name": alias_name, "type": "port", "address": vals,
                            "details": ["%s %s" % (host["name"], p["key"]) for p in members],
                            "description": "fwgen:ports:%s:%s" % (_safe(host["name"]), proto)})
    if firewall["type"] == "pfsense":
        all_network_interfaces = firewall["inside_interfaces"] + firewall["dmz_interfaces"]
        all_v4_networks = [network for iface in all_network_interfaces for network in iface["networks"]]
        all_v6_networks = [network for iface in all_network_interfaces for network in iface["ipv6"]]
        for iface in all_network_interfaces:
            if iface["networks"]:
                aliases.append({"name": "n_" + _safe(iface["name"]), "type": "network",
                                "address": iface["networks"],
                                "details": ["%s IPv4 downstream network %d" % (iface["name"], i)
                                            for i in range(1, len(iface["networks"]) + 1)],
                                "description": "fwgen:network:%s" % _safe(iface["name"])})
            for index, network in enumerate(iface["ipv6"]):
                aliases.append({"name": "n_%s_v6_%s" % (_safe(iface["name"]), index + 1),
                                "type": "network", "address": [network],
                                "details": ["%s IPv6" % iface["name"]],
                                "description": "fwgen:network:%s:ipv6" % _safe(iface["name"])})
            if iface["ipv6"]:
                aliases.append({"name": "n_%s_v6" % _safe(iface["name"]), "type": "network",
                                "address": iface["ipv6"],
                                "details": ["%s IPv6 downstream network %d" % (iface["name"], i)
                                            for i in range(1, len(iface["ipv6"]) + 1)],
                                "description": "fwgen:network:%s:ipv6_all" % _safe(iface["name"])})
        aliases.append({"name": "n_all_inside_v4", "type": "network", "address": all_v4_networks,
                        "details": ["Inside IPv4 network %d" % i for i in range(1, len(all_v4_networks) + 1)],
                        "description": "fwgen:network:all_inside_ipv4"})
        dmz_networks = [network for iface in firewall["dmz_interfaces"] for network in iface["networks"]]
        if dmz_networks:
            aliases.append({"name": "n_all_dmz_v4", "type": "network", "address": dmz_networks,
                            "details": ["DMZ IPv4 network %d" % i for i in range(1, len(dmz_networks) + 1)],
                            "description": "fwgen:network:all_dmz_ipv4"})
        lan_networks = [network for iface in firewall["inside_interfaces"] for network in iface["networks"]]
        if lan_networks:
            aliases.append({"name": "n_all_lan_v4", "type": "network", "address": lan_networks,
                            "details": ["LAN IPv4 network %d" % i for i in range(1, len(lan_networks) + 1)],
                            "description": "fwgen:network:all_lan_ipv4"})
        if all_v6_networks:
            aliases.append({"name": "n_all_inside_v6", "type": "network", "address": all_v6_networks,
                            "details": ["Inside IPv6 network %d" % i for i in range(1, len(all_v6_networks) + 1)],
                            "description": "fwgen:network:all_inside_ipv6"})
        dmz_ipv6_networks = [network for iface in firewall["dmz_interfaces"] for network in iface["ipv6"]]
        if dmz_ipv6_networks:
            aliases.append({"name": "n_all_dmz_v6", "type": "network", "address": dmz_ipv6_networks,
                            "details": ["DMZ IPv6 network %d" % i for i in range(1, len(dmz_ipv6_networks) + 1)],
                            "description": "fwgen:network:all_dmz_ipv6"})
        lan_ipv6_networks = [network for iface in firewall["inside_interfaces"] for network in iface["ipv6"]]
        if lan_ipv6_networks:
            aliases.append({"name": "n_all_lan_v6", "type": "network", "address": lan_ipv6_networks,
                            "details": ["LAN IPv6 network %d" % i for i in range(1, len(lan_ipv6_networks) + 1)],
                            "description": "fwgen:network:all_lan_ipv6"})
        aliases.append({"name": "p_fwgen_lan_wan_tcp", "type": "port",
                        "address": ["80", "443", "53", "853"],
                        "details": ["LAN to WAN TCP port %s" % port for port in (80, 443, 53, 853)],
                        "description": "fwgen:ports:lan_wan_tcp"})
        aliases.append({"name": "p_fwgen_lan_wan_udp", "type": "port",
                        "address": ["53", "123"],
                        "details": ["LAN to WAN UDP port %s" % port for port in (53, 123)],
                        "description": "fwgen:ports:lan_wan_udp"})
    rules = []
    wan = firewall["wan_interfaces"][0]["name"]
    if firewall["type"] == "pfsense":
        for wan_iface in firewall["wan_interfaces"]:
            wan = wan_iface["name"]
            for inside in firewall["inside_interfaces"] + firewall["dmz_interfaces"]:
                rules.append({"type": "block", "ipprotocol": "inet", "interface": wan,
                              "source": {"alias": "n_" + _safe(inside["name"])},
                              "destination": {"any": True}, "log": True,
                              "description": "fwgen:block-spoofed-lan-dmz-source:%s" % _safe(inside["name"])})
            if all_v6_networks:
                rules.append({"type": "block", "ipprotocol": "inet6", "interface": wan,
                              "source": {"alias": "n_all_inside_v6"}, "destination": {"any": True},
                              "log": True, "description": "fwgen:block-spoofed-lan-dmz-source-ipv6"})
            if firewall["dmz_interfaces"]:
                rules.append({"type": "block", "ipprotocol": "inet", "interface": wan,
                              "source": {"any": True}, "destination": {"alias": "n_all_dmz_v4"},
                              "log": True, "description": "fwgen:block-wan-to-dmz"})
                if any(iface["ipv6"] for iface in firewall["dmz_interfaces"]):
                    rules.append({"type": "block", "ipprotocol": "inet6", "interface": wan,
                                  "source": {"any": True}, "destination": {"alias": "n_all_dmz_v6"},
                                  "log": True, "description": "fwgen:block-wan-to-dmz-ipv6"})
            rules.append({"type": "pass", "ipprotocol": "inet", "protocol": "icmp", "icmp": True,
                          "interface": wan, "source": {"any": True},
                          "destination": {"alias": "n_all_lan_v4"},
                          "log": bool(log_all), "description": "fwgen:allow-wan-to-lan-icmp:%s" % _safe(wan)})
            if lan_ipv6_networks:
                rules.append({"type": "pass", "ipprotocol": "inet6", "protocol": "icmp",
                              "icmp": True, "icmp_type": "echoreq", "interface": wan,
                              "source": {"any": True}, "destination": {"alias": "n_all_lan_v6"},
                              "log": bool(log_all),
                              "description": "fwgen:allow-wan-to-lan-ipv6-ping:%s" % _safe(wan)})
            rules.append({"type": "block", "ipprotocol": "inet6", "interface": wan,
                          "source": {"any": True}, "destination": {"any": True},
                          "log": True, "description": "fwgen:block:ipv6"})
            for host in eligible:
                for port in host["port_aliases"]:
                    rules.append({"type": "pass", "ipprotocol": "inet", "protocol": port["proto"],
                                  "interface": wan, "source": {"any": True},
                                  "destination": {"alias": host["alias"], "port": port["name"]},
                                  "log": bool(log_all), "description": "fwgen:allow:%s:%s" % (_safe(host["name"]), port["proto"])})
            rules.append({"type": "block", "ipprotocol": "inet", "interface": wan,
                          "source": {"any": True}, "destination": {"any": True},
                          "log": True, "description": "fwgen:default-deny-wan:%s" % _safe(wan)})
        for source in firewall["inside_interfaces"]:
            source_alias = "n_" + _safe(source["name"])
            for destination in firewall["inside_interfaces"] + firewall["dmz_interfaces"]:
                destination_alias = "n_" + _safe(destination["name"])
                destination_role = "dmz" if destination["role"] == "dmz" else "lan"
                rules.append({"type": "pass", "ipprotocol": "inet", "interface": source["name"],
                              "source": {"alias": source_alias}, "destination": {"alias": destination_alias},
                              "log": bool(log_all), "description": "fwgen:allow-lan-to-%s:%s:%s" %
                              (destination_role, _safe(source["name"]), _safe(destination["name"]))})
                for source_index, unused in enumerate(source["ipv6"], 1):
                    for destination_index, unused in enumerate(destination["ipv6"], 1):
                        rules.append({"type": "pass", "ipprotocol": "inet6", "interface": source["name"],
                                      "source": {"alias": "n_%s_v6_%s" % (_safe(source["name"]), source_index)},
                                      "destination": {"alias": "n_%s_v6_%s" % (_safe(destination["name"]), destination_index)},
                                      "log": bool(log_all), "description": "fwgen:allow-lan-to-%s-ipv6:%s:%s" %
                                      (destination_role, _safe(source["name"]), _safe(destination["name"]))})
            for protocol, port_alias in (("tcp", "p_fwgen_lan_wan_tcp"),
                                         ("udp", "p_fwgen_lan_wan_udp")):
                rules.append({"type": "pass", "ipprotocol": "inet", "protocol": protocol,
                              "interface": source["name"], "source": {"alias": source_alias},
                              "destination": {"any": True, "port": port_alias},
                              "log": bool(log_all), "description": "fwgen:allow-lan-wan-%s" % protocol})
                if source["ipv6"]:
                    rules.append({"type": "pass", "ipprotocol": "inet6", "protocol": protocol,
                                  "interface": source["name"],
                                  "source": {"alias": "n_%s_v6" % _safe(source["name"])},
                                  "destination": {"any": True, "port": port_alias},
                                  "log": bool(log_all),
                                  "description": "fwgen:allow-lan-wan-ipv6-%s" % protocol})
            rules.append({"type": "pass", "ipprotocol": "inet", "protocol": "icmp", "icmp": True,
                          "interface": source["name"], "source": {"alias": source_alias},
                          "destination": {"any": True}, "log": bool(log_all),
                          "description": "fwgen:allow-lan-wan-icmp"})
            if source["ipv6"]:
                rules.append({"type": "pass", "ipprotocol": "inet6", "protocol": "ipv6-icmp",
                              "interface": source["name"],
                              "source": {"alias": "n_%s_v6" % _safe(source["name"])},
                              "destination": {"any": True}, "log": bool(log_all),
                              "description": "fwgen:allow-lan-wan-ipv6-icmp"})
            rules.append({"type": "block", "ipprotocol": "inet", "interface": source["name"],
                          "source": {"any": True}, "destination": {"any": True},
                          "log": True, "description": "fwgen:default-deny-lan:%s" % _safe(source["name"])})
            rules.append({"type": "block", "ipprotocol": "inet6", "interface": source["name"],
                          "source": {"any": True}, "destination": {"any": True},
                          "log": True, "description": "fwgen:default-deny-lan-ipv6:%s" % _safe(source["name"])})
        for source in firewall["dmz_interfaces"]:
            rules.append({"type": "pass", "ipprotocol": "inet", "interface": source["name"],
                          "source": {"alias": "n_" + _safe(source["name"])},
                          "destination": {"alias": "n_all_lan_v4"},
                          "log": bool(log_all), "description": "fwgen:allow-dmz-to-lan:%s" % _safe(source["name"])})
            if source["ipv6"] and any(iface["ipv6"] for iface in firewall["inside_interfaces"]):
                rules.append({"type": "pass", "ipprotocol": "inet6", "interface": source["name"],
                              "source": {"alias": "n_%s_v6" % _safe(source["name"])},
                              "destination": {"alias": "n_all_lan_v6"},
                              "log": bool(log_all), "description": "fwgen:allow-dmz-to-lan-ipv6:%s" % _safe(source["name"])})
            rules.append({"type": "block", "ipprotocol": "inet", "interface": source["name"],
                          "source": {"any": True}, "destination": {"any": True},
                          "log": True, "description": "fwgen:default-deny-dmz:%s" % _safe(source["name"])})
            rules.append({"type": "block", "ipprotocol": "inet6", "interface": source["name"],
                          "source": {"any": True}, "destination": {"any": True},
                          "log": True, "description": "fwgen:default-deny-dmz-ipv6:%s" % _safe(source["name"])})
    return {"hosts": all_hosts, "eligible_hosts": eligible, "aliases": aliases, "rules": rules, "wan": wan,
            "log_all": log_all}


def _safe(value):
    name = "".join(char if re.match(r"[A-Za-z0-9_]", char) else "_x%02x" % ord(char)
                   for char in value)
    if not name or name[0].isdigit():
        name = "x_" + name
    if len(name) > 18:
        name = name[:9] + "_" + hashlib.sha1(value.encode("utf-8")).hexdigest()[:8]
    return name


def render_template_text(template_dir, context, suffix, kind=None):
    """Render ordered constructs without requiring intermediate output files."""
    names = [name for name in os.listdir(template_dir)
             if re.match(r"^\d+_.+\.%s\.j2$" % re.escape(suffix), name)
             and (kind is None or name.split("_", 1)[1].startswith(kind + "."))]
    names.sort(key=lambda name: (int(name.split("_", 1)[0]), name))
    if not names:
        raise BuildError("no numbered .%s.j2 templates found in %s" % (suffix, template_dir))
    env = Environment(loader=FileSystemLoader(template_dir), undefined=StrictUndefined,
                      trim_blocks=True, lstrip_blocks=True, keep_trailing_newline=True,
                      autoescape=select_autoescape(enabled_extensions=("j2xml",), default=False))
    # XML templates have an XML target suffix, so enable escaping explicitly for them.
    if suffix == "xml":
        env.autoescape = lambda template_name: True
    chunks = [env.get_template(name).render(**context).rstrip() for name in names]
    return "\n".join(chunk for chunk in chunks if chunk) + "\n"


def render_templates(template_dir, output_path, context, suffix, kind=None):
    text = render_template_text(template_dir, context, suffix, kind)
    with open(output_path, "w", newline="\n") as output_file:
        output_file.write(text)


def unique_run_dir(base):
    if not os.path.isdir(base):
        os.makedirs(base)
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    candidate = os.path.join(base, stamp)
    suffix = 1
    while os.path.exists(candidate):
        candidate = os.path.join(base, "%s_%d" % (stamp, suffix))
        suffix += 1
    os.makedirs(candidate)
    return candidate
