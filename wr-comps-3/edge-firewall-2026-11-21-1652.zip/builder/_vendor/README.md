# Bundled builder dependencies

These runtime sources are shipped with the project so `build_firewall.py`
requires only Python 3.8 or later. No installation, download, or compiled
extension is needed. The builder prepends this directory to its import path.
PyYAML and MarkupSafe use their upstream pure-Python fallbacks; optional C
extensions are not shipped. Jinja's optional internationalization extension
and its Babel dependency are not used by the builder.

Unmodified runtime Python sources and licenses were extracted from these PyPI
source releases. Archive SHA256 values were verified before extraction:

| Package | Version | Source archive SHA256 | License |
| --- | --- | --- | --- |
| [PyYAML](https://pypi.org/project/PyYAML/6.0.2/) | 6.0.2 | `d584d9ec91ad65861cc08d42e834324ef890a082e591037abe114850ff7bbc3e` | yaml-LICENSE |
| [Jinja2](https://pypi.org/project/Jinja2/3.1.6/) | 3.1.6 | `0137fb05990d35f1275a587e9aee6d56da821fc83491a0fb838183be43f66d6d` | jinja2-LICENSE.txt |
| [MarkupSafe](https://pypi.org/project/MarkupSafe/2.1.5/) | 2.1.5 | `d283d37a890ba4c1ae73ffadf8046435c76e7bc2247bbb63c00bd1a709c6544b` | markupsafe-LICENSE.rst |

Keep this directory, its license files, and the runtime templates when copying
the project. `requirements-build.txt` is informational; it installs nothing.
